#include <stdlib.h>
#include <string>     /* strlen, strcpy */
#include <errno.h>
#include <assert.h>

#include <cstdio>
#include <ctype.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <time.h>
#include <sstream>
#include <fstream>
#include <iostream>

#include "msdp.h"

/*
 * model sensor data provider (msdp)
 * sensor data for the alarming protocol
 */

using namespace std;

FILE* data_file;
int output_pipe;

ifstream inputFile;

void print_msdp_sensor_packet(msdp_sensor_packet sp) {
	std::cout << "time: " << sp.timestamp << " chan 1: " << sp.chan1<< " chan 2: " << sp.chan2<< " chan 3: " << sp.chan3<< " chan 4: " << sp.chan4 << std::endl;
}

int parse_line(string line, msdp_sensor_packet &sp) {
	float floatTimeIndex;
	int successfully_read = sscanf(line.c_str(), "%f %f %f %f", &floatTimeIndex, &sp.chan1, &sp.chan2, &sp.chan3);

	sp.timestamp = (uint64_t) (floatTimeIndex * 1000.0f);
	sp.chan1 = sp.chan1 - 35.4229;
	sp.chan2 = sp.chan2 - 35.7737;
	sp.chan3 = sp.chan3 - 26.4221;
	sp.chan4 = 0.0;
	return successfully_read;
}

/*
 * To be called by parser when new sensor data is available.
 */
void process_data_file()
{
	uint64_t current_time;
	string line;
	msdp_sensor_packet sp;
	long long sleep_sum = 0;
	int samples = 0;

	//calibrate sleep
	long long starting = getCurrentMS();

	//read the first sample and submit
	getline( inputFile, line );
	parse_line(line, sp);
	print_msdp_sensor_packet(sp);
	write(output_pipe, (const char *) &sp, sizeof(sp));

	long long now;

	//now the rest of the file
	while (!inputFile.eof()) {
		getline( inputFile, line );
		int successfully_read = parse_line(line, sp);

		if (successfully_read != 4 ) {
			std::cerr << "error while reading line: " << line << std::endl;
			continue;
		}
		//sleep
		//std::cerr << (sp.timestamp - current_time) << " ... ";
		

		//usleep(u_sleep_time * factor);
		now = getCurrentMS();
		
		//std::cout << "starting: " << starting <<  " now: " << now << " sleeping: " << (starting + sp.timestamp - now) << std::endl;
		if ((starting + sp.timestamp - now) < 0 || (starting + sp.timestamp - now) > 1000) 
			std::cout << "to slow" << std::endl;
		else {
		//	std::cout << "sleep:" << starting + sp.timestamp - now << std::endl;
			msleep(starting + sp.timestamp - now);
		}
		//long long after_sleep = getCurrentMS();
		//sleep_sum += (after_sleep - before_sleep);
		//samples++;


		//submit
		write(output_pipe, (const char *) &sp, sizeof(sp));
	}

//	std::cerr << "sleep_sum: " << sleep_sum << " samples: " << samples << " average_sleep: " << (sleep_sum * 1.0) / (samples * 1.0) << " factor: " << factor << std::endl;
}


/*
 * Entry point of plugin, called by the parser at startup time.
 * If the return value is != 0, the plugin is
 */
void init(char* file_name)
{
	std::cout << "msdp loading ..." << std::endl;

	/* open named pipe */
	int ret_val = mkfifo(OUTPUT_PIPE, 0666);
	if ((ret_val == -1) && (errno != EEXIST)) {
		perror("Error creating the named pipe");
	}

	output_pipe = open(OUTPUT_PIPE, O_WRONLY | O_NONBLOCK);

	inputFile.open(file_name);

	//skip the header
	string line;
	for (int i = 1; i <= 5; i++) {
		getline( inputFile, line );
	}

	/* Everything OK */
	printf("rsdp_plugin loading finished\n");
}

int msleep(unsigned long milisec)
{
	struct timespec req={0};
	time_t sec=(int)(milisec/1000);
	milisec=milisec-(sec*1000);
	req.tv_sec=sec;
	req.tv_nsec=milisec*1000000L;
	while(nanosleep(&req,&req)==-1)
		continue;
	return 1;
}

long long getCurrentMS() {
	struct timeval tv;
	struct timezone tz;
	gettimeofday(&tv, &tz);
	long long now_ms = tv.tv_sec;
	now_ms *= 1000;
	now_ms += (tv.tv_usec / 1000);
	return now_ms;
}
