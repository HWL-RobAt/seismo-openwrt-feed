#ifndef MSDP_H
#define MSDP_H

#include <stdint.h>
#include <sys/time.h>

#define OUTPUT_PIPE "/tmp/pipe_msdp"
#define MAX_BUF_SIZE 255

typedef struct msdp_sensor_packet {
	uint64_t timestamp; 	// timestamp in usecs

	float chan1;
	float chan2;
	float chan3;
	float chan4;
} msdp_sensor_packet;

void process_data_file();
void init(char*);
int msleep(unsigned long milisec);
long long getCurrentMS();
#endif
