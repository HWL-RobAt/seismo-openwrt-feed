#include "msdp.h"
#include <stdio.h>
#include <stdlib.h>
#include <sys/time.h>
#include <ctime>
#include <iostream>



int main(int argc, char* argv[]) {
	if (argc < 2) {
		fprintf(stderr,"Bitte geben sie als Parameter eine Eingabedatei an.\n");
		exit(-1);
	} else {
		/* check the filename */
		FILE* input = fopen(argv[1], "r");
		if (input == 0) {
			fprintf(stderr, "Fehler: Konnte Datei %s nicht zum lesen oeffnen.\n", argv[1]);
			exit(-1);
		}
		fclose(input);

	}

	if ( argc == 3 ) {

		std::cerr << "unix starttime given." << std::endl;

		long long start_time_ms = atoll(argv[2]);
		long long now_ms = getCurrentMS();
		long long sleep_time_ms = start_time_ms - now_ms;
		std::cerr << "now is: " << now_ms << " should start in: " << start_time_ms <<  " difference is: " << sleep_time_ms << std::endl;
		if (sleep_time_ms < 0) {
			std::cerr << "given time was already passed. starting now." << std::endl;
		} else {
			std::cerr << "sleeping for " << sleep_time_ms << "ms" << std::endl;
			msleep (sleep_time_ms);
		}
	}

	long long startTime = getCurrentMS();
	std::cerr << "starting to send data at: " << startTime << std::endl;
	init(argv[1]);
	process_data_file();
	long long endTime = getCurrentMS();
	std::cerr << "finished at: " << endTime << " after a runtime of: " << (endTime - startTime) << " ms" << std::endl;
	return 0;
}
