/*SX*//** @file
 *  Generated file, find templates in SX folders
 */

#ifndef MANAGINGENTITY_UP_H_INCLUDED
#define MANAGINGENTITY_UP_H_INCLUDED
#ifndef _MANAGINGENTITY_H_
#define _MANAGINGENTITY_H_

#include "blockClass_Node.h"

#endif
#endif

#ifndef MANAGINGENTITY_H_INCLUDED
#define MANAGINGENTITY_H_INCLUDED

#include "RTDS_SDLPROCESS.h"

/**@brief The process ManagingEntity 
 */
class ManagingEntity : public RTDS::SDLProcess {
public:

    /**@brief Constructor.
     */
    ManagingEntity(RTDS::Logger& logger = RTDS::emptyLogger);

    /**@brief Lifeline of this process.
     */
    virtual int main();

private:
    
};

#ifndef _MANAGINGENTITY_H_
#define _MANAGINGENTITY_H_

#include "blockClass_Node.h"

#endif

#endif
