/**
 * @file define.h
 * @date Sep 8, 2008
 * @author ron
 *
 * @brief
 */

#ifndef DEFINE_H_
#define DEFINE_H_

#define RECEIVE_PORT 50000
#define SEND_PORT 50001


#endif /* DEFINE_H_ */
