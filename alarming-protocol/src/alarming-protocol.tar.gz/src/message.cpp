#include "message.h"

/***************** MESSAGE FUNCTIONS **********************************/

Message::Message( const std::string& data, IPAddress from, IPAddress to )
:	content( data ),
	sender( from ),
	receiver( to )
	{}


// member functions
//unsigned int Message::getHops() const
//{
//	static Randint random( "Random Hops", 40, 50 );
//	return static_cast< unsigned int >( random.sample() );
//}

// required implementations of pure virtual functions
/*inline bool Message::isUnicast() const { return receiver != 0; }

inline ProtocolNode* Message::getSource() const { return sender; }

inline ProtocolNode* Message::getDestination() const { return receiver; }

inline ProtocolNode* Message::getSendNode() const { return sender; }

inline ProtocolNode* Message::getReceiveNode() const { return receiver; }

inline SimTime Message::getTransmissionDuration() const { return 1;}

inline std::string Message::toString() { return content; }*/

