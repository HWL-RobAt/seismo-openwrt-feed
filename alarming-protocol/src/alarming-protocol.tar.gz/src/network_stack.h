/**
 * @file network_stack.h
 * @date Aug 17, 2008
 * @author Ronald Kluth
 *
 * @brief Declaration of class NetworkStack
 */

#ifndef NETWORKSTACK_H_
#define NETWORKSTACK_H_

#include <iostream>
#include <string>

#include <boost/bind.hpp>
#include <boost/shared_ptr.hpp>
#include <boost/enable_shared_from_this.hpp>
#include <boost/asio.hpp>

//#include "te_receiver.h" // is in ../boost_substitute
#include "RTDS_MSGQUEUE.h"
#include "message.h"
#include "send_connection.h"
#include "receive_connection.h"

using boost::asio::ip::tcp;

/**
 * @class NetworkStack
 * @brief This class presents a simple network interface for sending and
 * receiving data by using SendConnection and ReceiveConnection objects
 */
class NetworkStack
{
private:
	/// reference to the io_service, needed for asynchronous operations
	boost::asio::io_service& io_service;
	RTDS::MessageQueueT<Message*>::qWriter& receiveQueue; ///< the corresponding te_receiver owned by block_te
	tcp::acceptor acceptor; ///< local interface for accepting connections
	tcp::endpoint localEndpoint; ///< local tcp endpoint, used by acceptor

public:
	/// constructor with io_service reference for asynchronous operations
	NetworkStack( boost::asio::io_service& io_service, RTDS::MessageQueueT<Message*>::qWriter& writer,
				const unsigned short sendPort, const unsigned short receivePort );
	/// destructor
	~NetworkStack();

	//void inputData( Message& message );

	/**
	 * @brief asynchronously establish a tcp connection to the given peer and
	 * pass the message to a SendConnection object, which will try to transmit
	 */
	void connectAndSend( const std::string& peerAddress,
						 //const unsigned short peerPort,
						 const std::string& message );

	/**
	 * @brief asynchronously listen for incoming connections by creating
	 * a new ReceiveConnection object and calling async_accept() with it
	 */
	void listenToPort( const unsigned short listenPort );
	/**
	 * @brief handler that is called when connection is established, requests
	 * an asyncRead() from newConnection and starts new listening operation
	 */
	void handleAccept( const boost::system::error_code& error,
					   ReceiveConnection::pointer newConnection,
					   const unsigned short listenPort );
	/**
	 * @brief handler for received messages, puts the message into the
	 * given receiver's receiveQueue
	 */
	void receivedMessage( const std::string& msg, const std::string& fromIP,
			const std::string& ownIP );
};

#endif /*NETWORKSTACK_H_*/
