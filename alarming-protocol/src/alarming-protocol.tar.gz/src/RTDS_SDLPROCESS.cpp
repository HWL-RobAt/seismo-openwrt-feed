
#include "RTDS_SDLPROCESS.h"
#include <string>
#include <list>
#include <boost/thread/thread.hpp>
#include <boost/bind.hpp>

namespace RTDS {

using namespace boost;
  
boost::asio::io_service SDLProcess::ioService;

/* ************************************************************ SDL process */
/* PUBLIC ***************************************************************** */
SDLProcess::SDLProcess(Logger& _logger)
    : cover(0),
    offspring(0),
    parent(0),
    msgQueue(),
    saveQueue(),
    logger(_logger),
    sequenceNumber(0),
    sdlState(0),
    RTDS_sdlStatePrev(0),
    RTDS_currentContext(this)
{}

void SDLProcess::activate() {
    isRunning = new asio::io_service::work(ioService);
    thread t(bind(&SDLProcess::main, this));
    thread _workThread_t(bind(&asio::io_service::run, &ioService));
}
  
/* PROTECTED ************************************************************** */
void SDLProcess::msgQSend(MessageQueue::qWriter* receiver, MsgHeader* message) {
    receiver->put(message);
}

MsgHeader* SDLProcess::msgQRead() {
    return msgQueue.reader->get();
}

SDLTimer& SDLProcess::getTimerByID(int id, const char* ignoredTimerName) {
    std::list<SDLTimer*>::iterator iter = timer.begin();

    /* try to find the required timer in the list */
    while (iter != timer.end()) {
	if ((*iter)->getMessageID() == id)
	    return **iter; /* success */
	++iter;
    }

    /* unsuccessful */
    timer.push_front(new SDLTimer(*this, id));

    return *timer.front();
}

void SDLProcess::initProcess(SDLProcess* process, SDLBlock* cover, MessageQueue::qWriter* parent,
                 MessageQueue::qWriter*& offspring)
{
    process->cover = cover;
    process->parent = parent;
    offspring = process->msgQueue.writer;
}
}
