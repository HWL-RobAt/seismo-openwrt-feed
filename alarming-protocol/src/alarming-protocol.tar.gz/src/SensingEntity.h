/*SX*//** @file
 *  Generated file, find templates in SX folders
 */

#ifndef SENSINGENTITY_UP_H_INCLUDED
#define SENSINGENTITY_UP_H_INCLUDED
#ifndef _SENSINGENTITY_H_
#define _SENSINGENTITY_H_

#include "blockClass_Node.h"

#endif
#endif

#ifndef SENSINGENTITY_H_INCLUDED
#define SENSINGENTITY_H_INCLUDED

#include "RTDS_SDLPROCESS.h"

/**@brief The process SensingEntity 
 */
class SensingEntity : public RTDS::SDLProcess {
public:

    /**@brief Constructor.
     */
    SensingEntity(RTDS::Logger& logger = RTDS::emptyLogger);

    /**@brief Lifeline of this process.
     */
    virtual int main();

private:
    
};

#ifndef _SENSINGENTITY_H_
#define _SENSINGENTITY_H_

#include "blockClass_Node.h"

#endif

#endif
