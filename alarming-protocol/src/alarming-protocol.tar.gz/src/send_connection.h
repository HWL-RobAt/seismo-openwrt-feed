/**
 * @file SendConnection.h
 * @date Aug 17, 2008
 * @author Ronald Kluth
 *
 * @brief Declaration of class SendConnection
 */

#ifndef SEND_CONNECTION_H_
#define SEND_CONNECTION_H_

#include <boost/asio.hpp>
#include <boost/enable_shared_from_this.hpp>

class NetworkStack;

/**
 * @class SendConnection
 * @brief objects of this type represent one side of a tcp connection,
 * which in this case has sending capability, but no reception
 */
class SendConnection:
	public boost::enable_shared_from_this< SendConnection >
{
private:
	// data describing one connection endpoint
	NetworkStack& networkStack; ///< creator network interface
	boost::asio::ip::tcp::socket tcpSocket; ///< the connected local socket
	boost::asio::streambuf sendBuffer; ///< buffer for transmission

public:
	/// shared pointers are the only way to access objects of this class
	typedef boost::shared_ptr< SendConnection > pointer;

	/// creation with shared pointer
	static pointer create( boost::asio::io_service& io_service,
						   NetworkStack& ns, const std::string& message );

	/// attempt to connect to the given peer endpoint, returns immediately
	void asyncConnect( boost::asio::ip::tcp::endpoint peerEndpoint );
	/**
	 * @brief handler function, called when connection is established;
	 * sends the given message by calling asyncWrite()
	 */
	void handleConnect( const boost::system::error_code& error );

	/// attempt to send the given message to the connected endpoint
	void asyncWrite();
	/**
	 * @brief asynchronous handler function, called when asyncWrite()
	 * has finished, which either mean successful transmission or error
	 */
	void handleWrite( const boost::system::error_code& error,
					  std::size_t bytes_transferred );

	/// get a reference to the local (outgoing) socket object
	boost::asio::ip::tcp::socket& socket();

	/// destructor
	~SendConnection();
private:
	/// private constructor to require the use of create()
	SendConnection( boost::asio::io_service& io_service, NetworkStack& ns,
					const std::string& message );
};

#endif /* SEND_CONNECTION_H_ */
