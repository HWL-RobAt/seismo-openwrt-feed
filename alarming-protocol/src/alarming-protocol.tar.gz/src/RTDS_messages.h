/*SX*/
#ifndef _RTDS_MESSAGES_H_
#define _RTDS_MESSAGES_H_



#include "SingleNode.h"
#include "blockClass_Node.h"

/* DATA TYPES FOR MESSAGES */
typedef struct RTDS_Message_TE_TE_LS_Ala_data
{
	IPAddress	param1;
	IPAddress	param2;
	tDateTime	param3;
	EventID	param4;
	trig_vec	param5;
} RTDS_Message_TE_TE_LS_Ala_data;

typedef struct RTDS_TN_SN_ConfigureSetKeyValue_data
{
	IPAddress	param1;
	tDateTime	param2;
	key_vec	param3;
} RTDS_TN_SN_ConfigureSetKeyValue_data;

typedef struct RTDS_LN_SN_PrimaryLN_data
{
	IPAddress	param1;
	tDateTime	param2;
	IPAddress	param3;
	GroupID	param4;
} RTDS_LN_SN_PrimaryLN_data;

typedef struct RTDS_Message_TE_TE_TS_ALS_data
{
	IPAddress	param1;
	IPAddress	param2;
	tDateTime	param3;
	ip_vec	param4;
	GroupID	param5;
} RTDS_Message_TE_TE_TS_ALS_data;

typedef struct RTDS_Message_TE_TE_SL_Sum_data
{
	IPAddress	param1;
	IPAddress	param2;
	tDateTime	param3;
	tDateTime	param4;
	tDateTime	param5;
	tDateTime	param6;
	tSensorAcceleration	param7;
	tSensorVelocity	param8;
	tSensorDisplacement	param9;
	tSensorAccelerationAverage	param10;
	double	param11;
	double	param12;
	double	param13;
	double	param14;
} RTDS_Message_TE_TE_SL_Sum_data;

typedef struct RTDS_SN_LN_PositionChange_data
{
	IPAddress	param1;
	tDateTime	param2;
	tGeographicCoordinate	param3;
	tGeographicCoordinate	param4;
} RTDS_SN_LN_PositionChange_data;

typedef struct RTDS_Message_TE_TE_TS_Use_data
{
	IPAddress	param1;
	IPAddress	param2;
	tDateTime	param3;
	tDateTime	param4;
	tDateTime	param5;
	std::string	param6;
} RTDS_Message_TE_TE_TS_Use_data;

typedef struct RTDS_Message_TE_TE_LS_Sec_data
{
	IPAddress	param1;
	IPAddress	param2;
	tDateTime	param3;
	IPAddress	param4;
	GroupID	param5;
} RTDS_Message_TE_TE_LS_Sec_data;

typedef struct RTDS_SN_LN_Description_data
{
	IPAddress	param1;
	tDateTime	param2;
	tDateTime	param3;
	tWaveType	param4;
	tSensorAcceleration	param5;
	tSensorVelocity	param6;
	tSensorDisplacement	param7;
	tSensorAccelerationAverage	param8;
	double	param9;
	double	param10;
	double	param11;
	double	param12;
} RTDS_SN_LN_Description_data;

typedef struct RTDS_Message_TE_TE_LS_Pri_data
{
	IPAddress	param1;
	IPAddress	param2;
	tDateTime	param3;
	IPAddress	param4;
	GroupID	param5;
} RTDS_Message_TE_TE_LS_Pri_data;

typedef struct RTDS_StartLN_data
{
	IPAddress	param1;
	ip_vec	param2;
	GroupID	param3;
} RTDS_StartLN_data;

typedef struct RTDS_Message_TE_TE_SL_PoC_data
{
	IPAddress	param1;
	IPAddress	param2;
	tDateTime	param3;
	tGeographicCoordinate	param4;
	tGeographicCoordinate	param5;
} RTDS_Message_TE_TE_SL_PoC_data;

typedef struct RTDS_SN_LN_Summary_data
{
	IPAddress	param1;
	tDateTime	param2;
	tDateTime	param3;
	tDateTime	param4;
	tDateTime	param5;
	tSensorAcceleration	param6;
	tSensorVelocity	param7;
	tSensorDisplacement	param8;
	tSensorAccelerationAverage	param9;
	double	param10;
	double	param11;
	double	param12;
	double	param13;
} RTDS_SN_LN_Summary_data;

typedef struct RTDS_LNsInNetwork_data
{
	ip_vec	param1;
} RTDS_LNsInNetwork_data;

typedef struct RTDS_Message_TE_TE_LL_Det_data
{
	IPAddress	param1;
	IPAddress	param2;
	tDateTime	param3;
	EventID	param4;
	trig_vec	param5;
	inop_vec	param6;
} RTDS_Message_TE_TE_LL_Det_data;

typedef struct RTDS_LN_SN_FalseAlarm_data
{
	IPAddress	param1;
	tDateTime	param2;
	tDateTime	param3;
} RTDS_LN_SN_FalseAlarm_data;

typedef struct RTDS_LN_LN_Idle_data
{
	IPAddress	param1;
	tDateTime	param2;
	ip_vec	param3;
	inop_vec	param4;
	tSensorAccelerationAverage	param5;
} RTDS_LN_LN_Idle_data;

typedef struct RTDS_LN_SN_Describe_data
{
	IPAddress	param1;
	tDateTime	param2;
	EventID	param3;
} RTDS_LN_SN_Describe_data;

typedef struct RTDS_nextRecord_data
{
	tSensorData	param1;
} RTDS_nextRecord_data;

typedef struct RTDS_TN_SN_AssignLeadershipForGroup_data
{
	IPAddress	param1;
	tDateTime	param2;
	ip_vec	param3;
	GroupID	param4;
} RTDS_TN_SN_AssignLeadershipForGroup_data;

typedef struct RTDS_Message_TE_TE_TS_Ask_data
{
	IPAddress	param1;
	IPAddress	param2;
	tDateTime	param3;
} RTDS_Message_TE_TE_TS_Ask_data;

typedef struct RTDS_LN_EN_Alarm_data
{
	IPAddress	param1;
	tDateTime	param2;
	EventID	param3;
	trig_vec	param4;
} RTDS_LN_EN_Alarm_data;

typedef struct RTDS_Message_TE_TE_TL_ALN_data
{
	IPAddress	param1;
	IPAddress	param2;
	tDateTime	param3;
	ip_vec	param4;
} RTDS_Message_TE_TE_TL_ALN_data;

typedef struct RTDS_Message_TE_TE_SL_Idl_data
{
	IPAddress	param1;
	IPAddress	param2;
	tDateTime	param3;
	tSensorAccelerationAverage	param4;
	double	param5;
	double	param6;
} RTDS_Message_TE_TE_SL_Idl_data;

typedef struct RTDS_TN_SN_StartMessageLogging_data
{
	IPAddress	param1;
	tDateTime	param2;
	tDateTime	param3;
} RTDS_TN_SN_StartMessageLogging_data;

typedef struct RTDS_GNsInNetwork_data
{
	ip_vec	param1;
} RTDS_GNsInNetwork_data;

typedef struct RTDS_Message_TE_TE_LL_Des_data
{
	IPAddress	param1;
	IPAddress	param2;
	tDateTime	param3;
	EventID	param4;
} RTDS_Message_TE_TE_LL_Des_data;

typedef struct RTDS_TN_SN_CloseMessageLogfile_data
{
	IPAddress	param1;
	tDateTime	param2;
	tDateTime	param3;
} RTDS_TN_SN_CloseMessageLogfile_data;

typedef struct RTDS_Message_TE_TE_TL_AGN_data
{
	IPAddress	param1;
	IPAddress	param2;
	tDateTime	param3;
	ip_vec	param4;
} RTDS_Message_TE_TE_TL_AGN_data;

typedef struct RTDS_Message_TE_TE_LS_Des_data
{
	IPAddress	param1;
	IPAddress	param2;
	tDateTime	param3;
	EventID	param4;
} RTDS_Message_TE_TE_LS_Des_data;

typedef struct RTDS_Message_TE_TE_LE_Sum_data
{
	IPAddress	param1;
	IPAddress	param2;
	tDateTime	param3;
	EventID	param4;
	ip_vec	param5;
	inop_vec	param6;
	status_vec	param7;
	double	param8;
} RTDS_Message_TE_TE_LE_Sum_data;

typedef struct RTDS_SN_LN_Detection_data
{
	IPAddress	param1;
	tDateTime	param2;
	tDateTime	param3;
	tSensorAcceleration	param4;
	tSensorVelocity	param5;
	tSensorDisplacement	param6;
	tSensorAccelerationAverage	param7;
	double	param8;
	double	param9;
} RTDS_SN_LN_Detection_data;

typedef struct RTDS_LN_LN_Description_data
{
	IPAddress	param1;
	tDateTime	param2;
	EventID	param3;
} RTDS_LN_LN_Description_data;

typedef struct RTDS_TN_SN_AskGroupId_data
{
	IPAddress	param1;
	tDateTime	param2;
} RTDS_TN_SN_AskGroupId_data;

typedef struct RTDS_TN_LN_AssignLNsInNetwork_data
{
	IPAddress	param1;
	tDateTime	param2;
	ip_vec	param3;
} RTDS_TN_LN_AssignLNsInNetwork_data;

typedef struct RTDS_LN_EN_Summary_data
{
	IPAddress	param1;
	tDateTime	param2;
	EventID	param3;
	ip_vec	param4;
	inop_vec	param5;
	status_vec	param6;
	double	param7;
} RTDS_LN_EN_Summary_data;

typedef struct RTDS_Message_TE_TE_LL_Idl_data
{
	IPAddress	param1;
	IPAddress	param2;
	tDateTime	param3;
	ip_vec	param4;
	inop_vec	param5;
} RTDS_Message_TE_TE_LL_Idl_data;

typedef struct RTDS_LN_SN_SecondaryLN_data
{
	IPAddress	param1;
	tDateTime	param2;
	IPAddress	param3;
	GroupID	param4;
} RTDS_LN_SN_SecondaryLN_data;

typedef struct RTDS_SendPShared_data
{
	tSharedData*	param1;
} RTDS_SendPShared_data;

typedef struct RTDS_LN_LN_Detection_data
{
	IPAddress	param1;
	tDateTime	param2;
	EventID	param3;
	trig_vec	param4;
	inop_vec	param5;
	tSensorAccelerationAverage	param6;
} RTDS_LN_LN_Detection_data;

typedef struct RTDS_TN_SN_UseMSDP_data
{
	IPAddress	param1;
	tDateTime	param2;
	tDateTime	param3;
	tDateTime	param4;
	std::string	param5;
} RTDS_TN_SN_UseMSDP_data;

typedef struct RTDS_LN_SN_Summarise_data
{
	IPAddress	param1;
	tDateTime	param2;
	EventID	param3;
} RTDS_LN_SN_Summarise_data;

typedef struct RTDS_TN_LN_AssignGNsInNetwork_data
{
	IPAddress	param1;
	tDateTime	param2;
	ip_vec	param3;
} RTDS_TN_LN_AssignGNsInNetwork_data;

typedef struct RTDS_Message_TE_TE_ST_Ans_data
{
	IPAddress	param1;
	IPAddress	param2;
	tDateTime	param3;
	IPAddress	param4;
	GroupID	param5;
} RTDS_Message_TE_TE_ST_Ans_data;

typedef struct RTDS_SN_TN_HaveGroupId_data
{
	IPAddress	param1;
	tDateTime	param2;
	IPAddress	param3;
	GroupID	param4;
} RTDS_SN_TN_HaveGroupId_data;

typedef struct RTDS_Message_TE_TE_SL_Det_data
{
	IPAddress	param1;
	IPAddress	param2;
	tDateTime	param3;
	tDateTime	param4;
	tSensorAcceleration	param5;
	tSensorVelocity	param6;
	tSensorDisplacement	param7;
	tSensorAccelerationAverage	param8;
	double	param9;
	double	param10;
} RTDS_Message_TE_TE_SL_Det_data;

typedef struct RTDS_Message_TE_TE_SL_Des_data
{
	IPAddress	param1;
	IPAddress	param2;
	tDateTime	param3;
	tDateTime	param4;
	tWaveType	param5;
	tSensorAcceleration	param6;
	tSensorVelocity	param7;
	tSensorDisplacement	param8;
	tSensorAccelerationAverage	param9;
	double	param10;
	double	param11;
	double	param12;
	double	param13;
} RTDS_Message_TE_TE_SL_Des_data;

typedef struct RTDS_LN_LN_Alarm_data
{
	IPAddress	param1;
	tDateTime	param2;
	EventID	param3;
	trig_vec	param4;
} RTDS_LN_LN_Alarm_data;

typedef struct RTDS_Message_TE_TE_LS_Sum_data
{
	IPAddress	param1;
	IPAddress	param2;
	tDateTime	param3;
	EventID	param4;
} RTDS_Message_TE_TE_LS_Sum_data;

typedef struct RTDS_Message_TE_TE_LL_Ala_data
{
	IPAddress	param1;
	IPAddress	param2;
	tDateTime	param3;
	EventID	param4;
	trig_vec	param5;
} RTDS_Message_TE_TE_LL_Ala_data;

typedef struct RTDS_Message_TE_TE_LS_FA_data
{
	IPAddress	param1;
	IPAddress	param2;
	tDateTime	param3;
	tDateTime	param4;
} RTDS_Message_TE_TE_LS_FA_data;

typedef struct RTDS_SN_LN_Idle_data
{
	IPAddress	param1;
	tDateTime	param2;
	tSensorAccelerationAverage	param3;
	double	param4;
	double	param5;
} RTDS_SN_LN_Idle_data;

typedef struct RTDS_Message_TE_TE_LE_Ala_data
{
	IPAddress	param1;
	IPAddress	param2;
	tDateTime	param3;
	EventID	param4;
	trig_vec	param5;
} RTDS_Message_TE_TE_LE_Ala_data;

typedef struct RTDS_TN_SN_StopMessageLogging_data
{
	IPAddress	param1;
	tDateTime	param2;
	tDateTime	param3;
} RTDS_TN_SN_StopMessageLogging_data;

/* MACRO FOR DECLARATIONS FOR MESSAGE SEND/RECEIVE */

#ifndef RTDS_MSG_DATA_DECL
#define RTDS_MSG_DATA_DECL unsigned char * RTDS_msgData;
#endif  /* RTDS_MSG_DATA_DECL defined */

/* MACRO FOR RECEPTION OF MESSAGE LN_LN_Idle */

#ifndef RTDS_MSG_RECEIVE_LN_LN_Idle
#define RTDS_MSG_RECEIVE_LN_LN_Idle(RTDS_PARAM1, RTDS_PARAM2, RTDS_PARAM3, RTDS_PARAM4, RTDS_PARAM5) \
	{ \
	RTDS_msgData = (unsigned char *)(RTDS_currentContext->currentMessage->pData); \
	if ( RTDS_msgData != NULL ) \
		{ \
		(RTDS_PARAM1) = (((RTDS_LN_LN_Idle_data*)RTDS_msgData)->param1); \
		(RTDS_PARAM2) = (((RTDS_LN_LN_Idle_data*)RTDS_msgData)->param2); \
		(RTDS_PARAM3) = (((RTDS_LN_LN_Idle_data*)RTDS_msgData)->param3); \
		(RTDS_PARAM4) = (((RTDS_LN_LN_Idle_data*)RTDS_msgData)->param4); \
		(RTDS_PARAM5) = (((RTDS_LN_LN_Idle_data*)RTDS_msgData)->param5); \
		} \
	else \
		{ \
		RTDS_MSG_INPUT_ERROR; \
		} \
	}
#endif /* RTDS_MSG_RECEIVE_LN_LN_Idle defined */

/* MACRO FOR SENDING MESSAGE LN_LN_Idle TO A PROCESS NAME */

#ifndef RTDS_MSG_SEND_LN_LN_Idle_TO_NAME
#define RTDS_MSG_SEND_LN_LN_Idle_TO_NAME(RECEIVER, RECEIVER_NUMBER, RTDS_PARAM1, RTDS_PARAM2, RTDS_PARAM3, RTDS_PARAM4, RTDS_PARAM5) \
	{ \
	RTDS_msgData = (unsigned char *)new RTDS_LN_LN_Idle_data(); \
	(((RTDS_LN_LN_Idle_data*)RTDS_msgData)->param1) = (RTDS_PARAM1); \
	(((RTDS_LN_LN_Idle_data*)RTDS_msgData)->param2) = (RTDS_PARAM2); \
	(((RTDS_LN_LN_Idle_data*)RTDS_msgData)->param3) = (RTDS_PARAM3); \
	(((RTDS_LN_LN_Idle_data*)RTDS_msgData)->param4) = (RTDS_PARAM4); \
	(((RTDS_LN_LN_Idle_data*)RTDS_msgData)->param5) = (RTDS_PARAM5); \
	RTDS_MSG_QUEUE_SEND_TO_NAME(LN_LN_Idle, sizeof(RTDS_LN_LN_Idle_data), RTDS_msgData, RECEIVER, RECEIVER_NUMBER); \
	}
#endif /* RTDS_MSG_SEND_LN_LN_Idle_TO_NAME defined */

/* MACRO FOR SENDING MESSAGE LN_LN_Idle TO A PROCESS ID */

#ifndef RTDS_MSG_SEND_LN_LN_Idle_TO_ID
#define RTDS_MSG_SEND_LN_LN_Idle_TO_ID(RECEIVER, RTDS_PARAM1, RTDS_PARAM2, RTDS_PARAM3, RTDS_PARAM4, RTDS_PARAM5) \
	{ \
	RTDS_msgData = (unsigned char *)new RTDS_LN_LN_Idle_data(); \
	(((RTDS_LN_LN_Idle_data*)RTDS_msgData)->param1) = (RTDS_PARAM1); \
	(((RTDS_LN_LN_Idle_data*)RTDS_msgData)->param2) = (RTDS_PARAM2); \
	(((RTDS_LN_LN_Idle_data*)RTDS_msgData)->param3) = (RTDS_PARAM3); \
	(((RTDS_LN_LN_Idle_data*)RTDS_msgData)->param4) = (RTDS_PARAM4); \
	(((RTDS_LN_LN_Idle_data*)RTDS_msgData)->param5) = (RTDS_PARAM5); \
	RTDS_MSG_QUEUE_SEND_TO_ID(LN_LN_Idle, sizeof(RTDS_LN_LN_Idle_data), RTDS_msgData, RECEIVER); \
	}
#endif /* RTDS_MSG_SEND_LN_LN_Idle_TO_ID defined */

/* MACROS FOR SENDING MESSAGE LN_LN_Idle TO ENVIRONMENT */

#ifndef RTDS_MSG_SEND_LN_LN_Idle_TO_ENV
#define RTDS_MSG_SEND_LN_LN_Idle_TO_ENV(RTDS_PARAM1, RTDS_PARAM2, RTDS_PARAM3, RTDS_PARAM4, RTDS_PARAM5) \
	{ \
	RTDS_msgData = (unsigned char *)new RTDS_LN_LN_Idle_data(); \
	(((RTDS_LN_LN_Idle_data*)RTDS_msgData)->param1) = (RTDS_PARAM1); \
	(((RTDS_LN_LN_Idle_data*)RTDS_msgData)->param2) = (RTDS_PARAM2); \
	(((RTDS_LN_LN_Idle_data*)RTDS_msgData)->param3) = (RTDS_PARAM3); \
	(((RTDS_LN_LN_Idle_data*)RTDS_msgData)->param4) = (RTDS_PARAM4); \
	(((RTDS_LN_LN_Idle_data*)RTDS_msgData)->param5) = (RTDS_PARAM5); \
	RTDS_MSG_QUEUE_SEND_TO_ENV(LN_LN_Idle, sizeof(RTDS_LN_LN_Idle_data), RTDS_msgData); \
	}
#endif /* RTDS_MSG_SEND_LN_LN_Idle_TO_ENV defined */

#ifndef RTDS_MSG_SEND_LN_LN_Idle_TO_ENV_W_MACRO
#define RTDS_MSG_SEND_LN_LN_Idle_TO_ENV_W_MACRO(MACRO_NAME, RTDS_PARAM1, RTDS_PARAM2, RTDS_PARAM3, RTDS_PARAM4, RTDS_PARAM5) \
	{ \
	RTDS_msgData = (unsigned char *)new RTDS_LN_LN_Idle_data(); \
	(((RTDS_LN_LN_Idle_data*)RTDS_msgData)->param1) = (RTDS_PARAM1); \
	(((RTDS_LN_LN_Idle_data*)RTDS_msgData)->param2) = (RTDS_PARAM2); \
	(((RTDS_LN_LN_Idle_data*)RTDS_msgData)->param3) = (RTDS_PARAM3); \
	(((RTDS_LN_LN_Idle_data*)RTDS_msgData)->param4) = (RTDS_PARAM4); \
	(((RTDS_LN_LN_Idle_data*)RTDS_msgData)->param5) = (RTDS_PARAM5); \
	MACRO_NAME(LN_LN_Idle, sizeof(RTDS_LN_LN_Idle_data), RTDS_msgData); \
	}
#endif /* RTDS_MSG_SEND_LN_LN_Idle_TO_ENV defined */

/* MACRO FOR RECEPTION OF MESSAGE TN_SN_ConfigureSetKeyValue */

#ifndef RTDS_MSG_RECEIVE_TN_SN_ConfigureSetKeyValue
#define RTDS_MSG_RECEIVE_TN_SN_ConfigureSetKeyValue(RTDS_PARAM1, RTDS_PARAM2, RTDS_PARAM3) \
	{ \
	RTDS_msgData = (unsigned char *)(RTDS_currentContext->currentMessage->pData); \
	if ( RTDS_msgData != NULL ) \
		{ \
		(RTDS_PARAM1) = (((RTDS_TN_SN_ConfigureSetKeyValue_data*)RTDS_msgData)->param1); \
		(RTDS_PARAM2) = (((RTDS_TN_SN_ConfigureSetKeyValue_data*)RTDS_msgData)->param2); \
		(RTDS_PARAM3) = (((RTDS_TN_SN_ConfigureSetKeyValue_data*)RTDS_msgData)->param3); \
		} \
	else \
		{ \
		RTDS_MSG_INPUT_ERROR; \
		} \
	}
#endif /* RTDS_MSG_RECEIVE_TN_SN_ConfigureSetKeyValue defined */

/* MACRO FOR SENDING MESSAGE TN_SN_ConfigureSetKeyValue TO A PROCESS NAME */

#ifndef RTDS_MSG_SEND_TN_SN_ConfigureSetKeyValue_TO_NAME
#define RTDS_MSG_SEND_TN_SN_ConfigureSetKeyValue_TO_NAME(RECEIVER, RECEIVER_NUMBER, RTDS_PARAM1, RTDS_PARAM2, RTDS_PARAM3) \
	{ \
	RTDS_msgData = (unsigned char *)new RTDS_TN_SN_ConfigureSetKeyValue_data(); \
	(((RTDS_TN_SN_ConfigureSetKeyValue_data*)RTDS_msgData)->param1) = (RTDS_PARAM1); \
	(((RTDS_TN_SN_ConfigureSetKeyValue_data*)RTDS_msgData)->param2) = (RTDS_PARAM2); \
	(((RTDS_TN_SN_ConfigureSetKeyValue_data*)RTDS_msgData)->param3) = (RTDS_PARAM3); \
	RTDS_MSG_QUEUE_SEND_TO_NAME(TN_SN_ConfigureSetKeyValue, sizeof(RTDS_TN_SN_ConfigureSetKeyValue_data), RTDS_msgData, RECEIVER, RECEIVER_NUMBER); \
	}
#endif /* RTDS_MSG_SEND_TN_SN_ConfigureSetKeyValue_TO_NAME defined */

/* MACRO FOR SENDING MESSAGE TN_SN_ConfigureSetKeyValue TO A PROCESS ID */

#ifndef RTDS_MSG_SEND_TN_SN_ConfigureSetKeyValue_TO_ID
#define RTDS_MSG_SEND_TN_SN_ConfigureSetKeyValue_TO_ID(RECEIVER, RTDS_PARAM1, RTDS_PARAM2, RTDS_PARAM3) \
	{ \
	RTDS_msgData = (unsigned char *)new RTDS_TN_SN_ConfigureSetKeyValue_data(); \
	(((RTDS_TN_SN_ConfigureSetKeyValue_data*)RTDS_msgData)->param1) = (RTDS_PARAM1); \
	(((RTDS_TN_SN_ConfigureSetKeyValue_data*)RTDS_msgData)->param2) = (RTDS_PARAM2); \
	(((RTDS_TN_SN_ConfigureSetKeyValue_data*)RTDS_msgData)->param3) = (RTDS_PARAM3); \
	RTDS_MSG_QUEUE_SEND_TO_ID(TN_SN_ConfigureSetKeyValue, sizeof(RTDS_TN_SN_ConfigureSetKeyValue_data), RTDS_msgData, RECEIVER); \
	}
#endif /* RTDS_MSG_SEND_TN_SN_ConfigureSetKeyValue_TO_ID defined */

/* MACROS FOR SENDING MESSAGE TN_SN_ConfigureSetKeyValue TO ENVIRONMENT */

#ifndef RTDS_MSG_SEND_TN_SN_ConfigureSetKeyValue_TO_ENV
#define RTDS_MSG_SEND_TN_SN_ConfigureSetKeyValue_TO_ENV(RTDS_PARAM1, RTDS_PARAM2, RTDS_PARAM3) \
	{ \
	RTDS_msgData = (unsigned char *)new RTDS_TN_SN_ConfigureSetKeyValue_data(); \
	(((RTDS_TN_SN_ConfigureSetKeyValue_data*)RTDS_msgData)->param1) = (RTDS_PARAM1); \
	(((RTDS_TN_SN_ConfigureSetKeyValue_data*)RTDS_msgData)->param2) = (RTDS_PARAM2); \
	(((RTDS_TN_SN_ConfigureSetKeyValue_data*)RTDS_msgData)->param3) = (RTDS_PARAM3); \
	RTDS_MSG_QUEUE_SEND_TO_ENV(TN_SN_ConfigureSetKeyValue, sizeof(RTDS_TN_SN_ConfigureSetKeyValue_data), RTDS_msgData); \
	}
#endif /* RTDS_MSG_SEND_TN_SN_ConfigureSetKeyValue_TO_ENV defined */

#ifndef RTDS_MSG_SEND_TN_SN_ConfigureSetKeyValue_TO_ENV_W_MACRO
#define RTDS_MSG_SEND_TN_SN_ConfigureSetKeyValue_TO_ENV_W_MACRO(MACRO_NAME, RTDS_PARAM1, RTDS_PARAM2, RTDS_PARAM3) \
	{ \
	RTDS_msgData = (unsigned char *)new RTDS_TN_SN_ConfigureSetKeyValue_data(); \
	(((RTDS_TN_SN_ConfigureSetKeyValue_data*)RTDS_msgData)->param1) = (RTDS_PARAM1); \
	(((RTDS_TN_SN_ConfigureSetKeyValue_data*)RTDS_msgData)->param2) = (RTDS_PARAM2); \
	(((RTDS_TN_SN_ConfigureSetKeyValue_data*)RTDS_msgData)->param3) = (RTDS_PARAM3); \
	MACRO_NAME(TN_SN_ConfigureSetKeyValue, sizeof(RTDS_TN_SN_ConfigureSetKeyValue_data), RTDS_msgData); \
	}
#endif /* RTDS_MSG_SEND_TN_SN_ConfigureSetKeyValue_TO_ENV defined */

/* MACRO FOR RECEPTION OF MESSAGE LN_SN_PrimaryLN */

#ifndef RTDS_MSG_RECEIVE_LN_SN_PrimaryLN
#define RTDS_MSG_RECEIVE_LN_SN_PrimaryLN(RTDS_PARAM1, RTDS_PARAM2, RTDS_PARAM3, RTDS_PARAM4) \
	{ \
	RTDS_msgData = (unsigned char *)(RTDS_currentContext->currentMessage->pData); \
	if ( RTDS_msgData != NULL ) \
		{ \
		(RTDS_PARAM1) = (((RTDS_LN_SN_PrimaryLN_data*)RTDS_msgData)->param1); \
		(RTDS_PARAM2) = (((RTDS_LN_SN_PrimaryLN_data*)RTDS_msgData)->param2); \
		(RTDS_PARAM3) = (((RTDS_LN_SN_PrimaryLN_data*)RTDS_msgData)->param3); \
		RTDS_PARAM4 = ((RTDS_LN_SN_PrimaryLN_data*)RTDS_msgData)->param4; \
		} \
	else \
		{ \
		RTDS_MSG_INPUT_ERROR; \
		} \
	}
#endif /* RTDS_MSG_RECEIVE_LN_SN_PrimaryLN defined */

/* MACRO FOR SENDING MESSAGE LN_SN_PrimaryLN TO A PROCESS NAME */

#ifndef RTDS_MSG_SEND_LN_SN_PrimaryLN_TO_NAME
#define RTDS_MSG_SEND_LN_SN_PrimaryLN_TO_NAME(RECEIVER, RECEIVER_NUMBER, RTDS_PARAM1, RTDS_PARAM2, RTDS_PARAM3, RTDS_PARAM4) \
	{ \
	RTDS_msgData = (unsigned char *)new RTDS_LN_SN_PrimaryLN_data(); \
	(((RTDS_LN_SN_PrimaryLN_data*)RTDS_msgData)->param1) = (RTDS_PARAM1); \
	(((RTDS_LN_SN_PrimaryLN_data*)RTDS_msgData)->param2) = (RTDS_PARAM2); \
	(((RTDS_LN_SN_PrimaryLN_data*)RTDS_msgData)->param3) = (RTDS_PARAM3); \
	((RTDS_LN_SN_PrimaryLN_data*)RTDS_msgData)->param4 = RTDS_PARAM4; \
	RTDS_MSG_QUEUE_SEND_TO_NAME(LN_SN_PrimaryLN, sizeof(RTDS_LN_SN_PrimaryLN_data), RTDS_msgData, RECEIVER, RECEIVER_NUMBER); \
	}
#endif /* RTDS_MSG_SEND_LN_SN_PrimaryLN_TO_NAME defined */

/* MACRO FOR SENDING MESSAGE LN_SN_PrimaryLN TO A PROCESS ID */

#ifndef RTDS_MSG_SEND_LN_SN_PrimaryLN_TO_ID
#define RTDS_MSG_SEND_LN_SN_PrimaryLN_TO_ID(RECEIVER, RTDS_PARAM1, RTDS_PARAM2, RTDS_PARAM3, RTDS_PARAM4) \
	{ \
	RTDS_msgData = (unsigned char *)new RTDS_LN_SN_PrimaryLN_data(); \
	(((RTDS_LN_SN_PrimaryLN_data*)RTDS_msgData)->param1) = (RTDS_PARAM1); \
	(((RTDS_LN_SN_PrimaryLN_data*)RTDS_msgData)->param2) = (RTDS_PARAM2); \
	(((RTDS_LN_SN_PrimaryLN_data*)RTDS_msgData)->param3) = (RTDS_PARAM3); \
	((RTDS_LN_SN_PrimaryLN_data*)RTDS_msgData)->param4 = RTDS_PARAM4; \
	RTDS_MSG_QUEUE_SEND_TO_ID(LN_SN_PrimaryLN, sizeof(RTDS_LN_SN_PrimaryLN_data), RTDS_msgData, RECEIVER); \
	}
#endif /* RTDS_MSG_SEND_LN_SN_PrimaryLN_TO_ID defined */

/* MACROS FOR SENDING MESSAGE LN_SN_PrimaryLN TO ENVIRONMENT */

#ifndef RTDS_MSG_SEND_LN_SN_PrimaryLN_TO_ENV
#define RTDS_MSG_SEND_LN_SN_PrimaryLN_TO_ENV(RTDS_PARAM1, RTDS_PARAM2, RTDS_PARAM3, RTDS_PARAM4) \
	{ \
	RTDS_msgData = (unsigned char *)new RTDS_LN_SN_PrimaryLN_data(); \
	(((RTDS_LN_SN_PrimaryLN_data*)RTDS_msgData)->param1) = (RTDS_PARAM1); \
	(((RTDS_LN_SN_PrimaryLN_data*)RTDS_msgData)->param2) = (RTDS_PARAM2); \
	(((RTDS_LN_SN_PrimaryLN_data*)RTDS_msgData)->param3) = (RTDS_PARAM3); \
	((RTDS_LN_SN_PrimaryLN_data*)RTDS_msgData)->param4 = RTDS_PARAM4; \
	RTDS_MSG_QUEUE_SEND_TO_ENV(LN_SN_PrimaryLN, sizeof(RTDS_LN_SN_PrimaryLN_data), RTDS_msgData); \
	}
#endif /* RTDS_MSG_SEND_LN_SN_PrimaryLN_TO_ENV defined */

#ifndef RTDS_MSG_SEND_LN_SN_PrimaryLN_TO_ENV_W_MACRO
#define RTDS_MSG_SEND_LN_SN_PrimaryLN_TO_ENV_W_MACRO(MACRO_NAME, RTDS_PARAM1, RTDS_PARAM2, RTDS_PARAM3, RTDS_PARAM4) \
	{ \
	RTDS_msgData = (unsigned char *)new RTDS_LN_SN_PrimaryLN_data(); \
	(((RTDS_LN_SN_PrimaryLN_data*)RTDS_msgData)->param1) = (RTDS_PARAM1); \
	(((RTDS_LN_SN_PrimaryLN_data*)RTDS_msgData)->param2) = (RTDS_PARAM2); \
	(((RTDS_LN_SN_PrimaryLN_data*)RTDS_msgData)->param3) = (RTDS_PARAM3); \
	((RTDS_LN_SN_PrimaryLN_data*)RTDS_msgData)->param4 = RTDS_PARAM4; \
	MACRO_NAME(LN_SN_PrimaryLN, sizeof(RTDS_LN_SN_PrimaryLN_data), RTDS_msgData); \
	}
#endif /* RTDS_MSG_SEND_LN_SN_PrimaryLN_TO_ENV defined */

/* MACRO FOR RECEPTION OF MESSAGE Message_TE_TE_SL_Des */

#ifndef RTDS_MSG_RECEIVE_Message_TE_TE_SL_Des
#define RTDS_MSG_RECEIVE_Message_TE_TE_SL_Des(RTDS_PARAM1, RTDS_PARAM2, RTDS_PARAM3, RTDS_PARAM4, RTDS_PARAM5, RTDS_PARAM6, RTDS_PARAM7, RTDS_PARAM8, RTDS_PARAM9, RTDS_PARAM10, RTDS_PARAM11, RTDS_PARAM12, RTDS_PARAM13) \
	{ \
	RTDS_msgData = (unsigned char *)(RTDS_currentContext->currentMessage->pData); \
	if ( RTDS_msgData != NULL ) \
		{ \
		(RTDS_PARAM1) = (((RTDS_Message_TE_TE_SL_Des_data*)RTDS_msgData)->param1); \
		(RTDS_PARAM2) = (((RTDS_Message_TE_TE_SL_Des_data*)RTDS_msgData)->param2); \
		(RTDS_PARAM3) = (((RTDS_Message_TE_TE_SL_Des_data*)RTDS_msgData)->param3); \
		(RTDS_PARAM4) = (((RTDS_Message_TE_TE_SL_Des_data*)RTDS_msgData)->param4); \
		(RTDS_PARAM5) = (((RTDS_Message_TE_TE_SL_Des_data*)RTDS_msgData)->param5); \
		(RTDS_PARAM6) = (((RTDS_Message_TE_TE_SL_Des_data*)RTDS_msgData)->param6); \
		(RTDS_PARAM7) = (((RTDS_Message_TE_TE_SL_Des_data*)RTDS_msgData)->param7); \
		(RTDS_PARAM8) = (((RTDS_Message_TE_TE_SL_Des_data*)RTDS_msgData)->param8); \
		(RTDS_PARAM9) = (((RTDS_Message_TE_TE_SL_Des_data*)RTDS_msgData)->param9); \
		RTDS_PARAM10 = ((RTDS_Message_TE_TE_SL_Des_data*)RTDS_msgData)->param10; \
		RTDS_PARAM11 = ((RTDS_Message_TE_TE_SL_Des_data*)RTDS_msgData)->param11; \
		RTDS_PARAM12 = ((RTDS_Message_TE_TE_SL_Des_data*)RTDS_msgData)->param12; \
		RTDS_PARAM13 = ((RTDS_Message_TE_TE_SL_Des_data*)RTDS_msgData)->param13; \
		} \
	else \
		{ \
		RTDS_MSG_INPUT_ERROR; \
		} \
	}
#endif /* RTDS_MSG_RECEIVE_Message_TE_TE_SL_Des defined */

/* MACRO FOR SENDING MESSAGE Message_TE_TE_SL_Des TO A PROCESS NAME */

#ifndef RTDS_MSG_SEND_Message_TE_TE_SL_Des_TO_NAME
#define RTDS_MSG_SEND_Message_TE_TE_SL_Des_TO_NAME(RECEIVER, RECEIVER_NUMBER, RTDS_PARAM1, RTDS_PARAM2, RTDS_PARAM3, RTDS_PARAM4, RTDS_PARAM5, RTDS_PARAM6, RTDS_PARAM7, RTDS_PARAM8, RTDS_PARAM9, RTDS_PARAM10, RTDS_PARAM11, RTDS_PARAM12, RTDS_PARAM13) \
	{ \
	RTDS_msgData = (unsigned char *)new RTDS_Message_TE_TE_SL_Des_data(); \
	(((RTDS_Message_TE_TE_SL_Des_data*)RTDS_msgData)->param1) = (RTDS_PARAM1); \
	(((RTDS_Message_TE_TE_SL_Des_data*)RTDS_msgData)->param2) = (RTDS_PARAM2); \
	(((RTDS_Message_TE_TE_SL_Des_data*)RTDS_msgData)->param3) = (RTDS_PARAM3); \
	(((RTDS_Message_TE_TE_SL_Des_data*)RTDS_msgData)->param4) = (RTDS_PARAM4); \
	(((RTDS_Message_TE_TE_SL_Des_data*)RTDS_msgData)->param5) = (RTDS_PARAM5); \
	(((RTDS_Message_TE_TE_SL_Des_data*)RTDS_msgData)->param6) = (RTDS_PARAM6); \
	(((RTDS_Message_TE_TE_SL_Des_data*)RTDS_msgData)->param7) = (RTDS_PARAM7); \
	(((RTDS_Message_TE_TE_SL_Des_data*)RTDS_msgData)->param8) = (RTDS_PARAM8); \
	(((RTDS_Message_TE_TE_SL_Des_data*)RTDS_msgData)->param9) = (RTDS_PARAM9); \
	((RTDS_Message_TE_TE_SL_Des_data*)RTDS_msgData)->param10 = RTDS_PARAM10; \
	((RTDS_Message_TE_TE_SL_Des_data*)RTDS_msgData)->param11 = RTDS_PARAM11; \
	((RTDS_Message_TE_TE_SL_Des_data*)RTDS_msgData)->param12 = RTDS_PARAM12; \
	((RTDS_Message_TE_TE_SL_Des_data*)RTDS_msgData)->param13 = RTDS_PARAM13; \
	RTDS_MSG_QUEUE_SEND_TO_NAME(Message_TE_TE_SL_Des, sizeof(RTDS_Message_TE_TE_SL_Des_data), RTDS_msgData, RECEIVER, RECEIVER_NUMBER); \
	}
#endif /* RTDS_MSG_SEND_Message_TE_TE_SL_Des_TO_NAME defined */

/* MACRO FOR SENDING MESSAGE Message_TE_TE_SL_Des TO A PROCESS ID */

#ifndef RTDS_MSG_SEND_Message_TE_TE_SL_Des_TO_ID
#define RTDS_MSG_SEND_Message_TE_TE_SL_Des_TO_ID(RECEIVER, RTDS_PARAM1, RTDS_PARAM2, RTDS_PARAM3, RTDS_PARAM4, RTDS_PARAM5, RTDS_PARAM6, RTDS_PARAM7, RTDS_PARAM8, RTDS_PARAM9, RTDS_PARAM10, RTDS_PARAM11, RTDS_PARAM12, RTDS_PARAM13) \
	{ \
	RTDS_msgData = (unsigned char *)new RTDS_Message_TE_TE_SL_Des_data(); \
	(((RTDS_Message_TE_TE_SL_Des_data*)RTDS_msgData)->param1) = (RTDS_PARAM1); \
	(((RTDS_Message_TE_TE_SL_Des_data*)RTDS_msgData)->param2) = (RTDS_PARAM2); \
	(((RTDS_Message_TE_TE_SL_Des_data*)RTDS_msgData)->param3) = (RTDS_PARAM3); \
	(((RTDS_Message_TE_TE_SL_Des_data*)RTDS_msgData)->param4) = (RTDS_PARAM4); \
	(((RTDS_Message_TE_TE_SL_Des_data*)RTDS_msgData)->param5) = (RTDS_PARAM5); \
	(((RTDS_Message_TE_TE_SL_Des_data*)RTDS_msgData)->param6) = (RTDS_PARAM6); \
	(((RTDS_Message_TE_TE_SL_Des_data*)RTDS_msgData)->param7) = (RTDS_PARAM7); \
	(((RTDS_Message_TE_TE_SL_Des_data*)RTDS_msgData)->param8) = (RTDS_PARAM8); \
	(((RTDS_Message_TE_TE_SL_Des_data*)RTDS_msgData)->param9) = (RTDS_PARAM9); \
	((RTDS_Message_TE_TE_SL_Des_data*)RTDS_msgData)->param10 = RTDS_PARAM10; \
	((RTDS_Message_TE_TE_SL_Des_data*)RTDS_msgData)->param11 = RTDS_PARAM11; \
	((RTDS_Message_TE_TE_SL_Des_data*)RTDS_msgData)->param12 = RTDS_PARAM12; \
	((RTDS_Message_TE_TE_SL_Des_data*)RTDS_msgData)->param13 = RTDS_PARAM13; \
	RTDS_MSG_QUEUE_SEND_TO_ID(Message_TE_TE_SL_Des, sizeof(RTDS_Message_TE_TE_SL_Des_data), RTDS_msgData, RECEIVER); \
	}
#endif /* RTDS_MSG_SEND_Message_TE_TE_SL_Des_TO_ID defined */

/* MACROS FOR SENDING MESSAGE Message_TE_TE_SL_Des TO ENVIRONMENT */

#ifndef RTDS_MSG_SEND_Message_TE_TE_SL_Des_TO_ENV
#define RTDS_MSG_SEND_Message_TE_TE_SL_Des_TO_ENV(RTDS_PARAM1, RTDS_PARAM2, RTDS_PARAM3, RTDS_PARAM4, RTDS_PARAM5, RTDS_PARAM6, RTDS_PARAM7, RTDS_PARAM8, RTDS_PARAM9, RTDS_PARAM10, RTDS_PARAM11, RTDS_PARAM12, RTDS_PARAM13) \
	{ \
	RTDS_msgData = (unsigned char *)new RTDS_Message_TE_TE_SL_Des_data(); \
	(((RTDS_Message_TE_TE_SL_Des_data*)RTDS_msgData)->param1) = (RTDS_PARAM1); \
	(((RTDS_Message_TE_TE_SL_Des_data*)RTDS_msgData)->param2) = (RTDS_PARAM2); \
	(((RTDS_Message_TE_TE_SL_Des_data*)RTDS_msgData)->param3) = (RTDS_PARAM3); \
	(((RTDS_Message_TE_TE_SL_Des_data*)RTDS_msgData)->param4) = (RTDS_PARAM4); \
	(((RTDS_Message_TE_TE_SL_Des_data*)RTDS_msgData)->param5) = (RTDS_PARAM5); \
	(((RTDS_Message_TE_TE_SL_Des_data*)RTDS_msgData)->param6) = (RTDS_PARAM6); \
	(((RTDS_Message_TE_TE_SL_Des_data*)RTDS_msgData)->param7) = (RTDS_PARAM7); \
	(((RTDS_Message_TE_TE_SL_Des_data*)RTDS_msgData)->param8) = (RTDS_PARAM8); \
	(((RTDS_Message_TE_TE_SL_Des_data*)RTDS_msgData)->param9) = (RTDS_PARAM9); \
	((RTDS_Message_TE_TE_SL_Des_data*)RTDS_msgData)->param10 = RTDS_PARAM10; \
	((RTDS_Message_TE_TE_SL_Des_data*)RTDS_msgData)->param11 = RTDS_PARAM11; \
	((RTDS_Message_TE_TE_SL_Des_data*)RTDS_msgData)->param12 = RTDS_PARAM12; \
	((RTDS_Message_TE_TE_SL_Des_data*)RTDS_msgData)->param13 = RTDS_PARAM13; \
	RTDS_MSG_QUEUE_SEND_TO_ENV(Message_TE_TE_SL_Des, sizeof(RTDS_Message_TE_TE_SL_Des_data), RTDS_msgData); \
	}
#endif /* RTDS_MSG_SEND_Message_TE_TE_SL_Des_TO_ENV defined */

#ifndef RTDS_MSG_SEND_Message_TE_TE_SL_Des_TO_ENV_W_MACRO
#define RTDS_MSG_SEND_Message_TE_TE_SL_Des_TO_ENV_W_MACRO(MACRO_NAME, RTDS_PARAM1, RTDS_PARAM2, RTDS_PARAM3, RTDS_PARAM4, RTDS_PARAM5, RTDS_PARAM6, RTDS_PARAM7, RTDS_PARAM8, RTDS_PARAM9, RTDS_PARAM10, RTDS_PARAM11, RTDS_PARAM12, RTDS_PARAM13) \
	{ \
	RTDS_msgData = (unsigned char *)new RTDS_Message_TE_TE_SL_Des_data(); \
	(((RTDS_Message_TE_TE_SL_Des_data*)RTDS_msgData)->param1) = (RTDS_PARAM1); \
	(((RTDS_Message_TE_TE_SL_Des_data*)RTDS_msgData)->param2) = (RTDS_PARAM2); \
	(((RTDS_Message_TE_TE_SL_Des_data*)RTDS_msgData)->param3) = (RTDS_PARAM3); \
	(((RTDS_Message_TE_TE_SL_Des_data*)RTDS_msgData)->param4) = (RTDS_PARAM4); \
	(((RTDS_Message_TE_TE_SL_Des_data*)RTDS_msgData)->param5) = (RTDS_PARAM5); \
	(((RTDS_Message_TE_TE_SL_Des_data*)RTDS_msgData)->param6) = (RTDS_PARAM6); \
	(((RTDS_Message_TE_TE_SL_Des_data*)RTDS_msgData)->param7) = (RTDS_PARAM7); \
	(((RTDS_Message_TE_TE_SL_Des_data*)RTDS_msgData)->param8) = (RTDS_PARAM8); \
	(((RTDS_Message_TE_TE_SL_Des_data*)RTDS_msgData)->param9) = (RTDS_PARAM9); \
	((RTDS_Message_TE_TE_SL_Des_data*)RTDS_msgData)->param10 = RTDS_PARAM10; \
	((RTDS_Message_TE_TE_SL_Des_data*)RTDS_msgData)->param11 = RTDS_PARAM11; \
	((RTDS_Message_TE_TE_SL_Des_data*)RTDS_msgData)->param12 = RTDS_PARAM12; \
	((RTDS_Message_TE_TE_SL_Des_data*)RTDS_msgData)->param13 = RTDS_PARAM13; \
	MACRO_NAME(Message_TE_TE_SL_Des, sizeof(RTDS_Message_TE_TE_SL_Des_data), RTDS_msgData); \
	}
#endif /* RTDS_MSG_SEND_Message_TE_TE_SL_Des_TO_ENV defined */

/* MACRO FOR RECEPTION OF MESSAGE Message_TE_TE_SL_Sum */

#ifndef RTDS_MSG_RECEIVE_Message_TE_TE_SL_Sum
#define RTDS_MSG_RECEIVE_Message_TE_TE_SL_Sum(RTDS_PARAM1, RTDS_PARAM2, RTDS_PARAM3, RTDS_PARAM4, RTDS_PARAM5, RTDS_PARAM6, RTDS_PARAM7, RTDS_PARAM8, RTDS_PARAM9, RTDS_PARAM10, RTDS_PARAM11, RTDS_PARAM12, RTDS_PARAM13, RTDS_PARAM14) \
	{ \
	RTDS_msgData = (unsigned char *)(RTDS_currentContext->currentMessage->pData); \
	if ( RTDS_msgData != NULL ) \
		{ \
		(RTDS_PARAM1) = (((RTDS_Message_TE_TE_SL_Sum_data*)RTDS_msgData)->param1); \
		(RTDS_PARAM2) = (((RTDS_Message_TE_TE_SL_Sum_data*)RTDS_msgData)->param2); \
		(RTDS_PARAM3) = (((RTDS_Message_TE_TE_SL_Sum_data*)RTDS_msgData)->param3); \
		(RTDS_PARAM4) = (((RTDS_Message_TE_TE_SL_Sum_data*)RTDS_msgData)->param4); \
		(RTDS_PARAM5) = (((RTDS_Message_TE_TE_SL_Sum_data*)RTDS_msgData)->param5); \
		(RTDS_PARAM6) = (((RTDS_Message_TE_TE_SL_Sum_data*)RTDS_msgData)->param6); \
		(RTDS_PARAM7) = (((RTDS_Message_TE_TE_SL_Sum_data*)RTDS_msgData)->param7); \
		(RTDS_PARAM8) = (((RTDS_Message_TE_TE_SL_Sum_data*)RTDS_msgData)->param8); \
		(RTDS_PARAM9) = (((RTDS_Message_TE_TE_SL_Sum_data*)RTDS_msgData)->param9); \
		(RTDS_PARAM10) = (((RTDS_Message_TE_TE_SL_Sum_data*)RTDS_msgData)->param10); \
		RTDS_PARAM11 = ((RTDS_Message_TE_TE_SL_Sum_data*)RTDS_msgData)->param11; \
		RTDS_PARAM12 = ((RTDS_Message_TE_TE_SL_Sum_data*)RTDS_msgData)->param12; \
		RTDS_PARAM13 = ((RTDS_Message_TE_TE_SL_Sum_data*)RTDS_msgData)->param13; \
		RTDS_PARAM14 = ((RTDS_Message_TE_TE_SL_Sum_data*)RTDS_msgData)->param14; \
		} \
	else \
		{ \
		RTDS_MSG_INPUT_ERROR; \
		} \
	}
#endif /* RTDS_MSG_RECEIVE_Message_TE_TE_SL_Sum defined */

/* MACRO FOR SENDING MESSAGE Message_TE_TE_SL_Sum TO A PROCESS NAME */

#ifndef RTDS_MSG_SEND_Message_TE_TE_SL_Sum_TO_NAME
#define RTDS_MSG_SEND_Message_TE_TE_SL_Sum_TO_NAME(RECEIVER, RECEIVER_NUMBER, RTDS_PARAM1, RTDS_PARAM2, RTDS_PARAM3, RTDS_PARAM4, RTDS_PARAM5, RTDS_PARAM6, RTDS_PARAM7, RTDS_PARAM8, RTDS_PARAM9, RTDS_PARAM10, RTDS_PARAM11, RTDS_PARAM12, RTDS_PARAM13, RTDS_PARAM14) \
	{ \
	RTDS_msgData = (unsigned char *)new RTDS_Message_TE_TE_SL_Sum_data(); \
	(((RTDS_Message_TE_TE_SL_Sum_data*)RTDS_msgData)->param1) = (RTDS_PARAM1); \
	(((RTDS_Message_TE_TE_SL_Sum_data*)RTDS_msgData)->param2) = (RTDS_PARAM2); \
	(((RTDS_Message_TE_TE_SL_Sum_data*)RTDS_msgData)->param3) = (RTDS_PARAM3); \
	(((RTDS_Message_TE_TE_SL_Sum_data*)RTDS_msgData)->param4) = (RTDS_PARAM4); \
	(((RTDS_Message_TE_TE_SL_Sum_data*)RTDS_msgData)->param5) = (RTDS_PARAM5); \
	(((RTDS_Message_TE_TE_SL_Sum_data*)RTDS_msgData)->param6) = (RTDS_PARAM6); \
	(((RTDS_Message_TE_TE_SL_Sum_data*)RTDS_msgData)->param7) = (RTDS_PARAM7); \
	(((RTDS_Message_TE_TE_SL_Sum_data*)RTDS_msgData)->param8) = (RTDS_PARAM8); \
	(((RTDS_Message_TE_TE_SL_Sum_data*)RTDS_msgData)->param9) = (RTDS_PARAM9); \
	(((RTDS_Message_TE_TE_SL_Sum_data*)RTDS_msgData)->param10) = (RTDS_PARAM10); \
	((RTDS_Message_TE_TE_SL_Sum_data*)RTDS_msgData)->param11 = RTDS_PARAM11; \
	((RTDS_Message_TE_TE_SL_Sum_data*)RTDS_msgData)->param12 = RTDS_PARAM12; \
	((RTDS_Message_TE_TE_SL_Sum_data*)RTDS_msgData)->param13 = RTDS_PARAM13; \
	((RTDS_Message_TE_TE_SL_Sum_data*)RTDS_msgData)->param14 = RTDS_PARAM14; \
	RTDS_MSG_QUEUE_SEND_TO_NAME(Message_TE_TE_SL_Sum, sizeof(RTDS_Message_TE_TE_SL_Sum_data), RTDS_msgData, RECEIVER, RECEIVER_NUMBER); \
	}
#endif /* RTDS_MSG_SEND_Message_TE_TE_SL_Sum_TO_NAME defined */

/* MACRO FOR SENDING MESSAGE Message_TE_TE_SL_Sum TO A PROCESS ID */

#ifndef RTDS_MSG_SEND_Message_TE_TE_SL_Sum_TO_ID
#define RTDS_MSG_SEND_Message_TE_TE_SL_Sum_TO_ID(RECEIVER, RTDS_PARAM1, RTDS_PARAM2, RTDS_PARAM3, RTDS_PARAM4, RTDS_PARAM5, RTDS_PARAM6, RTDS_PARAM7, RTDS_PARAM8, RTDS_PARAM9, RTDS_PARAM10, RTDS_PARAM11, RTDS_PARAM12, RTDS_PARAM13, RTDS_PARAM14) \
	{ \
	RTDS_msgData = (unsigned char *)new RTDS_Message_TE_TE_SL_Sum_data(); \
	(((RTDS_Message_TE_TE_SL_Sum_data*)RTDS_msgData)->param1) = (RTDS_PARAM1); \
	(((RTDS_Message_TE_TE_SL_Sum_data*)RTDS_msgData)->param2) = (RTDS_PARAM2); \
	(((RTDS_Message_TE_TE_SL_Sum_data*)RTDS_msgData)->param3) = (RTDS_PARAM3); \
	(((RTDS_Message_TE_TE_SL_Sum_data*)RTDS_msgData)->param4) = (RTDS_PARAM4); \
	(((RTDS_Message_TE_TE_SL_Sum_data*)RTDS_msgData)->param5) = (RTDS_PARAM5); \
	(((RTDS_Message_TE_TE_SL_Sum_data*)RTDS_msgData)->param6) = (RTDS_PARAM6); \
	(((RTDS_Message_TE_TE_SL_Sum_data*)RTDS_msgData)->param7) = (RTDS_PARAM7); \
	(((RTDS_Message_TE_TE_SL_Sum_data*)RTDS_msgData)->param8) = (RTDS_PARAM8); \
	(((RTDS_Message_TE_TE_SL_Sum_data*)RTDS_msgData)->param9) = (RTDS_PARAM9); \
	(((RTDS_Message_TE_TE_SL_Sum_data*)RTDS_msgData)->param10) = (RTDS_PARAM10); \
	((RTDS_Message_TE_TE_SL_Sum_data*)RTDS_msgData)->param11 = RTDS_PARAM11; \
	((RTDS_Message_TE_TE_SL_Sum_data*)RTDS_msgData)->param12 = RTDS_PARAM12; \
	((RTDS_Message_TE_TE_SL_Sum_data*)RTDS_msgData)->param13 = RTDS_PARAM13; \
	((RTDS_Message_TE_TE_SL_Sum_data*)RTDS_msgData)->param14 = RTDS_PARAM14; \
	RTDS_MSG_QUEUE_SEND_TO_ID(Message_TE_TE_SL_Sum, sizeof(RTDS_Message_TE_TE_SL_Sum_data), RTDS_msgData, RECEIVER); \
	}
#endif /* RTDS_MSG_SEND_Message_TE_TE_SL_Sum_TO_ID defined */

/* MACROS FOR SENDING MESSAGE Message_TE_TE_SL_Sum TO ENVIRONMENT */

#ifndef RTDS_MSG_SEND_Message_TE_TE_SL_Sum_TO_ENV
#define RTDS_MSG_SEND_Message_TE_TE_SL_Sum_TO_ENV(RTDS_PARAM1, RTDS_PARAM2, RTDS_PARAM3, RTDS_PARAM4, RTDS_PARAM5, RTDS_PARAM6, RTDS_PARAM7, RTDS_PARAM8, RTDS_PARAM9, RTDS_PARAM10, RTDS_PARAM11, RTDS_PARAM12, RTDS_PARAM13, RTDS_PARAM14) \
	{ \
	RTDS_msgData = (unsigned char *)new RTDS_Message_TE_TE_SL_Sum_data(); \
	(((RTDS_Message_TE_TE_SL_Sum_data*)RTDS_msgData)->param1) = (RTDS_PARAM1); \
	(((RTDS_Message_TE_TE_SL_Sum_data*)RTDS_msgData)->param2) = (RTDS_PARAM2); \
	(((RTDS_Message_TE_TE_SL_Sum_data*)RTDS_msgData)->param3) = (RTDS_PARAM3); \
	(((RTDS_Message_TE_TE_SL_Sum_data*)RTDS_msgData)->param4) = (RTDS_PARAM4); \
	(((RTDS_Message_TE_TE_SL_Sum_data*)RTDS_msgData)->param5) = (RTDS_PARAM5); \
	(((RTDS_Message_TE_TE_SL_Sum_data*)RTDS_msgData)->param6) = (RTDS_PARAM6); \
	(((RTDS_Message_TE_TE_SL_Sum_data*)RTDS_msgData)->param7) = (RTDS_PARAM7); \
	(((RTDS_Message_TE_TE_SL_Sum_data*)RTDS_msgData)->param8) = (RTDS_PARAM8); \
	(((RTDS_Message_TE_TE_SL_Sum_data*)RTDS_msgData)->param9) = (RTDS_PARAM9); \
	(((RTDS_Message_TE_TE_SL_Sum_data*)RTDS_msgData)->param10) = (RTDS_PARAM10); \
	((RTDS_Message_TE_TE_SL_Sum_data*)RTDS_msgData)->param11 = RTDS_PARAM11; \
	((RTDS_Message_TE_TE_SL_Sum_data*)RTDS_msgData)->param12 = RTDS_PARAM12; \
	((RTDS_Message_TE_TE_SL_Sum_data*)RTDS_msgData)->param13 = RTDS_PARAM13; \
	((RTDS_Message_TE_TE_SL_Sum_data*)RTDS_msgData)->param14 = RTDS_PARAM14; \
	RTDS_MSG_QUEUE_SEND_TO_ENV(Message_TE_TE_SL_Sum, sizeof(RTDS_Message_TE_TE_SL_Sum_data), RTDS_msgData); \
	}
#endif /* RTDS_MSG_SEND_Message_TE_TE_SL_Sum_TO_ENV defined */

#ifndef RTDS_MSG_SEND_Message_TE_TE_SL_Sum_TO_ENV_W_MACRO
#define RTDS_MSG_SEND_Message_TE_TE_SL_Sum_TO_ENV_W_MACRO(MACRO_NAME, RTDS_PARAM1, RTDS_PARAM2, RTDS_PARAM3, RTDS_PARAM4, RTDS_PARAM5, RTDS_PARAM6, RTDS_PARAM7, RTDS_PARAM8, RTDS_PARAM9, RTDS_PARAM10, RTDS_PARAM11, RTDS_PARAM12, RTDS_PARAM13, RTDS_PARAM14) \
	{ \
	RTDS_msgData = (unsigned char *)new RTDS_Message_TE_TE_SL_Sum_data(); \
	(((RTDS_Message_TE_TE_SL_Sum_data*)RTDS_msgData)->param1) = (RTDS_PARAM1); \
	(((RTDS_Message_TE_TE_SL_Sum_data*)RTDS_msgData)->param2) = (RTDS_PARAM2); \
	(((RTDS_Message_TE_TE_SL_Sum_data*)RTDS_msgData)->param3) = (RTDS_PARAM3); \
	(((RTDS_Message_TE_TE_SL_Sum_data*)RTDS_msgData)->param4) = (RTDS_PARAM4); \
	(((RTDS_Message_TE_TE_SL_Sum_data*)RTDS_msgData)->param5) = (RTDS_PARAM5); \
	(((RTDS_Message_TE_TE_SL_Sum_data*)RTDS_msgData)->param6) = (RTDS_PARAM6); \
	(((RTDS_Message_TE_TE_SL_Sum_data*)RTDS_msgData)->param7) = (RTDS_PARAM7); \
	(((RTDS_Message_TE_TE_SL_Sum_data*)RTDS_msgData)->param8) = (RTDS_PARAM8); \
	(((RTDS_Message_TE_TE_SL_Sum_data*)RTDS_msgData)->param9) = (RTDS_PARAM9); \
	(((RTDS_Message_TE_TE_SL_Sum_data*)RTDS_msgData)->param10) = (RTDS_PARAM10); \
	((RTDS_Message_TE_TE_SL_Sum_data*)RTDS_msgData)->param11 = RTDS_PARAM11; \
	((RTDS_Message_TE_TE_SL_Sum_data*)RTDS_msgData)->param12 = RTDS_PARAM12; \
	((RTDS_Message_TE_TE_SL_Sum_data*)RTDS_msgData)->param13 = RTDS_PARAM13; \
	((RTDS_Message_TE_TE_SL_Sum_data*)RTDS_msgData)->param14 = RTDS_PARAM14; \
	MACRO_NAME(Message_TE_TE_SL_Sum, sizeof(RTDS_Message_TE_TE_SL_Sum_data), RTDS_msgData); \
	}
#endif /* RTDS_MSG_SEND_Message_TE_TE_SL_Sum_TO_ENV defined */

/* MACRO FOR RECEPTION OF MESSAGE SN_LN_PositionChange */

#ifndef RTDS_MSG_RECEIVE_SN_LN_PositionChange
#define RTDS_MSG_RECEIVE_SN_LN_PositionChange(RTDS_PARAM1, RTDS_PARAM2, RTDS_PARAM3, RTDS_PARAM4) \
	{ \
	RTDS_msgData = (unsigned char *)(RTDS_currentContext->currentMessage->pData); \
	if ( RTDS_msgData != NULL ) \
		{ \
		(RTDS_PARAM1) = (((RTDS_SN_LN_PositionChange_data*)RTDS_msgData)->param1); \
		(RTDS_PARAM2) = (((RTDS_SN_LN_PositionChange_data*)RTDS_msgData)->param2); \
		(RTDS_PARAM3) = (((RTDS_SN_LN_PositionChange_data*)RTDS_msgData)->param3); \
		(RTDS_PARAM4) = (((RTDS_SN_LN_PositionChange_data*)RTDS_msgData)->param4); \
		} \
	else \
		{ \
		RTDS_MSG_INPUT_ERROR; \
		} \
	}
#endif /* RTDS_MSG_RECEIVE_SN_LN_PositionChange defined */

/* MACRO FOR SENDING MESSAGE SN_LN_PositionChange TO A PROCESS NAME */

#ifndef RTDS_MSG_SEND_SN_LN_PositionChange_TO_NAME
#define RTDS_MSG_SEND_SN_LN_PositionChange_TO_NAME(RECEIVER, RECEIVER_NUMBER, RTDS_PARAM1, RTDS_PARAM2, RTDS_PARAM3, RTDS_PARAM4) \
	{ \
	RTDS_msgData = (unsigned char *)new RTDS_SN_LN_PositionChange_data(); \
	(((RTDS_SN_LN_PositionChange_data*)RTDS_msgData)->param1) = (RTDS_PARAM1); \
	(((RTDS_SN_LN_PositionChange_data*)RTDS_msgData)->param2) = (RTDS_PARAM2); \
	(((RTDS_SN_LN_PositionChange_data*)RTDS_msgData)->param3) = (RTDS_PARAM3); \
	(((RTDS_SN_LN_PositionChange_data*)RTDS_msgData)->param4) = (RTDS_PARAM4); \
	RTDS_MSG_QUEUE_SEND_TO_NAME(SN_LN_PositionChange, sizeof(RTDS_SN_LN_PositionChange_data), RTDS_msgData, RECEIVER, RECEIVER_NUMBER); \
	}
#endif /* RTDS_MSG_SEND_SN_LN_PositionChange_TO_NAME defined */

/* MACRO FOR SENDING MESSAGE SN_LN_PositionChange TO A PROCESS ID */

#ifndef RTDS_MSG_SEND_SN_LN_PositionChange_TO_ID
#define RTDS_MSG_SEND_SN_LN_PositionChange_TO_ID(RECEIVER, RTDS_PARAM1, RTDS_PARAM2, RTDS_PARAM3, RTDS_PARAM4) \
	{ \
	RTDS_msgData = (unsigned char *)new RTDS_SN_LN_PositionChange_data(); \
	(((RTDS_SN_LN_PositionChange_data*)RTDS_msgData)->param1) = (RTDS_PARAM1); \
	(((RTDS_SN_LN_PositionChange_data*)RTDS_msgData)->param2) = (RTDS_PARAM2); \
	(((RTDS_SN_LN_PositionChange_data*)RTDS_msgData)->param3) = (RTDS_PARAM3); \
	(((RTDS_SN_LN_PositionChange_data*)RTDS_msgData)->param4) = (RTDS_PARAM4); \
	RTDS_MSG_QUEUE_SEND_TO_ID(SN_LN_PositionChange, sizeof(RTDS_SN_LN_PositionChange_data), RTDS_msgData, RECEIVER); \
	}
#endif /* RTDS_MSG_SEND_SN_LN_PositionChange_TO_ID defined */

/* MACROS FOR SENDING MESSAGE SN_LN_PositionChange TO ENVIRONMENT */

#ifndef RTDS_MSG_SEND_SN_LN_PositionChange_TO_ENV
#define RTDS_MSG_SEND_SN_LN_PositionChange_TO_ENV(RTDS_PARAM1, RTDS_PARAM2, RTDS_PARAM3, RTDS_PARAM4) \
	{ \
	RTDS_msgData = (unsigned char *)new RTDS_SN_LN_PositionChange_data(); \
	(((RTDS_SN_LN_PositionChange_data*)RTDS_msgData)->param1) = (RTDS_PARAM1); \
	(((RTDS_SN_LN_PositionChange_data*)RTDS_msgData)->param2) = (RTDS_PARAM2); \
	(((RTDS_SN_LN_PositionChange_data*)RTDS_msgData)->param3) = (RTDS_PARAM3); \
	(((RTDS_SN_LN_PositionChange_data*)RTDS_msgData)->param4) = (RTDS_PARAM4); \
	RTDS_MSG_QUEUE_SEND_TO_ENV(SN_LN_PositionChange, sizeof(RTDS_SN_LN_PositionChange_data), RTDS_msgData); \
	}
#endif /* RTDS_MSG_SEND_SN_LN_PositionChange_TO_ENV defined */

#ifndef RTDS_MSG_SEND_SN_LN_PositionChange_TO_ENV_W_MACRO
#define RTDS_MSG_SEND_SN_LN_PositionChange_TO_ENV_W_MACRO(MACRO_NAME, RTDS_PARAM1, RTDS_PARAM2, RTDS_PARAM3, RTDS_PARAM4) \
	{ \
	RTDS_msgData = (unsigned char *)new RTDS_SN_LN_PositionChange_data(); \
	(((RTDS_SN_LN_PositionChange_data*)RTDS_msgData)->param1) = (RTDS_PARAM1); \
	(((RTDS_SN_LN_PositionChange_data*)RTDS_msgData)->param2) = (RTDS_PARAM2); \
	(((RTDS_SN_LN_PositionChange_data*)RTDS_msgData)->param3) = (RTDS_PARAM3); \
	(((RTDS_SN_LN_PositionChange_data*)RTDS_msgData)->param4) = (RTDS_PARAM4); \
	MACRO_NAME(SN_LN_PositionChange, sizeof(RTDS_SN_LN_PositionChange_data), RTDS_msgData); \
	}
#endif /* RTDS_MSG_SEND_SN_LN_PositionChange_TO_ENV defined */

/* MACRO FOR RECEPTION OF MESSAGE Message_TE_TE_TS_Use */

#ifndef RTDS_MSG_RECEIVE_Message_TE_TE_TS_Use
#define RTDS_MSG_RECEIVE_Message_TE_TE_TS_Use(RTDS_PARAM1, RTDS_PARAM2, RTDS_PARAM3, RTDS_PARAM4, RTDS_PARAM5, RTDS_PARAM6) \
	{ \
	RTDS_msgData = (unsigned char *)(RTDS_currentContext->currentMessage->pData); \
	if ( RTDS_msgData != NULL ) \
		{ \
		(RTDS_PARAM1) = (((RTDS_Message_TE_TE_TS_Use_data*)RTDS_msgData)->param1); \
		(RTDS_PARAM2) = (((RTDS_Message_TE_TE_TS_Use_data*)RTDS_msgData)->param2); \
		(RTDS_PARAM3) = (((RTDS_Message_TE_TE_TS_Use_data*)RTDS_msgData)->param3); \
		(RTDS_PARAM4) = (((RTDS_Message_TE_TE_TS_Use_data*)RTDS_msgData)->param4); \
		(RTDS_PARAM5) = (((RTDS_Message_TE_TE_TS_Use_data*)RTDS_msgData)->param5); \
		(RTDS_PARAM6) = (((RTDS_Message_TE_TE_TS_Use_data*)RTDS_msgData)->param6); \
		} \
	else \
		{ \
		RTDS_MSG_INPUT_ERROR; \
		} \
	}
#endif /* RTDS_MSG_RECEIVE_Message_TE_TE_TS_Use defined */

/* MACRO FOR SENDING MESSAGE Message_TE_TE_TS_Use TO A PROCESS NAME */

#ifndef RTDS_MSG_SEND_Message_TE_TE_TS_Use_TO_NAME
#define RTDS_MSG_SEND_Message_TE_TE_TS_Use_TO_NAME(RECEIVER, RECEIVER_NUMBER, RTDS_PARAM1, RTDS_PARAM2, RTDS_PARAM3, RTDS_PARAM4, RTDS_PARAM5, RTDS_PARAM6) \
	{ \
	RTDS_msgData = (unsigned char *)new RTDS_Message_TE_TE_TS_Use_data(); \
	(((RTDS_Message_TE_TE_TS_Use_data*)RTDS_msgData)->param1) = (RTDS_PARAM1); \
	(((RTDS_Message_TE_TE_TS_Use_data*)RTDS_msgData)->param2) = (RTDS_PARAM2); \
	(((RTDS_Message_TE_TE_TS_Use_data*)RTDS_msgData)->param3) = (RTDS_PARAM3); \
	(((RTDS_Message_TE_TE_TS_Use_data*)RTDS_msgData)->param4) = (RTDS_PARAM4); \
	(((RTDS_Message_TE_TE_TS_Use_data*)RTDS_msgData)->param5) = (RTDS_PARAM5); \
	(((RTDS_Message_TE_TE_TS_Use_data*)RTDS_msgData)->param6) = (RTDS_PARAM6); \
	RTDS_MSG_QUEUE_SEND_TO_NAME(Message_TE_TE_TS_Use, sizeof(RTDS_Message_TE_TE_TS_Use_data), RTDS_msgData, RECEIVER, RECEIVER_NUMBER); \
	}
#endif /* RTDS_MSG_SEND_Message_TE_TE_TS_Use_TO_NAME defined */

/* MACRO FOR SENDING MESSAGE Message_TE_TE_TS_Use TO A PROCESS ID */

#ifndef RTDS_MSG_SEND_Message_TE_TE_TS_Use_TO_ID
#define RTDS_MSG_SEND_Message_TE_TE_TS_Use_TO_ID(RECEIVER, RTDS_PARAM1, RTDS_PARAM2, RTDS_PARAM3, RTDS_PARAM4, RTDS_PARAM5, RTDS_PARAM6) \
	{ \
	RTDS_msgData = (unsigned char *)new RTDS_Message_TE_TE_TS_Use_data(); \
	(((RTDS_Message_TE_TE_TS_Use_data*)RTDS_msgData)->param1) = (RTDS_PARAM1); \
	(((RTDS_Message_TE_TE_TS_Use_data*)RTDS_msgData)->param2) = (RTDS_PARAM2); \
	(((RTDS_Message_TE_TE_TS_Use_data*)RTDS_msgData)->param3) = (RTDS_PARAM3); \
	(((RTDS_Message_TE_TE_TS_Use_data*)RTDS_msgData)->param4) = (RTDS_PARAM4); \
	(((RTDS_Message_TE_TE_TS_Use_data*)RTDS_msgData)->param5) = (RTDS_PARAM5); \
	(((RTDS_Message_TE_TE_TS_Use_data*)RTDS_msgData)->param6) = (RTDS_PARAM6); \
	RTDS_MSG_QUEUE_SEND_TO_ID(Message_TE_TE_TS_Use, sizeof(RTDS_Message_TE_TE_TS_Use_data), RTDS_msgData, RECEIVER); \
	}
#endif /* RTDS_MSG_SEND_Message_TE_TE_TS_Use_TO_ID defined */

/* MACROS FOR SENDING MESSAGE Message_TE_TE_TS_Use TO ENVIRONMENT */

#ifndef RTDS_MSG_SEND_Message_TE_TE_TS_Use_TO_ENV
#define RTDS_MSG_SEND_Message_TE_TE_TS_Use_TO_ENV(RTDS_PARAM1, RTDS_PARAM2, RTDS_PARAM3, RTDS_PARAM4, RTDS_PARAM5, RTDS_PARAM6) \
	{ \
	RTDS_msgData = (unsigned char *)new RTDS_Message_TE_TE_TS_Use_data(); \
	(((RTDS_Message_TE_TE_TS_Use_data*)RTDS_msgData)->param1) = (RTDS_PARAM1); \
	(((RTDS_Message_TE_TE_TS_Use_data*)RTDS_msgData)->param2) = (RTDS_PARAM2); \
	(((RTDS_Message_TE_TE_TS_Use_data*)RTDS_msgData)->param3) = (RTDS_PARAM3); \
	(((RTDS_Message_TE_TE_TS_Use_data*)RTDS_msgData)->param4) = (RTDS_PARAM4); \
	(((RTDS_Message_TE_TE_TS_Use_data*)RTDS_msgData)->param5) = (RTDS_PARAM5); \
	(((RTDS_Message_TE_TE_TS_Use_data*)RTDS_msgData)->param6) = (RTDS_PARAM6); \
	RTDS_MSG_QUEUE_SEND_TO_ENV(Message_TE_TE_TS_Use, sizeof(RTDS_Message_TE_TE_TS_Use_data), RTDS_msgData); \
	}
#endif /* RTDS_MSG_SEND_Message_TE_TE_TS_Use_TO_ENV defined */

#ifndef RTDS_MSG_SEND_Message_TE_TE_TS_Use_TO_ENV_W_MACRO
#define RTDS_MSG_SEND_Message_TE_TE_TS_Use_TO_ENV_W_MACRO(MACRO_NAME, RTDS_PARAM1, RTDS_PARAM2, RTDS_PARAM3, RTDS_PARAM4, RTDS_PARAM5, RTDS_PARAM6) \
	{ \
	RTDS_msgData = (unsigned char *)new RTDS_Message_TE_TE_TS_Use_data(); \
	(((RTDS_Message_TE_TE_TS_Use_data*)RTDS_msgData)->param1) = (RTDS_PARAM1); \
	(((RTDS_Message_TE_TE_TS_Use_data*)RTDS_msgData)->param2) = (RTDS_PARAM2); \
	(((RTDS_Message_TE_TE_TS_Use_data*)RTDS_msgData)->param3) = (RTDS_PARAM3); \
	(((RTDS_Message_TE_TE_TS_Use_data*)RTDS_msgData)->param4) = (RTDS_PARAM4); \
	(((RTDS_Message_TE_TE_TS_Use_data*)RTDS_msgData)->param5) = (RTDS_PARAM5); \
	(((RTDS_Message_TE_TE_TS_Use_data*)RTDS_msgData)->param6) = (RTDS_PARAM6); \
	MACRO_NAME(Message_TE_TE_TS_Use, sizeof(RTDS_Message_TE_TE_TS_Use_data), RTDS_msgData); \
	}
#endif /* RTDS_MSG_SEND_Message_TE_TE_TS_Use_TO_ENV defined */

/* MACRO FOR RECEPTION OF MESSAGE Message_TE_TE_LS_Sec */

#ifndef RTDS_MSG_RECEIVE_Message_TE_TE_LS_Sec
#define RTDS_MSG_RECEIVE_Message_TE_TE_LS_Sec(RTDS_PARAM1, RTDS_PARAM2, RTDS_PARAM3, RTDS_PARAM4, RTDS_PARAM5) \
	{ \
	RTDS_msgData = (unsigned char *)(RTDS_currentContext->currentMessage->pData); \
	if ( RTDS_msgData != NULL ) \
		{ \
		(RTDS_PARAM1) = (((RTDS_Message_TE_TE_LS_Sec_data*)RTDS_msgData)->param1); \
		(RTDS_PARAM2) = (((RTDS_Message_TE_TE_LS_Sec_data*)RTDS_msgData)->param2); \
		(RTDS_PARAM3) = (((RTDS_Message_TE_TE_LS_Sec_data*)RTDS_msgData)->param3); \
		(RTDS_PARAM4) = (((RTDS_Message_TE_TE_LS_Sec_data*)RTDS_msgData)->param4); \
		RTDS_PARAM5 = ((RTDS_Message_TE_TE_LS_Sec_data*)RTDS_msgData)->param5; \
		} \
	else \
		{ \
		RTDS_MSG_INPUT_ERROR; \
		} \
	}
#endif /* RTDS_MSG_RECEIVE_Message_TE_TE_LS_Sec defined */

/* MACRO FOR SENDING MESSAGE Message_TE_TE_LS_Sec TO A PROCESS NAME */

#ifndef RTDS_MSG_SEND_Message_TE_TE_LS_Sec_TO_NAME
#define RTDS_MSG_SEND_Message_TE_TE_LS_Sec_TO_NAME(RECEIVER, RECEIVER_NUMBER, RTDS_PARAM1, RTDS_PARAM2, RTDS_PARAM3, RTDS_PARAM4, RTDS_PARAM5) \
	{ \
	RTDS_msgData = (unsigned char *)new RTDS_Message_TE_TE_LS_Sec_data(); \
	(((RTDS_Message_TE_TE_LS_Sec_data*)RTDS_msgData)->param1) = (RTDS_PARAM1); \
	(((RTDS_Message_TE_TE_LS_Sec_data*)RTDS_msgData)->param2) = (RTDS_PARAM2); \
	(((RTDS_Message_TE_TE_LS_Sec_data*)RTDS_msgData)->param3) = (RTDS_PARAM3); \
	(((RTDS_Message_TE_TE_LS_Sec_data*)RTDS_msgData)->param4) = (RTDS_PARAM4); \
	((RTDS_Message_TE_TE_LS_Sec_data*)RTDS_msgData)->param5 = RTDS_PARAM5; \
	RTDS_MSG_QUEUE_SEND_TO_NAME(Message_TE_TE_LS_Sec, sizeof(RTDS_Message_TE_TE_LS_Sec_data), RTDS_msgData, RECEIVER, RECEIVER_NUMBER); \
	}
#endif /* RTDS_MSG_SEND_Message_TE_TE_LS_Sec_TO_NAME defined */

/* MACRO FOR SENDING MESSAGE Message_TE_TE_LS_Sec TO A PROCESS ID */

#ifndef RTDS_MSG_SEND_Message_TE_TE_LS_Sec_TO_ID
#define RTDS_MSG_SEND_Message_TE_TE_LS_Sec_TO_ID(RECEIVER, RTDS_PARAM1, RTDS_PARAM2, RTDS_PARAM3, RTDS_PARAM4, RTDS_PARAM5) \
	{ \
	RTDS_msgData = (unsigned char *)new RTDS_Message_TE_TE_LS_Sec_data(); \
	(((RTDS_Message_TE_TE_LS_Sec_data*)RTDS_msgData)->param1) = (RTDS_PARAM1); \
	(((RTDS_Message_TE_TE_LS_Sec_data*)RTDS_msgData)->param2) = (RTDS_PARAM2); \
	(((RTDS_Message_TE_TE_LS_Sec_data*)RTDS_msgData)->param3) = (RTDS_PARAM3); \
	(((RTDS_Message_TE_TE_LS_Sec_data*)RTDS_msgData)->param4) = (RTDS_PARAM4); \
	((RTDS_Message_TE_TE_LS_Sec_data*)RTDS_msgData)->param5 = RTDS_PARAM5; \
	RTDS_MSG_QUEUE_SEND_TO_ID(Message_TE_TE_LS_Sec, sizeof(RTDS_Message_TE_TE_LS_Sec_data), RTDS_msgData, RECEIVER); \
	}
#endif /* RTDS_MSG_SEND_Message_TE_TE_LS_Sec_TO_ID defined */

/* MACROS FOR SENDING MESSAGE Message_TE_TE_LS_Sec TO ENVIRONMENT */

#ifndef RTDS_MSG_SEND_Message_TE_TE_LS_Sec_TO_ENV
#define RTDS_MSG_SEND_Message_TE_TE_LS_Sec_TO_ENV(RTDS_PARAM1, RTDS_PARAM2, RTDS_PARAM3, RTDS_PARAM4, RTDS_PARAM5) \
	{ \
	RTDS_msgData = (unsigned char *)new RTDS_Message_TE_TE_LS_Sec_data(); \
	(((RTDS_Message_TE_TE_LS_Sec_data*)RTDS_msgData)->param1) = (RTDS_PARAM1); \
	(((RTDS_Message_TE_TE_LS_Sec_data*)RTDS_msgData)->param2) = (RTDS_PARAM2); \
	(((RTDS_Message_TE_TE_LS_Sec_data*)RTDS_msgData)->param3) = (RTDS_PARAM3); \
	(((RTDS_Message_TE_TE_LS_Sec_data*)RTDS_msgData)->param4) = (RTDS_PARAM4); \
	((RTDS_Message_TE_TE_LS_Sec_data*)RTDS_msgData)->param5 = RTDS_PARAM5; \
	RTDS_MSG_QUEUE_SEND_TO_ENV(Message_TE_TE_LS_Sec, sizeof(RTDS_Message_TE_TE_LS_Sec_data), RTDS_msgData); \
	}
#endif /* RTDS_MSG_SEND_Message_TE_TE_LS_Sec_TO_ENV defined */

#ifndef RTDS_MSG_SEND_Message_TE_TE_LS_Sec_TO_ENV_W_MACRO
#define RTDS_MSG_SEND_Message_TE_TE_LS_Sec_TO_ENV_W_MACRO(MACRO_NAME, RTDS_PARAM1, RTDS_PARAM2, RTDS_PARAM3, RTDS_PARAM4, RTDS_PARAM5) \
	{ \
	RTDS_msgData = (unsigned char *)new RTDS_Message_TE_TE_LS_Sec_data(); \
	(((RTDS_Message_TE_TE_LS_Sec_data*)RTDS_msgData)->param1) = (RTDS_PARAM1); \
	(((RTDS_Message_TE_TE_LS_Sec_data*)RTDS_msgData)->param2) = (RTDS_PARAM2); \
	(((RTDS_Message_TE_TE_LS_Sec_data*)RTDS_msgData)->param3) = (RTDS_PARAM3); \
	(((RTDS_Message_TE_TE_LS_Sec_data*)RTDS_msgData)->param4) = (RTDS_PARAM4); \
	((RTDS_Message_TE_TE_LS_Sec_data*)RTDS_msgData)->param5 = RTDS_PARAM5; \
	MACRO_NAME(Message_TE_TE_LS_Sec, sizeof(RTDS_Message_TE_TE_LS_Sec_data), RTDS_msgData); \
	}
#endif /* RTDS_MSG_SEND_Message_TE_TE_LS_Sec_TO_ENV defined */

/* MACRO FOR RECEPTION OF MESSAGE SN_LN_Description */

#ifndef RTDS_MSG_RECEIVE_SN_LN_Description
#define RTDS_MSG_RECEIVE_SN_LN_Description(RTDS_PARAM1, RTDS_PARAM2, RTDS_PARAM3, RTDS_PARAM4, RTDS_PARAM5, RTDS_PARAM6, RTDS_PARAM7, RTDS_PARAM8, RTDS_PARAM9, RTDS_PARAM10, RTDS_PARAM11, RTDS_PARAM12) \
	{ \
	RTDS_msgData = (unsigned char *)(RTDS_currentContext->currentMessage->pData); \
	if ( RTDS_msgData != NULL ) \
		{ \
		(RTDS_PARAM1) = (((RTDS_SN_LN_Description_data*)RTDS_msgData)->param1); \
		(RTDS_PARAM2) = (((RTDS_SN_LN_Description_data*)RTDS_msgData)->param2); \
		(RTDS_PARAM3) = (((RTDS_SN_LN_Description_data*)RTDS_msgData)->param3); \
		(RTDS_PARAM4) = (((RTDS_SN_LN_Description_data*)RTDS_msgData)->param4); \
		(RTDS_PARAM5) = (((RTDS_SN_LN_Description_data*)RTDS_msgData)->param5); \
		(RTDS_PARAM6) = (((RTDS_SN_LN_Description_data*)RTDS_msgData)->param6); \
		(RTDS_PARAM7) = (((RTDS_SN_LN_Description_data*)RTDS_msgData)->param7); \
		(RTDS_PARAM8) = (((RTDS_SN_LN_Description_data*)RTDS_msgData)->param8); \
		RTDS_PARAM9 = ((RTDS_SN_LN_Description_data*)RTDS_msgData)->param9; \
		RTDS_PARAM10 = ((RTDS_SN_LN_Description_data*)RTDS_msgData)->param10; \
		RTDS_PARAM11 = ((RTDS_SN_LN_Description_data*)RTDS_msgData)->param11; \
		RTDS_PARAM12 = ((RTDS_SN_LN_Description_data*)RTDS_msgData)->param12; \
		} \
	else \
		{ \
		RTDS_MSG_INPUT_ERROR; \
		} \
	}
#endif /* RTDS_MSG_RECEIVE_SN_LN_Description defined */

/* MACRO FOR SENDING MESSAGE SN_LN_Description TO A PROCESS NAME */

#ifndef RTDS_MSG_SEND_SN_LN_Description_TO_NAME
#define RTDS_MSG_SEND_SN_LN_Description_TO_NAME(RECEIVER, RECEIVER_NUMBER, RTDS_PARAM1, RTDS_PARAM2, RTDS_PARAM3, RTDS_PARAM4, RTDS_PARAM5, RTDS_PARAM6, RTDS_PARAM7, RTDS_PARAM8, RTDS_PARAM9, RTDS_PARAM10, RTDS_PARAM11, RTDS_PARAM12) \
	{ \
	RTDS_msgData = (unsigned char *)new RTDS_SN_LN_Description_data(); \
	(((RTDS_SN_LN_Description_data*)RTDS_msgData)->param1) = (RTDS_PARAM1); \
	(((RTDS_SN_LN_Description_data*)RTDS_msgData)->param2) = (RTDS_PARAM2); \
	(((RTDS_SN_LN_Description_data*)RTDS_msgData)->param3) = (RTDS_PARAM3); \
	(((RTDS_SN_LN_Description_data*)RTDS_msgData)->param4) = (RTDS_PARAM4); \
	(((RTDS_SN_LN_Description_data*)RTDS_msgData)->param5) = (RTDS_PARAM5); \
	(((RTDS_SN_LN_Description_data*)RTDS_msgData)->param6) = (RTDS_PARAM6); \
	(((RTDS_SN_LN_Description_data*)RTDS_msgData)->param7) = (RTDS_PARAM7); \
	(((RTDS_SN_LN_Description_data*)RTDS_msgData)->param8) = (RTDS_PARAM8); \
	((RTDS_SN_LN_Description_data*)RTDS_msgData)->param9 = RTDS_PARAM9; \
	((RTDS_SN_LN_Description_data*)RTDS_msgData)->param10 = RTDS_PARAM10; \
	((RTDS_SN_LN_Description_data*)RTDS_msgData)->param11 = RTDS_PARAM11; \
	((RTDS_SN_LN_Description_data*)RTDS_msgData)->param12 = RTDS_PARAM12; \
	RTDS_MSG_QUEUE_SEND_TO_NAME(SN_LN_Description, sizeof(RTDS_SN_LN_Description_data), RTDS_msgData, RECEIVER, RECEIVER_NUMBER); \
	}
#endif /* RTDS_MSG_SEND_SN_LN_Description_TO_NAME defined */

/* MACRO FOR SENDING MESSAGE SN_LN_Description TO A PROCESS ID */

#ifndef RTDS_MSG_SEND_SN_LN_Description_TO_ID
#define RTDS_MSG_SEND_SN_LN_Description_TO_ID(RECEIVER, RTDS_PARAM1, RTDS_PARAM2, RTDS_PARAM3, RTDS_PARAM4, RTDS_PARAM5, RTDS_PARAM6, RTDS_PARAM7, RTDS_PARAM8, RTDS_PARAM9, RTDS_PARAM10, RTDS_PARAM11, RTDS_PARAM12) \
	{ \
	RTDS_msgData = (unsigned char *)new RTDS_SN_LN_Description_data(); \
	(((RTDS_SN_LN_Description_data*)RTDS_msgData)->param1) = (RTDS_PARAM1); \
	(((RTDS_SN_LN_Description_data*)RTDS_msgData)->param2) = (RTDS_PARAM2); \
	(((RTDS_SN_LN_Description_data*)RTDS_msgData)->param3) = (RTDS_PARAM3); \
	(((RTDS_SN_LN_Description_data*)RTDS_msgData)->param4) = (RTDS_PARAM4); \
	(((RTDS_SN_LN_Description_data*)RTDS_msgData)->param5) = (RTDS_PARAM5); \
	(((RTDS_SN_LN_Description_data*)RTDS_msgData)->param6) = (RTDS_PARAM6); \
	(((RTDS_SN_LN_Description_data*)RTDS_msgData)->param7) = (RTDS_PARAM7); \
	(((RTDS_SN_LN_Description_data*)RTDS_msgData)->param8) = (RTDS_PARAM8); \
	((RTDS_SN_LN_Description_data*)RTDS_msgData)->param9 = RTDS_PARAM9; \
	((RTDS_SN_LN_Description_data*)RTDS_msgData)->param10 = RTDS_PARAM10; \
	((RTDS_SN_LN_Description_data*)RTDS_msgData)->param11 = RTDS_PARAM11; \
	((RTDS_SN_LN_Description_data*)RTDS_msgData)->param12 = RTDS_PARAM12; \
	RTDS_MSG_QUEUE_SEND_TO_ID(SN_LN_Description, sizeof(RTDS_SN_LN_Description_data), RTDS_msgData, RECEIVER); \
	}
#endif /* RTDS_MSG_SEND_SN_LN_Description_TO_ID defined */

/* MACROS FOR SENDING MESSAGE SN_LN_Description TO ENVIRONMENT */

#ifndef RTDS_MSG_SEND_SN_LN_Description_TO_ENV
#define RTDS_MSG_SEND_SN_LN_Description_TO_ENV(RTDS_PARAM1, RTDS_PARAM2, RTDS_PARAM3, RTDS_PARAM4, RTDS_PARAM5, RTDS_PARAM6, RTDS_PARAM7, RTDS_PARAM8, RTDS_PARAM9, RTDS_PARAM10, RTDS_PARAM11, RTDS_PARAM12) \
	{ \
	RTDS_msgData = (unsigned char *)new RTDS_SN_LN_Description_data(); \
	(((RTDS_SN_LN_Description_data*)RTDS_msgData)->param1) = (RTDS_PARAM1); \
	(((RTDS_SN_LN_Description_data*)RTDS_msgData)->param2) = (RTDS_PARAM2); \
	(((RTDS_SN_LN_Description_data*)RTDS_msgData)->param3) = (RTDS_PARAM3); \
	(((RTDS_SN_LN_Description_data*)RTDS_msgData)->param4) = (RTDS_PARAM4); \
	(((RTDS_SN_LN_Description_data*)RTDS_msgData)->param5) = (RTDS_PARAM5); \
	(((RTDS_SN_LN_Description_data*)RTDS_msgData)->param6) = (RTDS_PARAM6); \
	(((RTDS_SN_LN_Description_data*)RTDS_msgData)->param7) = (RTDS_PARAM7); \
	(((RTDS_SN_LN_Description_data*)RTDS_msgData)->param8) = (RTDS_PARAM8); \
	((RTDS_SN_LN_Description_data*)RTDS_msgData)->param9 = RTDS_PARAM9; \
	((RTDS_SN_LN_Description_data*)RTDS_msgData)->param10 = RTDS_PARAM10; \
	((RTDS_SN_LN_Description_data*)RTDS_msgData)->param11 = RTDS_PARAM11; \
	((RTDS_SN_LN_Description_data*)RTDS_msgData)->param12 = RTDS_PARAM12; \
	RTDS_MSG_QUEUE_SEND_TO_ENV(SN_LN_Description, sizeof(RTDS_SN_LN_Description_data), RTDS_msgData); \
	}
#endif /* RTDS_MSG_SEND_SN_LN_Description_TO_ENV defined */

#ifndef RTDS_MSG_SEND_SN_LN_Description_TO_ENV_W_MACRO
#define RTDS_MSG_SEND_SN_LN_Description_TO_ENV_W_MACRO(MACRO_NAME, RTDS_PARAM1, RTDS_PARAM2, RTDS_PARAM3, RTDS_PARAM4, RTDS_PARAM5, RTDS_PARAM6, RTDS_PARAM7, RTDS_PARAM8, RTDS_PARAM9, RTDS_PARAM10, RTDS_PARAM11, RTDS_PARAM12) \
	{ \
	RTDS_msgData = (unsigned char *)new RTDS_SN_LN_Description_data(); \
	(((RTDS_SN_LN_Description_data*)RTDS_msgData)->param1) = (RTDS_PARAM1); \
	(((RTDS_SN_LN_Description_data*)RTDS_msgData)->param2) = (RTDS_PARAM2); \
	(((RTDS_SN_LN_Description_data*)RTDS_msgData)->param3) = (RTDS_PARAM3); \
	(((RTDS_SN_LN_Description_data*)RTDS_msgData)->param4) = (RTDS_PARAM4); \
	(((RTDS_SN_LN_Description_data*)RTDS_msgData)->param5) = (RTDS_PARAM5); \
	(((RTDS_SN_LN_Description_data*)RTDS_msgData)->param6) = (RTDS_PARAM6); \
	(((RTDS_SN_LN_Description_data*)RTDS_msgData)->param7) = (RTDS_PARAM7); \
	(((RTDS_SN_LN_Description_data*)RTDS_msgData)->param8) = (RTDS_PARAM8); \
	((RTDS_SN_LN_Description_data*)RTDS_msgData)->param9 = RTDS_PARAM9; \
	((RTDS_SN_LN_Description_data*)RTDS_msgData)->param10 = RTDS_PARAM10; \
	((RTDS_SN_LN_Description_data*)RTDS_msgData)->param11 = RTDS_PARAM11; \
	((RTDS_SN_LN_Description_data*)RTDS_msgData)->param12 = RTDS_PARAM12; \
	MACRO_NAME(SN_LN_Description, sizeof(RTDS_SN_LN_Description_data), RTDS_msgData); \
	}
#endif /* RTDS_MSG_SEND_SN_LN_Description_TO_ENV defined */

/* MACRO FOR RECEPTION OF MESSAGE Message_TE_TE_TL_ALN */

#ifndef RTDS_MSG_RECEIVE_Message_TE_TE_TL_ALN
#define RTDS_MSG_RECEIVE_Message_TE_TE_TL_ALN(RTDS_PARAM1, RTDS_PARAM2, RTDS_PARAM3, RTDS_PARAM4) \
	{ \
	RTDS_msgData = (unsigned char *)(RTDS_currentContext->currentMessage->pData); \
	if ( RTDS_msgData != NULL ) \
		{ \
		(RTDS_PARAM1) = (((RTDS_Message_TE_TE_TL_ALN_data*)RTDS_msgData)->param1); \
		(RTDS_PARAM2) = (((RTDS_Message_TE_TE_TL_ALN_data*)RTDS_msgData)->param2); \
		(RTDS_PARAM3) = (((RTDS_Message_TE_TE_TL_ALN_data*)RTDS_msgData)->param3); \
		(RTDS_PARAM4) = (((RTDS_Message_TE_TE_TL_ALN_data*)RTDS_msgData)->param4); \
		} \
	else \
		{ \
		RTDS_MSG_INPUT_ERROR; \
		} \
	}
#endif /* RTDS_MSG_RECEIVE_Message_TE_TE_TL_ALN defined */

/* MACRO FOR SENDING MESSAGE Message_TE_TE_TL_ALN TO A PROCESS NAME */

#ifndef RTDS_MSG_SEND_Message_TE_TE_TL_ALN_TO_NAME
#define RTDS_MSG_SEND_Message_TE_TE_TL_ALN_TO_NAME(RECEIVER, RECEIVER_NUMBER, RTDS_PARAM1, RTDS_PARAM2, RTDS_PARAM3, RTDS_PARAM4) \
	{ \
	RTDS_msgData = (unsigned char *)new RTDS_Message_TE_TE_TL_ALN_data(); \
	(((RTDS_Message_TE_TE_TL_ALN_data*)RTDS_msgData)->param1) = (RTDS_PARAM1); \
	(((RTDS_Message_TE_TE_TL_ALN_data*)RTDS_msgData)->param2) = (RTDS_PARAM2); \
	(((RTDS_Message_TE_TE_TL_ALN_data*)RTDS_msgData)->param3) = (RTDS_PARAM3); \
	(((RTDS_Message_TE_TE_TL_ALN_data*)RTDS_msgData)->param4) = (RTDS_PARAM4); \
	RTDS_MSG_QUEUE_SEND_TO_NAME(Message_TE_TE_TL_ALN, sizeof(RTDS_Message_TE_TE_TL_ALN_data), RTDS_msgData, RECEIVER, RECEIVER_NUMBER); \
	}
#endif /* RTDS_MSG_SEND_Message_TE_TE_TL_ALN_TO_NAME defined */

/* MACRO FOR SENDING MESSAGE Message_TE_TE_TL_ALN TO A PROCESS ID */

#ifndef RTDS_MSG_SEND_Message_TE_TE_TL_ALN_TO_ID
#define RTDS_MSG_SEND_Message_TE_TE_TL_ALN_TO_ID(RECEIVER, RTDS_PARAM1, RTDS_PARAM2, RTDS_PARAM3, RTDS_PARAM4) \
	{ \
	RTDS_msgData = (unsigned char *)new RTDS_Message_TE_TE_TL_ALN_data(); \
	(((RTDS_Message_TE_TE_TL_ALN_data*)RTDS_msgData)->param1) = (RTDS_PARAM1); \
	(((RTDS_Message_TE_TE_TL_ALN_data*)RTDS_msgData)->param2) = (RTDS_PARAM2); \
	(((RTDS_Message_TE_TE_TL_ALN_data*)RTDS_msgData)->param3) = (RTDS_PARAM3); \
	(((RTDS_Message_TE_TE_TL_ALN_data*)RTDS_msgData)->param4) = (RTDS_PARAM4); \
	RTDS_MSG_QUEUE_SEND_TO_ID(Message_TE_TE_TL_ALN, sizeof(RTDS_Message_TE_TE_TL_ALN_data), RTDS_msgData, RECEIVER); \
	}
#endif /* RTDS_MSG_SEND_Message_TE_TE_TL_ALN_TO_ID defined */

/* MACROS FOR SENDING MESSAGE Message_TE_TE_TL_ALN TO ENVIRONMENT */

#ifndef RTDS_MSG_SEND_Message_TE_TE_TL_ALN_TO_ENV
#define RTDS_MSG_SEND_Message_TE_TE_TL_ALN_TO_ENV(RTDS_PARAM1, RTDS_PARAM2, RTDS_PARAM3, RTDS_PARAM4) \
	{ \
	RTDS_msgData = (unsigned char *)new RTDS_Message_TE_TE_TL_ALN_data(); \
	(((RTDS_Message_TE_TE_TL_ALN_data*)RTDS_msgData)->param1) = (RTDS_PARAM1); \
	(((RTDS_Message_TE_TE_TL_ALN_data*)RTDS_msgData)->param2) = (RTDS_PARAM2); \
	(((RTDS_Message_TE_TE_TL_ALN_data*)RTDS_msgData)->param3) = (RTDS_PARAM3); \
	(((RTDS_Message_TE_TE_TL_ALN_data*)RTDS_msgData)->param4) = (RTDS_PARAM4); \
	RTDS_MSG_QUEUE_SEND_TO_ENV(Message_TE_TE_TL_ALN, sizeof(RTDS_Message_TE_TE_TL_ALN_data), RTDS_msgData); \
	}
#endif /* RTDS_MSG_SEND_Message_TE_TE_TL_ALN_TO_ENV defined */

#ifndef RTDS_MSG_SEND_Message_TE_TE_TL_ALN_TO_ENV_W_MACRO
#define RTDS_MSG_SEND_Message_TE_TE_TL_ALN_TO_ENV_W_MACRO(MACRO_NAME, RTDS_PARAM1, RTDS_PARAM2, RTDS_PARAM3, RTDS_PARAM4) \
	{ \
	RTDS_msgData = (unsigned char *)new RTDS_Message_TE_TE_TL_ALN_data(); \
	(((RTDS_Message_TE_TE_TL_ALN_data*)RTDS_msgData)->param1) = (RTDS_PARAM1); \
	(((RTDS_Message_TE_TE_TL_ALN_data*)RTDS_msgData)->param2) = (RTDS_PARAM2); \
	(((RTDS_Message_TE_TE_TL_ALN_data*)RTDS_msgData)->param3) = (RTDS_PARAM3); \
	(((RTDS_Message_TE_TE_TL_ALN_data*)RTDS_msgData)->param4) = (RTDS_PARAM4); \
	MACRO_NAME(Message_TE_TE_TL_ALN, sizeof(RTDS_Message_TE_TE_TL_ALN_data), RTDS_msgData); \
	}
#endif /* RTDS_MSG_SEND_Message_TE_TE_TL_ALN_TO_ENV defined */

/* MACRO FOR RECEPTION OF MESSAGE Message_TE_TE_LS_Pri */

#ifndef RTDS_MSG_RECEIVE_Message_TE_TE_LS_Pri
#define RTDS_MSG_RECEIVE_Message_TE_TE_LS_Pri(RTDS_PARAM1, RTDS_PARAM2, RTDS_PARAM3, RTDS_PARAM4, RTDS_PARAM5) \
	{ \
	RTDS_msgData = (unsigned char *)(RTDS_currentContext->currentMessage->pData); \
	if ( RTDS_msgData != NULL ) \
		{ \
		(RTDS_PARAM1) = (((RTDS_Message_TE_TE_LS_Pri_data*)RTDS_msgData)->param1); \
		(RTDS_PARAM2) = (((RTDS_Message_TE_TE_LS_Pri_data*)RTDS_msgData)->param2); \
		(RTDS_PARAM3) = (((RTDS_Message_TE_TE_LS_Pri_data*)RTDS_msgData)->param3); \
		(RTDS_PARAM4) = (((RTDS_Message_TE_TE_LS_Pri_data*)RTDS_msgData)->param4); \
		RTDS_PARAM5 = ((RTDS_Message_TE_TE_LS_Pri_data*)RTDS_msgData)->param5; \
		} \
	else \
		{ \
		RTDS_MSG_INPUT_ERROR; \
		} \
	}
#endif /* RTDS_MSG_RECEIVE_Message_TE_TE_LS_Pri defined */

/* MACRO FOR SENDING MESSAGE Message_TE_TE_LS_Pri TO A PROCESS NAME */

#ifndef RTDS_MSG_SEND_Message_TE_TE_LS_Pri_TO_NAME
#define RTDS_MSG_SEND_Message_TE_TE_LS_Pri_TO_NAME(RECEIVER, RECEIVER_NUMBER, RTDS_PARAM1, RTDS_PARAM2, RTDS_PARAM3, RTDS_PARAM4, RTDS_PARAM5) \
	{ \
	RTDS_msgData = (unsigned char *)new RTDS_Message_TE_TE_LS_Pri_data(); \
	(((RTDS_Message_TE_TE_LS_Pri_data*)RTDS_msgData)->param1) = (RTDS_PARAM1); \
	(((RTDS_Message_TE_TE_LS_Pri_data*)RTDS_msgData)->param2) = (RTDS_PARAM2); \
	(((RTDS_Message_TE_TE_LS_Pri_data*)RTDS_msgData)->param3) = (RTDS_PARAM3); \
	(((RTDS_Message_TE_TE_LS_Pri_data*)RTDS_msgData)->param4) = (RTDS_PARAM4); \
	((RTDS_Message_TE_TE_LS_Pri_data*)RTDS_msgData)->param5 = RTDS_PARAM5; \
	RTDS_MSG_QUEUE_SEND_TO_NAME(Message_TE_TE_LS_Pri, sizeof(RTDS_Message_TE_TE_LS_Pri_data), RTDS_msgData, RECEIVER, RECEIVER_NUMBER); \
	}
#endif /* RTDS_MSG_SEND_Message_TE_TE_LS_Pri_TO_NAME defined */

/* MACRO FOR SENDING MESSAGE Message_TE_TE_LS_Pri TO A PROCESS ID */

#ifndef RTDS_MSG_SEND_Message_TE_TE_LS_Pri_TO_ID
#define RTDS_MSG_SEND_Message_TE_TE_LS_Pri_TO_ID(RECEIVER, RTDS_PARAM1, RTDS_PARAM2, RTDS_PARAM3, RTDS_PARAM4, RTDS_PARAM5) \
	{ \
	RTDS_msgData = (unsigned char *)new RTDS_Message_TE_TE_LS_Pri_data(); \
	(((RTDS_Message_TE_TE_LS_Pri_data*)RTDS_msgData)->param1) = (RTDS_PARAM1); \
	(((RTDS_Message_TE_TE_LS_Pri_data*)RTDS_msgData)->param2) = (RTDS_PARAM2); \
	(((RTDS_Message_TE_TE_LS_Pri_data*)RTDS_msgData)->param3) = (RTDS_PARAM3); \
	(((RTDS_Message_TE_TE_LS_Pri_data*)RTDS_msgData)->param4) = (RTDS_PARAM4); \
	((RTDS_Message_TE_TE_LS_Pri_data*)RTDS_msgData)->param5 = RTDS_PARAM5; \
	RTDS_MSG_QUEUE_SEND_TO_ID(Message_TE_TE_LS_Pri, sizeof(RTDS_Message_TE_TE_LS_Pri_data), RTDS_msgData, RECEIVER); \
	}
#endif /* RTDS_MSG_SEND_Message_TE_TE_LS_Pri_TO_ID defined */

/* MACROS FOR SENDING MESSAGE Message_TE_TE_LS_Pri TO ENVIRONMENT */

#ifndef RTDS_MSG_SEND_Message_TE_TE_LS_Pri_TO_ENV
#define RTDS_MSG_SEND_Message_TE_TE_LS_Pri_TO_ENV(RTDS_PARAM1, RTDS_PARAM2, RTDS_PARAM3, RTDS_PARAM4, RTDS_PARAM5) \
	{ \
	RTDS_msgData = (unsigned char *)new RTDS_Message_TE_TE_LS_Pri_data(); \
	(((RTDS_Message_TE_TE_LS_Pri_data*)RTDS_msgData)->param1) = (RTDS_PARAM1); \
	(((RTDS_Message_TE_TE_LS_Pri_data*)RTDS_msgData)->param2) = (RTDS_PARAM2); \
	(((RTDS_Message_TE_TE_LS_Pri_data*)RTDS_msgData)->param3) = (RTDS_PARAM3); \
	(((RTDS_Message_TE_TE_LS_Pri_data*)RTDS_msgData)->param4) = (RTDS_PARAM4); \
	((RTDS_Message_TE_TE_LS_Pri_data*)RTDS_msgData)->param5 = RTDS_PARAM5; \
	RTDS_MSG_QUEUE_SEND_TO_ENV(Message_TE_TE_LS_Pri, sizeof(RTDS_Message_TE_TE_LS_Pri_data), RTDS_msgData); \
	}
#endif /* RTDS_MSG_SEND_Message_TE_TE_LS_Pri_TO_ENV defined */

#ifndef RTDS_MSG_SEND_Message_TE_TE_LS_Pri_TO_ENV_W_MACRO
#define RTDS_MSG_SEND_Message_TE_TE_LS_Pri_TO_ENV_W_MACRO(MACRO_NAME, RTDS_PARAM1, RTDS_PARAM2, RTDS_PARAM3, RTDS_PARAM4, RTDS_PARAM5) \
	{ \
	RTDS_msgData = (unsigned char *)new RTDS_Message_TE_TE_LS_Pri_data(); \
	(((RTDS_Message_TE_TE_LS_Pri_data*)RTDS_msgData)->param1) = (RTDS_PARAM1); \
	(((RTDS_Message_TE_TE_LS_Pri_data*)RTDS_msgData)->param2) = (RTDS_PARAM2); \
	(((RTDS_Message_TE_TE_LS_Pri_data*)RTDS_msgData)->param3) = (RTDS_PARAM3); \
	(((RTDS_Message_TE_TE_LS_Pri_data*)RTDS_msgData)->param4) = (RTDS_PARAM4); \
	((RTDS_Message_TE_TE_LS_Pri_data*)RTDS_msgData)->param5 = RTDS_PARAM5; \
	MACRO_NAME(Message_TE_TE_LS_Pri, sizeof(RTDS_Message_TE_TE_LS_Pri_data), RTDS_msgData); \
	}
#endif /* RTDS_MSG_SEND_Message_TE_TE_LS_Pri_TO_ENV defined */

/* MACRO FOR RECEPTION OF MESSAGE StartLN */

#ifndef RTDS_MSG_RECEIVE_StartLN
#define RTDS_MSG_RECEIVE_StartLN(RTDS_PARAM1, RTDS_PARAM2, RTDS_PARAM3) \
	{ \
	RTDS_msgData = (unsigned char *)(RTDS_currentContext->currentMessage->pData); \
	if ( RTDS_msgData != NULL ) \
		{ \
		(RTDS_PARAM1) = (((RTDS_StartLN_data*)RTDS_msgData)->param1); \
		(RTDS_PARAM2) = (((RTDS_StartLN_data*)RTDS_msgData)->param2); \
		RTDS_PARAM3 = ((RTDS_StartLN_data*)RTDS_msgData)->param3; \
		} \
	else \
		{ \
		RTDS_MSG_INPUT_ERROR; \
		} \
	}
#endif /* RTDS_MSG_RECEIVE_StartLN defined */

/* MACRO FOR SENDING MESSAGE StartLN TO A PROCESS NAME */

#ifndef RTDS_MSG_SEND_StartLN_TO_NAME
#define RTDS_MSG_SEND_StartLN_TO_NAME(RECEIVER, RECEIVER_NUMBER, RTDS_PARAM1, RTDS_PARAM2, RTDS_PARAM3) \
	{ \
	RTDS_msgData = (unsigned char *)new RTDS_StartLN_data(); \
	(((RTDS_StartLN_data*)RTDS_msgData)->param1) = (RTDS_PARAM1); \
	(((RTDS_StartLN_data*)RTDS_msgData)->param2) = (RTDS_PARAM2); \
	((RTDS_StartLN_data*)RTDS_msgData)->param3 = RTDS_PARAM3; \
	RTDS_MSG_QUEUE_SEND_TO_NAME(StartLN, sizeof(RTDS_StartLN_data), RTDS_msgData, RECEIVER, RECEIVER_NUMBER); \
	}
#endif /* RTDS_MSG_SEND_StartLN_TO_NAME defined */

/* MACRO FOR SENDING MESSAGE StartLN TO A PROCESS ID */

#ifndef RTDS_MSG_SEND_StartLN_TO_ID
#define RTDS_MSG_SEND_StartLN_TO_ID(RECEIVER, RTDS_PARAM1, RTDS_PARAM2, RTDS_PARAM3) \
	{ \
	RTDS_msgData = (unsigned char *)new RTDS_StartLN_data(); \
	(((RTDS_StartLN_data*)RTDS_msgData)->param1) = (RTDS_PARAM1); \
	(((RTDS_StartLN_data*)RTDS_msgData)->param2) = (RTDS_PARAM2); \
	((RTDS_StartLN_data*)RTDS_msgData)->param3 = RTDS_PARAM3; \
	RTDS_MSG_QUEUE_SEND_TO_ID(StartLN, sizeof(RTDS_StartLN_data), RTDS_msgData, RECEIVER); \
	}
#endif /* RTDS_MSG_SEND_StartLN_TO_ID defined */

/* MACROS FOR SENDING MESSAGE StartLN TO ENVIRONMENT */

#ifndef RTDS_MSG_SEND_StartLN_TO_ENV
#define RTDS_MSG_SEND_StartLN_TO_ENV(RTDS_PARAM1, RTDS_PARAM2, RTDS_PARAM3) \
	{ \
	RTDS_msgData = (unsigned char *)new RTDS_StartLN_data(); \
	(((RTDS_StartLN_data*)RTDS_msgData)->param1) = (RTDS_PARAM1); \
	(((RTDS_StartLN_data*)RTDS_msgData)->param2) = (RTDS_PARAM2); \
	((RTDS_StartLN_data*)RTDS_msgData)->param3 = RTDS_PARAM3; \
	RTDS_MSG_QUEUE_SEND_TO_ENV(StartLN, sizeof(RTDS_StartLN_data), RTDS_msgData); \
	}
#endif /* RTDS_MSG_SEND_StartLN_TO_ENV defined */

#ifndef RTDS_MSG_SEND_StartLN_TO_ENV_W_MACRO
#define RTDS_MSG_SEND_StartLN_TO_ENV_W_MACRO(MACRO_NAME, RTDS_PARAM1, RTDS_PARAM2, RTDS_PARAM3) \
	{ \
	RTDS_msgData = (unsigned char *)new RTDS_StartLN_data(); \
	(((RTDS_StartLN_data*)RTDS_msgData)->param1) = (RTDS_PARAM1); \
	(((RTDS_StartLN_data*)RTDS_msgData)->param2) = (RTDS_PARAM2); \
	((RTDS_StartLN_data*)RTDS_msgData)->param3 = RTDS_PARAM3; \
	MACRO_NAME(StartLN, sizeof(RTDS_StartLN_data), RTDS_msgData); \
	}
#endif /* RTDS_MSG_SEND_StartLN_TO_ENV defined */

/* MACRO FOR RECEPTION OF MESSAGE Message_TE_TE_SL_PoC */

#ifndef RTDS_MSG_RECEIVE_Message_TE_TE_SL_PoC
#define RTDS_MSG_RECEIVE_Message_TE_TE_SL_PoC(RTDS_PARAM1, RTDS_PARAM2, RTDS_PARAM3, RTDS_PARAM4, RTDS_PARAM5) \
	{ \
	RTDS_msgData = (unsigned char *)(RTDS_currentContext->currentMessage->pData); \
	if ( RTDS_msgData != NULL ) \
		{ \
		(RTDS_PARAM1) = (((RTDS_Message_TE_TE_SL_PoC_data*)RTDS_msgData)->param1); \
		(RTDS_PARAM2) = (((RTDS_Message_TE_TE_SL_PoC_data*)RTDS_msgData)->param2); \
		(RTDS_PARAM3) = (((RTDS_Message_TE_TE_SL_PoC_data*)RTDS_msgData)->param3); \
		(RTDS_PARAM4) = (((RTDS_Message_TE_TE_SL_PoC_data*)RTDS_msgData)->param4); \
		(RTDS_PARAM5) = (((RTDS_Message_TE_TE_SL_PoC_data*)RTDS_msgData)->param5); \
		} \
	else \
		{ \
		RTDS_MSG_INPUT_ERROR; \
		} \
	}
#endif /* RTDS_MSG_RECEIVE_Message_TE_TE_SL_PoC defined */

/* MACRO FOR SENDING MESSAGE Message_TE_TE_SL_PoC TO A PROCESS NAME */

#ifndef RTDS_MSG_SEND_Message_TE_TE_SL_PoC_TO_NAME
#define RTDS_MSG_SEND_Message_TE_TE_SL_PoC_TO_NAME(RECEIVER, RECEIVER_NUMBER, RTDS_PARAM1, RTDS_PARAM2, RTDS_PARAM3, RTDS_PARAM4, RTDS_PARAM5) \
	{ \
	RTDS_msgData = (unsigned char *)new RTDS_Message_TE_TE_SL_PoC_data(); \
	(((RTDS_Message_TE_TE_SL_PoC_data*)RTDS_msgData)->param1) = (RTDS_PARAM1); \
	(((RTDS_Message_TE_TE_SL_PoC_data*)RTDS_msgData)->param2) = (RTDS_PARAM2); \
	(((RTDS_Message_TE_TE_SL_PoC_data*)RTDS_msgData)->param3) = (RTDS_PARAM3); \
	(((RTDS_Message_TE_TE_SL_PoC_data*)RTDS_msgData)->param4) = (RTDS_PARAM4); \
	(((RTDS_Message_TE_TE_SL_PoC_data*)RTDS_msgData)->param5) = (RTDS_PARAM5); \
	RTDS_MSG_QUEUE_SEND_TO_NAME(Message_TE_TE_SL_PoC, sizeof(RTDS_Message_TE_TE_SL_PoC_data), RTDS_msgData, RECEIVER, RECEIVER_NUMBER); \
	}
#endif /* RTDS_MSG_SEND_Message_TE_TE_SL_PoC_TO_NAME defined */

/* MACRO FOR SENDING MESSAGE Message_TE_TE_SL_PoC TO A PROCESS ID */

#ifndef RTDS_MSG_SEND_Message_TE_TE_SL_PoC_TO_ID
#define RTDS_MSG_SEND_Message_TE_TE_SL_PoC_TO_ID(RECEIVER, RTDS_PARAM1, RTDS_PARAM2, RTDS_PARAM3, RTDS_PARAM4, RTDS_PARAM5) \
	{ \
	RTDS_msgData = (unsigned char *)new RTDS_Message_TE_TE_SL_PoC_data(); \
	(((RTDS_Message_TE_TE_SL_PoC_data*)RTDS_msgData)->param1) = (RTDS_PARAM1); \
	(((RTDS_Message_TE_TE_SL_PoC_data*)RTDS_msgData)->param2) = (RTDS_PARAM2); \
	(((RTDS_Message_TE_TE_SL_PoC_data*)RTDS_msgData)->param3) = (RTDS_PARAM3); \
	(((RTDS_Message_TE_TE_SL_PoC_data*)RTDS_msgData)->param4) = (RTDS_PARAM4); \
	(((RTDS_Message_TE_TE_SL_PoC_data*)RTDS_msgData)->param5) = (RTDS_PARAM5); \
	RTDS_MSG_QUEUE_SEND_TO_ID(Message_TE_TE_SL_PoC, sizeof(RTDS_Message_TE_TE_SL_PoC_data), RTDS_msgData, RECEIVER); \
	}
#endif /* RTDS_MSG_SEND_Message_TE_TE_SL_PoC_TO_ID defined */

/* MACROS FOR SENDING MESSAGE Message_TE_TE_SL_PoC TO ENVIRONMENT */

#ifndef RTDS_MSG_SEND_Message_TE_TE_SL_PoC_TO_ENV
#define RTDS_MSG_SEND_Message_TE_TE_SL_PoC_TO_ENV(RTDS_PARAM1, RTDS_PARAM2, RTDS_PARAM3, RTDS_PARAM4, RTDS_PARAM5) \
	{ \
	RTDS_msgData = (unsigned char *)new RTDS_Message_TE_TE_SL_PoC_data(); \
	(((RTDS_Message_TE_TE_SL_PoC_data*)RTDS_msgData)->param1) = (RTDS_PARAM1); \
	(((RTDS_Message_TE_TE_SL_PoC_data*)RTDS_msgData)->param2) = (RTDS_PARAM2); \
	(((RTDS_Message_TE_TE_SL_PoC_data*)RTDS_msgData)->param3) = (RTDS_PARAM3); \
	(((RTDS_Message_TE_TE_SL_PoC_data*)RTDS_msgData)->param4) = (RTDS_PARAM4); \
	(((RTDS_Message_TE_TE_SL_PoC_data*)RTDS_msgData)->param5) = (RTDS_PARAM5); \
	RTDS_MSG_QUEUE_SEND_TO_ENV(Message_TE_TE_SL_PoC, sizeof(RTDS_Message_TE_TE_SL_PoC_data), RTDS_msgData); \
	}
#endif /* RTDS_MSG_SEND_Message_TE_TE_SL_PoC_TO_ENV defined */

#ifndef RTDS_MSG_SEND_Message_TE_TE_SL_PoC_TO_ENV_W_MACRO
#define RTDS_MSG_SEND_Message_TE_TE_SL_PoC_TO_ENV_W_MACRO(MACRO_NAME, RTDS_PARAM1, RTDS_PARAM2, RTDS_PARAM3, RTDS_PARAM4, RTDS_PARAM5) \
	{ \
	RTDS_msgData = (unsigned char *)new RTDS_Message_TE_TE_SL_PoC_data(); \
	(((RTDS_Message_TE_TE_SL_PoC_data*)RTDS_msgData)->param1) = (RTDS_PARAM1); \
	(((RTDS_Message_TE_TE_SL_PoC_data*)RTDS_msgData)->param2) = (RTDS_PARAM2); \
	(((RTDS_Message_TE_TE_SL_PoC_data*)RTDS_msgData)->param3) = (RTDS_PARAM3); \
	(((RTDS_Message_TE_TE_SL_PoC_data*)RTDS_msgData)->param4) = (RTDS_PARAM4); \
	(((RTDS_Message_TE_TE_SL_PoC_data*)RTDS_msgData)->param5) = (RTDS_PARAM5); \
	MACRO_NAME(Message_TE_TE_SL_PoC, sizeof(RTDS_Message_TE_TE_SL_PoC_data), RTDS_msgData); \
	}
#endif /* RTDS_MSG_SEND_Message_TE_TE_SL_PoC_TO_ENV defined */

/* MACRO FOR RECEPTION OF MESSAGE SN_LN_Summary */

#ifndef RTDS_MSG_RECEIVE_SN_LN_Summary
#define RTDS_MSG_RECEIVE_SN_LN_Summary(RTDS_PARAM1, RTDS_PARAM2, RTDS_PARAM3, RTDS_PARAM4, RTDS_PARAM5, RTDS_PARAM6, RTDS_PARAM7, RTDS_PARAM8, RTDS_PARAM9, RTDS_PARAM10, RTDS_PARAM11, RTDS_PARAM12, RTDS_PARAM13) \
	{ \
	RTDS_msgData = (unsigned char *)(RTDS_currentContext->currentMessage->pData); \
	if ( RTDS_msgData != NULL ) \
		{ \
		(RTDS_PARAM1) = (((RTDS_SN_LN_Summary_data*)RTDS_msgData)->param1); \
		(RTDS_PARAM2) = (((RTDS_SN_LN_Summary_data*)RTDS_msgData)->param2); \
		(RTDS_PARAM3) = (((RTDS_SN_LN_Summary_data*)RTDS_msgData)->param3); \
		(RTDS_PARAM4) = (((RTDS_SN_LN_Summary_data*)RTDS_msgData)->param4); \
		(RTDS_PARAM5) = (((RTDS_SN_LN_Summary_data*)RTDS_msgData)->param5); \
		(RTDS_PARAM6) = (((RTDS_SN_LN_Summary_data*)RTDS_msgData)->param6); \
		(RTDS_PARAM7) = (((RTDS_SN_LN_Summary_data*)RTDS_msgData)->param7); \
		(RTDS_PARAM8) = (((RTDS_SN_LN_Summary_data*)RTDS_msgData)->param8); \
		(RTDS_PARAM9) = (((RTDS_SN_LN_Summary_data*)RTDS_msgData)->param9); \
		RTDS_PARAM10 = ((RTDS_SN_LN_Summary_data*)RTDS_msgData)->param10; \
		RTDS_PARAM11 = ((RTDS_SN_LN_Summary_data*)RTDS_msgData)->param11; \
		RTDS_PARAM12 = ((RTDS_SN_LN_Summary_data*)RTDS_msgData)->param12; \
		RTDS_PARAM13 = ((RTDS_SN_LN_Summary_data*)RTDS_msgData)->param13; \
		} \
	else \
		{ \
		RTDS_MSG_INPUT_ERROR; \
		} \
	}
#endif /* RTDS_MSG_RECEIVE_SN_LN_Summary defined */

/* MACRO FOR SENDING MESSAGE SN_LN_Summary TO A PROCESS NAME */

#ifndef RTDS_MSG_SEND_SN_LN_Summary_TO_NAME
#define RTDS_MSG_SEND_SN_LN_Summary_TO_NAME(RECEIVER, RECEIVER_NUMBER, RTDS_PARAM1, RTDS_PARAM2, RTDS_PARAM3, RTDS_PARAM4, RTDS_PARAM5, RTDS_PARAM6, RTDS_PARAM7, RTDS_PARAM8, RTDS_PARAM9, RTDS_PARAM10, RTDS_PARAM11, RTDS_PARAM12, RTDS_PARAM13) \
	{ \
	RTDS_msgData = (unsigned char *)new RTDS_SN_LN_Summary_data(); \
	(((RTDS_SN_LN_Summary_data*)RTDS_msgData)->param1) = (RTDS_PARAM1); \
	(((RTDS_SN_LN_Summary_data*)RTDS_msgData)->param2) = (RTDS_PARAM2); \
	(((RTDS_SN_LN_Summary_data*)RTDS_msgData)->param3) = (RTDS_PARAM3); \
	(((RTDS_SN_LN_Summary_data*)RTDS_msgData)->param4) = (RTDS_PARAM4); \
	(((RTDS_SN_LN_Summary_data*)RTDS_msgData)->param5) = (RTDS_PARAM5); \
	(((RTDS_SN_LN_Summary_data*)RTDS_msgData)->param6) = (RTDS_PARAM6); \
	(((RTDS_SN_LN_Summary_data*)RTDS_msgData)->param7) = (RTDS_PARAM7); \
	(((RTDS_SN_LN_Summary_data*)RTDS_msgData)->param8) = (RTDS_PARAM8); \
	(((RTDS_SN_LN_Summary_data*)RTDS_msgData)->param9) = (RTDS_PARAM9); \
	((RTDS_SN_LN_Summary_data*)RTDS_msgData)->param10 = RTDS_PARAM10; \
	((RTDS_SN_LN_Summary_data*)RTDS_msgData)->param11 = RTDS_PARAM11; \
	((RTDS_SN_LN_Summary_data*)RTDS_msgData)->param12 = RTDS_PARAM12; \
	((RTDS_SN_LN_Summary_data*)RTDS_msgData)->param13 = RTDS_PARAM13; \
	RTDS_MSG_QUEUE_SEND_TO_NAME(SN_LN_Summary, sizeof(RTDS_SN_LN_Summary_data), RTDS_msgData, RECEIVER, RECEIVER_NUMBER); \
	}
#endif /* RTDS_MSG_SEND_SN_LN_Summary_TO_NAME defined */

/* MACRO FOR SENDING MESSAGE SN_LN_Summary TO A PROCESS ID */

#ifndef RTDS_MSG_SEND_SN_LN_Summary_TO_ID
#define RTDS_MSG_SEND_SN_LN_Summary_TO_ID(RECEIVER, RTDS_PARAM1, RTDS_PARAM2, RTDS_PARAM3, RTDS_PARAM4, RTDS_PARAM5, RTDS_PARAM6, RTDS_PARAM7, RTDS_PARAM8, RTDS_PARAM9, RTDS_PARAM10, RTDS_PARAM11, RTDS_PARAM12, RTDS_PARAM13) \
	{ \
	RTDS_msgData = (unsigned char *)new RTDS_SN_LN_Summary_data(); \
	(((RTDS_SN_LN_Summary_data*)RTDS_msgData)->param1) = (RTDS_PARAM1); \
	(((RTDS_SN_LN_Summary_data*)RTDS_msgData)->param2) = (RTDS_PARAM2); \
	(((RTDS_SN_LN_Summary_data*)RTDS_msgData)->param3) = (RTDS_PARAM3); \
	(((RTDS_SN_LN_Summary_data*)RTDS_msgData)->param4) = (RTDS_PARAM4); \
	(((RTDS_SN_LN_Summary_data*)RTDS_msgData)->param5) = (RTDS_PARAM5); \
	(((RTDS_SN_LN_Summary_data*)RTDS_msgData)->param6) = (RTDS_PARAM6); \
	(((RTDS_SN_LN_Summary_data*)RTDS_msgData)->param7) = (RTDS_PARAM7); \
	(((RTDS_SN_LN_Summary_data*)RTDS_msgData)->param8) = (RTDS_PARAM8); \
	(((RTDS_SN_LN_Summary_data*)RTDS_msgData)->param9) = (RTDS_PARAM9); \
	((RTDS_SN_LN_Summary_data*)RTDS_msgData)->param10 = RTDS_PARAM10; \
	((RTDS_SN_LN_Summary_data*)RTDS_msgData)->param11 = RTDS_PARAM11; \
	((RTDS_SN_LN_Summary_data*)RTDS_msgData)->param12 = RTDS_PARAM12; \
	((RTDS_SN_LN_Summary_data*)RTDS_msgData)->param13 = RTDS_PARAM13; \
	RTDS_MSG_QUEUE_SEND_TO_ID(SN_LN_Summary, sizeof(RTDS_SN_LN_Summary_data), RTDS_msgData, RECEIVER); \
	}
#endif /* RTDS_MSG_SEND_SN_LN_Summary_TO_ID defined */

/* MACROS FOR SENDING MESSAGE SN_LN_Summary TO ENVIRONMENT */

#ifndef RTDS_MSG_SEND_SN_LN_Summary_TO_ENV
#define RTDS_MSG_SEND_SN_LN_Summary_TO_ENV(RTDS_PARAM1, RTDS_PARAM2, RTDS_PARAM3, RTDS_PARAM4, RTDS_PARAM5, RTDS_PARAM6, RTDS_PARAM7, RTDS_PARAM8, RTDS_PARAM9, RTDS_PARAM10, RTDS_PARAM11, RTDS_PARAM12, RTDS_PARAM13) \
	{ \
	RTDS_msgData = (unsigned char *)new RTDS_SN_LN_Summary_data(); \
	(((RTDS_SN_LN_Summary_data*)RTDS_msgData)->param1) = (RTDS_PARAM1); \
	(((RTDS_SN_LN_Summary_data*)RTDS_msgData)->param2) = (RTDS_PARAM2); \
	(((RTDS_SN_LN_Summary_data*)RTDS_msgData)->param3) = (RTDS_PARAM3); \
	(((RTDS_SN_LN_Summary_data*)RTDS_msgData)->param4) = (RTDS_PARAM4); \
	(((RTDS_SN_LN_Summary_data*)RTDS_msgData)->param5) = (RTDS_PARAM5); \
	(((RTDS_SN_LN_Summary_data*)RTDS_msgData)->param6) = (RTDS_PARAM6); \
	(((RTDS_SN_LN_Summary_data*)RTDS_msgData)->param7) = (RTDS_PARAM7); \
	(((RTDS_SN_LN_Summary_data*)RTDS_msgData)->param8) = (RTDS_PARAM8); \
	(((RTDS_SN_LN_Summary_data*)RTDS_msgData)->param9) = (RTDS_PARAM9); \
	((RTDS_SN_LN_Summary_data*)RTDS_msgData)->param10 = RTDS_PARAM10; \
	((RTDS_SN_LN_Summary_data*)RTDS_msgData)->param11 = RTDS_PARAM11; \
	((RTDS_SN_LN_Summary_data*)RTDS_msgData)->param12 = RTDS_PARAM12; \
	((RTDS_SN_LN_Summary_data*)RTDS_msgData)->param13 = RTDS_PARAM13; \
	RTDS_MSG_QUEUE_SEND_TO_ENV(SN_LN_Summary, sizeof(RTDS_SN_LN_Summary_data), RTDS_msgData); \
	}
#endif /* RTDS_MSG_SEND_SN_LN_Summary_TO_ENV defined */

#ifndef RTDS_MSG_SEND_SN_LN_Summary_TO_ENV_W_MACRO
#define RTDS_MSG_SEND_SN_LN_Summary_TO_ENV_W_MACRO(MACRO_NAME, RTDS_PARAM1, RTDS_PARAM2, RTDS_PARAM3, RTDS_PARAM4, RTDS_PARAM5, RTDS_PARAM6, RTDS_PARAM7, RTDS_PARAM8, RTDS_PARAM9, RTDS_PARAM10, RTDS_PARAM11, RTDS_PARAM12, RTDS_PARAM13) \
	{ \
	RTDS_msgData = (unsigned char *)new RTDS_SN_LN_Summary_data(); \
	(((RTDS_SN_LN_Summary_data*)RTDS_msgData)->param1) = (RTDS_PARAM1); \
	(((RTDS_SN_LN_Summary_data*)RTDS_msgData)->param2) = (RTDS_PARAM2); \
	(((RTDS_SN_LN_Summary_data*)RTDS_msgData)->param3) = (RTDS_PARAM3); \
	(((RTDS_SN_LN_Summary_data*)RTDS_msgData)->param4) = (RTDS_PARAM4); \
	(((RTDS_SN_LN_Summary_data*)RTDS_msgData)->param5) = (RTDS_PARAM5); \
	(((RTDS_SN_LN_Summary_data*)RTDS_msgData)->param6) = (RTDS_PARAM6); \
	(((RTDS_SN_LN_Summary_data*)RTDS_msgData)->param7) = (RTDS_PARAM7); \
	(((RTDS_SN_LN_Summary_data*)RTDS_msgData)->param8) = (RTDS_PARAM8); \
	(((RTDS_SN_LN_Summary_data*)RTDS_msgData)->param9) = (RTDS_PARAM9); \
	((RTDS_SN_LN_Summary_data*)RTDS_msgData)->param10 = RTDS_PARAM10; \
	((RTDS_SN_LN_Summary_data*)RTDS_msgData)->param11 = RTDS_PARAM11; \
	((RTDS_SN_LN_Summary_data*)RTDS_msgData)->param12 = RTDS_PARAM12; \
	((RTDS_SN_LN_Summary_data*)RTDS_msgData)->param13 = RTDS_PARAM13; \
	MACRO_NAME(SN_LN_Summary, sizeof(RTDS_SN_LN_Summary_data), RTDS_msgData); \
	}
#endif /* RTDS_MSG_SEND_SN_LN_Summary_TO_ENV defined */

/* MACRO FOR RECEPTION OF MESSAGE LNsInNetwork */

#ifndef RTDS_MSG_RECEIVE_LNsInNetwork
#define RTDS_MSG_RECEIVE_LNsInNetwork(RTDS_PARAM1) \
	{ \
	RTDS_msgData = (unsigned char *)(RTDS_currentContext->currentMessage->pData); \
	if ( RTDS_msgData != NULL ) \
		{ \
		(RTDS_PARAM1) = (((RTDS_LNsInNetwork_data*)RTDS_msgData)->param1); \
		} \
	else \
		{ \
		RTDS_MSG_INPUT_ERROR; \
		} \
	}
#endif /* RTDS_MSG_RECEIVE_LNsInNetwork defined */

/* MACRO FOR SENDING MESSAGE LNsInNetwork TO A PROCESS NAME */

#ifndef RTDS_MSG_SEND_LNsInNetwork_TO_NAME
#define RTDS_MSG_SEND_LNsInNetwork_TO_NAME(RECEIVER, RECEIVER_NUMBER, RTDS_PARAM1) \
	{ \
	RTDS_msgData = (unsigned char *)new RTDS_LNsInNetwork_data(); \
	(((RTDS_LNsInNetwork_data*)RTDS_msgData)->param1) = (RTDS_PARAM1); \
	RTDS_MSG_QUEUE_SEND_TO_NAME(LNsInNetwork, sizeof(RTDS_LNsInNetwork_data), RTDS_msgData, RECEIVER, RECEIVER_NUMBER); \
	}
#endif /* RTDS_MSG_SEND_LNsInNetwork_TO_NAME defined */

/* MACRO FOR SENDING MESSAGE LNsInNetwork TO A PROCESS ID */

#ifndef RTDS_MSG_SEND_LNsInNetwork_TO_ID
#define RTDS_MSG_SEND_LNsInNetwork_TO_ID(RECEIVER, RTDS_PARAM1) \
	{ \
	RTDS_msgData = (unsigned char *)new RTDS_LNsInNetwork_data(); \
	(((RTDS_LNsInNetwork_data*)RTDS_msgData)->param1) = (RTDS_PARAM1); \
	RTDS_MSG_QUEUE_SEND_TO_ID(LNsInNetwork, sizeof(RTDS_LNsInNetwork_data), RTDS_msgData, RECEIVER); \
	}
#endif /* RTDS_MSG_SEND_LNsInNetwork_TO_ID defined */

/* MACROS FOR SENDING MESSAGE LNsInNetwork TO ENVIRONMENT */

#ifndef RTDS_MSG_SEND_LNsInNetwork_TO_ENV
#define RTDS_MSG_SEND_LNsInNetwork_TO_ENV(RTDS_PARAM1) \
	{ \
	RTDS_msgData = (unsigned char *)new RTDS_LNsInNetwork_data(); \
	(((RTDS_LNsInNetwork_data*)RTDS_msgData)->param1) = (RTDS_PARAM1); \
	RTDS_MSG_QUEUE_SEND_TO_ENV(LNsInNetwork, sizeof(RTDS_LNsInNetwork_data), RTDS_msgData); \
	}
#endif /* RTDS_MSG_SEND_LNsInNetwork_TO_ENV defined */

#ifndef RTDS_MSG_SEND_LNsInNetwork_TO_ENV_W_MACRO
#define RTDS_MSG_SEND_LNsInNetwork_TO_ENV_W_MACRO(MACRO_NAME, RTDS_PARAM1) \
	{ \
	RTDS_msgData = (unsigned char *)new RTDS_LNsInNetwork_data(); \
	(((RTDS_LNsInNetwork_data*)RTDS_msgData)->param1) = (RTDS_PARAM1); \
	MACRO_NAME(LNsInNetwork, sizeof(RTDS_LNsInNetwork_data), RTDS_msgData); \
	}
#endif /* RTDS_MSG_SEND_LNsInNetwork_TO_ENV defined */

/* MACRO FOR RECEPTION OF MESSAGE GNsInNetwork */

#ifndef RTDS_MSG_RECEIVE_GNsInNetwork
#define RTDS_MSG_RECEIVE_GNsInNetwork(RTDS_PARAM1) \
	{ \
	RTDS_msgData = (unsigned char *)(RTDS_currentContext->currentMessage->pData); \
	if ( RTDS_msgData != NULL ) \
		{ \
		(RTDS_PARAM1) = (((RTDS_GNsInNetwork_data*)RTDS_msgData)->param1); \
		} \
	else \
		{ \
		RTDS_MSG_INPUT_ERROR; \
		} \
	}
#endif /* RTDS_MSG_RECEIVE_GNsInNetwork defined */

/* MACRO FOR SENDING MESSAGE GNsInNetwork TO A PROCESS NAME */

#ifndef RTDS_MSG_SEND_GNsInNetwork_TO_NAME
#define RTDS_MSG_SEND_GNsInNetwork_TO_NAME(RECEIVER, RECEIVER_NUMBER, RTDS_PARAM1) \
	{ \
	RTDS_msgData = (unsigned char *)new RTDS_GNsInNetwork_data(); \
	(((RTDS_GNsInNetwork_data*)RTDS_msgData)->param1) = (RTDS_PARAM1); \
	RTDS_MSG_QUEUE_SEND_TO_NAME(GNsInNetwork, sizeof(RTDS_GNsInNetwork_data), RTDS_msgData, RECEIVER, RECEIVER_NUMBER); \
	}
#endif /* RTDS_MSG_SEND_GNsInNetwork_TO_NAME defined */

/* MACRO FOR SENDING MESSAGE GNsInNetwork TO A PROCESS ID */

#ifndef RTDS_MSG_SEND_GNsInNetwork_TO_ID
#define RTDS_MSG_SEND_GNsInNetwork_TO_ID(RECEIVER, RTDS_PARAM1) \
	{ \
	RTDS_msgData = (unsigned char *)new RTDS_GNsInNetwork_data(); \
	(((RTDS_GNsInNetwork_data*)RTDS_msgData)->param1) = (RTDS_PARAM1); \
	RTDS_MSG_QUEUE_SEND_TO_ID(GNsInNetwork, sizeof(RTDS_GNsInNetwork_data), RTDS_msgData, RECEIVER); \
	}
#endif /* RTDS_MSG_SEND_GNsInNetwork_TO_ID defined */

/* MACROS FOR SENDING MESSAGE GNsInNetwork TO ENVIRONMENT */

#ifndef RTDS_MSG_SEND_GNsInNetwork_TO_ENV
#define RTDS_MSG_SEND_GNsInNetwork_TO_ENV(RTDS_PARAM1) \
	{ \
	RTDS_msgData = (unsigned char *)new RTDS_GNsInNetwork_data(); \
	(((RTDS_GNsInNetwork_data*)RTDS_msgData)->param1) = (RTDS_PARAM1); \
	RTDS_MSG_QUEUE_SEND_TO_ENV(GNsInNetwork, sizeof(RTDS_GNsInNetwork_data), RTDS_msgData); \
	}
#endif /* RTDS_MSG_SEND_GNsInNetwork_TO_ENV defined */

#ifndef RTDS_MSG_SEND_GNsInNetwork_TO_ENV_W_MACRO
#define RTDS_MSG_SEND_GNsInNetwork_TO_ENV_W_MACRO(MACRO_NAME, RTDS_PARAM1) \
	{ \
	RTDS_msgData = (unsigned char *)new RTDS_GNsInNetwork_data(); \
	(((RTDS_GNsInNetwork_data*)RTDS_msgData)->param1) = (RTDS_PARAM1); \
	MACRO_NAME(GNsInNetwork, sizeof(RTDS_GNsInNetwork_data), RTDS_msgData); \
	}
#endif /* RTDS_MSG_SEND_GNsInNetwork_TO_ENV defined */

/* MACRO FOR RECEPTION OF MESSAGE LN_SN_FalseAlarm */

#ifndef RTDS_MSG_RECEIVE_LN_SN_FalseAlarm
#define RTDS_MSG_RECEIVE_LN_SN_FalseAlarm(RTDS_PARAM1, RTDS_PARAM2, RTDS_PARAM3) \
	{ \
	RTDS_msgData = (unsigned char *)(RTDS_currentContext->currentMessage->pData); \
	if ( RTDS_msgData != NULL ) \
		{ \
		(RTDS_PARAM1) = (((RTDS_LN_SN_FalseAlarm_data*)RTDS_msgData)->param1); \
		(RTDS_PARAM2) = (((RTDS_LN_SN_FalseAlarm_data*)RTDS_msgData)->param2); \
		(RTDS_PARAM3) = (((RTDS_LN_SN_FalseAlarm_data*)RTDS_msgData)->param3); \
		} \
	else \
		{ \
		RTDS_MSG_INPUT_ERROR; \
		} \
	}
#endif /* RTDS_MSG_RECEIVE_LN_SN_FalseAlarm defined */

/* MACRO FOR SENDING MESSAGE LN_SN_FalseAlarm TO A PROCESS NAME */

#ifndef RTDS_MSG_SEND_LN_SN_FalseAlarm_TO_NAME
#define RTDS_MSG_SEND_LN_SN_FalseAlarm_TO_NAME(RECEIVER, RECEIVER_NUMBER, RTDS_PARAM1, RTDS_PARAM2, RTDS_PARAM3) \
	{ \
	RTDS_msgData = (unsigned char *)new RTDS_LN_SN_FalseAlarm_data(); \
	(((RTDS_LN_SN_FalseAlarm_data*)RTDS_msgData)->param1) = (RTDS_PARAM1); \
	(((RTDS_LN_SN_FalseAlarm_data*)RTDS_msgData)->param2) = (RTDS_PARAM2); \
	(((RTDS_LN_SN_FalseAlarm_data*)RTDS_msgData)->param3) = (RTDS_PARAM3); \
	RTDS_MSG_QUEUE_SEND_TO_NAME(LN_SN_FalseAlarm, sizeof(RTDS_LN_SN_FalseAlarm_data), RTDS_msgData, RECEIVER, RECEIVER_NUMBER); \
	}
#endif /* RTDS_MSG_SEND_LN_SN_FalseAlarm_TO_NAME defined */

/* MACRO FOR SENDING MESSAGE LN_SN_FalseAlarm TO A PROCESS ID */

#ifndef RTDS_MSG_SEND_LN_SN_FalseAlarm_TO_ID
#define RTDS_MSG_SEND_LN_SN_FalseAlarm_TO_ID(RECEIVER, RTDS_PARAM1, RTDS_PARAM2, RTDS_PARAM3) \
	{ \
	RTDS_msgData = (unsigned char *)new RTDS_LN_SN_FalseAlarm_data(); \
	(((RTDS_LN_SN_FalseAlarm_data*)RTDS_msgData)->param1) = (RTDS_PARAM1); \
	(((RTDS_LN_SN_FalseAlarm_data*)RTDS_msgData)->param2) = (RTDS_PARAM2); \
	(((RTDS_LN_SN_FalseAlarm_data*)RTDS_msgData)->param3) = (RTDS_PARAM3); \
	RTDS_MSG_QUEUE_SEND_TO_ID(LN_SN_FalseAlarm, sizeof(RTDS_LN_SN_FalseAlarm_data), RTDS_msgData, RECEIVER); \
	}
#endif /* RTDS_MSG_SEND_LN_SN_FalseAlarm_TO_ID defined */

/* MACROS FOR SENDING MESSAGE LN_SN_FalseAlarm TO ENVIRONMENT */

#ifndef RTDS_MSG_SEND_LN_SN_FalseAlarm_TO_ENV
#define RTDS_MSG_SEND_LN_SN_FalseAlarm_TO_ENV(RTDS_PARAM1, RTDS_PARAM2, RTDS_PARAM3) \
	{ \
	RTDS_msgData = (unsigned char *)new RTDS_LN_SN_FalseAlarm_data(); \
	(((RTDS_LN_SN_FalseAlarm_data*)RTDS_msgData)->param1) = (RTDS_PARAM1); \
	(((RTDS_LN_SN_FalseAlarm_data*)RTDS_msgData)->param2) = (RTDS_PARAM2); \
	(((RTDS_LN_SN_FalseAlarm_data*)RTDS_msgData)->param3) = (RTDS_PARAM3); \
	RTDS_MSG_QUEUE_SEND_TO_ENV(LN_SN_FalseAlarm, sizeof(RTDS_LN_SN_FalseAlarm_data), RTDS_msgData); \
	}
#endif /* RTDS_MSG_SEND_LN_SN_FalseAlarm_TO_ENV defined */

#ifndef RTDS_MSG_SEND_LN_SN_FalseAlarm_TO_ENV_W_MACRO
#define RTDS_MSG_SEND_LN_SN_FalseAlarm_TO_ENV_W_MACRO(MACRO_NAME, RTDS_PARAM1, RTDS_PARAM2, RTDS_PARAM3) \
	{ \
	RTDS_msgData = (unsigned char *)new RTDS_LN_SN_FalseAlarm_data(); \
	(((RTDS_LN_SN_FalseAlarm_data*)RTDS_msgData)->param1) = (RTDS_PARAM1); \
	(((RTDS_LN_SN_FalseAlarm_data*)RTDS_msgData)->param2) = (RTDS_PARAM2); \
	(((RTDS_LN_SN_FalseAlarm_data*)RTDS_msgData)->param3) = (RTDS_PARAM3); \
	MACRO_NAME(LN_SN_FalseAlarm, sizeof(RTDS_LN_SN_FalseAlarm_data), RTDS_msgData); \
	}
#endif /* RTDS_MSG_SEND_LN_SN_FalseAlarm_TO_ENV defined */

/* MACRO FOR RECEPTION OF MESSAGE Message_TE_TE_LS_Ala */

#ifndef RTDS_MSG_RECEIVE_Message_TE_TE_LS_Ala
#define RTDS_MSG_RECEIVE_Message_TE_TE_LS_Ala(RTDS_PARAM1, RTDS_PARAM2, RTDS_PARAM3, RTDS_PARAM4, RTDS_PARAM5) \
	{ \
	RTDS_msgData = (unsigned char *)(RTDS_currentContext->currentMessage->pData); \
	if ( RTDS_msgData != NULL ) \
		{ \
		(RTDS_PARAM1) = (((RTDS_Message_TE_TE_LS_Ala_data*)RTDS_msgData)->param1); \
		(RTDS_PARAM2) = (((RTDS_Message_TE_TE_LS_Ala_data*)RTDS_msgData)->param2); \
		(RTDS_PARAM3) = (((RTDS_Message_TE_TE_LS_Ala_data*)RTDS_msgData)->param3); \
		RTDS_PARAM4 = ((RTDS_Message_TE_TE_LS_Ala_data*)RTDS_msgData)->param4; \
		(RTDS_PARAM5) = (((RTDS_Message_TE_TE_LS_Ala_data*)RTDS_msgData)->param5); \
		} \
	else \
		{ \
		RTDS_MSG_INPUT_ERROR; \
		} \
	}
#endif /* RTDS_MSG_RECEIVE_Message_TE_TE_LS_Ala defined */

/* MACRO FOR SENDING MESSAGE Message_TE_TE_LS_Ala TO A PROCESS NAME */

#ifndef RTDS_MSG_SEND_Message_TE_TE_LS_Ala_TO_NAME
#define RTDS_MSG_SEND_Message_TE_TE_LS_Ala_TO_NAME(RECEIVER, RECEIVER_NUMBER, RTDS_PARAM1, RTDS_PARAM2, RTDS_PARAM3, RTDS_PARAM4, RTDS_PARAM5) \
	{ \
	RTDS_msgData = (unsigned char *)new RTDS_Message_TE_TE_LS_Ala_data(); \
	(((RTDS_Message_TE_TE_LS_Ala_data*)RTDS_msgData)->param1) = (RTDS_PARAM1); \
	(((RTDS_Message_TE_TE_LS_Ala_data*)RTDS_msgData)->param2) = (RTDS_PARAM2); \
	(((RTDS_Message_TE_TE_LS_Ala_data*)RTDS_msgData)->param3) = (RTDS_PARAM3); \
	((RTDS_Message_TE_TE_LS_Ala_data*)RTDS_msgData)->param4 = RTDS_PARAM4; \
	(((RTDS_Message_TE_TE_LS_Ala_data*)RTDS_msgData)->param5) = (RTDS_PARAM5); \
	RTDS_MSG_QUEUE_SEND_TO_NAME(Message_TE_TE_LS_Ala, sizeof(RTDS_Message_TE_TE_LS_Ala_data), RTDS_msgData, RECEIVER, RECEIVER_NUMBER); \
	}
#endif /* RTDS_MSG_SEND_Message_TE_TE_LS_Ala_TO_NAME defined */

/* MACRO FOR SENDING MESSAGE Message_TE_TE_LS_Ala TO A PROCESS ID */

#ifndef RTDS_MSG_SEND_Message_TE_TE_LS_Ala_TO_ID
#define RTDS_MSG_SEND_Message_TE_TE_LS_Ala_TO_ID(RECEIVER, RTDS_PARAM1, RTDS_PARAM2, RTDS_PARAM3, RTDS_PARAM4, RTDS_PARAM5) \
	{ \
	RTDS_msgData = (unsigned char *)new RTDS_Message_TE_TE_LS_Ala_data(); \
	(((RTDS_Message_TE_TE_LS_Ala_data*)RTDS_msgData)->param1) = (RTDS_PARAM1); \
	(((RTDS_Message_TE_TE_LS_Ala_data*)RTDS_msgData)->param2) = (RTDS_PARAM2); \
	(((RTDS_Message_TE_TE_LS_Ala_data*)RTDS_msgData)->param3) = (RTDS_PARAM3); \
	((RTDS_Message_TE_TE_LS_Ala_data*)RTDS_msgData)->param4 = RTDS_PARAM4; \
	(((RTDS_Message_TE_TE_LS_Ala_data*)RTDS_msgData)->param5) = (RTDS_PARAM5); \
	RTDS_MSG_QUEUE_SEND_TO_ID(Message_TE_TE_LS_Ala, sizeof(RTDS_Message_TE_TE_LS_Ala_data), RTDS_msgData, RECEIVER); \
	}
#endif /* RTDS_MSG_SEND_Message_TE_TE_LS_Ala_TO_ID defined */

/* MACROS FOR SENDING MESSAGE Message_TE_TE_LS_Ala TO ENVIRONMENT */

#ifndef RTDS_MSG_SEND_Message_TE_TE_LS_Ala_TO_ENV
#define RTDS_MSG_SEND_Message_TE_TE_LS_Ala_TO_ENV(RTDS_PARAM1, RTDS_PARAM2, RTDS_PARAM3, RTDS_PARAM4, RTDS_PARAM5) \
	{ \
	RTDS_msgData = (unsigned char *)new RTDS_Message_TE_TE_LS_Ala_data(); \
	(((RTDS_Message_TE_TE_LS_Ala_data*)RTDS_msgData)->param1) = (RTDS_PARAM1); \
	(((RTDS_Message_TE_TE_LS_Ala_data*)RTDS_msgData)->param2) = (RTDS_PARAM2); \
	(((RTDS_Message_TE_TE_LS_Ala_data*)RTDS_msgData)->param3) = (RTDS_PARAM3); \
	((RTDS_Message_TE_TE_LS_Ala_data*)RTDS_msgData)->param4 = RTDS_PARAM4; \
	(((RTDS_Message_TE_TE_LS_Ala_data*)RTDS_msgData)->param5) = (RTDS_PARAM5); \
	RTDS_MSG_QUEUE_SEND_TO_ENV(Message_TE_TE_LS_Ala, sizeof(RTDS_Message_TE_TE_LS_Ala_data), RTDS_msgData); \
	}
#endif /* RTDS_MSG_SEND_Message_TE_TE_LS_Ala_TO_ENV defined */

#ifndef RTDS_MSG_SEND_Message_TE_TE_LS_Ala_TO_ENV_W_MACRO
#define RTDS_MSG_SEND_Message_TE_TE_LS_Ala_TO_ENV_W_MACRO(MACRO_NAME, RTDS_PARAM1, RTDS_PARAM2, RTDS_PARAM3, RTDS_PARAM4, RTDS_PARAM5) \
	{ \
	RTDS_msgData = (unsigned char *)new RTDS_Message_TE_TE_LS_Ala_data(); \
	(((RTDS_Message_TE_TE_LS_Ala_data*)RTDS_msgData)->param1) = (RTDS_PARAM1); \
	(((RTDS_Message_TE_TE_LS_Ala_data*)RTDS_msgData)->param2) = (RTDS_PARAM2); \
	(((RTDS_Message_TE_TE_LS_Ala_data*)RTDS_msgData)->param3) = (RTDS_PARAM3); \
	((RTDS_Message_TE_TE_LS_Ala_data*)RTDS_msgData)->param4 = RTDS_PARAM4; \
	(((RTDS_Message_TE_TE_LS_Ala_data*)RTDS_msgData)->param5) = (RTDS_PARAM5); \
	MACRO_NAME(Message_TE_TE_LS_Ala, sizeof(RTDS_Message_TE_TE_LS_Ala_data), RTDS_msgData); \
	}
#endif /* RTDS_MSG_SEND_Message_TE_TE_LS_Ala_TO_ENV defined */

/* MACRO FOR RECEPTION OF MESSAGE nextRecord */

#ifndef RTDS_MSG_RECEIVE_nextRecord
#define RTDS_MSG_RECEIVE_nextRecord(RTDS_PARAM1) \
	{ \
	RTDS_msgData = (unsigned char *)(RTDS_currentContext->currentMessage->pData); \
	if ( RTDS_msgData != NULL ) \
		{ \
		(RTDS_PARAM1) = (((RTDS_nextRecord_data*)RTDS_msgData)->param1); \
		} \
	else \
		{ \
		RTDS_MSG_INPUT_ERROR; \
		} \
	}
#endif /* RTDS_MSG_RECEIVE_nextRecord defined */

/* MACRO FOR SENDING MESSAGE nextRecord TO A PROCESS NAME */

#ifndef RTDS_MSG_SEND_nextRecord_TO_NAME
#define RTDS_MSG_SEND_nextRecord_TO_NAME(RECEIVER, RECEIVER_NUMBER, RTDS_PARAM1) \
	{ \
	RTDS_msgData = (unsigned char *)new RTDS_nextRecord_data(); \
	(((RTDS_nextRecord_data*)RTDS_msgData)->param1) = (RTDS_PARAM1); \
	RTDS_MSG_QUEUE_SEND_TO_NAME(nextRecord, sizeof(RTDS_nextRecord_data), RTDS_msgData, RECEIVER, RECEIVER_NUMBER); \
	}
#endif /* RTDS_MSG_SEND_nextRecord_TO_NAME defined */

/* MACRO FOR SENDING MESSAGE nextRecord TO A PROCESS ID */

#ifndef RTDS_MSG_SEND_nextRecord_TO_ID
#define RTDS_MSG_SEND_nextRecord_TO_ID(RECEIVER, RTDS_PARAM1) \
	{ \
	RTDS_msgData = (unsigned char *)new RTDS_nextRecord_data(); \
	(((RTDS_nextRecord_data*)RTDS_msgData)->param1) = (RTDS_PARAM1); \
	RTDS_MSG_QUEUE_SEND_TO_ID(nextRecord, sizeof(RTDS_nextRecord_data), RTDS_msgData, RECEIVER); \
	}
#endif /* RTDS_MSG_SEND_nextRecord_TO_ID defined */

/* MACROS FOR SENDING MESSAGE nextRecord TO ENVIRONMENT */

#ifndef RTDS_MSG_SEND_nextRecord_TO_ENV
#define RTDS_MSG_SEND_nextRecord_TO_ENV(RTDS_PARAM1) \
	{ \
	RTDS_msgData = (unsigned char *)new RTDS_nextRecord_data(); \
	(((RTDS_nextRecord_data*)RTDS_msgData)->param1) = (RTDS_PARAM1); \
	RTDS_MSG_QUEUE_SEND_TO_ENV(nextRecord, sizeof(RTDS_nextRecord_data), RTDS_msgData); \
	}
#endif /* RTDS_MSG_SEND_nextRecord_TO_ENV defined */

#ifndef RTDS_MSG_SEND_nextRecord_TO_ENV_W_MACRO
#define RTDS_MSG_SEND_nextRecord_TO_ENV_W_MACRO(MACRO_NAME, RTDS_PARAM1) \
	{ \
	RTDS_msgData = (unsigned char *)new RTDS_nextRecord_data(); \
	(((RTDS_nextRecord_data*)RTDS_msgData)->param1) = (RTDS_PARAM1); \
	MACRO_NAME(nextRecord, sizeof(RTDS_nextRecord_data), RTDS_msgData); \
	}
#endif /* RTDS_MSG_SEND_nextRecord_TO_ENV defined */

/* MACRO FOR RECEPTION OF MESSAGE TN_SN_AssignLeadershipForGroup */

#ifndef RTDS_MSG_RECEIVE_TN_SN_AssignLeadershipForGroup
#define RTDS_MSG_RECEIVE_TN_SN_AssignLeadershipForGroup(RTDS_PARAM1, RTDS_PARAM2, RTDS_PARAM3, RTDS_PARAM4) \
	{ \
	RTDS_msgData = (unsigned char *)(RTDS_currentContext->currentMessage->pData); \
	if ( RTDS_msgData != NULL ) \
		{ \
		(RTDS_PARAM1) = (((RTDS_TN_SN_AssignLeadershipForGroup_data*)RTDS_msgData)->param1); \
		(RTDS_PARAM2) = (((RTDS_TN_SN_AssignLeadershipForGroup_data*)RTDS_msgData)->param2); \
		(RTDS_PARAM3) = (((RTDS_TN_SN_AssignLeadershipForGroup_data*)RTDS_msgData)->param3); \
		RTDS_PARAM4 = ((RTDS_TN_SN_AssignLeadershipForGroup_data*)RTDS_msgData)->param4; \
		} \
	else \
		{ \
		RTDS_MSG_INPUT_ERROR; \
		} \
	}
#endif /* RTDS_MSG_RECEIVE_TN_SN_AssignLeadershipForGroup defined */

/* MACRO FOR SENDING MESSAGE TN_SN_AssignLeadershipForGroup TO A PROCESS NAME */

#ifndef RTDS_MSG_SEND_TN_SN_AssignLeadershipForGroup_TO_NAME
#define RTDS_MSG_SEND_TN_SN_AssignLeadershipForGroup_TO_NAME(RECEIVER, RECEIVER_NUMBER, RTDS_PARAM1, RTDS_PARAM2, RTDS_PARAM3, RTDS_PARAM4) \
	{ \
	RTDS_msgData = (unsigned char *)new RTDS_TN_SN_AssignLeadershipForGroup_data(); \
	(((RTDS_TN_SN_AssignLeadershipForGroup_data*)RTDS_msgData)->param1) = (RTDS_PARAM1); \
	(((RTDS_TN_SN_AssignLeadershipForGroup_data*)RTDS_msgData)->param2) = (RTDS_PARAM2); \
	(((RTDS_TN_SN_AssignLeadershipForGroup_data*)RTDS_msgData)->param3) = (RTDS_PARAM3); \
	((RTDS_TN_SN_AssignLeadershipForGroup_data*)RTDS_msgData)->param4 = RTDS_PARAM4; \
	RTDS_MSG_QUEUE_SEND_TO_NAME(TN_SN_AssignLeadershipForGroup, sizeof(RTDS_TN_SN_AssignLeadershipForGroup_data), RTDS_msgData, RECEIVER, RECEIVER_NUMBER); \
	}
#endif /* RTDS_MSG_SEND_TN_SN_AssignLeadershipForGroup_TO_NAME defined */

/* MACRO FOR SENDING MESSAGE TN_SN_AssignLeadershipForGroup TO A PROCESS ID */

#ifndef RTDS_MSG_SEND_TN_SN_AssignLeadershipForGroup_TO_ID
#define RTDS_MSG_SEND_TN_SN_AssignLeadershipForGroup_TO_ID(RECEIVER, RTDS_PARAM1, RTDS_PARAM2, RTDS_PARAM3, RTDS_PARAM4) \
	{ \
	RTDS_msgData = (unsigned char *)new RTDS_TN_SN_AssignLeadershipForGroup_data(); \
	(((RTDS_TN_SN_AssignLeadershipForGroup_data*)RTDS_msgData)->param1) = (RTDS_PARAM1); \
	(((RTDS_TN_SN_AssignLeadershipForGroup_data*)RTDS_msgData)->param2) = (RTDS_PARAM2); \
	(((RTDS_TN_SN_AssignLeadershipForGroup_data*)RTDS_msgData)->param3) = (RTDS_PARAM3); \
	((RTDS_TN_SN_AssignLeadershipForGroup_data*)RTDS_msgData)->param4 = RTDS_PARAM4; \
	RTDS_MSG_QUEUE_SEND_TO_ID(TN_SN_AssignLeadershipForGroup, sizeof(RTDS_TN_SN_AssignLeadershipForGroup_data), RTDS_msgData, RECEIVER); \
	}
#endif /* RTDS_MSG_SEND_TN_SN_AssignLeadershipForGroup_TO_ID defined */

/* MACROS FOR SENDING MESSAGE TN_SN_AssignLeadershipForGroup TO ENVIRONMENT */

#ifndef RTDS_MSG_SEND_TN_SN_AssignLeadershipForGroup_TO_ENV
#define RTDS_MSG_SEND_TN_SN_AssignLeadershipForGroup_TO_ENV(RTDS_PARAM1, RTDS_PARAM2, RTDS_PARAM3, RTDS_PARAM4) \
	{ \
	RTDS_msgData = (unsigned char *)new RTDS_TN_SN_AssignLeadershipForGroup_data(); \
	(((RTDS_TN_SN_AssignLeadershipForGroup_data*)RTDS_msgData)->param1) = (RTDS_PARAM1); \
	(((RTDS_TN_SN_AssignLeadershipForGroup_data*)RTDS_msgData)->param2) = (RTDS_PARAM2); \
	(((RTDS_TN_SN_AssignLeadershipForGroup_data*)RTDS_msgData)->param3) = (RTDS_PARAM3); \
	((RTDS_TN_SN_AssignLeadershipForGroup_data*)RTDS_msgData)->param4 = RTDS_PARAM4; \
	RTDS_MSG_QUEUE_SEND_TO_ENV(TN_SN_AssignLeadershipForGroup, sizeof(RTDS_TN_SN_AssignLeadershipForGroup_data), RTDS_msgData); \
	}
#endif /* RTDS_MSG_SEND_TN_SN_AssignLeadershipForGroup_TO_ENV defined */

#ifndef RTDS_MSG_SEND_TN_SN_AssignLeadershipForGroup_TO_ENV_W_MACRO
#define RTDS_MSG_SEND_TN_SN_AssignLeadershipForGroup_TO_ENV_W_MACRO(MACRO_NAME, RTDS_PARAM1, RTDS_PARAM2, RTDS_PARAM3, RTDS_PARAM4) \
	{ \
	RTDS_msgData = (unsigned char *)new RTDS_TN_SN_AssignLeadershipForGroup_data(); \
	(((RTDS_TN_SN_AssignLeadershipForGroup_data*)RTDS_msgData)->param1) = (RTDS_PARAM1); \
	(((RTDS_TN_SN_AssignLeadershipForGroup_data*)RTDS_msgData)->param2) = (RTDS_PARAM2); \
	(((RTDS_TN_SN_AssignLeadershipForGroup_data*)RTDS_msgData)->param3) = (RTDS_PARAM3); \
	((RTDS_TN_SN_AssignLeadershipForGroup_data*)RTDS_msgData)->param4 = RTDS_PARAM4; \
	MACRO_NAME(TN_SN_AssignLeadershipForGroup, sizeof(RTDS_TN_SN_AssignLeadershipForGroup_data), RTDS_msgData); \
	}
#endif /* RTDS_MSG_SEND_TN_SN_AssignLeadershipForGroup_TO_ENV defined */

/* MACRO FOR RECEPTION OF MESSAGE Message_TE_TE_TS_Ask */

#ifndef RTDS_MSG_RECEIVE_Message_TE_TE_TS_Ask
#define RTDS_MSG_RECEIVE_Message_TE_TE_TS_Ask(RTDS_PARAM1, RTDS_PARAM2, RTDS_PARAM3) \
	{ \
	RTDS_msgData = (unsigned char *)(RTDS_currentContext->currentMessage->pData); \
	if ( RTDS_msgData != NULL ) \
		{ \
		(RTDS_PARAM1) = (((RTDS_Message_TE_TE_TS_Ask_data*)RTDS_msgData)->param1); \
		(RTDS_PARAM2) = (((RTDS_Message_TE_TE_TS_Ask_data*)RTDS_msgData)->param2); \
		(RTDS_PARAM3) = (((RTDS_Message_TE_TE_TS_Ask_data*)RTDS_msgData)->param3); \
		} \
	else \
		{ \
		RTDS_MSG_INPUT_ERROR; \
		} \
	}
#endif /* RTDS_MSG_RECEIVE_Message_TE_TE_TS_Ask defined */

/* MACRO FOR SENDING MESSAGE Message_TE_TE_TS_Ask TO A PROCESS NAME */

#ifndef RTDS_MSG_SEND_Message_TE_TE_TS_Ask_TO_NAME
#define RTDS_MSG_SEND_Message_TE_TE_TS_Ask_TO_NAME(RECEIVER, RECEIVER_NUMBER, RTDS_PARAM1, RTDS_PARAM2, RTDS_PARAM3) \
	{ \
	RTDS_msgData = (unsigned char *)new RTDS_Message_TE_TE_TS_Ask_data(); \
	(((RTDS_Message_TE_TE_TS_Ask_data*)RTDS_msgData)->param1) = (RTDS_PARAM1); \
	(((RTDS_Message_TE_TE_TS_Ask_data*)RTDS_msgData)->param2) = (RTDS_PARAM2); \
	(((RTDS_Message_TE_TE_TS_Ask_data*)RTDS_msgData)->param3) = (RTDS_PARAM3); \
	RTDS_MSG_QUEUE_SEND_TO_NAME(Message_TE_TE_TS_Ask, sizeof(RTDS_Message_TE_TE_TS_Ask_data), RTDS_msgData, RECEIVER, RECEIVER_NUMBER); \
	}
#endif /* RTDS_MSG_SEND_Message_TE_TE_TS_Ask_TO_NAME defined */

/* MACRO FOR SENDING MESSAGE Message_TE_TE_TS_Ask TO A PROCESS ID */

#ifndef RTDS_MSG_SEND_Message_TE_TE_TS_Ask_TO_ID
#define RTDS_MSG_SEND_Message_TE_TE_TS_Ask_TO_ID(RECEIVER, RTDS_PARAM1, RTDS_PARAM2, RTDS_PARAM3) \
	{ \
	RTDS_msgData = (unsigned char *)new RTDS_Message_TE_TE_TS_Ask_data(); \
	(((RTDS_Message_TE_TE_TS_Ask_data*)RTDS_msgData)->param1) = (RTDS_PARAM1); \
	(((RTDS_Message_TE_TE_TS_Ask_data*)RTDS_msgData)->param2) = (RTDS_PARAM2); \
	(((RTDS_Message_TE_TE_TS_Ask_data*)RTDS_msgData)->param3) = (RTDS_PARAM3); \
	RTDS_MSG_QUEUE_SEND_TO_ID(Message_TE_TE_TS_Ask, sizeof(RTDS_Message_TE_TE_TS_Ask_data), RTDS_msgData, RECEIVER); \
	}
#endif /* RTDS_MSG_SEND_Message_TE_TE_TS_Ask_TO_ID defined */

/* MACROS FOR SENDING MESSAGE Message_TE_TE_TS_Ask TO ENVIRONMENT */

#ifndef RTDS_MSG_SEND_Message_TE_TE_TS_Ask_TO_ENV
#define RTDS_MSG_SEND_Message_TE_TE_TS_Ask_TO_ENV(RTDS_PARAM1, RTDS_PARAM2, RTDS_PARAM3) \
	{ \
	RTDS_msgData = (unsigned char *)new RTDS_Message_TE_TE_TS_Ask_data(); \
	(((RTDS_Message_TE_TE_TS_Ask_data*)RTDS_msgData)->param1) = (RTDS_PARAM1); \
	(((RTDS_Message_TE_TE_TS_Ask_data*)RTDS_msgData)->param2) = (RTDS_PARAM2); \
	(((RTDS_Message_TE_TE_TS_Ask_data*)RTDS_msgData)->param3) = (RTDS_PARAM3); \
	RTDS_MSG_QUEUE_SEND_TO_ENV(Message_TE_TE_TS_Ask, sizeof(RTDS_Message_TE_TE_TS_Ask_data), RTDS_msgData); \
	}
#endif /* RTDS_MSG_SEND_Message_TE_TE_TS_Ask_TO_ENV defined */

#ifndef RTDS_MSG_SEND_Message_TE_TE_TS_Ask_TO_ENV_W_MACRO
#define RTDS_MSG_SEND_Message_TE_TE_TS_Ask_TO_ENV_W_MACRO(MACRO_NAME, RTDS_PARAM1, RTDS_PARAM2, RTDS_PARAM3) \
	{ \
	RTDS_msgData = (unsigned char *)new RTDS_Message_TE_TE_TS_Ask_data(); \
	(((RTDS_Message_TE_TE_TS_Ask_data*)RTDS_msgData)->param1) = (RTDS_PARAM1); \
	(((RTDS_Message_TE_TE_TS_Ask_data*)RTDS_msgData)->param2) = (RTDS_PARAM2); \
	(((RTDS_Message_TE_TE_TS_Ask_data*)RTDS_msgData)->param3) = (RTDS_PARAM3); \
	MACRO_NAME(Message_TE_TE_TS_Ask, sizeof(RTDS_Message_TE_TE_TS_Ask_data), RTDS_msgData); \
	}
#endif /* RTDS_MSG_SEND_Message_TE_TE_TS_Ask_TO_ENV defined */

/* MACRO FOR RECEPTION OF MESSAGE LN_EN_Alarm */

#ifndef RTDS_MSG_RECEIVE_LN_EN_Alarm
#define RTDS_MSG_RECEIVE_LN_EN_Alarm(RTDS_PARAM1, RTDS_PARAM2, RTDS_PARAM3, RTDS_PARAM4) \
	{ \
	RTDS_msgData = (unsigned char *)(RTDS_currentContext->currentMessage->pData); \
	if ( RTDS_msgData != NULL ) \
		{ \
		(RTDS_PARAM1) = (((RTDS_LN_EN_Alarm_data*)RTDS_msgData)->param1); \
		(RTDS_PARAM2) = (((RTDS_LN_EN_Alarm_data*)RTDS_msgData)->param2); \
		RTDS_PARAM3 = ((RTDS_LN_EN_Alarm_data*)RTDS_msgData)->param3; \
		(RTDS_PARAM4) = (((RTDS_LN_EN_Alarm_data*)RTDS_msgData)->param4); \
		} \
	else \
		{ \
		RTDS_MSG_INPUT_ERROR; \
		} \
	}
#endif /* RTDS_MSG_RECEIVE_LN_EN_Alarm defined */

/* MACRO FOR SENDING MESSAGE LN_EN_Alarm TO A PROCESS NAME */

#ifndef RTDS_MSG_SEND_LN_EN_Alarm_TO_NAME
#define RTDS_MSG_SEND_LN_EN_Alarm_TO_NAME(RECEIVER, RECEIVER_NUMBER, RTDS_PARAM1, RTDS_PARAM2, RTDS_PARAM3, RTDS_PARAM4) \
	{ \
	RTDS_msgData = (unsigned char *)new RTDS_LN_EN_Alarm_data(); \
	(((RTDS_LN_EN_Alarm_data*)RTDS_msgData)->param1) = (RTDS_PARAM1); \
	(((RTDS_LN_EN_Alarm_data*)RTDS_msgData)->param2) = (RTDS_PARAM2); \
	((RTDS_LN_EN_Alarm_data*)RTDS_msgData)->param3 = RTDS_PARAM3; \
	(((RTDS_LN_EN_Alarm_data*)RTDS_msgData)->param4) = (RTDS_PARAM4); \
	RTDS_MSG_QUEUE_SEND_TO_NAME(LN_EN_Alarm, sizeof(RTDS_LN_EN_Alarm_data), RTDS_msgData, RECEIVER, RECEIVER_NUMBER); \
	}
#endif /* RTDS_MSG_SEND_LN_EN_Alarm_TO_NAME defined */

/* MACRO FOR SENDING MESSAGE LN_EN_Alarm TO A PROCESS ID */

#ifndef RTDS_MSG_SEND_LN_EN_Alarm_TO_ID
#define RTDS_MSG_SEND_LN_EN_Alarm_TO_ID(RECEIVER, RTDS_PARAM1, RTDS_PARAM2, RTDS_PARAM3, RTDS_PARAM4) \
	{ \
	RTDS_msgData = (unsigned char *)new RTDS_LN_EN_Alarm_data(); \
	(((RTDS_LN_EN_Alarm_data*)RTDS_msgData)->param1) = (RTDS_PARAM1); \
	(((RTDS_LN_EN_Alarm_data*)RTDS_msgData)->param2) = (RTDS_PARAM2); \
	((RTDS_LN_EN_Alarm_data*)RTDS_msgData)->param3 = RTDS_PARAM3; \
	(((RTDS_LN_EN_Alarm_data*)RTDS_msgData)->param4) = (RTDS_PARAM4); \
	RTDS_MSG_QUEUE_SEND_TO_ID(LN_EN_Alarm, sizeof(RTDS_LN_EN_Alarm_data), RTDS_msgData, RECEIVER); \
	}
#endif /* RTDS_MSG_SEND_LN_EN_Alarm_TO_ID defined */

/* MACROS FOR SENDING MESSAGE LN_EN_Alarm TO ENVIRONMENT */

#ifndef RTDS_MSG_SEND_LN_EN_Alarm_TO_ENV
#define RTDS_MSG_SEND_LN_EN_Alarm_TO_ENV(RTDS_PARAM1, RTDS_PARAM2, RTDS_PARAM3, RTDS_PARAM4) \
	{ \
	RTDS_msgData = (unsigned char *)new RTDS_LN_EN_Alarm_data(); \
	(((RTDS_LN_EN_Alarm_data*)RTDS_msgData)->param1) = (RTDS_PARAM1); \
	(((RTDS_LN_EN_Alarm_data*)RTDS_msgData)->param2) = (RTDS_PARAM2); \
	((RTDS_LN_EN_Alarm_data*)RTDS_msgData)->param3 = RTDS_PARAM3; \
	(((RTDS_LN_EN_Alarm_data*)RTDS_msgData)->param4) = (RTDS_PARAM4); \
	RTDS_MSG_QUEUE_SEND_TO_ENV(LN_EN_Alarm, sizeof(RTDS_LN_EN_Alarm_data), RTDS_msgData); \
	}
#endif /* RTDS_MSG_SEND_LN_EN_Alarm_TO_ENV defined */

#ifndef RTDS_MSG_SEND_LN_EN_Alarm_TO_ENV_W_MACRO
#define RTDS_MSG_SEND_LN_EN_Alarm_TO_ENV_W_MACRO(MACRO_NAME, RTDS_PARAM1, RTDS_PARAM2, RTDS_PARAM3, RTDS_PARAM4) \
	{ \
	RTDS_msgData = (unsigned char *)new RTDS_LN_EN_Alarm_data(); \
	(((RTDS_LN_EN_Alarm_data*)RTDS_msgData)->param1) = (RTDS_PARAM1); \
	(((RTDS_LN_EN_Alarm_data*)RTDS_msgData)->param2) = (RTDS_PARAM2); \
	((RTDS_LN_EN_Alarm_data*)RTDS_msgData)->param3 = RTDS_PARAM3; \
	(((RTDS_LN_EN_Alarm_data*)RTDS_msgData)->param4) = (RTDS_PARAM4); \
	MACRO_NAME(LN_EN_Alarm, sizeof(RTDS_LN_EN_Alarm_data), RTDS_msgData); \
	}
#endif /* RTDS_MSG_SEND_LN_EN_Alarm_TO_ENV defined */

/* MACRO FOR RECEPTION OF MESSAGE Message_TE_TE_LL_Det */

#ifndef RTDS_MSG_RECEIVE_Message_TE_TE_LL_Det
#define RTDS_MSG_RECEIVE_Message_TE_TE_LL_Det(RTDS_PARAM1, RTDS_PARAM2, RTDS_PARAM3, RTDS_PARAM4, RTDS_PARAM5, RTDS_PARAM6) \
	{ \
	RTDS_msgData = (unsigned char *)(RTDS_currentContext->currentMessage->pData); \
	if ( RTDS_msgData != NULL ) \
		{ \
		(RTDS_PARAM1) = (((RTDS_Message_TE_TE_LL_Det_data*)RTDS_msgData)->param1); \
		(RTDS_PARAM2) = (((RTDS_Message_TE_TE_LL_Det_data*)RTDS_msgData)->param2); \
		(RTDS_PARAM3) = (((RTDS_Message_TE_TE_LL_Det_data*)RTDS_msgData)->param3); \
		RTDS_PARAM4 = ((RTDS_Message_TE_TE_LL_Det_data*)RTDS_msgData)->param4; \
		(RTDS_PARAM5) = (((RTDS_Message_TE_TE_LL_Det_data*)RTDS_msgData)->param5); \
		(RTDS_PARAM6) = (((RTDS_Message_TE_TE_LL_Det_data*)RTDS_msgData)->param6); \
		} \
	else \
		{ \
		RTDS_MSG_INPUT_ERROR; \
		} \
	}
#endif /* RTDS_MSG_RECEIVE_Message_TE_TE_LL_Det defined */

/* MACRO FOR SENDING MESSAGE Message_TE_TE_LL_Det TO A PROCESS NAME */

#ifndef RTDS_MSG_SEND_Message_TE_TE_LL_Det_TO_NAME
#define RTDS_MSG_SEND_Message_TE_TE_LL_Det_TO_NAME(RECEIVER, RECEIVER_NUMBER, RTDS_PARAM1, RTDS_PARAM2, RTDS_PARAM3, RTDS_PARAM4, RTDS_PARAM5, RTDS_PARAM6) \
	{ \
	RTDS_msgData = (unsigned char *)new RTDS_Message_TE_TE_LL_Det_data(); \
	(((RTDS_Message_TE_TE_LL_Det_data*)RTDS_msgData)->param1) = (RTDS_PARAM1); \
	(((RTDS_Message_TE_TE_LL_Det_data*)RTDS_msgData)->param2) = (RTDS_PARAM2); \
	(((RTDS_Message_TE_TE_LL_Det_data*)RTDS_msgData)->param3) = (RTDS_PARAM3); \
	((RTDS_Message_TE_TE_LL_Det_data*)RTDS_msgData)->param4 = RTDS_PARAM4; \
	(((RTDS_Message_TE_TE_LL_Det_data*)RTDS_msgData)->param5) = (RTDS_PARAM5); \
	(((RTDS_Message_TE_TE_LL_Det_data*)RTDS_msgData)->param6) = (RTDS_PARAM6); \
	RTDS_MSG_QUEUE_SEND_TO_NAME(Message_TE_TE_LL_Det, sizeof(RTDS_Message_TE_TE_LL_Det_data), RTDS_msgData, RECEIVER, RECEIVER_NUMBER); \
	}
#endif /* RTDS_MSG_SEND_Message_TE_TE_LL_Det_TO_NAME defined */

/* MACRO FOR SENDING MESSAGE Message_TE_TE_LL_Det TO A PROCESS ID */

#ifndef RTDS_MSG_SEND_Message_TE_TE_LL_Det_TO_ID
#define RTDS_MSG_SEND_Message_TE_TE_LL_Det_TO_ID(RECEIVER, RTDS_PARAM1, RTDS_PARAM2, RTDS_PARAM3, RTDS_PARAM4, RTDS_PARAM5, RTDS_PARAM6) \
	{ \
	RTDS_msgData = (unsigned char *)new RTDS_Message_TE_TE_LL_Det_data(); \
	(((RTDS_Message_TE_TE_LL_Det_data*)RTDS_msgData)->param1) = (RTDS_PARAM1); \
	(((RTDS_Message_TE_TE_LL_Det_data*)RTDS_msgData)->param2) = (RTDS_PARAM2); \
	(((RTDS_Message_TE_TE_LL_Det_data*)RTDS_msgData)->param3) = (RTDS_PARAM3); \
	((RTDS_Message_TE_TE_LL_Det_data*)RTDS_msgData)->param4 = RTDS_PARAM4; \
	(((RTDS_Message_TE_TE_LL_Det_data*)RTDS_msgData)->param5) = (RTDS_PARAM5); \
	(((RTDS_Message_TE_TE_LL_Det_data*)RTDS_msgData)->param6) = (RTDS_PARAM6); \
	RTDS_MSG_QUEUE_SEND_TO_ID(Message_TE_TE_LL_Det, sizeof(RTDS_Message_TE_TE_LL_Det_data), RTDS_msgData, RECEIVER); \
	}
#endif /* RTDS_MSG_SEND_Message_TE_TE_LL_Det_TO_ID defined */

/* MACROS FOR SENDING MESSAGE Message_TE_TE_LL_Det TO ENVIRONMENT */

#ifndef RTDS_MSG_SEND_Message_TE_TE_LL_Det_TO_ENV
#define RTDS_MSG_SEND_Message_TE_TE_LL_Det_TO_ENV(RTDS_PARAM1, RTDS_PARAM2, RTDS_PARAM3, RTDS_PARAM4, RTDS_PARAM5, RTDS_PARAM6) \
	{ \
	RTDS_msgData = (unsigned char *)new RTDS_Message_TE_TE_LL_Det_data(); \
	(((RTDS_Message_TE_TE_LL_Det_data*)RTDS_msgData)->param1) = (RTDS_PARAM1); \
	(((RTDS_Message_TE_TE_LL_Det_data*)RTDS_msgData)->param2) = (RTDS_PARAM2); \
	(((RTDS_Message_TE_TE_LL_Det_data*)RTDS_msgData)->param3) = (RTDS_PARAM3); \
	((RTDS_Message_TE_TE_LL_Det_data*)RTDS_msgData)->param4 = RTDS_PARAM4; \
	(((RTDS_Message_TE_TE_LL_Det_data*)RTDS_msgData)->param5) = (RTDS_PARAM5); \
	(((RTDS_Message_TE_TE_LL_Det_data*)RTDS_msgData)->param6) = (RTDS_PARAM6); \
	RTDS_MSG_QUEUE_SEND_TO_ENV(Message_TE_TE_LL_Det, sizeof(RTDS_Message_TE_TE_LL_Det_data), RTDS_msgData); \
	}
#endif /* RTDS_MSG_SEND_Message_TE_TE_LL_Det_TO_ENV defined */

#ifndef RTDS_MSG_SEND_Message_TE_TE_LL_Det_TO_ENV_W_MACRO
#define RTDS_MSG_SEND_Message_TE_TE_LL_Det_TO_ENV_W_MACRO(MACRO_NAME, RTDS_PARAM1, RTDS_PARAM2, RTDS_PARAM3, RTDS_PARAM4, RTDS_PARAM5, RTDS_PARAM6) \
	{ \
	RTDS_msgData = (unsigned char *)new RTDS_Message_TE_TE_LL_Det_data(); \
	(((RTDS_Message_TE_TE_LL_Det_data*)RTDS_msgData)->param1) = (RTDS_PARAM1); \
	(((RTDS_Message_TE_TE_LL_Det_data*)RTDS_msgData)->param2) = (RTDS_PARAM2); \
	(((RTDS_Message_TE_TE_LL_Det_data*)RTDS_msgData)->param3) = (RTDS_PARAM3); \
	((RTDS_Message_TE_TE_LL_Det_data*)RTDS_msgData)->param4 = RTDS_PARAM4; \
	(((RTDS_Message_TE_TE_LL_Det_data*)RTDS_msgData)->param5) = (RTDS_PARAM5); \
	(((RTDS_Message_TE_TE_LL_Det_data*)RTDS_msgData)->param6) = (RTDS_PARAM6); \
	MACRO_NAME(Message_TE_TE_LL_Det, sizeof(RTDS_Message_TE_TE_LL_Det_data), RTDS_msgData); \
	}
#endif /* RTDS_MSG_SEND_Message_TE_TE_LL_Det_TO_ENV defined */

/* MACRO FOR RECEPTION OF MESSAGE Message_TE_TE_SL_Idl */

#ifndef RTDS_MSG_RECEIVE_Message_TE_TE_SL_Idl
#define RTDS_MSG_RECEIVE_Message_TE_TE_SL_Idl(RTDS_PARAM1, RTDS_PARAM2, RTDS_PARAM3, RTDS_PARAM4, RTDS_PARAM5, RTDS_PARAM6) \
	{ \
	RTDS_msgData = (unsigned char *)(RTDS_currentContext->currentMessage->pData); \
	if ( RTDS_msgData != NULL ) \
		{ \
		(RTDS_PARAM1) = (((RTDS_Message_TE_TE_SL_Idl_data*)RTDS_msgData)->param1); \
		(RTDS_PARAM2) = (((RTDS_Message_TE_TE_SL_Idl_data*)RTDS_msgData)->param2); \
		(RTDS_PARAM3) = (((RTDS_Message_TE_TE_SL_Idl_data*)RTDS_msgData)->param3); \
		(RTDS_PARAM4) = (((RTDS_Message_TE_TE_SL_Idl_data*)RTDS_msgData)->param4); \
		RTDS_PARAM5 = ((RTDS_Message_TE_TE_SL_Idl_data*)RTDS_msgData)->param5; \
		RTDS_PARAM6 = ((RTDS_Message_TE_TE_SL_Idl_data*)RTDS_msgData)->param6; \
		} \
	else \
		{ \
		RTDS_MSG_INPUT_ERROR; \
		} \
	}
#endif /* RTDS_MSG_RECEIVE_Message_TE_TE_SL_Idl defined */

/* MACRO FOR SENDING MESSAGE Message_TE_TE_SL_Idl TO A PROCESS NAME */

#ifndef RTDS_MSG_SEND_Message_TE_TE_SL_Idl_TO_NAME
#define RTDS_MSG_SEND_Message_TE_TE_SL_Idl_TO_NAME(RECEIVER, RECEIVER_NUMBER, RTDS_PARAM1, RTDS_PARAM2, RTDS_PARAM3, RTDS_PARAM4, RTDS_PARAM5, RTDS_PARAM6) \
	{ \
	RTDS_msgData = (unsigned char *)new RTDS_Message_TE_TE_SL_Idl_data(); \
	(((RTDS_Message_TE_TE_SL_Idl_data*)RTDS_msgData)->param1) = (RTDS_PARAM1); \
	(((RTDS_Message_TE_TE_SL_Idl_data*)RTDS_msgData)->param2) = (RTDS_PARAM2); \
	(((RTDS_Message_TE_TE_SL_Idl_data*)RTDS_msgData)->param3) = (RTDS_PARAM3); \
	(((RTDS_Message_TE_TE_SL_Idl_data*)RTDS_msgData)->param4) = (RTDS_PARAM4); \
	((RTDS_Message_TE_TE_SL_Idl_data*)RTDS_msgData)->param5 = RTDS_PARAM5; \
	((RTDS_Message_TE_TE_SL_Idl_data*)RTDS_msgData)->param6 = RTDS_PARAM6; \
	RTDS_MSG_QUEUE_SEND_TO_NAME(Message_TE_TE_SL_Idl, sizeof(RTDS_Message_TE_TE_SL_Idl_data), RTDS_msgData, RECEIVER, RECEIVER_NUMBER); \
	}
#endif /* RTDS_MSG_SEND_Message_TE_TE_SL_Idl_TO_NAME defined */

/* MACRO FOR SENDING MESSAGE Message_TE_TE_SL_Idl TO A PROCESS ID */

#ifndef RTDS_MSG_SEND_Message_TE_TE_SL_Idl_TO_ID
#define RTDS_MSG_SEND_Message_TE_TE_SL_Idl_TO_ID(RECEIVER, RTDS_PARAM1, RTDS_PARAM2, RTDS_PARAM3, RTDS_PARAM4, RTDS_PARAM5, RTDS_PARAM6) \
	{ \
	RTDS_msgData = (unsigned char *)new RTDS_Message_TE_TE_SL_Idl_data(); \
	(((RTDS_Message_TE_TE_SL_Idl_data*)RTDS_msgData)->param1) = (RTDS_PARAM1); \
	(((RTDS_Message_TE_TE_SL_Idl_data*)RTDS_msgData)->param2) = (RTDS_PARAM2); \
	(((RTDS_Message_TE_TE_SL_Idl_data*)RTDS_msgData)->param3) = (RTDS_PARAM3); \
	(((RTDS_Message_TE_TE_SL_Idl_data*)RTDS_msgData)->param4) = (RTDS_PARAM4); \
	((RTDS_Message_TE_TE_SL_Idl_data*)RTDS_msgData)->param5 = RTDS_PARAM5; \
	((RTDS_Message_TE_TE_SL_Idl_data*)RTDS_msgData)->param6 = RTDS_PARAM6; \
	RTDS_MSG_QUEUE_SEND_TO_ID(Message_TE_TE_SL_Idl, sizeof(RTDS_Message_TE_TE_SL_Idl_data), RTDS_msgData, RECEIVER); \
	}
#endif /* RTDS_MSG_SEND_Message_TE_TE_SL_Idl_TO_ID defined */

/* MACROS FOR SENDING MESSAGE Message_TE_TE_SL_Idl TO ENVIRONMENT */

#ifndef RTDS_MSG_SEND_Message_TE_TE_SL_Idl_TO_ENV
#define RTDS_MSG_SEND_Message_TE_TE_SL_Idl_TO_ENV(RTDS_PARAM1, RTDS_PARAM2, RTDS_PARAM3, RTDS_PARAM4, RTDS_PARAM5, RTDS_PARAM6) \
	{ \
	RTDS_msgData = (unsigned char *)new RTDS_Message_TE_TE_SL_Idl_data(); \
	(((RTDS_Message_TE_TE_SL_Idl_data*)RTDS_msgData)->param1) = (RTDS_PARAM1); \
	(((RTDS_Message_TE_TE_SL_Idl_data*)RTDS_msgData)->param2) = (RTDS_PARAM2); \
	(((RTDS_Message_TE_TE_SL_Idl_data*)RTDS_msgData)->param3) = (RTDS_PARAM3); \
	(((RTDS_Message_TE_TE_SL_Idl_data*)RTDS_msgData)->param4) = (RTDS_PARAM4); \
	((RTDS_Message_TE_TE_SL_Idl_data*)RTDS_msgData)->param5 = RTDS_PARAM5; \
	((RTDS_Message_TE_TE_SL_Idl_data*)RTDS_msgData)->param6 = RTDS_PARAM6; \
	RTDS_MSG_QUEUE_SEND_TO_ENV(Message_TE_TE_SL_Idl, sizeof(RTDS_Message_TE_TE_SL_Idl_data), RTDS_msgData); \
	}
#endif /* RTDS_MSG_SEND_Message_TE_TE_SL_Idl_TO_ENV defined */

#ifndef RTDS_MSG_SEND_Message_TE_TE_SL_Idl_TO_ENV_W_MACRO
#define RTDS_MSG_SEND_Message_TE_TE_SL_Idl_TO_ENV_W_MACRO(MACRO_NAME, RTDS_PARAM1, RTDS_PARAM2, RTDS_PARAM3, RTDS_PARAM4, RTDS_PARAM5, RTDS_PARAM6) \
	{ \
	RTDS_msgData = (unsigned char *)new RTDS_Message_TE_TE_SL_Idl_data(); \
	(((RTDS_Message_TE_TE_SL_Idl_data*)RTDS_msgData)->param1) = (RTDS_PARAM1); \
	(((RTDS_Message_TE_TE_SL_Idl_data*)RTDS_msgData)->param2) = (RTDS_PARAM2); \
	(((RTDS_Message_TE_TE_SL_Idl_data*)RTDS_msgData)->param3) = (RTDS_PARAM3); \
	(((RTDS_Message_TE_TE_SL_Idl_data*)RTDS_msgData)->param4) = (RTDS_PARAM4); \
	((RTDS_Message_TE_TE_SL_Idl_data*)RTDS_msgData)->param5 = RTDS_PARAM5; \
	((RTDS_Message_TE_TE_SL_Idl_data*)RTDS_msgData)->param6 = RTDS_PARAM6; \
	MACRO_NAME(Message_TE_TE_SL_Idl, sizeof(RTDS_Message_TE_TE_SL_Idl_data), RTDS_msgData); \
	}
#endif /* RTDS_MSG_SEND_Message_TE_TE_SL_Idl_TO_ENV defined */

/* MACRO FOR RECEPTION OF MESSAGE TN_SN_StartMessageLogging */

#ifndef RTDS_MSG_RECEIVE_TN_SN_StartMessageLogging
#define RTDS_MSG_RECEIVE_TN_SN_StartMessageLogging(RTDS_PARAM1, RTDS_PARAM2, RTDS_PARAM3) \
	{ \
	RTDS_msgData = (unsigned char *)(RTDS_currentContext->currentMessage->pData); \
	if ( RTDS_msgData != NULL ) \
		{ \
		(RTDS_PARAM1) = (((RTDS_TN_SN_StartMessageLogging_data*)RTDS_msgData)->param1); \
		(RTDS_PARAM2) = (((RTDS_TN_SN_StartMessageLogging_data*)RTDS_msgData)->param2); \
		(RTDS_PARAM3) = (((RTDS_TN_SN_StartMessageLogging_data*)RTDS_msgData)->param3); \
		} \
	else \
		{ \
		RTDS_MSG_INPUT_ERROR; \
		} \
	}
#endif /* RTDS_MSG_RECEIVE_TN_SN_StartMessageLogging defined */

/* MACRO FOR SENDING MESSAGE TN_SN_StartMessageLogging TO A PROCESS NAME */

#ifndef RTDS_MSG_SEND_TN_SN_StartMessageLogging_TO_NAME
#define RTDS_MSG_SEND_TN_SN_StartMessageLogging_TO_NAME(RECEIVER, RECEIVER_NUMBER, RTDS_PARAM1, RTDS_PARAM2, RTDS_PARAM3) \
	{ \
	RTDS_msgData = (unsigned char *)new RTDS_TN_SN_StartMessageLogging_data(); \
	(((RTDS_TN_SN_StartMessageLogging_data*)RTDS_msgData)->param1) = (RTDS_PARAM1); \
	(((RTDS_TN_SN_StartMessageLogging_data*)RTDS_msgData)->param2) = (RTDS_PARAM2); \
	(((RTDS_TN_SN_StartMessageLogging_data*)RTDS_msgData)->param3) = (RTDS_PARAM3); \
	RTDS_MSG_QUEUE_SEND_TO_NAME(TN_SN_StartMessageLogging, sizeof(RTDS_TN_SN_StartMessageLogging_data), RTDS_msgData, RECEIVER, RECEIVER_NUMBER); \
	}
#endif /* RTDS_MSG_SEND_TN_SN_StartMessageLogging_TO_NAME defined */

/* MACRO FOR SENDING MESSAGE TN_SN_StartMessageLogging TO A PROCESS ID */

#ifndef RTDS_MSG_SEND_TN_SN_StartMessageLogging_TO_ID
#define RTDS_MSG_SEND_TN_SN_StartMessageLogging_TO_ID(RECEIVER, RTDS_PARAM1, RTDS_PARAM2, RTDS_PARAM3) \
	{ \
	RTDS_msgData = (unsigned char *)new RTDS_TN_SN_StartMessageLogging_data(); \
	(((RTDS_TN_SN_StartMessageLogging_data*)RTDS_msgData)->param1) = (RTDS_PARAM1); \
	(((RTDS_TN_SN_StartMessageLogging_data*)RTDS_msgData)->param2) = (RTDS_PARAM2); \
	(((RTDS_TN_SN_StartMessageLogging_data*)RTDS_msgData)->param3) = (RTDS_PARAM3); \
	RTDS_MSG_QUEUE_SEND_TO_ID(TN_SN_StartMessageLogging, sizeof(RTDS_TN_SN_StartMessageLogging_data), RTDS_msgData, RECEIVER); \
	}
#endif /* RTDS_MSG_SEND_TN_SN_StartMessageLogging_TO_ID defined */

/* MACROS FOR SENDING MESSAGE TN_SN_StartMessageLogging TO ENVIRONMENT */

#ifndef RTDS_MSG_SEND_TN_SN_StartMessageLogging_TO_ENV
#define RTDS_MSG_SEND_TN_SN_StartMessageLogging_TO_ENV(RTDS_PARAM1, RTDS_PARAM2, RTDS_PARAM3) \
	{ \
	RTDS_msgData = (unsigned char *)new RTDS_TN_SN_StartMessageLogging_data(); \
	(((RTDS_TN_SN_StartMessageLogging_data*)RTDS_msgData)->param1) = (RTDS_PARAM1); \
	(((RTDS_TN_SN_StartMessageLogging_data*)RTDS_msgData)->param2) = (RTDS_PARAM2); \
	(((RTDS_TN_SN_StartMessageLogging_data*)RTDS_msgData)->param3) = (RTDS_PARAM3); \
	RTDS_MSG_QUEUE_SEND_TO_ENV(TN_SN_StartMessageLogging, sizeof(RTDS_TN_SN_StartMessageLogging_data), RTDS_msgData); \
	}
#endif /* RTDS_MSG_SEND_TN_SN_StartMessageLogging_TO_ENV defined */

#ifndef RTDS_MSG_SEND_TN_SN_StartMessageLogging_TO_ENV_W_MACRO
#define RTDS_MSG_SEND_TN_SN_StartMessageLogging_TO_ENV_W_MACRO(MACRO_NAME, RTDS_PARAM1, RTDS_PARAM2, RTDS_PARAM3) \
	{ \
	RTDS_msgData = (unsigned char *)new RTDS_TN_SN_StartMessageLogging_data(); \
	(((RTDS_TN_SN_StartMessageLogging_data*)RTDS_msgData)->param1) = (RTDS_PARAM1); \
	(((RTDS_TN_SN_StartMessageLogging_data*)RTDS_msgData)->param2) = (RTDS_PARAM2); \
	(((RTDS_TN_SN_StartMessageLogging_data*)RTDS_msgData)->param3) = (RTDS_PARAM3); \
	MACRO_NAME(TN_SN_StartMessageLogging, sizeof(RTDS_TN_SN_StartMessageLogging_data), RTDS_msgData); \
	}
#endif /* RTDS_MSG_SEND_TN_SN_StartMessageLogging_TO_ENV defined */

/* MACRO FOR RECEPTION OF MESSAGE Message_TE_TE_LL_Des */

#ifndef RTDS_MSG_RECEIVE_Message_TE_TE_LL_Des
#define RTDS_MSG_RECEIVE_Message_TE_TE_LL_Des(RTDS_PARAM1, RTDS_PARAM2, RTDS_PARAM3, RTDS_PARAM4) \
	{ \
	RTDS_msgData = (unsigned char *)(RTDS_currentContext->currentMessage->pData); \
	if ( RTDS_msgData != NULL ) \
		{ \
		(RTDS_PARAM1) = (((RTDS_Message_TE_TE_LL_Des_data*)RTDS_msgData)->param1); \
		(RTDS_PARAM2) = (((RTDS_Message_TE_TE_LL_Des_data*)RTDS_msgData)->param2); \
		(RTDS_PARAM3) = (((RTDS_Message_TE_TE_LL_Des_data*)RTDS_msgData)->param3); \
		RTDS_PARAM4 = ((RTDS_Message_TE_TE_LL_Des_data*)RTDS_msgData)->param4; \
		} \
	else \
		{ \
		RTDS_MSG_INPUT_ERROR; \
		} \
	}
#endif /* RTDS_MSG_RECEIVE_Message_TE_TE_LL_Des defined */

/* MACRO FOR SENDING MESSAGE Message_TE_TE_LL_Des TO A PROCESS NAME */

#ifndef RTDS_MSG_SEND_Message_TE_TE_LL_Des_TO_NAME
#define RTDS_MSG_SEND_Message_TE_TE_LL_Des_TO_NAME(RECEIVER, RECEIVER_NUMBER, RTDS_PARAM1, RTDS_PARAM2, RTDS_PARAM3, RTDS_PARAM4) \
	{ \
	RTDS_msgData = (unsigned char *)new RTDS_Message_TE_TE_LL_Des_data(); \
	(((RTDS_Message_TE_TE_LL_Des_data*)RTDS_msgData)->param1) = (RTDS_PARAM1); \
	(((RTDS_Message_TE_TE_LL_Des_data*)RTDS_msgData)->param2) = (RTDS_PARAM2); \
	(((RTDS_Message_TE_TE_LL_Des_data*)RTDS_msgData)->param3) = (RTDS_PARAM3); \
	((RTDS_Message_TE_TE_LL_Des_data*)RTDS_msgData)->param4 = RTDS_PARAM4; \
	RTDS_MSG_QUEUE_SEND_TO_NAME(Message_TE_TE_LL_Des, sizeof(RTDS_Message_TE_TE_LL_Des_data), RTDS_msgData, RECEIVER, RECEIVER_NUMBER); \
	}
#endif /* RTDS_MSG_SEND_Message_TE_TE_LL_Des_TO_NAME defined */

/* MACRO FOR SENDING MESSAGE Message_TE_TE_LL_Des TO A PROCESS ID */

#ifndef RTDS_MSG_SEND_Message_TE_TE_LL_Des_TO_ID
#define RTDS_MSG_SEND_Message_TE_TE_LL_Des_TO_ID(RECEIVER, RTDS_PARAM1, RTDS_PARAM2, RTDS_PARAM3, RTDS_PARAM4) \
	{ \
	RTDS_msgData = (unsigned char *)new RTDS_Message_TE_TE_LL_Des_data(); \
	(((RTDS_Message_TE_TE_LL_Des_data*)RTDS_msgData)->param1) = (RTDS_PARAM1); \
	(((RTDS_Message_TE_TE_LL_Des_data*)RTDS_msgData)->param2) = (RTDS_PARAM2); \
	(((RTDS_Message_TE_TE_LL_Des_data*)RTDS_msgData)->param3) = (RTDS_PARAM3); \
	((RTDS_Message_TE_TE_LL_Des_data*)RTDS_msgData)->param4 = RTDS_PARAM4; \
	RTDS_MSG_QUEUE_SEND_TO_ID(Message_TE_TE_LL_Des, sizeof(RTDS_Message_TE_TE_LL_Des_data), RTDS_msgData, RECEIVER); \
	}
#endif /* RTDS_MSG_SEND_Message_TE_TE_LL_Des_TO_ID defined */

/* MACROS FOR SENDING MESSAGE Message_TE_TE_LL_Des TO ENVIRONMENT */

#ifndef RTDS_MSG_SEND_Message_TE_TE_LL_Des_TO_ENV
#define RTDS_MSG_SEND_Message_TE_TE_LL_Des_TO_ENV(RTDS_PARAM1, RTDS_PARAM2, RTDS_PARAM3, RTDS_PARAM4) \
	{ \
	RTDS_msgData = (unsigned char *)new RTDS_Message_TE_TE_LL_Des_data(); \
	(((RTDS_Message_TE_TE_LL_Des_data*)RTDS_msgData)->param1) = (RTDS_PARAM1); \
	(((RTDS_Message_TE_TE_LL_Des_data*)RTDS_msgData)->param2) = (RTDS_PARAM2); \
	(((RTDS_Message_TE_TE_LL_Des_data*)RTDS_msgData)->param3) = (RTDS_PARAM3); \
	((RTDS_Message_TE_TE_LL_Des_data*)RTDS_msgData)->param4 = RTDS_PARAM4; \
	RTDS_MSG_QUEUE_SEND_TO_ENV(Message_TE_TE_LL_Des, sizeof(RTDS_Message_TE_TE_LL_Des_data), RTDS_msgData); \
	}
#endif /* RTDS_MSG_SEND_Message_TE_TE_LL_Des_TO_ENV defined */

#ifndef RTDS_MSG_SEND_Message_TE_TE_LL_Des_TO_ENV_W_MACRO
#define RTDS_MSG_SEND_Message_TE_TE_LL_Des_TO_ENV_W_MACRO(MACRO_NAME, RTDS_PARAM1, RTDS_PARAM2, RTDS_PARAM3, RTDS_PARAM4) \
	{ \
	RTDS_msgData = (unsigned char *)new RTDS_Message_TE_TE_LL_Des_data(); \
	(((RTDS_Message_TE_TE_LL_Des_data*)RTDS_msgData)->param1) = (RTDS_PARAM1); \
	(((RTDS_Message_TE_TE_LL_Des_data*)RTDS_msgData)->param2) = (RTDS_PARAM2); \
	(((RTDS_Message_TE_TE_LL_Des_data*)RTDS_msgData)->param3) = (RTDS_PARAM3); \
	((RTDS_Message_TE_TE_LL_Des_data*)RTDS_msgData)->param4 = RTDS_PARAM4; \
	MACRO_NAME(Message_TE_TE_LL_Des, sizeof(RTDS_Message_TE_TE_LL_Des_data), RTDS_msgData); \
	}
#endif /* RTDS_MSG_SEND_Message_TE_TE_LL_Des_TO_ENV defined */

/* MACRO FOR RECEPTION OF MESSAGE TN_SN_CloseMessageLogfile */

#ifndef RTDS_MSG_RECEIVE_TN_SN_CloseMessageLogfile
#define RTDS_MSG_RECEIVE_TN_SN_CloseMessageLogfile(RTDS_PARAM1, RTDS_PARAM2, RTDS_PARAM3) \
	{ \
	RTDS_msgData = (unsigned char *)(RTDS_currentContext->currentMessage->pData); \
	if ( RTDS_msgData != NULL ) \
		{ \
		(RTDS_PARAM1) = (((RTDS_TN_SN_CloseMessageLogfile_data*)RTDS_msgData)->param1); \
		(RTDS_PARAM2) = (((RTDS_TN_SN_CloseMessageLogfile_data*)RTDS_msgData)->param2); \
		(RTDS_PARAM3) = (((RTDS_TN_SN_CloseMessageLogfile_data*)RTDS_msgData)->param3); \
		} \
	else \
		{ \
		RTDS_MSG_INPUT_ERROR; \
		} \
	}
#endif /* RTDS_MSG_RECEIVE_TN_SN_CloseMessageLogfile defined */

/* MACRO FOR SENDING MESSAGE TN_SN_CloseMessageLogfile TO A PROCESS NAME */

#ifndef RTDS_MSG_SEND_TN_SN_CloseMessageLogfile_TO_NAME
#define RTDS_MSG_SEND_TN_SN_CloseMessageLogfile_TO_NAME(RECEIVER, RECEIVER_NUMBER, RTDS_PARAM1, RTDS_PARAM2, RTDS_PARAM3) \
	{ \
	RTDS_msgData = (unsigned char *)new RTDS_TN_SN_CloseMessageLogfile_data(); \
	(((RTDS_TN_SN_CloseMessageLogfile_data*)RTDS_msgData)->param1) = (RTDS_PARAM1); \
	(((RTDS_TN_SN_CloseMessageLogfile_data*)RTDS_msgData)->param2) = (RTDS_PARAM2); \
	(((RTDS_TN_SN_CloseMessageLogfile_data*)RTDS_msgData)->param3) = (RTDS_PARAM3); \
	RTDS_MSG_QUEUE_SEND_TO_NAME(TN_SN_CloseMessageLogfile, sizeof(RTDS_TN_SN_CloseMessageLogfile_data), RTDS_msgData, RECEIVER, RECEIVER_NUMBER); \
	}
#endif /* RTDS_MSG_SEND_TN_SN_CloseMessageLogfile_TO_NAME defined */

/* MACRO FOR SENDING MESSAGE TN_SN_CloseMessageLogfile TO A PROCESS ID */

#ifndef RTDS_MSG_SEND_TN_SN_CloseMessageLogfile_TO_ID
#define RTDS_MSG_SEND_TN_SN_CloseMessageLogfile_TO_ID(RECEIVER, RTDS_PARAM1, RTDS_PARAM2, RTDS_PARAM3) \
	{ \
	RTDS_msgData = (unsigned char *)new RTDS_TN_SN_CloseMessageLogfile_data(); \
	(((RTDS_TN_SN_CloseMessageLogfile_data*)RTDS_msgData)->param1) = (RTDS_PARAM1); \
	(((RTDS_TN_SN_CloseMessageLogfile_data*)RTDS_msgData)->param2) = (RTDS_PARAM2); \
	(((RTDS_TN_SN_CloseMessageLogfile_data*)RTDS_msgData)->param3) = (RTDS_PARAM3); \
	RTDS_MSG_QUEUE_SEND_TO_ID(TN_SN_CloseMessageLogfile, sizeof(RTDS_TN_SN_CloseMessageLogfile_data), RTDS_msgData, RECEIVER); \
	}
#endif /* RTDS_MSG_SEND_TN_SN_CloseMessageLogfile_TO_ID defined */

/* MACROS FOR SENDING MESSAGE TN_SN_CloseMessageLogfile TO ENVIRONMENT */

#ifndef RTDS_MSG_SEND_TN_SN_CloseMessageLogfile_TO_ENV
#define RTDS_MSG_SEND_TN_SN_CloseMessageLogfile_TO_ENV(RTDS_PARAM1, RTDS_PARAM2, RTDS_PARAM3) \
	{ \
	RTDS_msgData = (unsigned char *)new RTDS_TN_SN_CloseMessageLogfile_data(); \
	(((RTDS_TN_SN_CloseMessageLogfile_data*)RTDS_msgData)->param1) = (RTDS_PARAM1); \
	(((RTDS_TN_SN_CloseMessageLogfile_data*)RTDS_msgData)->param2) = (RTDS_PARAM2); \
	(((RTDS_TN_SN_CloseMessageLogfile_data*)RTDS_msgData)->param3) = (RTDS_PARAM3); \
	RTDS_MSG_QUEUE_SEND_TO_ENV(TN_SN_CloseMessageLogfile, sizeof(RTDS_TN_SN_CloseMessageLogfile_data), RTDS_msgData); \
	}
#endif /* RTDS_MSG_SEND_TN_SN_CloseMessageLogfile_TO_ENV defined */

#ifndef RTDS_MSG_SEND_TN_SN_CloseMessageLogfile_TO_ENV_W_MACRO
#define RTDS_MSG_SEND_TN_SN_CloseMessageLogfile_TO_ENV_W_MACRO(MACRO_NAME, RTDS_PARAM1, RTDS_PARAM2, RTDS_PARAM3) \
	{ \
	RTDS_msgData = (unsigned char *)new RTDS_TN_SN_CloseMessageLogfile_data(); \
	(((RTDS_TN_SN_CloseMessageLogfile_data*)RTDS_msgData)->param1) = (RTDS_PARAM1); \
	(((RTDS_TN_SN_CloseMessageLogfile_data*)RTDS_msgData)->param2) = (RTDS_PARAM2); \
	(((RTDS_TN_SN_CloseMessageLogfile_data*)RTDS_msgData)->param3) = (RTDS_PARAM3); \
	MACRO_NAME(TN_SN_CloseMessageLogfile, sizeof(RTDS_TN_SN_CloseMessageLogfile_data), RTDS_msgData); \
	}
#endif /* RTDS_MSG_SEND_TN_SN_CloseMessageLogfile_TO_ENV defined */

/* MACRO FOR RECEPTION OF MESSAGE Message_TE_TE_TL_AGN */

#ifndef RTDS_MSG_RECEIVE_Message_TE_TE_TL_AGN
#define RTDS_MSG_RECEIVE_Message_TE_TE_TL_AGN(RTDS_PARAM1, RTDS_PARAM2, RTDS_PARAM3, RTDS_PARAM4) \
	{ \
	RTDS_msgData = (unsigned char *)(RTDS_currentContext->currentMessage->pData); \
	if ( RTDS_msgData != NULL ) \
		{ \
		(RTDS_PARAM1) = (((RTDS_Message_TE_TE_TL_AGN_data*)RTDS_msgData)->param1); \
		(RTDS_PARAM2) = (((RTDS_Message_TE_TE_TL_AGN_data*)RTDS_msgData)->param2); \
		(RTDS_PARAM3) = (((RTDS_Message_TE_TE_TL_AGN_data*)RTDS_msgData)->param3); \
		(RTDS_PARAM4) = (((RTDS_Message_TE_TE_TL_AGN_data*)RTDS_msgData)->param4); \
		} \
	else \
		{ \
		RTDS_MSG_INPUT_ERROR; \
		} \
	}
#endif /* RTDS_MSG_RECEIVE_Message_TE_TE_TL_AGN defined */

/* MACRO FOR SENDING MESSAGE Message_TE_TE_TL_AGN TO A PROCESS NAME */

#ifndef RTDS_MSG_SEND_Message_TE_TE_TL_AGN_TO_NAME
#define RTDS_MSG_SEND_Message_TE_TE_TL_AGN_TO_NAME(RECEIVER, RECEIVER_NUMBER, RTDS_PARAM1, RTDS_PARAM2, RTDS_PARAM3, RTDS_PARAM4) \
	{ \
	RTDS_msgData = (unsigned char *)new RTDS_Message_TE_TE_TL_AGN_data(); \
	(((RTDS_Message_TE_TE_TL_AGN_data*)RTDS_msgData)->param1) = (RTDS_PARAM1); \
	(((RTDS_Message_TE_TE_TL_AGN_data*)RTDS_msgData)->param2) = (RTDS_PARAM2); \
	(((RTDS_Message_TE_TE_TL_AGN_data*)RTDS_msgData)->param3) = (RTDS_PARAM3); \
	(((RTDS_Message_TE_TE_TL_AGN_data*)RTDS_msgData)->param4) = (RTDS_PARAM4); \
	RTDS_MSG_QUEUE_SEND_TO_NAME(Message_TE_TE_TL_AGN, sizeof(RTDS_Message_TE_TE_TL_AGN_data), RTDS_msgData, RECEIVER, RECEIVER_NUMBER); \
	}
#endif /* RTDS_MSG_SEND_Message_TE_TE_TL_AGN_TO_NAME defined */

/* MACRO FOR SENDING MESSAGE Message_TE_TE_TL_AGN TO A PROCESS ID */

#ifndef RTDS_MSG_SEND_Message_TE_TE_TL_AGN_TO_ID
#define RTDS_MSG_SEND_Message_TE_TE_TL_AGN_TO_ID(RECEIVER, RTDS_PARAM1, RTDS_PARAM2, RTDS_PARAM3, RTDS_PARAM4) \
	{ \
	RTDS_msgData = (unsigned char *)new RTDS_Message_TE_TE_TL_AGN_data(); \
	(((RTDS_Message_TE_TE_TL_AGN_data*)RTDS_msgData)->param1) = (RTDS_PARAM1); \
	(((RTDS_Message_TE_TE_TL_AGN_data*)RTDS_msgData)->param2) = (RTDS_PARAM2); \
	(((RTDS_Message_TE_TE_TL_AGN_data*)RTDS_msgData)->param3) = (RTDS_PARAM3); \
	(((RTDS_Message_TE_TE_TL_AGN_data*)RTDS_msgData)->param4) = (RTDS_PARAM4); \
	RTDS_MSG_QUEUE_SEND_TO_ID(Message_TE_TE_TL_AGN, sizeof(RTDS_Message_TE_TE_TL_AGN_data), RTDS_msgData, RECEIVER); \
	}
#endif /* RTDS_MSG_SEND_Message_TE_TE_TL_AGN_TO_ID defined */

/* MACROS FOR SENDING MESSAGE Message_TE_TE_TL_AGN TO ENVIRONMENT */

#ifndef RTDS_MSG_SEND_Message_TE_TE_TL_AGN_TO_ENV
#define RTDS_MSG_SEND_Message_TE_TE_TL_AGN_TO_ENV(RTDS_PARAM1, RTDS_PARAM2, RTDS_PARAM3, RTDS_PARAM4) \
	{ \
	RTDS_msgData = (unsigned char *)new RTDS_Message_TE_TE_TL_AGN_data(); \
	(((RTDS_Message_TE_TE_TL_AGN_data*)RTDS_msgData)->param1) = (RTDS_PARAM1); \
	(((RTDS_Message_TE_TE_TL_AGN_data*)RTDS_msgData)->param2) = (RTDS_PARAM2); \
	(((RTDS_Message_TE_TE_TL_AGN_data*)RTDS_msgData)->param3) = (RTDS_PARAM3); \
	(((RTDS_Message_TE_TE_TL_AGN_data*)RTDS_msgData)->param4) = (RTDS_PARAM4); \
	RTDS_MSG_QUEUE_SEND_TO_ENV(Message_TE_TE_TL_AGN, sizeof(RTDS_Message_TE_TE_TL_AGN_data), RTDS_msgData); \
	}
#endif /* RTDS_MSG_SEND_Message_TE_TE_TL_AGN_TO_ENV defined */

#ifndef RTDS_MSG_SEND_Message_TE_TE_TL_AGN_TO_ENV_W_MACRO
#define RTDS_MSG_SEND_Message_TE_TE_TL_AGN_TO_ENV_W_MACRO(MACRO_NAME, RTDS_PARAM1, RTDS_PARAM2, RTDS_PARAM3, RTDS_PARAM4) \
	{ \
	RTDS_msgData = (unsigned char *)new RTDS_Message_TE_TE_TL_AGN_data(); \
	(((RTDS_Message_TE_TE_TL_AGN_data*)RTDS_msgData)->param1) = (RTDS_PARAM1); \
	(((RTDS_Message_TE_TE_TL_AGN_data*)RTDS_msgData)->param2) = (RTDS_PARAM2); \
	(((RTDS_Message_TE_TE_TL_AGN_data*)RTDS_msgData)->param3) = (RTDS_PARAM3); \
	(((RTDS_Message_TE_TE_TL_AGN_data*)RTDS_msgData)->param4) = (RTDS_PARAM4); \
	MACRO_NAME(Message_TE_TE_TL_AGN, sizeof(RTDS_Message_TE_TE_TL_AGN_data), RTDS_msgData); \
	}
#endif /* RTDS_MSG_SEND_Message_TE_TE_TL_AGN_TO_ENV defined */

/* MACRO FOR RECEPTION OF MESSAGE Message_TE_TE_LL_Idl */

#ifndef RTDS_MSG_RECEIVE_Message_TE_TE_LL_Idl
#define RTDS_MSG_RECEIVE_Message_TE_TE_LL_Idl(RTDS_PARAM1, RTDS_PARAM2, RTDS_PARAM3, RTDS_PARAM4, RTDS_PARAM5) \
	{ \
	RTDS_msgData = (unsigned char *)(RTDS_currentContext->currentMessage->pData); \
	if ( RTDS_msgData != NULL ) \
		{ \
		(RTDS_PARAM1) = (((RTDS_Message_TE_TE_LL_Idl_data*)RTDS_msgData)->param1); \
		(RTDS_PARAM2) = (((RTDS_Message_TE_TE_LL_Idl_data*)RTDS_msgData)->param2); \
		(RTDS_PARAM3) = (((RTDS_Message_TE_TE_LL_Idl_data*)RTDS_msgData)->param3); \
		(RTDS_PARAM4) = (((RTDS_Message_TE_TE_LL_Idl_data*)RTDS_msgData)->param4); \
		(RTDS_PARAM5) = (((RTDS_Message_TE_TE_LL_Idl_data*)RTDS_msgData)->param5); \
		} \
	else \
		{ \
		RTDS_MSG_INPUT_ERROR; \
		} \
	}
#endif /* RTDS_MSG_RECEIVE_Message_TE_TE_LL_Idl defined */

/* MACRO FOR SENDING MESSAGE Message_TE_TE_LL_Idl TO A PROCESS NAME */

#ifndef RTDS_MSG_SEND_Message_TE_TE_LL_Idl_TO_NAME
#define RTDS_MSG_SEND_Message_TE_TE_LL_Idl_TO_NAME(RECEIVER, RECEIVER_NUMBER, RTDS_PARAM1, RTDS_PARAM2, RTDS_PARAM3, RTDS_PARAM4, RTDS_PARAM5) \
	{ \
	RTDS_msgData = (unsigned char *)new RTDS_Message_TE_TE_LL_Idl_data(); \
	(((RTDS_Message_TE_TE_LL_Idl_data*)RTDS_msgData)->param1) = (RTDS_PARAM1); \
	(((RTDS_Message_TE_TE_LL_Idl_data*)RTDS_msgData)->param2) = (RTDS_PARAM2); \
	(((RTDS_Message_TE_TE_LL_Idl_data*)RTDS_msgData)->param3) = (RTDS_PARAM3); \
	(((RTDS_Message_TE_TE_LL_Idl_data*)RTDS_msgData)->param4) = (RTDS_PARAM4); \
	(((RTDS_Message_TE_TE_LL_Idl_data*)RTDS_msgData)->param5) = (RTDS_PARAM5); \
	RTDS_MSG_QUEUE_SEND_TO_NAME(Message_TE_TE_LL_Idl, sizeof(RTDS_Message_TE_TE_LL_Idl_data), RTDS_msgData, RECEIVER, RECEIVER_NUMBER); \
	}
#endif /* RTDS_MSG_SEND_Message_TE_TE_LL_Idl_TO_NAME defined */

/* MACRO FOR SENDING MESSAGE Message_TE_TE_LL_Idl TO A PROCESS ID */

#ifndef RTDS_MSG_SEND_Message_TE_TE_LL_Idl_TO_ID
#define RTDS_MSG_SEND_Message_TE_TE_LL_Idl_TO_ID(RECEIVER, RTDS_PARAM1, RTDS_PARAM2, RTDS_PARAM3, RTDS_PARAM4, RTDS_PARAM5) \
	{ \
	RTDS_msgData = (unsigned char *)new RTDS_Message_TE_TE_LL_Idl_data(); \
	(((RTDS_Message_TE_TE_LL_Idl_data*)RTDS_msgData)->param1) = (RTDS_PARAM1); \
	(((RTDS_Message_TE_TE_LL_Idl_data*)RTDS_msgData)->param2) = (RTDS_PARAM2); \
	(((RTDS_Message_TE_TE_LL_Idl_data*)RTDS_msgData)->param3) = (RTDS_PARAM3); \
	(((RTDS_Message_TE_TE_LL_Idl_data*)RTDS_msgData)->param4) = (RTDS_PARAM4); \
	(((RTDS_Message_TE_TE_LL_Idl_data*)RTDS_msgData)->param5) = (RTDS_PARAM5); \
	RTDS_MSG_QUEUE_SEND_TO_ID(Message_TE_TE_LL_Idl, sizeof(RTDS_Message_TE_TE_LL_Idl_data), RTDS_msgData, RECEIVER); \
	}
#endif /* RTDS_MSG_SEND_Message_TE_TE_LL_Idl_TO_ID defined */

/* MACROS FOR SENDING MESSAGE Message_TE_TE_LL_Idl TO ENVIRONMENT */

#ifndef RTDS_MSG_SEND_Message_TE_TE_LL_Idl_TO_ENV
#define RTDS_MSG_SEND_Message_TE_TE_LL_Idl_TO_ENV(RTDS_PARAM1, RTDS_PARAM2, RTDS_PARAM3, RTDS_PARAM4, RTDS_PARAM5) \
	{ \
	RTDS_msgData = (unsigned char *)new RTDS_Message_TE_TE_LL_Idl_data(); \
	(((RTDS_Message_TE_TE_LL_Idl_data*)RTDS_msgData)->param1) = (RTDS_PARAM1); \
	(((RTDS_Message_TE_TE_LL_Idl_data*)RTDS_msgData)->param2) = (RTDS_PARAM2); \
	(((RTDS_Message_TE_TE_LL_Idl_data*)RTDS_msgData)->param3) = (RTDS_PARAM3); \
	(((RTDS_Message_TE_TE_LL_Idl_data*)RTDS_msgData)->param4) = (RTDS_PARAM4); \
	(((RTDS_Message_TE_TE_LL_Idl_data*)RTDS_msgData)->param5) = (RTDS_PARAM5); \
	RTDS_MSG_QUEUE_SEND_TO_ENV(Message_TE_TE_LL_Idl, sizeof(RTDS_Message_TE_TE_LL_Idl_data), RTDS_msgData); \
	}
#endif /* RTDS_MSG_SEND_Message_TE_TE_LL_Idl_TO_ENV defined */

#ifndef RTDS_MSG_SEND_Message_TE_TE_LL_Idl_TO_ENV_W_MACRO
#define RTDS_MSG_SEND_Message_TE_TE_LL_Idl_TO_ENV_W_MACRO(MACRO_NAME, RTDS_PARAM1, RTDS_PARAM2, RTDS_PARAM3, RTDS_PARAM4, RTDS_PARAM5) \
	{ \
	RTDS_msgData = (unsigned char *)new RTDS_Message_TE_TE_LL_Idl_data(); \
	(((RTDS_Message_TE_TE_LL_Idl_data*)RTDS_msgData)->param1) = (RTDS_PARAM1); \
	(((RTDS_Message_TE_TE_LL_Idl_data*)RTDS_msgData)->param2) = (RTDS_PARAM2); \
	(((RTDS_Message_TE_TE_LL_Idl_data*)RTDS_msgData)->param3) = (RTDS_PARAM3); \
	(((RTDS_Message_TE_TE_LL_Idl_data*)RTDS_msgData)->param4) = (RTDS_PARAM4); \
	(((RTDS_Message_TE_TE_LL_Idl_data*)RTDS_msgData)->param5) = (RTDS_PARAM5); \
	MACRO_NAME(Message_TE_TE_LL_Idl, sizeof(RTDS_Message_TE_TE_LL_Idl_data), RTDS_msgData); \
	}
#endif /* RTDS_MSG_SEND_Message_TE_TE_LL_Idl_TO_ENV defined */

/* MACRO FOR RECEPTION OF MESSAGE Message_TE_TE_LS_Des */

#ifndef RTDS_MSG_RECEIVE_Message_TE_TE_LS_Des
#define RTDS_MSG_RECEIVE_Message_TE_TE_LS_Des(RTDS_PARAM1, RTDS_PARAM2, RTDS_PARAM3, RTDS_PARAM4) \
	{ \
	RTDS_msgData = (unsigned char *)(RTDS_currentContext->currentMessage->pData); \
	if ( RTDS_msgData != NULL ) \
		{ \
		(RTDS_PARAM1) = (((RTDS_Message_TE_TE_LS_Des_data*)RTDS_msgData)->param1); \
		(RTDS_PARAM2) = (((RTDS_Message_TE_TE_LS_Des_data*)RTDS_msgData)->param2); \
		(RTDS_PARAM3) = (((RTDS_Message_TE_TE_LS_Des_data*)RTDS_msgData)->param3); \
		RTDS_PARAM4 = ((RTDS_Message_TE_TE_LS_Des_data*)RTDS_msgData)->param4; \
		} \
	else \
		{ \
		RTDS_MSG_INPUT_ERROR; \
		} \
	}
#endif /* RTDS_MSG_RECEIVE_Message_TE_TE_LS_Des defined */

/* MACRO FOR SENDING MESSAGE Message_TE_TE_LS_Des TO A PROCESS NAME */

#ifndef RTDS_MSG_SEND_Message_TE_TE_LS_Des_TO_NAME
#define RTDS_MSG_SEND_Message_TE_TE_LS_Des_TO_NAME(RECEIVER, RECEIVER_NUMBER, RTDS_PARAM1, RTDS_PARAM2, RTDS_PARAM3, RTDS_PARAM4) \
	{ \
	RTDS_msgData = (unsigned char *)new RTDS_Message_TE_TE_LS_Des_data(); \
	(((RTDS_Message_TE_TE_LS_Des_data*)RTDS_msgData)->param1) = (RTDS_PARAM1); \
	(((RTDS_Message_TE_TE_LS_Des_data*)RTDS_msgData)->param2) = (RTDS_PARAM2); \
	(((RTDS_Message_TE_TE_LS_Des_data*)RTDS_msgData)->param3) = (RTDS_PARAM3); \
	((RTDS_Message_TE_TE_LS_Des_data*)RTDS_msgData)->param4 = RTDS_PARAM4; \
	RTDS_MSG_QUEUE_SEND_TO_NAME(Message_TE_TE_LS_Des, sizeof(RTDS_Message_TE_TE_LS_Des_data), RTDS_msgData, RECEIVER, RECEIVER_NUMBER); \
	}
#endif /* RTDS_MSG_SEND_Message_TE_TE_LS_Des_TO_NAME defined */

/* MACRO FOR SENDING MESSAGE Message_TE_TE_LS_Des TO A PROCESS ID */

#ifndef RTDS_MSG_SEND_Message_TE_TE_LS_Des_TO_ID
#define RTDS_MSG_SEND_Message_TE_TE_LS_Des_TO_ID(RECEIVER, RTDS_PARAM1, RTDS_PARAM2, RTDS_PARAM3, RTDS_PARAM4) \
	{ \
	RTDS_msgData = (unsigned char *)new RTDS_Message_TE_TE_LS_Des_data(); \
	(((RTDS_Message_TE_TE_LS_Des_data*)RTDS_msgData)->param1) = (RTDS_PARAM1); \
	(((RTDS_Message_TE_TE_LS_Des_data*)RTDS_msgData)->param2) = (RTDS_PARAM2); \
	(((RTDS_Message_TE_TE_LS_Des_data*)RTDS_msgData)->param3) = (RTDS_PARAM3); \
	((RTDS_Message_TE_TE_LS_Des_data*)RTDS_msgData)->param4 = RTDS_PARAM4; \
	RTDS_MSG_QUEUE_SEND_TO_ID(Message_TE_TE_LS_Des, sizeof(RTDS_Message_TE_TE_LS_Des_data), RTDS_msgData, RECEIVER); \
	}
#endif /* RTDS_MSG_SEND_Message_TE_TE_LS_Des_TO_ID defined */

/* MACROS FOR SENDING MESSAGE Message_TE_TE_LS_Des TO ENVIRONMENT */

#ifndef RTDS_MSG_SEND_Message_TE_TE_LS_Des_TO_ENV
#define RTDS_MSG_SEND_Message_TE_TE_LS_Des_TO_ENV(RTDS_PARAM1, RTDS_PARAM2, RTDS_PARAM3, RTDS_PARAM4) \
	{ \
	RTDS_msgData = (unsigned char *)new RTDS_Message_TE_TE_LS_Des_data(); \
	(((RTDS_Message_TE_TE_LS_Des_data*)RTDS_msgData)->param1) = (RTDS_PARAM1); \
	(((RTDS_Message_TE_TE_LS_Des_data*)RTDS_msgData)->param2) = (RTDS_PARAM2); \
	(((RTDS_Message_TE_TE_LS_Des_data*)RTDS_msgData)->param3) = (RTDS_PARAM3); \
	((RTDS_Message_TE_TE_LS_Des_data*)RTDS_msgData)->param4 = RTDS_PARAM4; \
	RTDS_MSG_QUEUE_SEND_TO_ENV(Message_TE_TE_LS_Des, sizeof(RTDS_Message_TE_TE_LS_Des_data), RTDS_msgData); \
	}
#endif /* RTDS_MSG_SEND_Message_TE_TE_LS_Des_TO_ENV defined */

#ifndef RTDS_MSG_SEND_Message_TE_TE_LS_Des_TO_ENV_W_MACRO
#define RTDS_MSG_SEND_Message_TE_TE_LS_Des_TO_ENV_W_MACRO(MACRO_NAME, RTDS_PARAM1, RTDS_PARAM2, RTDS_PARAM3, RTDS_PARAM4) \
	{ \
	RTDS_msgData = (unsigned char *)new RTDS_Message_TE_TE_LS_Des_data(); \
	(((RTDS_Message_TE_TE_LS_Des_data*)RTDS_msgData)->param1) = (RTDS_PARAM1); \
	(((RTDS_Message_TE_TE_LS_Des_data*)RTDS_msgData)->param2) = (RTDS_PARAM2); \
	(((RTDS_Message_TE_TE_LS_Des_data*)RTDS_msgData)->param3) = (RTDS_PARAM3); \
	((RTDS_Message_TE_TE_LS_Des_data*)RTDS_msgData)->param4 = RTDS_PARAM4; \
	MACRO_NAME(Message_TE_TE_LS_Des, sizeof(RTDS_Message_TE_TE_LS_Des_data), RTDS_msgData); \
	}
#endif /* RTDS_MSG_SEND_Message_TE_TE_LS_Des_TO_ENV defined */

/* MACRO FOR RECEPTION OF MESSAGE Message_TE_TE_LE_Sum */

#ifndef RTDS_MSG_RECEIVE_Message_TE_TE_LE_Sum
#define RTDS_MSG_RECEIVE_Message_TE_TE_LE_Sum(RTDS_PARAM1, RTDS_PARAM2, RTDS_PARAM3, RTDS_PARAM4, RTDS_PARAM5, RTDS_PARAM6, RTDS_PARAM7, RTDS_PARAM8) \
	{ \
	RTDS_msgData = (unsigned char *)(RTDS_currentContext->currentMessage->pData); \
	if ( RTDS_msgData != NULL ) \
		{ \
		(RTDS_PARAM1) = (((RTDS_Message_TE_TE_LE_Sum_data*)RTDS_msgData)->param1); \
		(RTDS_PARAM2) = (((RTDS_Message_TE_TE_LE_Sum_data*)RTDS_msgData)->param2); \
		(RTDS_PARAM3) = (((RTDS_Message_TE_TE_LE_Sum_data*)RTDS_msgData)->param3); \
		RTDS_PARAM4 = ((RTDS_Message_TE_TE_LE_Sum_data*)RTDS_msgData)->param4; \
		(RTDS_PARAM5) = (((RTDS_Message_TE_TE_LE_Sum_data*)RTDS_msgData)->param5); \
		(RTDS_PARAM6) = (((RTDS_Message_TE_TE_LE_Sum_data*)RTDS_msgData)->param6); \
		(RTDS_PARAM7) = (((RTDS_Message_TE_TE_LE_Sum_data*)RTDS_msgData)->param7); \
		RTDS_PARAM8 = ((RTDS_Message_TE_TE_LE_Sum_data*)RTDS_msgData)->param8; \
		} \
	else \
		{ \
		RTDS_MSG_INPUT_ERROR; \
		} \
	}
#endif /* RTDS_MSG_RECEIVE_Message_TE_TE_LE_Sum defined */

/* MACRO FOR SENDING MESSAGE Message_TE_TE_LE_Sum TO A PROCESS NAME */

#ifndef RTDS_MSG_SEND_Message_TE_TE_LE_Sum_TO_NAME
#define RTDS_MSG_SEND_Message_TE_TE_LE_Sum_TO_NAME(RECEIVER, RECEIVER_NUMBER, RTDS_PARAM1, RTDS_PARAM2, RTDS_PARAM3, RTDS_PARAM4, RTDS_PARAM5, RTDS_PARAM6, RTDS_PARAM7, RTDS_PARAM8) \
	{ \
	RTDS_msgData = (unsigned char *)new RTDS_Message_TE_TE_LE_Sum_data(); \
	(((RTDS_Message_TE_TE_LE_Sum_data*)RTDS_msgData)->param1) = (RTDS_PARAM1); \
	(((RTDS_Message_TE_TE_LE_Sum_data*)RTDS_msgData)->param2) = (RTDS_PARAM2); \
	(((RTDS_Message_TE_TE_LE_Sum_data*)RTDS_msgData)->param3) = (RTDS_PARAM3); \
	((RTDS_Message_TE_TE_LE_Sum_data*)RTDS_msgData)->param4 = RTDS_PARAM4; \
	(((RTDS_Message_TE_TE_LE_Sum_data*)RTDS_msgData)->param5) = (RTDS_PARAM5); \
	(((RTDS_Message_TE_TE_LE_Sum_data*)RTDS_msgData)->param6) = (RTDS_PARAM6); \
	(((RTDS_Message_TE_TE_LE_Sum_data*)RTDS_msgData)->param7) = (RTDS_PARAM7); \
	((RTDS_Message_TE_TE_LE_Sum_data*)RTDS_msgData)->param8 = RTDS_PARAM8; \
	RTDS_MSG_QUEUE_SEND_TO_NAME(Message_TE_TE_LE_Sum, sizeof(RTDS_Message_TE_TE_LE_Sum_data), RTDS_msgData, RECEIVER, RECEIVER_NUMBER); \
	}
#endif /* RTDS_MSG_SEND_Message_TE_TE_LE_Sum_TO_NAME defined */

/* MACRO FOR SENDING MESSAGE Message_TE_TE_LE_Sum TO A PROCESS ID */

#ifndef RTDS_MSG_SEND_Message_TE_TE_LE_Sum_TO_ID
#define RTDS_MSG_SEND_Message_TE_TE_LE_Sum_TO_ID(RECEIVER, RTDS_PARAM1, RTDS_PARAM2, RTDS_PARAM3, RTDS_PARAM4, RTDS_PARAM5, RTDS_PARAM6, RTDS_PARAM7, RTDS_PARAM8) \
	{ \
	RTDS_msgData = (unsigned char *)new RTDS_Message_TE_TE_LE_Sum_data(); \
	(((RTDS_Message_TE_TE_LE_Sum_data*)RTDS_msgData)->param1) = (RTDS_PARAM1); \
	(((RTDS_Message_TE_TE_LE_Sum_data*)RTDS_msgData)->param2) = (RTDS_PARAM2); \
	(((RTDS_Message_TE_TE_LE_Sum_data*)RTDS_msgData)->param3) = (RTDS_PARAM3); \
	((RTDS_Message_TE_TE_LE_Sum_data*)RTDS_msgData)->param4 = RTDS_PARAM4; \
	(((RTDS_Message_TE_TE_LE_Sum_data*)RTDS_msgData)->param5) = (RTDS_PARAM5); \
	(((RTDS_Message_TE_TE_LE_Sum_data*)RTDS_msgData)->param6) = (RTDS_PARAM6); \
	(((RTDS_Message_TE_TE_LE_Sum_data*)RTDS_msgData)->param7) = (RTDS_PARAM7); \
	((RTDS_Message_TE_TE_LE_Sum_data*)RTDS_msgData)->param8 = RTDS_PARAM8; \
	RTDS_MSG_QUEUE_SEND_TO_ID(Message_TE_TE_LE_Sum, sizeof(RTDS_Message_TE_TE_LE_Sum_data), RTDS_msgData, RECEIVER); \
	}
#endif /* RTDS_MSG_SEND_Message_TE_TE_LE_Sum_TO_ID defined */

/* MACROS FOR SENDING MESSAGE Message_TE_TE_LE_Sum TO ENVIRONMENT */

#ifndef RTDS_MSG_SEND_Message_TE_TE_LE_Sum_TO_ENV
#define RTDS_MSG_SEND_Message_TE_TE_LE_Sum_TO_ENV(RTDS_PARAM1, RTDS_PARAM2, RTDS_PARAM3, RTDS_PARAM4, RTDS_PARAM5, RTDS_PARAM6, RTDS_PARAM7, RTDS_PARAM8) \
	{ \
	RTDS_msgData = (unsigned char *)new RTDS_Message_TE_TE_LE_Sum_data(); \
	(((RTDS_Message_TE_TE_LE_Sum_data*)RTDS_msgData)->param1) = (RTDS_PARAM1); \
	(((RTDS_Message_TE_TE_LE_Sum_data*)RTDS_msgData)->param2) = (RTDS_PARAM2); \
	(((RTDS_Message_TE_TE_LE_Sum_data*)RTDS_msgData)->param3) = (RTDS_PARAM3); \
	((RTDS_Message_TE_TE_LE_Sum_data*)RTDS_msgData)->param4 = RTDS_PARAM4; \
	(((RTDS_Message_TE_TE_LE_Sum_data*)RTDS_msgData)->param5) = (RTDS_PARAM5); \
	(((RTDS_Message_TE_TE_LE_Sum_data*)RTDS_msgData)->param6) = (RTDS_PARAM6); \
	(((RTDS_Message_TE_TE_LE_Sum_data*)RTDS_msgData)->param7) = (RTDS_PARAM7); \
	((RTDS_Message_TE_TE_LE_Sum_data*)RTDS_msgData)->param8 = RTDS_PARAM8; \
	RTDS_MSG_QUEUE_SEND_TO_ENV(Message_TE_TE_LE_Sum, sizeof(RTDS_Message_TE_TE_LE_Sum_data), RTDS_msgData); \
	}
#endif /* RTDS_MSG_SEND_Message_TE_TE_LE_Sum_TO_ENV defined */

#ifndef RTDS_MSG_SEND_Message_TE_TE_LE_Sum_TO_ENV_W_MACRO
#define RTDS_MSG_SEND_Message_TE_TE_LE_Sum_TO_ENV_W_MACRO(MACRO_NAME, RTDS_PARAM1, RTDS_PARAM2, RTDS_PARAM3, RTDS_PARAM4, RTDS_PARAM5, RTDS_PARAM6, RTDS_PARAM7, RTDS_PARAM8) \
	{ \
	RTDS_msgData = (unsigned char *)new RTDS_Message_TE_TE_LE_Sum_data(); \
	(((RTDS_Message_TE_TE_LE_Sum_data*)RTDS_msgData)->param1) = (RTDS_PARAM1); \
	(((RTDS_Message_TE_TE_LE_Sum_data*)RTDS_msgData)->param2) = (RTDS_PARAM2); \
	(((RTDS_Message_TE_TE_LE_Sum_data*)RTDS_msgData)->param3) = (RTDS_PARAM3); \
	((RTDS_Message_TE_TE_LE_Sum_data*)RTDS_msgData)->param4 = RTDS_PARAM4; \
	(((RTDS_Message_TE_TE_LE_Sum_data*)RTDS_msgData)->param5) = (RTDS_PARAM5); \
	(((RTDS_Message_TE_TE_LE_Sum_data*)RTDS_msgData)->param6) = (RTDS_PARAM6); \
	(((RTDS_Message_TE_TE_LE_Sum_data*)RTDS_msgData)->param7) = (RTDS_PARAM7); \
	((RTDS_Message_TE_TE_LE_Sum_data*)RTDS_msgData)->param8 = RTDS_PARAM8; \
	MACRO_NAME(Message_TE_TE_LE_Sum, sizeof(RTDS_Message_TE_TE_LE_Sum_data), RTDS_msgData); \
	}
#endif /* RTDS_MSG_SEND_Message_TE_TE_LE_Sum_TO_ENV defined */

/* MACRO FOR RECEPTION OF MESSAGE SN_LN_Detection */

#ifndef RTDS_MSG_RECEIVE_SN_LN_Detection
#define RTDS_MSG_RECEIVE_SN_LN_Detection(RTDS_PARAM1, RTDS_PARAM2, RTDS_PARAM3, RTDS_PARAM4, RTDS_PARAM5, RTDS_PARAM6, RTDS_PARAM7, RTDS_PARAM8, RTDS_PARAM9) \
	{ \
	RTDS_msgData = (unsigned char *)(RTDS_currentContext->currentMessage->pData); \
	if ( RTDS_msgData != NULL ) \
		{ \
		(RTDS_PARAM1) = (((RTDS_SN_LN_Detection_data*)RTDS_msgData)->param1); \
		(RTDS_PARAM2) = (((RTDS_SN_LN_Detection_data*)RTDS_msgData)->param2); \
		(RTDS_PARAM3) = (((RTDS_SN_LN_Detection_data*)RTDS_msgData)->param3); \
		(RTDS_PARAM4) = (((RTDS_SN_LN_Detection_data*)RTDS_msgData)->param4); \
		(RTDS_PARAM5) = (((RTDS_SN_LN_Detection_data*)RTDS_msgData)->param5); \
		(RTDS_PARAM6) = (((RTDS_SN_LN_Detection_data*)RTDS_msgData)->param6); \
		(RTDS_PARAM7) = (((RTDS_SN_LN_Detection_data*)RTDS_msgData)->param7); \
		RTDS_PARAM8 = ((RTDS_SN_LN_Detection_data*)RTDS_msgData)->param8; \
		RTDS_PARAM9 = ((RTDS_SN_LN_Detection_data*)RTDS_msgData)->param9; \
		} \
	else \
		{ \
		RTDS_MSG_INPUT_ERROR; \
		} \
	}
#endif /* RTDS_MSG_RECEIVE_SN_LN_Detection defined */

/* MACRO FOR SENDING MESSAGE SN_LN_Detection TO A PROCESS NAME */

#ifndef RTDS_MSG_SEND_SN_LN_Detection_TO_NAME
#define RTDS_MSG_SEND_SN_LN_Detection_TO_NAME(RECEIVER, RECEIVER_NUMBER, RTDS_PARAM1, RTDS_PARAM2, RTDS_PARAM3, RTDS_PARAM4, RTDS_PARAM5, RTDS_PARAM6, RTDS_PARAM7, RTDS_PARAM8, RTDS_PARAM9) \
	{ \
	RTDS_msgData = (unsigned char *)new RTDS_SN_LN_Detection_data(); \
	(((RTDS_SN_LN_Detection_data*)RTDS_msgData)->param1) = (RTDS_PARAM1); \
	(((RTDS_SN_LN_Detection_data*)RTDS_msgData)->param2) = (RTDS_PARAM2); \
	(((RTDS_SN_LN_Detection_data*)RTDS_msgData)->param3) = (RTDS_PARAM3); \
	(((RTDS_SN_LN_Detection_data*)RTDS_msgData)->param4) = (RTDS_PARAM4); \
	(((RTDS_SN_LN_Detection_data*)RTDS_msgData)->param5) = (RTDS_PARAM5); \
	(((RTDS_SN_LN_Detection_data*)RTDS_msgData)->param6) = (RTDS_PARAM6); \
	(((RTDS_SN_LN_Detection_data*)RTDS_msgData)->param7) = (RTDS_PARAM7); \
	((RTDS_SN_LN_Detection_data*)RTDS_msgData)->param8 = RTDS_PARAM8; \
	((RTDS_SN_LN_Detection_data*)RTDS_msgData)->param9 = RTDS_PARAM9; \
	RTDS_MSG_QUEUE_SEND_TO_NAME(SN_LN_Detection, sizeof(RTDS_SN_LN_Detection_data), RTDS_msgData, RECEIVER, RECEIVER_NUMBER); \
	}
#endif /* RTDS_MSG_SEND_SN_LN_Detection_TO_NAME defined */

/* MACRO FOR SENDING MESSAGE SN_LN_Detection TO A PROCESS ID */

#ifndef RTDS_MSG_SEND_SN_LN_Detection_TO_ID
#define RTDS_MSG_SEND_SN_LN_Detection_TO_ID(RECEIVER, RTDS_PARAM1, RTDS_PARAM2, RTDS_PARAM3, RTDS_PARAM4, RTDS_PARAM5, RTDS_PARAM6, RTDS_PARAM7, RTDS_PARAM8, RTDS_PARAM9) \
	{ \
	RTDS_msgData = (unsigned char *)new RTDS_SN_LN_Detection_data(); \
	(((RTDS_SN_LN_Detection_data*)RTDS_msgData)->param1) = (RTDS_PARAM1); \
	(((RTDS_SN_LN_Detection_data*)RTDS_msgData)->param2) = (RTDS_PARAM2); \
	(((RTDS_SN_LN_Detection_data*)RTDS_msgData)->param3) = (RTDS_PARAM3); \
	(((RTDS_SN_LN_Detection_data*)RTDS_msgData)->param4) = (RTDS_PARAM4); \
	(((RTDS_SN_LN_Detection_data*)RTDS_msgData)->param5) = (RTDS_PARAM5); \
	(((RTDS_SN_LN_Detection_data*)RTDS_msgData)->param6) = (RTDS_PARAM6); \
	(((RTDS_SN_LN_Detection_data*)RTDS_msgData)->param7) = (RTDS_PARAM7); \
	((RTDS_SN_LN_Detection_data*)RTDS_msgData)->param8 = RTDS_PARAM8; \
	((RTDS_SN_LN_Detection_data*)RTDS_msgData)->param9 = RTDS_PARAM9; \
	RTDS_MSG_QUEUE_SEND_TO_ID(SN_LN_Detection, sizeof(RTDS_SN_LN_Detection_data), RTDS_msgData, RECEIVER); \
	}
#endif /* RTDS_MSG_SEND_SN_LN_Detection_TO_ID defined */

/* MACROS FOR SENDING MESSAGE SN_LN_Detection TO ENVIRONMENT */

#ifndef RTDS_MSG_SEND_SN_LN_Detection_TO_ENV
#define RTDS_MSG_SEND_SN_LN_Detection_TO_ENV(RTDS_PARAM1, RTDS_PARAM2, RTDS_PARAM3, RTDS_PARAM4, RTDS_PARAM5, RTDS_PARAM6, RTDS_PARAM7, RTDS_PARAM8, RTDS_PARAM9) \
	{ \
	RTDS_msgData = (unsigned char *)new RTDS_SN_LN_Detection_data(); \
	(((RTDS_SN_LN_Detection_data*)RTDS_msgData)->param1) = (RTDS_PARAM1); \
	(((RTDS_SN_LN_Detection_data*)RTDS_msgData)->param2) = (RTDS_PARAM2); \
	(((RTDS_SN_LN_Detection_data*)RTDS_msgData)->param3) = (RTDS_PARAM3); \
	(((RTDS_SN_LN_Detection_data*)RTDS_msgData)->param4) = (RTDS_PARAM4); \
	(((RTDS_SN_LN_Detection_data*)RTDS_msgData)->param5) = (RTDS_PARAM5); \
	(((RTDS_SN_LN_Detection_data*)RTDS_msgData)->param6) = (RTDS_PARAM6); \
	(((RTDS_SN_LN_Detection_data*)RTDS_msgData)->param7) = (RTDS_PARAM7); \
	((RTDS_SN_LN_Detection_data*)RTDS_msgData)->param8 = RTDS_PARAM8; \
	((RTDS_SN_LN_Detection_data*)RTDS_msgData)->param9 = RTDS_PARAM9; \
	RTDS_MSG_QUEUE_SEND_TO_ENV(SN_LN_Detection, sizeof(RTDS_SN_LN_Detection_data), RTDS_msgData); \
	}
#endif /* RTDS_MSG_SEND_SN_LN_Detection_TO_ENV defined */

#ifndef RTDS_MSG_SEND_SN_LN_Detection_TO_ENV_W_MACRO
#define RTDS_MSG_SEND_SN_LN_Detection_TO_ENV_W_MACRO(MACRO_NAME, RTDS_PARAM1, RTDS_PARAM2, RTDS_PARAM3, RTDS_PARAM4, RTDS_PARAM5, RTDS_PARAM6, RTDS_PARAM7, RTDS_PARAM8, RTDS_PARAM9) \
	{ \
	RTDS_msgData = (unsigned char *)new RTDS_SN_LN_Detection_data(); \
	(((RTDS_SN_LN_Detection_data*)RTDS_msgData)->param1) = (RTDS_PARAM1); \
	(((RTDS_SN_LN_Detection_data*)RTDS_msgData)->param2) = (RTDS_PARAM2); \
	(((RTDS_SN_LN_Detection_data*)RTDS_msgData)->param3) = (RTDS_PARAM3); \
	(((RTDS_SN_LN_Detection_data*)RTDS_msgData)->param4) = (RTDS_PARAM4); \
	(((RTDS_SN_LN_Detection_data*)RTDS_msgData)->param5) = (RTDS_PARAM5); \
	(((RTDS_SN_LN_Detection_data*)RTDS_msgData)->param6) = (RTDS_PARAM6); \
	(((RTDS_SN_LN_Detection_data*)RTDS_msgData)->param7) = (RTDS_PARAM7); \
	((RTDS_SN_LN_Detection_data*)RTDS_msgData)->param8 = RTDS_PARAM8; \
	((RTDS_SN_LN_Detection_data*)RTDS_msgData)->param9 = RTDS_PARAM9; \
	MACRO_NAME(SN_LN_Detection, sizeof(RTDS_SN_LN_Detection_data), RTDS_msgData); \
	}
#endif /* RTDS_MSG_SEND_SN_LN_Detection_TO_ENV defined */

/* MACRO FOR RECEPTION OF MESSAGE LN_LN_Description */

#ifndef RTDS_MSG_RECEIVE_LN_LN_Description
#define RTDS_MSG_RECEIVE_LN_LN_Description(RTDS_PARAM1, RTDS_PARAM2, RTDS_PARAM3) \
	{ \
	RTDS_msgData = (unsigned char *)(RTDS_currentContext->currentMessage->pData); \
	if ( RTDS_msgData != NULL ) \
		{ \
		(RTDS_PARAM1) = (((RTDS_LN_LN_Description_data*)RTDS_msgData)->param1); \
		(RTDS_PARAM2) = (((RTDS_LN_LN_Description_data*)RTDS_msgData)->param2); \
		RTDS_PARAM3 = ((RTDS_LN_LN_Description_data*)RTDS_msgData)->param3; \
		} \
	else \
		{ \
		RTDS_MSG_INPUT_ERROR; \
		} \
	}
#endif /* RTDS_MSG_RECEIVE_LN_LN_Description defined */

/* MACRO FOR SENDING MESSAGE LN_LN_Description TO A PROCESS NAME */

#ifndef RTDS_MSG_SEND_LN_LN_Description_TO_NAME
#define RTDS_MSG_SEND_LN_LN_Description_TO_NAME(RECEIVER, RECEIVER_NUMBER, RTDS_PARAM1, RTDS_PARAM2, RTDS_PARAM3) \
	{ \
	RTDS_msgData = (unsigned char *)new RTDS_LN_LN_Description_data(); \
	(((RTDS_LN_LN_Description_data*)RTDS_msgData)->param1) = (RTDS_PARAM1); \
	(((RTDS_LN_LN_Description_data*)RTDS_msgData)->param2) = (RTDS_PARAM2); \
	((RTDS_LN_LN_Description_data*)RTDS_msgData)->param3 = RTDS_PARAM3; \
	RTDS_MSG_QUEUE_SEND_TO_NAME(LN_LN_Description, sizeof(RTDS_LN_LN_Description_data), RTDS_msgData, RECEIVER, RECEIVER_NUMBER); \
	}
#endif /* RTDS_MSG_SEND_LN_LN_Description_TO_NAME defined */

/* MACRO FOR SENDING MESSAGE LN_LN_Description TO A PROCESS ID */

#ifndef RTDS_MSG_SEND_LN_LN_Description_TO_ID
#define RTDS_MSG_SEND_LN_LN_Description_TO_ID(RECEIVER, RTDS_PARAM1, RTDS_PARAM2, RTDS_PARAM3) \
	{ \
	RTDS_msgData = (unsigned char *)new RTDS_LN_LN_Description_data(); \
	(((RTDS_LN_LN_Description_data*)RTDS_msgData)->param1) = (RTDS_PARAM1); \
	(((RTDS_LN_LN_Description_data*)RTDS_msgData)->param2) = (RTDS_PARAM2); \
	((RTDS_LN_LN_Description_data*)RTDS_msgData)->param3 = RTDS_PARAM3; \
	RTDS_MSG_QUEUE_SEND_TO_ID(LN_LN_Description, sizeof(RTDS_LN_LN_Description_data), RTDS_msgData, RECEIVER); \
	}
#endif /* RTDS_MSG_SEND_LN_LN_Description_TO_ID defined */

/* MACROS FOR SENDING MESSAGE LN_LN_Description TO ENVIRONMENT */

#ifndef RTDS_MSG_SEND_LN_LN_Description_TO_ENV
#define RTDS_MSG_SEND_LN_LN_Description_TO_ENV(RTDS_PARAM1, RTDS_PARAM2, RTDS_PARAM3) \
	{ \
	RTDS_msgData = (unsigned char *)new RTDS_LN_LN_Description_data(); \
	(((RTDS_LN_LN_Description_data*)RTDS_msgData)->param1) = (RTDS_PARAM1); \
	(((RTDS_LN_LN_Description_data*)RTDS_msgData)->param2) = (RTDS_PARAM2); \
	((RTDS_LN_LN_Description_data*)RTDS_msgData)->param3 = RTDS_PARAM3; \
	RTDS_MSG_QUEUE_SEND_TO_ENV(LN_LN_Description, sizeof(RTDS_LN_LN_Description_data), RTDS_msgData); \
	}
#endif /* RTDS_MSG_SEND_LN_LN_Description_TO_ENV defined */

#ifndef RTDS_MSG_SEND_LN_LN_Description_TO_ENV_W_MACRO
#define RTDS_MSG_SEND_LN_LN_Description_TO_ENV_W_MACRO(MACRO_NAME, RTDS_PARAM1, RTDS_PARAM2, RTDS_PARAM3) \
	{ \
	RTDS_msgData = (unsigned char *)new RTDS_LN_LN_Description_data(); \
	(((RTDS_LN_LN_Description_data*)RTDS_msgData)->param1) = (RTDS_PARAM1); \
	(((RTDS_LN_LN_Description_data*)RTDS_msgData)->param2) = (RTDS_PARAM2); \
	((RTDS_LN_LN_Description_data*)RTDS_msgData)->param3 = RTDS_PARAM3; \
	MACRO_NAME(LN_LN_Description, sizeof(RTDS_LN_LN_Description_data), RTDS_msgData); \
	}
#endif /* RTDS_MSG_SEND_LN_LN_Description_TO_ENV defined */

/* MACRO FOR RECEPTION OF MESSAGE TN_SN_AskGroupId */

#ifndef RTDS_MSG_RECEIVE_TN_SN_AskGroupId
#define RTDS_MSG_RECEIVE_TN_SN_AskGroupId(RTDS_PARAM1, RTDS_PARAM2) \
	{ \
	RTDS_msgData = (unsigned char *)(RTDS_currentContext->currentMessage->pData); \
	if ( RTDS_msgData != NULL ) \
		{ \
		(RTDS_PARAM1) = (((RTDS_TN_SN_AskGroupId_data*)RTDS_msgData)->param1); \
		(RTDS_PARAM2) = (((RTDS_TN_SN_AskGroupId_data*)RTDS_msgData)->param2); \
		} \
	else \
		{ \
		RTDS_MSG_INPUT_ERROR; \
		} \
	}
#endif /* RTDS_MSG_RECEIVE_TN_SN_AskGroupId defined */

/* MACRO FOR SENDING MESSAGE TN_SN_AskGroupId TO A PROCESS NAME */

#ifndef RTDS_MSG_SEND_TN_SN_AskGroupId_TO_NAME
#define RTDS_MSG_SEND_TN_SN_AskGroupId_TO_NAME(RECEIVER, RECEIVER_NUMBER, RTDS_PARAM1, RTDS_PARAM2) \
	{ \
	RTDS_msgData = (unsigned char *)new RTDS_TN_SN_AskGroupId_data(); \
	(((RTDS_TN_SN_AskGroupId_data*)RTDS_msgData)->param1) = (RTDS_PARAM1); \
	(((RTDS_TN_SN_AskGroupId_data*)RTDS_msgData)->param2) = (RTDS_PARAM2); \
	RTDS_MSG_QUEUE_SEND_TO_NAME(TN_SN_AskGroupId, sizeof(RTDS_TN_SN_AskGroupId_data), RTDS_msgData, RECEIVER, RECEIVER_NUMBER); \
	}
#endif /* RTDS_MSG_SEND_TN_SN_AskGroupId_TO_NAME defined */

/* MACRO FOR SENDING MESSAGE TN_SN_AskGroupId TO A PROCESS ID */

#ifndef RTDS_MSG_SEND_TN_SN_AskGroupId_TO_ID
#define RTDS_MSG_SEND_TN_SN_AskGroupId_TO_ID(RECEIVER, RTDS_PARAM1, RTDS_PARAM2) \
	{ \
	RTDS_msgData = (unsigned char *)new RTDS_TN_SN_AskGroupId_data(); \
	(((RTDS_TN_SN_AskGroupId_data*)RTDS_msgData)->param1) = (RTDS_PARAM1); \
	(((RTDS_TN_SN_AskGroupId_data*)RTDS_msgData)->param2) = (RTDS_PARAM2); \
	RTDS_MSG_QUEUE_SEND_TO_ID(TN_SN_AskGroupId, sizeof(RTDS_TN_SN_AskGroupId_data), RTDS_msgData, RECEIVER); \
	}
#endif /* RTDS_MSG_SEND_TN_SN_AskGroupId_TO_ID defined */

/* MACROS FOR SENDING MESSAGE TN_SN_AskGroupId TO ENVIRONMENT */

#ifndef RTDS_MSG_SEND_TN_SN_AskGroupId_TO_ENV
#define RTDS_MSG_SEND_TN_SN_AskGroupId_TO_ENV(RTDS_PARAM1, RTDS_PARAM2) \
	{ \
	RTDS_msgData = (unsigned char *)new RTDS_TN_SN_AskGroupId_data(); \
	(((RTDS_TN_SN_AskGroupId_data*)RTDS_msgData)->param1) = (RTDS_PARAM1); \
	(((RTDS_TN_SN_AskGroupId_data*)RTDS_msgData)->param2) = (RTDS_PARAM2); \
	RTDS_MSG_QUEUE_SEND_TO_ENV(TN_SN_AskGroupId, sizeof(RTDS_TN_SN_AskGroupId_data), RTDS_msgData); \
	}
#endif /* RTDS_MSG_SEND_TN_SN_AskGroupId_TO_ENV defined */

#ifndef RTDS_MSG_SEND_TN_SN_AskGroupId_TO_ENV_W_MACRO
#define RTDS_MSG_SEND_TN_SN_AskGroupId_TO_ENV_W_MACRO(MACRO_NAME, RTDS_PARAM1, RTDS_PARAM2) \
	{ \
	RTDS_msgData = (unsigned char *)new RTDS_TN_SN_AskGroupId_data(); \
	(((RTDS_TN_SN_AskGroupId_data*)RTDS_msgData)->param1) = (RTDS_PARAM1); \
	(((RTDS_TN_SN_AskGroupId_data*)RTDS_msgData)->param2) = (RTDS_PARAM2); \
	MACRO_NAME(TN_SN_AskGroupId, sizeof(RTDS_TN_SN_AskGroupId_data), RTDS_msgData); \
	}
#endif /* RTDS_MSG_SEND_TN_SN_AskGroupId_TO_ENV defined */

/* MACRO FOR RECEPTION OF MESSAGE TN_LN_AssignLNsInNetwork */

#ifndef RTDS_MSG_RECEIVE_TN_LN_AssignLNsInNetwork
#define RTDS_MSG_RECEIVE_TN_LN_AssignLNsInNetwork(RTDS_PARAM1, RTDS_PARAM2, RTDS_PARAM3) \
	{ \
	RTDS_msgData = (unsigned char *)(RTDS_currentContext->currentMessage->pData); \
	if ( RTDS_msgData != NULL ) \
		{ \
		(RTDS_PARAM1) = (((RTDS_TN_LN_AssignLNsInNetwork_data*)RTDS_msgData)->param1); \
		(RTDS_PARAM2) = (((RTDS_TN_LN_AssignLNsInNetwork_data*)RTDS_msgData)->param2); \
		(RTDS_PARAM3) = (((RTDS_TN_LN_AssignLNsInNetwork_data*)RTDS_msgData)->param3); \
		} \
	else \
		{ \
		RTDS_MSG_INPUT_ERROR; \
		} \
	}
#endif /* RTDS_MSG_RECEIVE_TN_LN_AssignLNsInNetwork defined */

/* MACRO FOR SENDING MESSAGE TN_LN_AssignLNsInNetwork TO A PROCESS NAME */

#ifndef RTDS_MSG_SEND_TN_LN_AssignLNsInNetwork_TO_NAME
#define RTDS_MSG_SEND_TN_LN_AssignLNsInNetwork_TO_NAME(RECEIVER, RECEIVER_NUMBER, RTDS_PARAM1, RTDS_PARAM2, RTDS_PARAM3) \
	{ \
	RTDS_msgData = (unsigned char *)new RTDS_TN_LN_AssignLNsInNetwork_data(); \
	(((RTDS_TN_LN_AssignLNsInNetwork_data*)RTDS_msgData)->param1) = (RTDS_PARAM1); \
	(((RTDS_TN_LN_AssignLNsInNetwork_data*)RTDS_msgData)->param2) = (RTDS_PARAM2); \
	(((RTDS_TN_LN_AssignLNsInNetwork_data*)RTDS_msgData)->param3) = (RTDS_PARAM3); \
	RTDS_MSG_QUEUE_SEND_TO_NAME(TN_LN_AssignLNsInNetwork, sizeof(RTDS_TN_LN_AssignLNsInNetwork_data), RTDS_msgData, RECEIVER, RECEIVER_NUMBER); \
	}
#endif /* RTDS_MSG_SEND_TN_LN_AssignLNsInNetwork_TO_NAME defined */

/* MACRO FOR SENDING MESSAGE TN_LN_AssignLNsInNetwork TO A PROCESS ID */

#ifndef RTDS_MSG_SEND_TN_LN_AssignLNsInNetwork_TO_ID
#define RTDS_MSG_SEND_TN_LN_AssignLNsInNetwork_TO_ID(RECEIVER, RTDS_PARAM1, RTDS_PARAM2, RTDS_PARAM3) \
	{ \
	RTDS_msgData = (unsigned char *)new RTDS_TN_LN_AssignLNsInNetwork_data(); \
	(((RTDS_TN_LN_AssignLNsInNetwork_data*)RTDS_msgData)->param1) = (RTDS_PARAM1); \
	(((RTDS_TN_LN_AssignLNsInNetwork_data*)RTDS_msgData)->param2) = (RTDS_PARAM2); \
	(((RTDS_TN_LN_AssignLNsInNetwork_data*)RTDS_msgData)->param3) = (RTDS_PARAM3); \
	RTDS_MSG_QUEUE_SEND_TO_ID(TN_LN_AssignLNsInNetwork, sizeof(RTDS_TN_LN_AssignLNsInNetwork_data), RTDS_msgData, RECEIVER); \
	}
#endif /* RTDS_MSG_SEND_TN_LN_AssignLNsInNetwork_TO_ID defined */

/* MACROS FOR SENDING MESSAGE TN_LN_AssignLNsInNetwork TO ENVIRONMENT */

#ifndef RTDS_MSG_SEND_TN_LN_AssignLNsInNetwork_TO_ENV
#define RTDS_MSG_SEND_TN_LN_AssignLNsInNetwork_TO_ENV(RTDS_PARAM1, RTDS_PARAM2, RTDS_PARAM3) \
	{ \
	RTDS_msgData = (unsigned char *)new RTDS_TN_LN_AssignLNsInNetwork_data(); \
	(((RTDS_TN_LN_AssignLNsInNetwork_data*)RTDS_msgData)->param1) = (RTDS_PARAM1); \
	(((RTDS_TN_LN_AssignLNsInNetwork_data*)RTDS_msgData)->param2) = (RTDS_PARAM2); \
	(((RTDS_TN_LN_AssignLNsInNetwork_data*)RTDS_msgData)->param3) = (RTDS_PARAM3); \
	RTDS_MSG_QUEUE_SEND_TO_ENV(TN_LN_AssignLNsInNetwork, sizeof(RTDS_TN_LN_AssignLNsInNetwork_data), RTDS_msgData); \
	}
#endif /* RTDS_MSG_SEND_TN_LN_AssignLNsInNetwork_TO_ENV defined */

#ifndef RTDS_MSG_SEND_TN_LN_AssignLNsInNetwork_TO_ENV_W_MACRO
#define RTDS_MSG_SEND_TN_LN_AssignLNsInNetwork_TO_ENV_W_MACRO(MACRO_NAME, RTDS_PARAM1, RTDS_PARAM2, RTDS_PARAM3) \
	{ \
	RTDS_msgData = (unsigned char *)new RTDS_TN_LN_AssignLNsInNetwork_data(); \
	(((RTDS_TN_LN_AssignLNsInNetwork_data*)RTDS_msgData)->param1) = (RTDS_PARAM1); \
	(((RTDS_TN_LN_AssignLNsInNetwork_data*)RTDS_msgData)->param2) = (RTDS_PARAM2); \
	(((RTDS_TN_LN_AssignLNsInNetwork_data*)RTDS_msgData)->param3) = (RTDS_PARAM3); \
	MACRO_NAME(TN_LN_AssignLNsInNetwork, sizeof(RTDS_TN_LN_AssignLNsInNetwork_data), RTDS_msgData); \
	}
#endif /* RTDS_MSG_SEND_TN_LN_AssignLNsInNetwork_TO_ENV defined */

/* MACRO FOR RECEPTION OF MESSAGE LN_EN_Summary */

#ifndef RTDS_MSG_RECEIVE_LN_EN_Summary
#define RTDS_MSG_RECEIVE_LN_EN_Summary(RTDS_PARAM1, RTDS_PARAM2, RTDS_PARAM3, RTDS_PARAM4, RTDS_PARAM5, RTDS_PARAM6, RTDS_PARAM7) \
	{ \
	RTDS_msgData = (unsigned char *)(RTDS_currentContext->currentMessage->pData); \
	if ( RTDS_msgData != NULL ) \
		{ \
		(RTDS_PARAM1) = (((RTDS_LN_EN_Summary_data*)RTDS_msgData)->param1); \
		(RTDS_PARAM2) = (((RTDS_LN_EN_Summary_data*)RTDS_msgData)->param2); \
		RTDS_PARAM3 = ((RTDS_LN_EN_Summary_data*)RTDS_msgData)->param3; \
		(RTDS_PARAM4) = (((RTDS_LN_EN_Summary_data*)RTDS_msgData)->param4); \
		(RTDS_PARAM5) = (((RTDS_LN_EN_Summary_data*)RTDS_msgData)->param5); \
		(RTDS_PARAM6) = (((RTDS_LN_EN_Summary_data*)RTDS_msgData)->param6); \
		RTDS_PARAM7 = ((RTDS_LN_EN_Summary_data*)RTDS_msgData)->param7; \
		} \
	else \
		{ \
		RTDS_MSG_INPUT_ERROR; \
		} \
	}
#endif /* RTDS_MSG_RECEIVE_LN_EN_Summary defined */

/* MACRO FOR SENDING MESSAGE LN_EN_Summary TO A PROCESS NAME */

#ifndef RTDS_MSG_SEND_LN_EN_Summary_TO_NAME
#define RTDS_MSG_SEND_LN_EN_Summary_TO_NAME(RECEIVER, RECEIVER_NUMBER, RTDS_PARAM1, RTDS_PARAM2, RTDS_PARAM3, RTDS_PARAM4, RTDS_PARAM5, RTDS_PARAM6, RTDS_PARAM7) \
	{ \
	RTDS_msgData = (unsigned char *)new RTDS_LN_EN_Summary_data(); \
	(((RTDS_LN_EN_Summary_data*)RTDS_msgData)->param1) = (RTDS_PARAM1); \
	(((RTDS_LN_EN_Summary_data*)RTDS_msgData)->param2) = (RTDS_PARAM2); \
	((RTDS_LN_EN_Summary_data*)RTDS_msgData)->param3 = RTDS_PARAM3; \
	(((RTDS_LN_EN_Summary_data*)RTDS_msgData)->param4) = (RTDS_PARAM4); \
	(((RTDS_LN_EN_Summary_data*)RTDS_msgData)->param5) = (RTDS_PARAM5); \
	(((RTDS_LN_EN_Summary_data*)RTDS_msgData)->param6) = (RTDS_PARAM6); \
	((RTDS_LN_EN_Summary_data*)RTDS_msgData)->param7 = RTDS_PARAM7; \
	RTDS_MSG_QUEUE_SEND_TO_NAME(LN_EN_Summary, sizeof(RTDS_LN_EN_Summary_data), RTDS_msgData, RECEIVER, RECEIVER_NUMBER); \
	}
#endif /* RTDS_MSG_SEND_LN_EN_Summary_TO_NAME defined */

/* MACRO FOR SENDING MESSAGE LN_EN_Summary TO A PROCESS ID */

#ifndef RTDS_MSG_SEND_LN_EN_Summary_TO_ID
#define RTDS_MSG_SEND_LN_EN_Summary_TO_ID(RECEIVER, RTDS_PARAM1, RTDS_PARAM2, RTDS_PARAM3, RTDS_PARAM4, RTDS_PARAM5, RTDS_PARAM6, RTDS_PARAM7) \
	{ \
	RTDS_msgData = (unsigned char *)new RTDS_LN_EN_Summary_data(); \
	(((RTDS_LN_EN_Summary_data*)RTDS_msgData)->param1) = (RTDS_PARAM1); \
	(((RTDS_LN_EN_Summary_data*)RTDS_msgData)->param2) = (RTDS_PARAM2); \
	((RTDS_LN_EN_Summary_data*)RTDS_msgData)->param3 = RTDS_PARAM3; \
	(((RTDS_LN_EN_Summary_data*)RTDS_msgData)->param4) = (RTDS_PARAM4); \
	(((RTDS_LN_EN_Summary_data*)RTDS_msgData)->param5) = (RTDS_PARAM5); \
	(((RTDS_LN_EN_Summary_data*)RTDS_msgData)->param6) = (RTDS_PARAM6); \
	((RTDS_LN_EN_Summary_data*)RTDS_msgData)->param7 = RTDS_PARAM7; \
	RTDS_MSG_QUEUE_SEND_TO_ID(LN_EN_Summary, sizeof(RTDS_LN_EN_Summary_data), RTDS_msgData, RECEIVER); \
	}
#endif /* RTDS_MSG_SEND_LN_EN_Summary_TO_ID defined */

/* MACROS FOR SENDING MESSAGE LN_EN_Summary TO ENVIRONMENT */

#ifndef RTDS_MSG_SEND_LN_EN_Summary_TO_ENV
#define RTDS_MSG_SEND_LN_EN_Summary_TO_ENV(RTDS_PARAM1, RTDS_PARAM2, RTDS_PARAM3, RTDS_PARAM4, RTDS_PARAM5, RTDS_PARAM6, RTDS_PARAM7) \
	{ \
	RTDS_msgData = (unsigned char *)new RTDS_LN_EN_Summary_data(); \
	(((RTDS_LN_EN_Summary_data*)RTDS_msgData)->param1) = (RTDS_PARAM1); \
	(((RTDS_LN_EN_Summary_data*)RTDS_msgData)->param2) = (RTDS_PARAM2); \
	((RTDS_LN_EN_Summary_data*)RTDS_msgData)->param3 = RTDS_PARAM3; \
	(((RTDS_LN_EN_Summary_data*)RTDS_msgData)->param4) = (RTDS_PARAM4); \
	(((RTDS_LN_EN_Summary_data*)RTDS_msgData)->param5) = (RTDS_PARAM5); \
	(((RTDS_LN_EN_Summary_data*)RTDS_msgData)->param6) = (RTDS_PARAM6); \
	((RTDS_LN_EN_Summary_data*)RTDS_msgData)->param7 = RTDS_PARAM7; \
	RTDS_MSG_QUEUE_SEND_TO_ENV(LN_EN_Summary, sizeof(RTDS_LN_EN_Summary_data), RTDS_msgData); \
	}
#endif /* RTDS_MSG_SEND_LN_EN_Summary_TO_ENV defined */

#ifndef RTDS_MSG_SEND_LN_EN_Summary_TO_ENV_W_MACRO
#define RTDS_MSG_SEND_LN_EN_Summary_TO_ENV_W_MACRO(MACRO_NAME, RTDS_PARAM1, RTDS_PARAM2, RTDS_PARAM3, RTDS_PARAM4, RTDS_PARAM5, RTDS_PARAM6, RTDS_PARAM7) \
	{ \
	RTDS_msgData = (unsigned char *)new RTDS_LN_EN_Summary_data(); \
	(((RTDS_LN_EN_Summary_data*)RTDS_msgData)->param1) = (RTDS_PARAM1); \
	(((RTDS_LN_EN_Summary_data*)RTDS_msgData)->param2) = (RTDS_PARAM2); \
	((RTDS_LN_EN_Summary_data*)RTDS_msgData)->param3 = RTDS_PARAM3; \
	(((RTDS_LN_EN_Summary_data*)RTDS_msgData)->param4) = (RTDS_PARAM4); \
	(((RTDS_LN_EN_Summary_data*)RTDS_msgData)->param5) = (RTDS_PARAM5); \
	(((RTDS_LN_EN_Summary_data*)RTDS_msgData)->param6) = (RTDS_PARAM6); \
	((RTDS_LN_EN_Summary_data*)RTDS_msgData)->param7 = RTDS_PARAM7; \
	MACRO_NAME(LN_EN_Summary, sizeof(RTDS_LN_EN_Summary_data), RTDS_msgData); \
	}
#endif /* RTDS_MSG_SEND_LN_EN_Summary_TO_ENV defined */

/* MACRO FOR RECEPTION OF MESSAGE LN_SN_Describe */

#ifndef RTDS_MSG_RECEIVE_LN_SN_Describe
#define RTDS_MSG_RECEIVE_LN_SN_Describe(RTDS_PARAM1, RTDS_PARAM2, RTDS_PARAM3) \
	{ \
	RTDS_msgData = (unsigned char *)(RTDS_currentContext->currentMessage->pData); \
	if ( RTDS_msgData != NULL ) \
		{ \
		(RTDS_PARAM1) = (((RTDS_LN_SN_Describe_data*)RTDS_msgData)->param1); \
		(RTDS_PARAM2) = (((RTDS_LN_SN_Describe_data*)RTDS_msgData)->param2); \
		RTDS_PARAM3 = ((RTDS_LN_SN_Describe_data*)RTDS_msgData)->param3; \
		} \
	else \
		{ \
		RTDS_MSG_INPUT_ERROR; \
		} \
	}
#endif /* RTDS_MSG_RECEIVE_LN_SN_Describe defined */

/* MACRO FOR SENDING MESSAGE LN_SN_Describe TO A PROCESS NAME */

#ifndef RTDS_MSG_SEND_LN_SN_Describe_TO_NAME
#define RTDS_MSG_SEND_LN_SN_Describe_TO_NAME(RECEIVER, RECEIVER_NUMBER, RTDS_PARAM1, RTDS_PARAM2, RTDS_PARAM3) \
	{ \
	RTDS_msgData = (unsigned char *)new RTDS_LN_SN_Describe_data(); \
	(((RTDS_LN_SN_Describe_data*)RTDS_msgData)->param1) = (RTDS_PARAM1); \
	(((RTDS_LN_SN_Describe_data*)RTDS_msgData)->param2) = (RTDS_PARAM2); \
	((RTDS_LN_SN_Describe_data*)RTDS_msgData)->param3 = RTDS_PARAM3; \
	RTDS_MSG_QUEUE_SEND_TO_NAME(LN_SN_Describe, sizeof(RTDS_LN_SN_Describe_data), RTDS_msgData, RECEIVER, RECEIVER_NUMBER); \
	}
#endif /* RTDS_MSG_SEND_LN_SN_Describe_TO_NAME defined */

/* MACRO FOR SENDING MESSAGE LN_SN_Describe TO A PROCESS ID */

#ifndef RTDS_MSG_SEND_LN_SN_Describe_TO_ID
#define RTDS_MSG_SEND_LN_SN_Describe_TO_ID(RECEIVER, RTDS_PARAM1, RTDS_PARAM2, RTDS_PARAM3) \
	{ \
	RTDS_msgData = (unsigned char *)new RTDS_LN_SN_Describe_data(); \
	(((RTDS_LN_SN_Describe_data*)RTDS_msgData)->param1) = (RTDS_PARAM1); \
	(((RTDS_LN_SN_Describe_data*)RTDS_msgData)->param2) = (RTDS_PARAM2); \
	((RTDS_LN_SN_Describe_data*)RTDS_msgData)->param3 = RTDS_PARAM3; \
	RTDS_MSG_QUEUE_SEND_TO_ID(LN_SN_Describe, sizeof(RTDS_LN_SN_Describe_data), RTDS_msgData, RECEIVER); \
	}
#endif /* RTDS_MSG_SEND_LN_SN_Describe_TO_ID defined */

/* MACROS FOR SENDING MESSAGE LN_SN_Describe TO ENVIRONMENT */

#ifndef RTDS_MSG_SEND_LN_SN_Describe_TO_ENV
#define RTDS_MSG_SEND_LN_SN_Describe_TO_ENV(RTDS_PARAM1, RTDS_PARAM2, RTDS_PARAM3) \
	{ \
	RTDS_msgData = (unsigned char *)new RTDS_LN_SN_Describe_data(); \
	(((RTDS_LN_SN_Describe_data*)RTDS_msgData)->param1) = (RTDS_PARAM1); \
	(((RTDS_LN_SN_Describe_data*)RTDS_msgData)->param2) = (RTDS_PARAM2); \
	((RTDS_LN_SN_Describe_data*)RTDS_msgData)->param3 = RTDS_PARAM3; \
	RTDS_MSG_QUEUE_SEND_TO_ENV(LN_SN_Describe, sizeof(RTDS_LN_SN_Describe_data), RTDS_msgData); \
	}
#endif /* RTDS_MSG_SEND_LN_SN_Describe_TO_ENV defined */

#ifndef RTDS_MSG_SEND_LN_SN_Describe_TO_ENV_W_MACRO
#define RTDS_MSG_SEND_LN_SN_Describe_TO_ENV_W_MACRO(MACRO_NAME, RTDS_PARAM1, RTDS_PARAM2, RTDS_PARAM3) \
	{ \
	RTDS_msgData = (unsigned char *)new RTDS_LN_SN_Describe_data(); \
	(((RTDS_LN_SN_Describe_data*)RTDS_msgData)->param1) = (RTDS_PARAM1); \
	(((RTDS_LN_SN_Describe_data*)RTDS_msgData)->param2) = (RTDS_PARAM2); \
	((RTDS_LN_SN_Describe_data*)RTDS_msgData)->param3 = RTDS_PARAM3; \
	MACRO_NAME(LN_SN_Describe, sizeof(RTDS_LN_SN_Describe_data), RTDS_msgData); \
	}
#endif /* RTDS_MSG_SEND_LN_SN_Describe_TO_ENV defined */

/* MACRO FOR RECEPTION OF MESSAGE LN_SN_SecondaryLN */

#ifndef RTDS_MSG_RECEIVE_LN_SN_SecondaryLN
#define RTDS_MSG_RECEIVE_LN_SN_SecondaryLN(RTDS_PARAM1, RTDS_PARAM2, RTDS_PARAM3, RTDS_PARAM4) \
	{ \
	RTDS_msgData = (unsigned char *)(RTDS_currentContext->currentMessage->pData); \
	if ( RTDS_msgData != NULL ) \
		{ \
		(RTDS_PARAM1) = (((RTDS_LN_SN_SecondaryLN_data*)RTDS_msgData)->param1); \
		(RTDS_PARAM2) = (((RTDS_LN_SN_SecondaryLN_data*)RTDS_msgData)->param2); \
		(RTDS_PARAM3) = (((RTDS_LN_SN_SecondaryLN_data*)RTDS_msgData)->param3); \
		RTDS_PARAM4 = ((RTDS_LN_SN_SecondaryLN_data*)RTDS_msgData)->param4; \
		} \
	else \
		{ \
		RTDS_MSG_INPUT_ERROR; \
		} \
	}
#endif /* RTDS_MSG_RECEIVE_LN_SN_SecondaryLN defined */

/* MACRO FOR SENDING MESSAGE LN_SN_SecondaryLN TO A PROCESS NAME */

#ifndef RTDS_MSG_SEND_LN_SN_SecondaryLN_TO_NAME
#define RTDS_MSG_SEND_LN_SN_SecondaryLN_TO_NAME(RECEIVER, RECEIVER_NUMBER, RTDS_PARAM1, RTDS_PARAM2, RTDS_PARAM3, RTDS_PARAM4) \
	{ \
	RTDS_msgData = (unsigned char *)new RTDS_LN_SN_SecondaryLN_data(); \
	(((RTDS_LN_SN_SecondaryLN_data*)RTDS_msgData)->param1) = (RTDS_PARAM1); \
	(((RTDS_LN_SN_SecondaryLN_data*)RTDS_msgData)->param2) = (RTDS_PARAM2); \
	(((RTDS_LN_SN_SecondaryLN_data*)RTDS_msgData)->param3) = (RTDS_PARAM3); \
	((RTDS_LN_SN_SecondaryLN_data*)RTDS_msgData)->param4 = RTDS_PARAM4; \
	RTDS_MSG_QUEUE_SEND_TO_NAME(LN_SN_SecondaryLN, sizeof(RTDS_LN_SN_SecondaryLN_data), RTDS_msgData, RECEIVER, RECEIVER_NUMBER); \
	}
#endif /* RTDS_MSG_SEND_LN_SN_SecondaryLN_TO_NAME defined */

/* MACRO FOR SENDING MESSAGE LN_SN_SecondaryLN TO A PROCESS ID */

#ifndef RTDS_MSG_SEND_LN_SN_SecondaryLN_TO_ID
#define RTDS_MSG_SEND_LN_SN_SecondaryLN_TO_ID(RECEIVER, RTDS_PARAM1, RTDS_PARAM2, RTDS_PARAM3, RTDS_PARAM4) \
	{ \
	RTDS_msgData = (unsigned char *)new RTDS_LN_SN_SecondaryLN_data(); \
	(((RTDS_LN_SN_SecondaryLN_data*)RTDS_msgData)->param1) = (RTDS_PARAM1); \
	(((RTDS_LN_SN_SecondaryLN_data*)RTDS_msgData)->param2) = (RTDS_PARAM2); \
	(((RTDS_LN_SN_SecondaryLN_data*)RTDS_msgData)->param3) = (RTDS_PARAM3); \
	((RTDS_LN_SN_SecondaryLN_data*)RTDS_msgData)->param4 = RTDS_PARAM4; \
	RTDS_MSG_QUEUE_SEND_TO_ID(LN_SN_SecondaryLN, sizeof(RTDS_LN_SN_SecondaryLN_data), RTDS_msgData, RECEIVER); \
	}
#endif /* RTDS_MSG_SEND_LN_SN_SecondaryLN_TO_ID defined */

/* MACROS FOR SENDING MESSAGE LN_SN_SecondaryLN TO ENVIRONMENT */

#ifndef RTDS_MSG_SEND_LN_SN_SecondaryLN_TO_ENV
#define RTDS_MSG_SEND_LN_SN_SecondaryLN_TO_ENV(RTDS_PARAM1, RTDS_PARAM2, RTDS_PARAM3, RTDS_PARAM4) \
	{ \
	RTDS_msgData = (unsigned char *)new RTDS_LN_SN_SecondaryLN_data(); \
	(((RTDS_LN_SN_SecondaryLN_data*)RTDS_msgData)->param1) = (RTDS_PARAM1); \
	(((RTDS_LN_SN_SecondaryLN_data*)RTDS_msgData)->param2) = (RTDS_PARAM2); \
	(((RTDS_LN_SN_SecondaryLN_data*)RTDS_msgData)->param3) = (RTDS_PARAM3); \
	((RTDS_LN_SN_SecondaryLN_data*)RTDS_msgData)->param4 = RTDS_PARAM4; \
	RTDS_MSG_QUEUE_SEND_TO_ENV(LN_SN_SecondaryLN, sizeof(RTDS_LN_SN_SecondaryLN_data), RTDS_msgData); \
	}
#endif /* RTDS_MSG_SEND_LN_SN_SecondaryLN_TO_ENV defined */

#ifndef RTDS_MSG_SEND_LN_SN_SecondaryLN_TO_ENV_W_MACRO
#define RTDS_MSG_SEND_LN_SN_SecondaryLN_TO_ENV_W_MACRO(MACRO_NAME, RTDS_PARAM1, RTDS_PARAM2, RTDS_PARAM3, RTDS_PARAM4) \
	{ \
	RTDS_msgData = (unsigned char *)new RTDS_LN_SN_SecondaryLN_data(); \
	(((RTDS_LN_SN_SecondaryLN_data*)RTDS_msgData)->param1) = (RTDS_PARAM1); \
	(((RTDS_LN_SN_SecondaryLN_data*)RTDS_msgData)->param2) = (RTDS_PARAM2); \
	(((RTDS_LN_SN_SecondaryLN_data*)RTDS_msgData)->param3) = (RTDS_PARAM3); \
	((RTDS_LN_SN_SecondaryLN_data*)RTDS_msgData)->param4 = RTDS_PARAM4; \
	MACRO_NAME(LN_SN_SecondaryLN, sizeof(RTDS_LN_SN_SecondaryLN_data), RTDS_msgData); \
	}
#endif /* RTDS_MSG_SEND_LN_SN_SecondaryLN_TO_ENV defined */

/* MACRO FOR RECEPTION OF MESSAGE SendPShared */

#ifndef RTDS_MSG_RECEIVE_SendPShared
#define RTDS_MSG_RECEIVE_SendPShared(RTDS_PARAM1) \
	{ \
	RTDS_msgData = (unsigned char *)(RTDS_currentContext->currentMessage->pData); \
	if ( RTDS_msgData != NULL ) \
		{ \
		RTDS_PARAM1 = ((RTDS_SendPShared_data*)RTDS_msgData)->param1; \
		} \
	else \
		{ \
		RTDS_MSG_INPUT_ERROR; \
		} \
	}
#endif /* RTDS_MSG_RECEIVE_SendPShared defined */

/* MACRO FOR SENDING MESSAGE SendPShared TO A PROCESS NAME */

#ifndef RTDS_MSG_SEND_SendPShared_TO_NAME
#define RTDS_MSG_SEND_SendPShared_TO_NAME(RECEIVER, RECEIVER_NUMBER, RTDS_PARAM1) \
	{ \
	RTDS_msgData = (unsigned char *)new RTDS_SendPShared_data(); \
	((RTDS_SendPShared_data*)RTDS_msgData)->param1 = RTDS_PARAM1; \
	RTDS_MSG_QUEUE_SEND_TO_NAME(SendPShared, sizeof(RTDS_SendPShared_data), RTDS_msgData, RECEIVER, RECEIVER_NUMBER); \
	}
#endif /* RTDS_MSG_SEND_SendPShared_TO_NAME defined */

/* MACRO FOR SENDING MESSAGE SendPShared TO A PROCESS ID */

#ifndef RTDS_MSG_SEND_SendPShared_TO_ID
#define RTDS_MSG_SEND_SendPShared_TO_ID(RECEIVER, RTDS_PARAM1) \
	{ \
	RTDS_msgData = (unsigned char *)new RTDS_SendPShared_data(); \
	((RTDS_SendPShared_data*)RTDS_msgData)->param1 = RTDS_PARAM1; \
	RTDS_MSG_QUEUE_SEND_TO_ID(SendPShared, sizeof(RTDS_SendPShared_data), RTDS_msgData, RECEIVER); \
	}
#endif /* RTDS_MSG_SEND_SendPShared_TO_ID defined */

/* MACROS FOR SENDING MESSAGE SendPShared TO ENVIRONMENT */

#ifndef RTDS_MSG_SEND_SendPShared_TO_ENV
#define RTDS_MSG_SEND_SendPShared_TO_ENV(RTDS_PARAM1) \
	{ \
	RTDS_msgData = (unsigned char *)new RTDS_SendPShared_data(); \
	((RTDS_SendPShared_data*)RTDS_msgData)->param1 = RTDS_PARAM1; \
	RTDS_MSG_QUEUE_SEND_TO_ENV(SendPShared, sizeof(RTDS_SendPShared_data), RTDS_msgData); \
	}
#endif /* RTDS_MSG_SEND_SendPShared_TO_ENV defined */

#ifndef RTDS_MSG_SEND_SendPShared_TO_ENV_W_MACRO
#define RTDS_MSG_SEND_SendPShared_TO_ENV_W_MACRO(MACRO_NAME, RTDS_PARAM1) \
	{ \
	RTDS_msgData = (unsigned char *)new RTDS_SendPShared_data(); \
	((RTDS_SendPShared_data*)RTDS_msgData)->param1 = RTDS_PARAM1; \
	MACRO_NAME(SendPShared, sizeof(RTDS_SendPShared_data), RTDS_msgData); \
	}
#endif /* RTDS_MSG_SEND_SendPShared_TO_ENV defined */

/* MACRO FOR RECEPTION OF MESSAGE LN_LN_Detection */

#ifndef RTDS_MSG_RECEIVE_LN_LN_Detection
#define RTDS_MSG_RECEIVE_LN_LN_Detection(RTDS_PARAM1, RTDS_PARAM2, RTDS_PARAM3, RTDS_PARAM4, RTDS_PARAM5, RTDS_PARAM6) \
	{ \
	RTDS_msgData = (unsigned char *)(RTDS_currentContext->currentMessage->pData); \
	if ( RTDS_msgData != NULL ) \
		{ \
		(RTDS_PARAM1) = (((RTDS_LN_LN_Detection_data*)RTDS_msgData)->param1); \
		(RTDS_PARAM2) = (((RTDS_LN_LN_Detection_data*)RTDS_msgData)->param2); \
		RTDS_PARAM3 = ((RTDS_LN_LN_Detection_data*)RTDS_msgData)->param3; \
		(RTDS_PARAM4) = (((RTDS_LN_LN_Detection_data*)RTDS_msgData)->param4); \
		(RTDS_PARAM5) = (((RTDS_LN_LN_Detection_data*)RTDS_msgData)->param5); \
		(RTDS_PARAM6) = (((RTDS_LN_LN_Detection_data*)RTDS_msgData)->param6); \
		} \
	else \
		{ \
		RTDS_MSG_INPUT_ERROR; \
		} \
	}
#endif /* RTDS_MSG_RECEIVE_LN_LN_Detection defined */

/* MACRO FOR SENDING MESSAGE LN_LN_Detection TO A PROCESS NAME */

#ifndef RTDS_MSG_SEND_LN_LN_Detection_TO_NAME
#define RTDS_MSG_SEND_LN_LN_Detection_TO_NAME(RECEIVER, RECEIVER_NUMBER, RTDS_PARAM1, RTDS_PARAM2, RTDS_PARAM3, RTDS_PARAM4, RTDS_PARAM5, RTDS_PARAM6) \
	{ \
	RTDS_msgData = (unsigned char *)new RTDS_LN_LN_Detection_data(); \
	(((RTDS_LN_LN_Detection_data*)RTDS_msgData)->param1) = (RTDS_PARAM1); \
	(((RTDS_LN_LN_Detection_data*)RTDS_msgData)->param2) = (RTDS_PARAM2); \
	((RTDS_LN_LN_Detection_data*)RTDS_msgData)->param3 = RTDS_PARAM3; \
	(((RTDS_LN_LN_Detection_data*)RTDS_msgData)->param4) = (RTDS_PARAM4); \
	(((RTDS_LN_LN_Detection_data*)RTDS_msgData)->param5) = (RTDS_PARAM5); \
	(((RTDS_LN_LN_Detection_data*)RTDS_msgData)->param6) = (RTDS_PARAM6); \
	RTDS_MSG_QUEUE_SEND_TO_NAME(LN_LN_Detection, sizeof(RTDS_LN_LN_Detection_data), RTDS_msgData, RECEIVER, RECEIVER_NUMBER); \
	}
#endif /* RTDS_MSG_SEND_LN_LN_Detection_TO_NAME defined */

/* MACRO FOR SENDING MESSAGE LN_LN_Detection TO A PROCESS ID */

#ifndef RTDS_MSG_SEND_LN_LN_Detection_TO_ID
#define RTDS_MSG_SEND_LN_LN_Detection_TO_ID(RECEIVER, RTDS_PARAM1, RTDS_PARAM2, RTDS_PARAM3, RTDS_PARAM4, RTDS_PARAM5, RTDS_PARAM6) \
	{ \
	RTDS_msgData = (unsigned char *)new RTDS_LN_LN_Detection_data(); \
	(((RTDS_LN_LN_Detection_data*)RTDS_msgData)->param1) = (RTDS_PARAM1); \
	(((RTDS_LN_LN_Detection_data*)RTDS_msgData)->param2) = (RTDS_PARAM2); \
	((RTDS_LN_LN_Detection_data*)RTDS_msgData)->param3 = RTDS_PARAM3; \
	(((RTDS_LN_LN_Detection_data*)RTDS_msgData)->param4) = (RTDS_PARAM4); \
	(((RTDS_LN_LN_Detection_data*)RTDS_msgData)->param5) = (RTDS_PARAM5); \
	(((RTDS_LN_LN_Detection_data*)RTDS_msgData)->param6) = (RTDS_PARAM6); \
	RTDS_MSG_QUEUE_SEND_TO_ID(LN_LN_Detection, sizeof(RTDS_LN_LN_Detection_data), RTDS_msgData, RECEIVER); \
	}
#endif /* RTDS_MSG_SEND_LN_LN_Detection_TO_ID defined */

/* MACROS FOR SENDING MESSAGE LN_LN_Detection TO ENVIRONMENT */

#ifndef RTDS_MSG_SEND_LN_LN_Detection_TO_ENV
#define RTDS_MSG_SEND_LN_LN_Detection_TO_ENV(RTDS_PARAM1, RTDS_PARAM2, RTDS_PARAM3, RTDS_PARAM4, RTDS_PARAM5, RTDS_PARAM6) \
	{ \
	RTDS_msgData = (unsigned char *)new RTDS_LN_LN_Detection_data(); \
	(((RTDS_LN_LN_Detection_data*)RTDS_msgData)->param1) = (RTDS_PARAM1); \
	(((RTDS_LN_LN_Detection_data*)RTDS_msgData)->param2) = (RTDS_PARAM2); \
	((RTDS_LN_LN_Detection_data*)RTDS_msgData)->param3 = RTDS_PARAM3; \
	(((RTDS_LN_LN_Detection_data*)RTDS_msgData)->param4) = (RTDS_PARAM4); \
	(((RTDS_LN_LN_Detection_data*)RTDS_msgData)->param5) = (RTDS_PARAM5); \
	(((RTDS_LN_LN_Detection_data*)RTDS_msgData)->param6) = (RTDS_PARAM6); \
	RTDS_MSG_QUEUE_SEND_TO_ENV(LN_LN_Detection, sizeof(RTDS_LN_LN_Detection_data), RTDS_msgData); \
	}
#endif /* RTDS_MSG_SEND_LN_LN_Detection_TO_ENV defined */

#ifndef RTDS_MSG_SEND_LN_LN_Detection_TO_ENV_W_MACRO
#define RTDS_MSG_SEND_LN_LN_Detection_TO_ENV_W_MACRO(MACRO_NAME, RTDS_PARAM1, RTDS_PARAM2, RTDS_PARAM3, RTDS_PARAM4, RTDS_PARAM5, RTDS_PARAM6) \
	{ \
	RTDS_msgData = (unsigned char *)new RTDS_LN_LN_Detection_data(); \
	(((RTDS_LN_LN_Detection_data*)RTDS_msgData)->param1) = (RTDS_PARAM1); \
	(((RTDS_LN_LN_Detection_data*)RTDS_msgData)->param2) = (RTDS_PARAM2); \
	((RTDS_LN_LN_Detection_data*)RTDS_msgData)->param3 = RTDS_PARAM3; \
	(((RTDS_LN_LN_Detection_data*)RTDS_msgData)->param4) = (RTDS_PARAM4); \
	(((RTDS_LN_LN_Detection_data*)RTDS_msgData)->param5) = (RTDS_PARAM5); \
	(((RTDS_LN_LN_Detection_data*)RTDS_msgData)->param6) = (RTDS_PARAM6); \
	MACRO_NAME(LN_LN_Detection, sizeof(RTDS_LN_LN_Detection_data), RTDS_msgData); \
	}
#endif /* RTDS_MSG_SEND_LN_LN_Detection_TO_ENV defined */

/* MACRO FOR RECEPTION OF MESSAGE TN_SN_UseMSDP */

#ifndef RTDS_MSG_RECEIVE_TN_SN_UseMSDP
#define RTDS_MSG_RECEIVE_TN_SN_UseMSDP(RTDS_PARAM1, RTDS_PARAM2, RTDS_PARAM3, RTDS_PARAM4, RTDS_PARAM5) \
	{ \
	RTDS_msgData = (unsigned char *)(RTDS_currentContext->currentMessage->pData); \
	if ( RTDS_msgData != NULL ) \
		{ \
		(RTDS_PARAM1) = (((RTDS_TN_SN_UseMSDP_data*)RTDS_msgData)->param1); \
		(RTDS_PARAM2) = (((RTDS_TN_SN_UseMSDP_data*)RTDS_msgData)->param2); \
		(RTDS_PARAM3) = (((RTDS_TN_SN_UseMSDP_data*)RTDS_msgData)->param3); \
		(RTDS_PARAM4) = (((RTDS_TN_SN_UseMSDP_data*)RTDS_msgData)->param4); \
		(RTDS_PARAM5) = (((RTDS_TN_SN_UseMSDP_data*)RTDS_msgData)->param5); \
		} \
	else \
		{ \
		RTDS_MSG_INPUT_ERROR; \
		} \
	}
#endif /* RTDS_MSG_RECEIVE_TN_SN_UseMSDP defined */

/* MACRO FOR SENDING MESSAGE TN_SN_UseMSDP TO A PROCESS NAME */

#ifndef RTDS_MSG_SEND_TN_SN_UseMSDP_TO_NAME
#define RTDS_MSG_SEND_TN_SN_UseMSDP_TO_NAME(RECEIVER, RECEIVER_NUMBER, RTDS_PARAM1, RTDS_PARAM2, RTDS_PARAM3, RTDS_PARAM4, RTDS_PARAM5) \
	{ \
	RTDS_msgData = (unsigned char *)new RTDS_TN_SN_UseMSDP_data(); \
	(((RTDS_TN_SN_UseMSDP_data*)RTDS_msgData)->param1) = (RTDS_PARAM1); \
	(((RTDS_TN_SN_UseMSDP_data*)RTDS_msgData)->param2) = (RTDS_PARAM2); \
	(((RTDS_TN_SN_UseMSDP_data*)RTDS_msgData)->param3) = (RTDS_PARAM3); \
	(((RTDS_TN_SN_UseMSDP_data*)RTDS_msgData)->param4) = (RTDS_PARAM4); \
	(((RTDS_TN_SN_UseMSDP_data*)RTDS_msgData)->param5) = (RTDS_PARAM5); \
	RTDS_MSG_QUEUE_SEND_TO_NAME(TN_SN_UseMSDP, sizeof(RTDS_TN_SN_UseMSDP_data), RTDS_msgData, RECEIVER, RECEIVER_NUMBER); \
	}
#endif /* RTDS_MSG_SEND_TN_SN_UseMSDP_TO_NAME defined */

/* MACRO FOR SENDING MESSAGE TN_SN_UseMSDP TO A PROCESS ID */

#ifndef RTDS_MSG_SEND_TN_SN_UseMSDP_TO_ID
#define RTDS_MSG_SEND_TN_SN_UseMSDP_TO_ID(RECEIVER, RTDS_PARAM1, RTDS_PARAM2, RTDS_PARAM3, RTDS_PARAM4, RTDS_PARAM5) \
	{ \
	RTDS_msgData = (unsigned char *)new RTDS_TN_SN_UseMSDP_data(); \
	(((RTDS_TN_SN_UseMSDP_data*)RTDS_msgData)->param1) = (RTDS_PARAM1); \
	(((RTDS_TN_SN_UseMSDP_data*)RTDS_msgData)->param2) = (RTDS_PARAM2); \
	(((RTDS_TN_SN_UseMSDP_data*)RTDS_msgData)->param3) = (RTDS_PARAM3); \
	(((RTDS_TN_SN_UseMSDP_data*)RTDS_msgData)->param4) = (RTDS_PARAM4); \
	(((RTDS_TN_SN_UseMSDP_data*)RTDS_msgData)->param5) = (RTDS_PARAM5); \
	RTDS_MSG_QUEUE_SEND_TO_ID(TN_SN_UseMSDP, sizeof(RTDS_TN_SN_UseMSDP_data), RTDS_msgData, RECEIVER); \
	}
#endif /* RTDS_MSG_SEND_TN_SN_UseMSDP_TO_ID defined */

/* MACROS FOR SENDING MESSAGE TN_SN_UseMSDP TO ENVIRONMENT */

#ifndef RTDS_MSG_SEND_TN_SN_UseMSDP_TO_ENV
#define RTDS_MSG_SEND_TN_SN_UseMSDP_TO_ENV(RTDS_PARAM1, RTDS_PARAM2, RTDS_PARAM3, RTDS_PARAM4, RTDS_PARAM5) \
	{ \
	RTDS_msgData = (unsigned char *)new RTDS_TN_SN_UseMSDP_data(); \
	(((RTDS_TN_SN_UseMSDP_data*)RTDS_msgData)->param1) = (RTDS_PARAM1); \
	(((RTDS_TN_SN_UseMSDP_data*)RTDS_msgData)->param2) = (RTDS_PARAM2); \
	(((RTDS_TN_SN_UseMSDP_data*)RTDS_msgData)->param3) = (RTDS_PARAM3); \
	(((RTDS_TN_SN_UseMSDP_data*)RTDS_msgData)->param4) = (RTDS_PARAM4); \
	(((RTDS_TN_SN_UseMSDP_data*)RTDS_msgData)->param5) = (RTDS_PARAM5); \
	RTDS_MSG_QUEUE_SEND_TO_ENV(TN_SN_UseMSDP, sizeof(RTDS_TN_SN_UseMSDP_data), RTDS_msgData); \
	}
#endif /* RTDS_MSG_SEND_TN_SN_UseMSDP_TO_ENV defined */

#ifndef RTDS_MSG_SEND_TN_SN_UseMSDP_TO_ENV_W_MACRO
#define RTDS_MSG_SEND_TN_SN_UseMSDP_TO_ENV_W_MACRO(MACRO_NAME, RTDS_PARAM1, RTDS_PARAM2, RTDS_PARAM3, RTDS_PARAM4, RTDS_PARAM5) \
	{ \
	RTDS_msgData = (unsigned char *)new RTDS_TN_SN_UseMSDP_data(); \
	(((RTDS_TN_SN_UseMSDP_data*)RTDS_msgData)->param1) = (RTDS_PARAM1); \
	(((RTDS_TN_SN_UseMSDP_data*)RTDS_msgData)->param2) = (RTDS_PARAM2); \
	(((RTDS_TN_SN_UseMSDP_data*)RTDS_msgData)->param3) = (RTDS_PARAM3); \
	(((RTDS_TN_SN_UseMSDP_data*)RTDS_msgData)->param4) = (RTDS_PARAM4); \
	(((RTDS_TN_SN_UseMSDP_data*)RTDS_msgData)->param5) = (RTDS_PARAM5); \
	MACRO_NAME(TN_SN_UseMSDP, sizeof(RTDS_TN_SN_UseMSDP_data), RTDS_msgData); \
	}
#endif /* RTDS_MSG_SEND_TN_SN_UseMSDP_TO_ENV defined */

/* MACRO FOR RECEPTION OF MESSAGE LN_SN_Summarise */

#ifndef RTDS_MSG_RECEIVE_LN_SN_Summarise
#define RTDS_MSG_RECEIVE_LN_SN_Summarise(RTDS_PARAM1, RTDS_PARAM2, RTDS_PARAM3) \
	{ \
	RTDS_msgData = (unsigned char *)(RTDS_currentContext->currentMessage->pData); \
	if ( RTDS_msgData != NULL ) \
		{ \
		(RTDS_PARAM1) = (((RTDS_LN_SN_Summarise_data*)RTDS_msgData)->param1); \
		(RTDS_PARAM2) = (((RTDS_LN_SN_Summarise_data*)RTDS_msgData)->param2); \
		RTDS_PARAM3 = ((RTDS_LN_SN_Summarise_data*)RTDS_msgData)->param3; \
		} \
	else \
		{ \
		RTDS_MSG_INPUT_ERROR; \
		} \
	}
#endif /* RTDS_MSG_RECEIVE_LN_SN_Summarise defined */

/* MACRO FOR SENDING MESSAGE LN_SN_Summarise TO A PROCESS NAME */

#ifndef RTDS_MSG_SEND_LN_SN_Summarise_TO_NAME
#define RTDS_MSG_SEND_LN_SN_Summarise_TO_NAME(RECEIVER, RECEIVER_NUMBER, RTDS_PARAM1, RTDS_PARAM2, RTDS_PARAM3) \
	{ \
	RTDS_msgData = (unsigned char *)new RTDS_LN_SN_Summarise_data(); \
	(((RTDS_LN_SN_Summarise_data*)RTDS_msgData)->param1) = (RTDS_PARAM1); \
	(((RTDS_LN_SN_Summarise_data*)RTDS_msgData)->param2) = (RTDS_PARAM2); \
	((RTDS_LN_SN_Summarise_data*)RTDS_msgData)->param3 = RTDS_PARAM3; \
	RTDS_MSG_QUEUE_SEND_TO_NAME(LN_SN_Summarise, sizeof(RTDS_LN_SN_Summarise_data), RTDS_msgData, RECEIVER, RECEIVER_NUMBER); \
	}
#endif /* RTDS_MSG_SEND_LN_SN_Summarise_TO_NAME defined */

/* MACRO FOR SENDING MESSAGE LN_SN_Summarise TO A PROCESS ID */

#ifndef RTDS_MSG_SEND_LN_SN_Summarise_TO_ID
#define RTDS_MSG_SEND_LN_SN_Summarise_TO_ID(RECEIVER, RTDS_PARAM1, RTDS_PARAM2, RTDS_PARAM3) \
	{ \
	RTDS_msgData = (unsigned char *)new RTDS_LN_SN_Summarise_data(); \
	(((RTDS_LN_SN_Summarise_data*)RTDS_msgData)->param1) = (RTDS_PARAM1); \
	(((RTDS_LN_SN_Summarise_data*)RTDS_msgData)->param2) = (RTDS_PARAM2); \
	((RTDS_LN_SN_Summarise_data*)RTDS_msgData)->param3 = RTDS_PARAM3; \
	RTDS_MSG_QUEUE_SEND_TO_ID(LN_SN_Summarise, sizeof(RTDS_LN_SN_Summarise_data), RTDS_msgData, RECEIVER); \
	}
#endif /* RTDS_MSG_SEND_LN_SN_Summarise_TO_ID defined */

/* MACROS FOR SENDING MESSAGE LN_SN_Summarise TO ENVIRONMENT */

#ifndef RTDS_MSG_SEND_LN_SN_Summarise_TO_ENV
#define RTDS_MSG_SEND_LN_SN_Summarise_TO_ENV(RTDS_PARAM1, RTDS_PARAM2, RTDS_PARAM3) \
	{ \
	RTDS_msgData = (unsigned char *)new RTDS_LN_SN_Summarise_data(); \
	(((RTDS_LN_SN_Summarise_data*)RTDS_msgData)->param1) = (RTDS_PARAM1); \
	(((RTDS_LN_SN_Summarise_data*)RTDS_msgData)->param2) = (RTDS_PARAM2); \
	((RTDS_LN_SN_Summarise_data*)RTDS_msgData)->param3 = RTDS_PARAM3; \
	RTDS_MSG_QUEUE_SEND_TO_ENV(LN_SN_Summarise, sizeof(RTDS_LN_SN_Summarise_data), RTDS_msgData); \
	}
#endif /* RTDS_MSG_SEND_LN_SN_Summarise_TO_ENV defined */

#ifndef RTDS_MSG_SEND_LN_SN_Summarise_TO_ENV_W_MACRO
#define RTDS_MSG_SEND_LN_SN_Summarise_TO_ENV_W_MACRO(MACRO_NAME, RTDS_PARAM1, RTDS_PARAM2, RTDS_PARAM3) \
	{ \
	RTDS_msgData = (unsigned char *)new RTDS_LN_SN_Summarise_data(); \
	(((RTDS_LN_SN_Summarise_data*)RTDS_msgData)->param1) = (RTDS_PARAM1); \
	(((RTDS_LN_SN_Summarise_data*)RTDS_msgData)->param2) = (RTDS_PARAM2); \
	((RTDS_LN_SN_Summarise_data*)RTDS_msgData)->param3 = RTDS_PARAM3; \
	MACRO_NAME(LN_SN_Summarise, sizeof(RTDS_LN_SN_Summarise_data), RTDS_msgData); \
	}
#endif /* RTDS_MSG_SEND_LN_SN_Summarise_TO_ENV defined */

/* MACRO FOR RECEPTION OF MESSAGE TN_LN_AssignGNsInNetwork */

#ifndef RTDS_MSG_RECEIVE_TN_LN_AssignGNsInNetwork
#define RTDS_MSG_RECEIVE_TN_LN_AssignGNsInNetwork(RTDS_PARAM1, RTDS_PARAM2, RTDS_PARAM3) \
	{ \
	RTDS_msgData = (unsigned char *)(RTDS_currentContext->currentMessage->pData); \
	if ( RTDS_msgData != NULL ) \
		{ \
		(RTDS_PARAM1) = (((RTDS_TN_LN_AssignGNsInNetwork_data*)RTDS_msgData)->param1); \
		(RTDS_PARAM2) = (((RTDS_TN_LN_AssignGNsInNetwork_data*)RTDS_msgData)->param2); \
		(RTDS_PARAM3) = (((RTDS_TN_LN_AssignGNsInNetwork_data*)RTDS_msgData)->param3); \
		} \
	else \
		{ \
		RTDS_MSG_INPUT_ERROR; \
		} \
	}
#endif /* RTDS_MSG_RECEIVE_TN_LN_AssignGNsInNetwork defined */

/* MACRO FOR SENDING MESSAGE TN_LN_AssignGNsInNetwork TO A PROCESS NAME */

#ifndef RTDS_MSG_SEND_TN_LN_AssignGNsInNetwork_TO_NAME
#define RTDS_MSG_SEND_TN_LN_AssignGNsInNetwork_TO_NAME(RECEIVER, RECEIVER_NUMBER, RTDS_PARAM1, RTDS_PARAM2, RTDS_PARAM3) \
	{ \
	RTDS_msgData = (unsigned char *)new RTDS_TN_LN_AssignGNsInNetwork_data(); \
	(((RTDS_TN_LN_AssignGNsInNetwork_data*)RTDS_msgData)->param1) = (RTDS_PARAM1); \
	(((RTDS_TN_LN_AssignGNsInNetwork_data*)RTDS_msgData)->param2) = (RTDS_PARAM2); \
	(((RTDS_TN_LN_AssignGNsInNetwork_data*)RTDS_msgData)->param3) = (RTDS_PARAM3); \
	RTDS_MSG_QUEUE_SEND_TO_NAME(TN_LN_AssignGNsInNetwork, sizeof(RTDS_TN_LN_AssignGNsInNetwork_data), RTDS_msgData, RECEIVER, RECEIVER_NUMBER); \
	}
#endif /* RTDS_MSG_SEND_TN_LN_AssignGNsInNetwork_TO_NAME defined */

/* MACRO FOR SENDING MESSAGE TN_LN_AssignGNsInNetwork TO A PROCESS ID */

#ifndef RTDS_MSG_SEND_TN_LN_AssignGNsInNetwork_TO_ID
#define RTDS_MSG_SEND_TN_LN_AssignGNsInNetwork_TO_ID(RECEIVER, RTDS_PARAM1, RTDS_PARAM2, RTDS_PARAM3) \
	{ \
	RTDS_msgData = (unsigned char *)new RTDS_TN_LN_AssignGNsInNetwork_data(); \
	(((RTDS_TN_LN_AssignGNsInNetwork_data*)RTDS_msgData)->param1) = (RTDS_PARAM1); \
	(((RTDS_TN_LN_AssignGNsInNetwork_data*)RTDS_msgData)->param2) = (RTDS_PARAM2); \
	(((RTDS_TN_LN_AssignGNsInNetwork_data*)RTDS_msgData)->param3) = (RTDS_PARAM3); \
	RTDS_MSG_QUEUE_SEND_TO_ID(TN_LN_AssignGNsInNetwork, sizeof(RTDS_TN_LN_AssignGNsInNetwork_data), RTDS_msgData, RECEIVER); \
	}
#endif /* RTDS_MSG_SEND_TN_LN_AssignGNsInNetwork_TO_ID defined */

/* MACROS FOR SENDING MESSAGE TN_LN_AssignGNsInNetwork TO ENVIRONMENT */

#ifndef RTDS_MSG_SEND_TN_LN_AssignGNsInNetwork_TO_ENV
#define RTDS_MSG_SEND_TN_LN_AssignGNsInNetwork_TO_ENV(RTDS_PARAM1, RTDS_PARAM2, RTDS_PARAM3) \
	{ \
	RTDS_msgData = (unsigned char *)new RTDS_TN_LN_AssignGNsInNetwork_data(); \
	(((RTDS_TN_LN_AssignGNsInNetwork_data*)RTDS_msgData)->param1) = (RTDS_PARAM1); \
	(((RTDS_TN_LN_AssignGNsInNetwork_data*)RTDS_msgData)->param2) = (RTDS_PARAM2); \
	(((RTDS_TN_LN_AssignGNsInNetwork_data*)RTDS_msgData)->param3) = (RTDS_PARAM3); \
	RTDS_MSG_QUEUE_SEND_TO_ENV(TN_LN_AssignGNsInNetwork, sizeof(RTDS_TN_LN_AssignGNsInNetwork_data), RTDS_msgData); \
	}
#endif /* RTDS_MSG_SEND_TN_LN_AssignGNsInNetwork_TO_ENV defined */

#ifndef RTDS_MSG_SEND_TN_LN_AssignGNsInNetwork_TO_ENV_W_MACRO
#define RTDS_MSG_SEND_TN_LN_AssignGNsInNetwork_TO_ENV_W_MACRO(MACRO_NAME, RTDS_PARAM1, RTDS_PARAM2, RTDS_PARAM3) \
	{ \
	RTDS_msgData = (unsigned char *)new RTDS_TN_LN_AssignGNsInNetwork_data(); \
	(((RTDS_TN_LN_AssignGNsInNetwork_data*)RTDS_msgData)->param1) = (RTDS_PARAM1); \
	(((RTDS_TN_LN_AssignGNsInNetwork_data*)RTDS_msgData)->param2) = (RTDS_PARAM2); \
	(((RTDS_TN_LN_AssignGNsInNetwork_data*)RTDS_msgData)->param3) = (RTDS_PARAM3); \
	MACRO_NAME(TN_LN_AssignGNsInNetwork, sizeof(RTDS_TN_LN_AssignGNsInNetwork_data), RTDS_msgData); \
	}
#endif /* RTDS_MSG_SEND_TN_LN_AssignGNsInNetwork_TO_ENV defined */

/* MACRO FOR RECEPTION OF MESSAGE Message_TE_TE_ST_Ans */

#ifndef RTDS_MSG_RECEIVE_Message_TE_TE_ST_Ans
#define RTDS_MSG_RECEIVE_Message_TE_TE_ST_Ans(RTDS_PARAM1, RTDS_PARAM2, RTDS_PARAM3, RTDS_PARAM4, RTDS_PARAM5) \
	{ \
	RTDS_msgData = (unsigned char *)(RTDS_currentContext->currentMessage->pData); \
	if ( RTDS_msgData != NULL ) \
		{ \
		(RTDS_PARAM1) = (((RTDS_Message_TE_TE_ST_Ans_data*)RTDS_msgData)->param1); \
		(RTDS_PARAM2) = (((RTDS_Message_TE_TE_ST_Ans_data*)RTDS_msgData)->param2); \
		(RTDS_PARAM3) = (((RTDS_Message_TE_TE_ST_Ans_data*)RTDS_msgData)->param3); \
		(RTDS_PARAM4) = (((RTDS_Message_TE_TE_ST_Ans_data*)RTDS_msgData)->param4); \
		RTDS_PARAM5 = ((RTDS_Message_TE_TE_ST_Ans_data*)RTDS_msgData)->param5; \
		} \
	else \
		{ \
		RTDS_MSG_INPUT_ERROR; \
		} \
	}
#endif /* RTDS_MSG_RECEIVE_Message_TE_TE_ST_Ans defined */

/* MACRO FOR SENDING MESSAGE Message_TE_TE_ST_Ans TO A PROCESS NAME */

#ifndef RTDS_MSG_SEND_Message_TE_TE_ST_Ans_TO_NAME
#define RTDS_MSG_SEND_Message_TE_TE_ST_Ans_TO_NAME(RECEIVER, RECEIVER_NUMBER, RTDS_PARAM1, RTDS_PARAM2, RTDS_PARAM3, RTDS_PARAM4, RTDS_PARAM5) \
	{ \
	RTDS_msgData = (unsigned char *)new RTDS_Message_TE_TE_ST_Ans_data(); \
	(((RTDS_Message_TE_TE_ST_Ans_data*)RTDS_msgData)->param1) = (RTDS_PARAM1); \
	(((RTDS_Message_TE_TE_ST_Ans_data*)RTDS_msgData)->param2) = (RTDS_PARAM2); \
	(((RTDS_Message_TE_TE_ST_Ans_data*)RTDS_msgData)->param3) = (RTDS_PARAM3); \
	(((RTDS_Message_TE_TE_ST_Ans_data*)RTDS_msgData)->param4) = (RTDS_PARAM4); \
	((RTDS_Message_TE_TE_ST_Ans_data*)RTDS_msgData)->param5 = RTDS_PARAM5; \
	RTDS_MSG_QUEUE_SEND_TO_NAME(Message_TE_TE_ST_Ans, sizeof(RTDS_Message_TE_TE_ST_Ans_data), RTDS_msgData, RECEIVER, RECEIVER_NUMBER); \
	}
#endif /* RTDS_MSG_SEND_Message_TE_TE_ST_Ans_TO_NAME defined */

/* MACRO FOR SENDING MESSAGE Message_TE_TE_ST_Ans TO A PROCESS ID */

#ifndef RTDS_MSG_SEND_Message_TE_TE_ST_Ans_TO_ID
#define RTDS_MSG_SEND_Message_TE_TE_ST_Ans_TO_ID(RECEIVER, RTDS_PARAM1, RTDS_PARAM2, RTDS_PARAM3, RTDS_PARAM4, RTDS_PARAM5) \
	{ \
	RTDS_msgData = (unsigned char *)new RTDS_Message_TE_TE_ST_Ans_data(); \
	(((RTDS_Message_TE_TE_ST_Ans_data*)RTDS_msgData)->param1) = (RTDS_PARAM1); \
	(((RTDS_Message_TE_TE_ST_Ans_data*)RTDS_msgData)->param2) = (RTDS_PARAM2); \
	(((RTDS_Message_TE_TE_ST_Ans_data*)RTDS_msgData)->param3) = (RTDS_PARAM3); \
	(((RTDS_Message_TE_TE_ST_Ans_data*)RTDS_msgData)->param4) = (RTDS_PARAM4); \
	((RTDS_Message_TE_TE_ST_Ans_data*)RTDS_msgData)->param5 = RTDS_PARAM5; \
	RTDS_MSG_QUEUE_SEND_TO_ID(Message_TE_TE_ST_Ans, sizeof(RTDS_Message_TE_TE_ST_Ans_data), RTDS_msgData, RECEIVER); \
	}
#endif /* RTDS_MSG_SEND_Message_TE_TE_ST_Ans_TO_ID defined */

/* MACROS FOR SENDING MESSAGE Message_TE_TE_ST_Ans TO ENVIRONMENT */

#ifndef RTDS_MSG_SEND_Message_TE_TE_ST_Ans_TO_ENV
#define RTDS_MSG_SEND_Message_TE_TE_ST_Ans_TO_ENV(RTDS_PARAM1, RTDS_PARAM2, RTDS_PARAM3, RTDS_PARAM4, RTDS_PARAM5) \
	{ \
	RTDS_msgData = (unsigned char *)new RTDS_Message_TE_TE_ST_Ans_data(); \
	(((RTDS_Message_TE_TE_ST_Ans_data*)RTDS_msgData)->param1) = (RTDS_PARAM1); \
	(((RTDS_Message_TE_TE_ST_Ans_data*)RTDS_msgData)->param2) = (RTDS_PARAM2); \
	(((RTDS_Message_TE_TE_ST_Ans_data*)RTDS_msgData)->param3) = (RTDS_PARAM3); \
	(((RTDS_Message_TE_TE_ST_Ans_data*)RTDS_msgData)->param4) = (RTDS_PARAM4); \
	((RTDS_Message_TE_TE_ST_Ans_data*)RTDS_msgData)->param5 = RTDS_PARAM5; \
	RTDS_MSG_QUEUE_SEND_TO_ENV(Message_TE_TE_ST_Ans, sizeof(RTDS_Message_TE_TE_ST_Ans_data), RTDS_msgData); \
	}
#endif /* RTDS_MSG_SEND_Message_TE_TE_ST_Ans_TO_ENV defined */

#ifndef RTDS_MSG_SEND_Message_TE_TE_ST_Ans_TO_ENV_W_MACRO
#define RTDS_MSG_SEND_Message_TE_TE_ST_Ans_TO_ENV_W_MACRO(MACRO_NAME, RTDS_PARAM1, RTDS_PARAM2, RTDS_PARAM3, RTDS_PARAM4, RTDS_PARAM5) \
	{ \
	RTDS_msgData = (unsigned char *)new RTDS_Message_TE_TE_ST_Ans_data(); \
	(((RTDS_Message_TE_TE_ST_Ans_data*)RTDS_msgData)->param1) = (RTDS_PARAM1); \
	(((RTDS_Message_TE_TE_ST_Ans_data*)RTDS_msgData)->param2) = (RTDS_PARAM2); \
	(((RTDS_Message_TE_TE_ST_Ans_data*)RTDS_msgData)->param3) = (RTDS_PARAM3); \
	(((RTDS_Message_TE_TE_ST_Ans_data*)RTDS_msgData)->param4) = (RTDS_PARAM4); \
	((RTDS_Message_TE_TE_ST_Ans_data*)RTDS_msgData)->param5 = RTDS_PARAM5; \
	MACRO_NAME(Message_TE_TE_ST_Ans, sizeof(RTDS_Message_TE_TE_ST_Ans_data), RTDS_msgData); \
	}
#endif /* RTDS_MSG_SEND_Message_TE_TE_ST_Ans_TO_ENV defined */

/* MACRO FOR RECEPTION OF MESSAGE Message_TE_TE_LE_Ala */

#ifndef RTDS_MSG_RECEIVE_Message_TE_TE_LE_Ala
#define RTDS_MSG_RECEIVE_Message_TE_TE_LE_Ala(RTDS_PARAM1, RTDS_PARAM2, RTDS_PARAM3, RTDS_PARAM4, RTDS_PARAM5) \
	{ \
	RTDS_msgData = (unsigned char *)(RTDS_currentContext->currentMessage->pData); \
	if ( RTDS_msgData != NULL ) \
		{ \
		(RTDS_PARAM1) = (((RTDS_Message_TE_TE_LE_Ala_data*)RTDS_msgData)->param1); \
		(RTDS_PARAM2) = (((RTDS_Message_TE_TE_LE_Ala_data*)RTDS_msgData)->param2); \
		(RTDS_PARAM3) = (((RTDS_Message_TE_TE_LE_Ala_data*)RTDS_msgData)->param3); \
		RTDS_PARAM4 = ((RTDS_Message_TE_TE_LE_Ala_data*)RTDS_msgData)->param4; \
		(RTDS_PARAM5) = (((RTDS_Message_TE_TE_LE_Ala_data*)RTDS_msgData)->param5); \
		} \
	else \
		{ \
		RTDS_MSG_INPUT_ERROR; \
		} \
	}
#endif /* RTDS_MSG_RECEIVE_Message_TE_TE_LE_Ala defined */

/* MACRO FOR SENDING MESSAGE Message_TE_TE_LE_Ala TO A PROCESS NAME */

#ifndef RTDS_MSG_SEND_Message_TE_TE_LE_Ala_TO_NAME
#define RTDS_MSG_SEND_Message_TE_TE_LE_Ala_TO_NAME(RECEIVER, RECEIVER_NUMBER, RTDS_PARAM1, RTDS_PARAM2, RTDS_PARAM3, RTDS_PARAM4, RTDS_PARAM5) \
	{ \
	RTDS_msgData = (unsigned char *)new RTDS_Message_TE_TE_LE_Ala_data(); \
	(((RTDS_Message_TE_TE_LE_Ala_data*)RTDS_msgData)->param1) = (RTDS_PARAM1); \
	(((RTDS_Message_TE_TE_LE_Ala_data*)RTDS_msgData)->param2) = (RTDS_PARAM2); \
	(((RTDS_Message_TE_TE_LE_Ala_data*)RTDS_msgData)->param3) = (RTDS_PARAM3); \
	((RTDS_Message_TE_TE_LE_Ala_data*)RTDS_msgData)->param4 = RTDS_PARAM4; \
	(((RTDS_Message_TE_TE_LE_Ala_data*)RTDS_msgData)->param5) = (RTDS_PARAM5); \
	RTDS_MSG_QUEUE_SEND_TO_NAME(Message_TE_TE_LE_Ala, sizeof(RTDS_Message_TE_TE_LE_Ala_data), RTDS_msgData, RECEIVER, RECEIVER_NUMBER); \
	}
#endif /* RTDS_MSG_SEND_Message_TE_TE_LE_Ala_TO_NAME defined */

/* MACRO FOR SENDING MESSAGE Message_TE_TE_LE_Ala TO A PROCESS ID */

#ifndef RTDS_MSG_SEND_Message_TE_TE_LE_Ala_TO_ID
#define RTDS_MSG_SEND_Message_TE_TE_LE_Ala_TO_ID(RECEIVER, RTDS_PARAM1, RTDS_PARAM2, RTDS_PARAM3, RTDS_PARAM4, RTDS_PARAM5) \
	{ \
	RTDS_msgData = (unsigned char *)new RTDS_Message_TE_TE_LE_Ala_data(); \
	(((RTDS_Message_TE_TE_LE_Ala_data*)RTDS_msgData)->param1) = (RTDS_PARAM1); \
	(((RTDS_Message_TE_TE_LE_Ala_data*)RTDS_msgData)->param2) = (RTDS_PARAM2); \
	(((RTDS_Message_TE_TE_LE_Ala_data*)RTDS_msgData)->param3) = (RTDS_PARAM3); \
	((RTDS_Message_TE_TE_LE_Ala_data*)RTDS_msgData)->param4 = RTDS_PARAM4; \
	(((RTDS_Message_TE_TE_LE_Ala_data*)RTDS_msgData)->param5) = (RTDS_PARAM5); \
	RTDS_MSG_QUEUE_SEND_TO_ID(Message_TE_TE_LE_Ala, sizeof(RTDS_Message_TE_TE_LE_Ala_data), RTDS_msgData, RECEIVER); \
	}
#endif /* RTDS_MSG_SEND_Message_TE_TE_LE_Ala_TO_ID defined */

/* MACROS FOR SENDING MESSAGE Message_TE_TE_LE_Ala TO ENVIRONMENT */

#ifndef RTDS_MSG_SEND_Message_TE_TE_LE_Ala_TO_ENV
#define RTDS_MSG_SEND_Message_TE_TE_LE_Ala_TO_ENV(RTDS_PARAM1, RTDS_PARAM2, RTDS_PARAM3, RTDS_PARAM4, RTDS_PARAM5) \
	{ \
	RTDS_msgData = (unsigned char *)new RTDS_Message_TE_TE_LE_Ala_data(); \
	(((RTDS_Message_TE_TE_LE_Ala_data*)RTDS_msgData)->param1) = (RTDS_PARAM1); \
	(((RTDS_Message_TE_TE_LE_Ala_data*)RTDS_msgData)->param2) = (RTDS_PARAM2); \
	(((RTDS_Message_TE_TE_LE_Ala_data*)RTDS_msgData)->param3) = (RTDS_PARAM3); \
	((RTDS_Message_TE_TE_LE_Ala_data*)RTDS_msgData)->param4 = RTDS_PARAM4; \
	(((RTDS_Message_TE_TE_LE_Ala_data*)RTDS_msgData)->param5) = (RTDS_PARAM5); \
	RTDS_MSG_QUEUE_SEND_TO_ENV(Message_TE_TE_LE_Ala, sizeof(RTDS_Message_TE_TE_LE_Ala_data), RTDS_msgData); \
	}
#endif /* RTDS_MSG_SEND_Message_TE_TE_LE_Ala_TO_ENV defined */

#ifndef RTDS_MSG_SEND_Message_TE_TE_LE_Ala_TO_ENV_W_MACRO
#define RTDS_MSG_SEND_Message_TE_TE_LE_Ala_TO_ENV_W_MACRO(MACRO_NAME, RTDS_PARAM1, RTDS_PARAM2, RTDS_PARAM3, RTDS_PARAM4, RTDS_PARAM5) \
	{ \
	RTDS_msgData = (unsigned char *)new RTDS_Message_TE_TE_LE_Ala_data(); \
	(((RTDS_Message_TE_TE_LE_Ala_data*)RTDS_msgData)->param1) = (RTDS_PARAM1); \
	(((RTDS_Message_TE_TE_LE_Ala_data*)RTDS_msgData)->param2) = (RTDS_PARAM2); \
	(((RTDS_Message_TE_TE_LE_Ala_data*)RTDS_msgData)->param3) = (RTDS_PARAM3); \
	((RTDS_Message_TE_TE_LE_Ala_data*)RTDS_msgData)->param4 = RTDS_PARAM4; \
	(((RTDS_Message_TE_TE_LE_Ala_data*)RTDS_msgData)->param5) = (RTDS_PARAM5); \
	MACRO_NAME(Message_TE_TE_LE_Ala, sizeof(RTDS_Message_TE_TE_LE_Ala_data), RTDS_msgData); \
	}
#endif /* RTDS_MSG_SEND_Message_TE_TE_LE_Ala_TO_ENV defined */

/* MACRO FOR RECEPTION OF MESSAGE Message_TE_TE_SL_Det */

#ifndef RTDS_MSG_RECEIVE_Message_TE_TE_SL_Det
#define RTDS_MSG_RECEIVE_Message_TE_TE_SL_Det(RTDS_PARAM1, RTDS_PARAM2, RTDS_PARAM3, RTDS_PARAM4, RTDS_PARAM5, RTDS_PARAM6, RTDS_PARAM7, RTDS_PARAM8, RTDS_PARAM9, RTDS_PARAM10) \
	{ \
	RTDS_msgData = (unsigned char *)(RTDS_currentContext->currentMessage->pData); \
	if ( RTDS_msgData != NULL ) \
		{ \
		(RTDS_PARAM1) = (((RTDS_Message_TE_TE_SL_Det_data*)RTDS_msgData)->param1); \
		(RTDS_PARAM2) = (((RTDS_Message_TE_TE_SL_Det_data*)RTDS_msgData)->param2); \
		(RTDS_PARAM3) = (((RTDS_Message_TE_TE_SL_Det_data*)RTDS_msgData)->param3); \
		(RTDS_PARAM4) = (((RTDS_Message_TE_TE_SL_Det_data*)RTDS_msgData)->param4); \
		(RTDS_PARAM5) = (((RTDS_Message_TE_TE_SL_Det_data*)RTDS_msgData)->param5); \
		(RTDS_PARAM6) = (((RTDS_Message_TE_TE_SL_Det_data*)RTDS_msgData)->param6); \
		(RTDS_PARAM7) = (((RTDS_Message_TE_TE_SL_Det_data*)RTDS_msgData)->param7); \
		(RTDS_PARAM8) = (((RTDS_Message_TE_TE_SL_Det_data*)RTDS_msgData)->param8); \
		RTDS_PARAM9 = ((RTDS_Message_TE_TE_SL_Det_data*)RTDS_msgData)->param9; \
		RTDS_PARAM10 = ((RTDS_Message_TE_TE_SL_Det_data*)RTDS_msgData)->param10; \
		} \
	else \
		{ \
		RTDS_MSG_INPUT_ERROR; \
		} \
	}
#endif /* RTDS_MSG_RECEIVE_Message_TE_TE_SL_Det defined */

/* MACRO FOR SENDING MESSAGE Message_TE_TE_SL_Det TO A PROCESS NAME */

#ifndef RTDS_MSG_SEND_Message_TE_TE_SL_Det_TO_NAME
#define RTDS_MSG_SEND_Message_TE_TE_SL_Det_TO_NAME(RECEIVER, RECEIVER_NUMBER, RTDS_PARAM1, RTDS_PARAM2, RTDS_PARAM3, RTDS_PARAM4, RTDS_PARAM5, RTDS_PARAM6, RTDS_PARAM7, RTDS_PARAM8, RTDS_PARAM9, RTDS_PARAM10) \
	{ \
	RTDS_msgData = (unsigned char *)new RTDS_Message_TE_TE_SL_Det_data(); \
	(((RTDS_Message_TE_TE_SL_Det_data*)RTDS_msgData)->param1) = (RTDS_PARAM1); \
	(((RTDS_Message_TE_TE_SL_Det_data*)RTDS_msgData)->param2) = (RTDS_PARAM2); \
	(((RTDS_Message_TE_TE_SL_Det_data*)RTDS_msgData)->param3) = (RTDS_PARAM3); \
	(((RTDS_Message_TE_TE_SL_Det_data*)RTDS_msgData)->param4) = (RTDS_PARAM4); \
	(((RTDS_Message_TE_TE_SL_Det_data*)RTDS_msgData)->param5) = (RTDS_PARAM5); \
	(((RTDS_Message_TE_TE_SL_Det_data*)RTDS_msgData)->param6) = (RTDS_PARAM6); \
	(((RTDS_Message_TE_TE_SL_Det_data*)RTDS_msgData)->param7) = (RTDS_PARAM7); \
	(((RTDS_Message_TE_TE_SL_Det_data*)RTDS_msgData)->param8) = (RTDS_PARAM8); \
	((RTDS_Message_TE_TE_SL_Det_data*)RTDS_msgData)->param9 = RTDS_PARAM9; \
	((RTDS_Message_TE_TE_SL_Det_data*)RTDS_msgData)->param10 = RTDS_PARAM10; \
	RTDS_MSG_QUEUE_SEND_TO_NAME(Message_TE_TE_SL_Det, sizeof(RTDS_Message_TE_TE_SL_Det_data), RTDS_msgData, RECEIVER, RECEIVER_NUMBER); \
	}
#endif /* RTDS_MSG_SEND_Message_TE_TE_SL_Det_TO_NAME defined */

/* MACRO FOR SENDING MESSAGE Message_TE_TE_SL_Det TO A PROCESS ID */

#ifndef RTDS_MSG_SEND_Message_TE_TE_SL_Det_TO_ID
#define RTDS_MSG_SEND_Message_TE_TE_SL_Det_TO_ID(RECEIVER, RTDS_PARAM1, RTDS_PARAM2, RTDS_PARAM3, RTDS_PARAM4, RTDS_PARAM5, RTDS_PARAM6, RTDS_PARAM7, RTDS_PARAM8, RTDS_PARAM9, RTDS_PARAM10) \
	{ \
	RTDS_msgData = (unsigned char *)new RTDS_Message_TE_TE_SL_Det_data(); \
	(((RTDS_Message_TE_TE_SL_Det_data*)RTDS_msgData)->param1) = (RTDS_PARAM1); \
	(((RTDS_Message_TE_TE_SL_Det_data*)RTDS_msgData)->param2) = (RTDS_PARAM2); \
	(((RTDS_Message_TE_TE_SL_Det_data*)RTDS_msgData)->param3) = (RTDS_PARAM3); \
	(((RTDS_Message_TE_TE_SL_Det_data*)RTDS_msgData)->param4) = (RTDS_PARAM4); \
	(((RTDS_Message_TE_TE_SL_Det_data*)RTDS_msgData)->param5) = (RTDS_PARAM5); \
	(((RTDS_Message_TE_TE_SL_Det_data*)RTDS_msgData)->param6) = (RTDS_PARAM6); \
	(((RTDS_Message_TE_TE_SL_Det_data*)RTDS_msgData)->param7) = (RTDS_PARAM7); \
	(((RTDS_Message_TE_TE_SL_Det_data*)RTDS_msgData)->param8) = (RTDS_PARAM8); \
	((RTDS_Message_TE_TE_SL_Det_data*)RTDS_msgData)->param9 = RTDS_PARAM9; \
	((RTDS_Message_TE_TE_SL_Det_data*)RTDS_msgData)->param10 = RTDS_PARAM10; \
	RTDS_MSG_QUEUE_SEND_TO_ID(Message_TE_TE_SL_Det, sizeof(RTDS_Message_TE_TE_SL_Det_data), RTDS_msgData, RECEIVER); \
	}
#endif /* RTDS_MSG_SEND_Message_TE_TE_SL_Det_TO_ID defined */

/* MACROS FOR SENDING MESSAGE Message_TE_TE_SL_Det TO ENVIRONMENT */

#ifndef RTDS_MSG_SEND_Message_TE_TE_SL_Det_TO_ENV
#define RTDS_MSG_SEND_Message_TE_TE_SL_Det_TO_ENV(RTDS_PARAM1, RTDS_PARAM2, RTDS_PARAM3, RTDS_PARAM4, RTDS_PARAM5, RTDS_PARAM6, RTDS_PARAM7, RTDS_PARAM8, RTDS_PARAM9, RTDS_PARAM10) \
	{ \
	RTDS_msgData = (unsigned char *)new RTDS_Message_TE_TE_SL_Det_data(); \
	(((RTDS_Message_TE_TE_SL_Det_data*)RTDS_msgData)->param1) = (RTDS_PARAM1); \
	(((RTDS_Message_TE_TE_SL_Det_data*)RTDS_msgData)->param2) = (RTDS_PARAM2); \
	(((RTDS_Message_TE_TE_SL_Det_data*)RTDS_msgData)->param3) = (RTDS_PARAM3); \
	(((RTDS_Message_TE_TE_SL_Det_data*)RTDS_msgData)->param4) = (RTDS_PARAM4); \
	(((RTDS_Message_TE_TE_SL_Det_data*)RTDS_msgData)->param5) = (RTDS_PARAM5); \
	(((RTDS_Message_TE_TE_SL_Det_data*)RTDS_msgData)->param6) = (RTDS_PARAM6); \
	(((RTDS_Message_TE_TE_SL_Det_data*)RTDS_msgData)->param7) = (RTDS_PARAM7); \
	(((RTDS_Message_TE_TE_SL_Det_data*)RTDS_msgData)->param8) = (RTDS_PARAM8); \
	((RTDS_Message_TE_TE_SL_Det_data*)RTDS_msgData)->param9 = RTDS_PARAM9; \
	((RTDS_Message_TE_TE_SL_Det_data*)RTDS_msgData)->param10 = RTDS_PARAM10; \
	RTDS_MSG_QUEUE_SEND_TO_ENV(Message_TE_TE_SL_Det, sizeof(RTDS_Message_TE_TE_SL_Det_data), RTDS_msgData); \
	}
#endif /* RTDS_MSG_SEND_Message_TE_TE_SL_Det_TO_ENV defined */

#ifndef RTDS_MSG_SEND_Message_TE_TE_SL_Det_TO_ENV_W_MACRO
#define RTDS_MSG_SEND_Message_TE_TE_SL_Det_TO_ENV_W_MACRO(MACRO_NAME, RTDS_PARAM1, RTDS_PARAM2, RTDS_PARAM3, RTDS_PARAM4, RTDS_PARAM5, RTDS_PARAM6, RTDS_PARAM7, RTDS_PARAM8, RTDS_PARAM9, RTDS_PARAM10) \
	{ \
	RTDS_msgData = (unsigned char *)new RTDS_Message_TE_TE_SL_Det_data(); \
	(((RTDS_Message_TE_TE_SL_Det_data*)RTDS_msgData)->param1) = (RTDS_PARAM1); \
	(((RTDS_Message_TE_TE_SL_Det_data*)RTDS_msgData)->param2) = (RTDS_PARAM2); \
	(((RTDS_Message_TE_TE_SL_Det_data*)RTDS_msgData)->param3) = (RTDS_PARAM3); \
	(((RTDS_Message_TE_TE_SL_Det_data*)RTDS_msgData)->param4) = (RTDS_PARAM4); \
	(((RTDS_Message_TE_TE_SL_Det_data*)RTDS_msgData)->param5) = (RTDS_PARAM5); \
	(((RTDS_Message_TE_TE_SL_Det_data*)RTDS_msgData)->param6) = (RTDS_PARAM6); \
	(((RTDS_Message_TE_TE_SL_Det_data*)RTDS_msgData)->param7) = (RTDS_PARAM7); \
	(((RTDS_Message_TE_TE_SL_Det_data*)RTDS_msgData)->param8) = (RTDS_PARAM8); \
	((RTDS_Message_TE_TE_SL_Det_data*)RTDS_msgData)->param9 = RTDS_PARAM9; \
	((RTDS_Message_TE_TE_SL_Det_data*)RTDS_msgData)->param10 = RTDS_PARAM10; \
	MACRO_NAME(Message_TE_TE_SL_Det, sizeof(RTDS_Message_TE_TE_SL_Det_data), RTDS_msgData); \
	}
#endif /* RTDS_MSG_SEND_Message_TE_TE_SL_Det_TO_ENV defined */

/* MACRO FOR RECEPTION OF MESSAGE Message_TE_TE_TS_ALS */

#ifndef RTDS_MSG_RECEIVE_Message_TE_TE_TS_ALS
#define RTDS_MSG_RECEIVE_Message_TE_TE_TS_ALS(RTDS_PARAM1, RTDS_PARAM2, RTDS_PARAM3, RTDS_PARAM4, RTDS_PARAM5) \
	{ \
	RTDS_msgData = (unsigned char *)(RTDS_currentContext->currentMessage->pData); \
	if ( RTDS_msgData != NULL ) \
		{ \
		(RTDS_PARAM1) = (((RTDS_Message_TE_TE_TS_ALS_data*)RTDS_msgData)->param1); \
		(RTDS_PARAM2) = (((RTDS_Message_TE_TE_TS_ALS_data*)RTDS_msgData)->param2); \
		(RTDS_PARAM3) = (((RTDS_Message_TE_TE_TS_ALS_data*)RTDS_msgData)->param3); \
		(RTDS_PARAM4) = (((RTDS_Message_TE_TE_TS_ALS_data*)RTDS_msgData)->param4); \
		RTDS_PARAM5 = ((RTDS_Message_TE_TE_TS_ALS_data*)RTDS_msgData)->param5; \
		} \
	else \
		{ \
		RTDS_MSG_INPUT_ERROR; \
		} \
	}
#endif /* RTDS_MSG_RECEIVE_Message_TE_TE_TS_ALS defined */

/* MACRO FOR SENDING MESSAGE Message_TE_TE_TS_ALS TO A PROCESS NAME */

#ifndef RTDS_MSG_SEND_Message_TE_TE_TS_ALS_TO_NAME
#define RTDS_MSG_SEND_Message_TE_TE_TS_ALS_TO_NAME(RECEIVER, RECEIVER_NUMBER, RTDS_PARAM1, RTDS_PARAM2, RTDS_PARAM3, RTDS_PARAM4, RTDS_PARAM5) \
	{ \
	RTDS_msgData = (unsigned char *)new RTDS_Message_TE_TE_TS_ALS_data(); \
	(((RTDS_Message_TE_TE_TS_ALS_data*)RTDS_msgData)->param1) = (RTDS_PARAM1); \
	(((RTDS_Message_TE_TE_TS_ALS_data*)RTDS_msgData)->param2) = (RTDS_PARAM2); \
	(((RTDS_Message_TE_TE_TS_ALS_data*)RTDS_msgData)->param3) = (RTDS_PARAM3); \
	(((RTDS_Message_TE_TE_TS_ALS_data*)RTDS_msgData)->param4) = (RTDS_PARAM4); \
	((RTDS_Message_TE_TE_TS_ALS_data*)RTDS_msgData)->param5 = RTDS_PARAM5; \
	RTDS_MSG_QUEUE_SEND_TO_NAME(Message_TE_TE_TS_ALS, sizeof(RTDS_Message_TE_TE_TS_ALS_data), RTDS_msgData, RECEIVER, RECEIVER_NUMBER); \
	}
#endif /* RTDS_MSG_SEND_Message_TE_TE_TS_ALS_TO_NAME defined */

/* MACRO FOR SENDING MESSAGE Message_TE_TE_TS_ALS TO A PROCESS ID */

#ifndef RTDS_MSG_SEND_Message_TE_TE_TS_ALS_TO_ID
#define RTDS_MSG_SEND_Message_TE_TE_TS_ALS_TO_ID(RECEIVER, RTDS_PARAM1, RTDS_PARAM2, RTDS_PARAM3, RTDS_PARAM4, RTDS_PARAM5) \
	{ \
	RTDS_msgData = (unsigned char *)new RTDS_Message_TE_TE_TS_ALS_data(); \
	(((RTDS_Message_TE_TE_TS_ALS_data*)RTDS_msgData)->param1) = (RTDS_PARAM1); \
	(((RTDS_Message_TE_TE_TS_ALS_data*)RTDS_msgData)->param2) = (RTDS_PARAM2); \
	(((RTDS_Message_TE_TE_TS_ALS_data*)RTDS_msgData)->param3) = (RTDS_PARAM3); \
	(((RTDS_Message_TE_TE_TS_ALS_data*)RTDS_msgData)->param4) = (RTDS_PARAM4); \
	((RTDS_Message_TE_TE_TS_ALS_data*)RTDS_msgData)->param5 = RTDS_PARAM5; \
	RTDS_MSG_QUEUE_SEND_TO_ID(Message_TE_TE_TS_ALS, sizeof(RTDS_Message_TE_TE_TS_ALS_data), RTDS_msgData, RECEIVER); \
	}
#endif /* RTDS_MSG_SEND_Message_TE_TE_TS_ALS_TO_ID defined */

/* MACROS FOR SENDING MESSAGE Message_TE_TE_TS_ALS TO ENVIRONMENT */

#ifndef RTDS_MSG_SEND_Message_TE_TE_TS_ALS_TO_ENV
#define RTDS_MSG_SEND_Message_TE_TE_TS_ALS_TO_ENV(RTDS_PARAM1, RTDS_PARAM2, RTDS_PARAM3, RTDS_PARAM4, RTDS_PARAM5) \
	{ \
	RTDS_msgData = (unsigned char *)new RTDS_Message_TE_TE_TS_ALS_data(); \
	(((RTDS_Message_TE_TE_TS_ALS_data*)RTDS_msgData)->param1) = (RTDS_PARAM1); \
	(((RTDS_Message_TE_TE_TS_ALS_data*)RTDS_msgData)->param2) = (RTDS_PARAM2); \
	(((RTDS_Message_TE_TE_TS_ALS_data*)RTDS_msgData)->param3) = (RTDS_PARAM3); \
	(((RTDS_Message_TE_TE_TS_ALS_data*)RTDS_msgData)->param4) = (RTDS_PARAM4); \
	((RTDS_Message_TE_TE_TS_ALS_data*)RTDS_msgData)->param5 = RTDS_PARAM5; \
	RTDS_MSG_QUEUE_SEND_TO_ENV(Message_TE_TE_TS_ALS, sizeof(RTDS_Message_TE_TE_TS_ALS_data), RTDS_msgData); \
	}
#endif /* RTDS_MSG_SEND_Message_TE_TE_TS_ALS_TO_ENV defined */

#ifndef RTDS_MSG_SEND_Message_TE_TE_TS_ALS_TO_ENV_W_MACRO
#define RTDS_MSG_SEND_Message_TE_TE_TS_ALS_TO_ENV_W_MACRO(MACRO_NAME, RTDS_PARAM1, RTDS_PARAM2, RTDS_PARAM3, RTDS_PARAM4, RTDS_PARAM5) \
	{ \
	RTDS_msgData = (unsigned char *)new RTDS_Message_TE_TE_TS_ALS_data(); \
	(((RTDS_Message_TE_TE_TS_ALS_data*)RTDS_msgData)->param1) = (RTDS_PARAM1); \
	(((RTDS_Message_TE_TE_TS_ALS_data*)RTDS_msgData)->param2) = (RTDS_PARAM2); \
	(((RTDS_Message_TE_TE_TS_ALS_data*)RTDS_msgData)->param3) = (RTDS_PARAM3); \
	(((RTDS_Message_TE_TE_TS_ALS_data*)RTDS_msgData)->param4) = (RTDS_PARAM4); \
	((RTDS_Message_TE_TE_TS_ALS_data*)RTDS_msgData)->param5 = RTDS_PARAM5; \
	MACRO_NAME(Message_TE_TE_TS_ALS, sizeof(RTDS_Message_TE_TE_TS_ALS_data), RTDS_msgData); \
	}
#endif /* RTDS_MSG_SEND_Message_TE_TE_TS_ALS_TO_ENV defined */

/* MACRO FOR RECEPTION OF MESSAGE LN_LN_Alarm */

#ifndef RTDS_MSG_RECEIVE_LN_LN_Alarm
#define RTDS_MSG_RECEIVE_LN_LN_Alarm(RTDS_PARAM1, RTDS_PARAM2, RTDS_PARAM3, RTDS_PARAM4) \
	{ \
	RTDS_msgData = (unsigned char *)(RTDS_currentContext->currentMessage->pData); \
	if ( RTDS_msgData != NULL ) \
		{ \
		(RTDS_PARAM1) = (((RTDS_LN_LN_Alarm_data*)RTDS_msgData)->param1); \
		(RTDS_PARAM2) = (((RTDS_LN_LN_Alarm_data*)RTDS_msgData)->param2); \
		RTDS_PARAM3 = ((RTDS_LN_LN_Alarm_data*)RTDS_msgData)->param3; \
		(RTDS_PARAM4) = (((RTDS_LN_LN_Alarm_data*)RTDS_msgData)->param4); \
		} \
	else \
		{ \
		RTDS_MSG_INPUT_ERROR; \
		} \
	}
#endif /* RTDS_MSG_RECEIVE_LN_LN_Alarm defined */

/* MACRO FOR SENDING MESSAGE LN_LN_Alarm TO A PROCESS NAME */

#ifndef RTDS_MSG_SEND_LN_LN_Alarm_TO_NAME
#define RTDS_MSG_SEND_LN_LN_Alarm_TO_NAME(RECEIVER, RECEIVER_NUMBER, RTDS_PARAM1, RTDS_PARAM2, RTDS_PARAM3, RTDS_PARAM4) \
	{ \
	RTDS_msgData = (unsigned char *)new RTDS_LN_LN_Alarm_data(); \
	(((RTDS_LN_LN_Alarm_data*)RTDS_msgData)->param1) = (RTDS_PARAM1); \
	(((RTDS_LN_LN_Alarm_data*)RTDS_msgData)->param2) = (RTDS_PARAM2); \
	((RTDS_LN_LN_Alarm_data*)RTDS_msgData)->param3 = RTDS_PARAM3; \
	(((RTDS_LN_LN_Alarm_data*)RTDS_msgData)->param4) = (RTDS_PARAM4); \
	RTDS_MSG_QUEUE_SEND_TO_NAME(LN_LN_Alarm, sizeof(RTDS_LN_LN_Alarm_data), RTDS_msgData, RECEIVER, RECEIVER_NUMBER); \
	}
#endif /* RTDS_MSG_SEND_LN_LN_Alarm_TO_NAME defined */

/* MACRO FOR SENDING MESSAGE LN_LN_Alarm TO A PROCESS ID */

#ifndef RTDS_MSG_SEND_LN_LN_Alarm_TO_ID
#define RTDS_MSG_SEND_LN_LN_Alarm_TO_ID(RECEIVER, RTDS_PARAM1, RTDS_PARAM2, RTDS_PARAM3, RTDS_PARAM4) \
	{ \
	RTDS_msgData = (unsigned char *)new RTDS_LN_LN_Alarm_data(); \
	(((RTDS_LN_LN_Alarm_data*)RTDS_msgData)->param1) = (RTDS_PARAM1); \
	(((RTDS_LN_LN_Alarm_data*)RTDS_msgData)->param2) = (RTDS_PARAM2); \
	((RTDS_LN_LN_Alarm_data*)RTDS_msgData)->param3 = RTDS_PARAM3; \
	(((RTDS_LN_LN_Alarm_data*)RTDS_msgData)->param4) = (RTDS_PARAM4); \
	RTDS_MSG_QUEUE_SEND_TO_ID(LN_LN_Alarm, sizeof(RTDS_LN_LN_Alarm_data), RTDS_msgData, RECEIVER); \
	}
#endif /* RTDS_MSG_SEND_LN_LN_Alarm_TO_ID defined */

/* MACROS FOR SENDING MESSAGE LN_LN_Alarm TO ENVIRONMENT */

#ifndef RTDS_MSG_SEND_LN_LN_Alarm_TO_ENV
#define RTDS_MSG_SEND_LN_LN_Alarm_TO_ENV(RTDS_PARAM1, RTDS_PARAM2, RTDS_PARAM3, RTDS_PARAM4) \
	{ \
	RTDS_msgData = (unsigned char *)new RTDS_LN_LN_Alarm_data(); \
	(((RTDS_LN_LN_Alarm_data*)RTDS_msgData)->param1) = (RTDS_PARAM1); \
	(((RTDS_LN_LN_Alarm_data*)RTDS_msgData)->param2) = (RTDS_PARAM2); \
	((RTDS_LN_LN_Alarm_data*)RTDS_msgData)->param3 = RTDS_PARAM3; \
	(((RTDS_LN_LN_Alarm_data*)RTDS_msgData)->param4) = (RTDS_PARAM4); \
	RTDS_MSG_QUEUE_SEND_TO_ENV(LN_LN_Alarm, sizeof(RTDS_LN_LN_Alarm_data), RTDS_msgData); \
	}
#endif /* RTDS_MSG_SEND_LN_LN_Alarm_TO_ENV defined */

#ifndef RTDS_MSG_SEND_LN_LN_Alarm_TO_ENV_W_MACRO
#define RTDS_MSG_SEND_LN_LN_Alarm_TO_ENV_W_MACRO(MACRO_NAME, RTDS_PARAM1, RTDS_PARAM2, RTDS_PARAM3, RTDS_PARAM4) \
	{ \
	RTDS_msgData = (unsigned char *)new RTDS_LN_LN_Alarm_data(); \
	(((RTDS_LN_LN_Alarm_data*)RTDS_msgData)->param1) = (RTDS_PARAM1); \
	(((RTDS_LN_LN_Alarm_data*)RTDS_msgData)->param2) = (RTDS_PARAM2); \
	((RTDS_LN_LN_Alarm_data*)RTDS_msgData)->param3 = RTDS_PARAM3; \
	(((RTDS_LN_LN_Alarm_data*)RTDS_msgData)->param4) = (RTDS_PARAM4); \
	MACRO_NAME(LN_LN_Alarm, sizeof(RTDS_LN_LN_Alarm_data), RTDS_msgData); \
	}
#endif /* RTDS_MSG_SEND_LN_LN_Alarm_TO_ENV defined */

/* MACRO FOR RECEPTION OF MESSAGE Message_TE_TE_LS_Sum */

#ifndef RTDS_MSG_RECEIVE_Message_TE_TE_LS_Sum
#define RTDS_MSG_RECEIVE_Message_TE_TE_LS_Sum(RTDS_PARAM1, RTDS_PARAM2, RTDS_PARAM3, RTDS_PARAM4) \
	{ \
	RTDS_msgData = (unsigned char *)(RTDS_currentContext->currentMessage->pData); \
	if ( RTDS_msgData != NULL ) \
		{ \
		(RTDS_PARAM1) = (((RTDS_Message_TE_TE_LS_Sum_data*)RTDS_msgData)->param1); \
		(RTDS_PARAM2) = (((RTDS_Message_TE_TE_LS_Sum_data*)RTDS_msgData)->param2); \
		(RTDS_PARAM3) = (((RTDS_Message_TE_TE_LS_Sum_data*)RTDS_msgData)->param3); \
		RTDS_PARAM4 = ((RTDS_Message_TE_TE_LS_Sum_data*)RTDS_msgData)->param4; \
		} \
	else \
		{ \
		RTDS_MSG_INPUT_ERROR; \
		} \
	}
#endif /* RTDS_MSG_RECEIVE_Message_TE_TE_LS_Sum defined */

/* MACRO FOR SENDING MESSAGE Message_TE_TE_LS_Sum TO A PROCESS NAME */

#ifndef RTDS_MSG_SEND_Message_TE_TE_LS_Sum_TO_NAME
#define RTDS_MSG_SEND_Message_TE_TE_LS_Sum_TO_NAME(RECEIVER, RECEIVER_NUMBER, RTDS_PARAM1, RTDS_PARAM2, RTDS_PARAM3, RTDS_PARAM4) \
	{ \
	RTDS_msgData = (unsigned char *)new RTDS_Message_TE_TE_LS_Sum_data(); \
	(((RTDS_Message_TE_TE_LS_Sum_data*)RTDS_msgData)->param1) = (RTDS_PARAM1); \
	(((RTDS_Message_TE_TE_LS_Sum_data*)RTDS_msgData)->param2) = (RTDS_PARAM2); \
	(((RTDS_Message_TE_TE_LS_Sum_data*)RTDS_msgData)->param3) = (RTDS_PARAM3); \
	((RTDS_Message_TE_TE_LS_Sum_data*)RTDS_msgData)->param4 = RTDS_PARAM4; \
	RTDS_MSG_QUEUE_SEND_TO_NAME(Message_TE_TE_LS_Sum, sizeof(RTDS_Message_TE_TE_LS_Sum_data), RTDS_msgData, RECEIVER, RECEIVER_NUMBER); \
	}
#endif /* RTDS_MSG_SEND_Message_TE_TE_LS_Sum_TO_NAME defined */

/* MACRO FOR SENDING MESSAGE Message_TE_TE_LS_Sum TO A PROCESS ID */

#ifndef RTDS_MSG_SEND_Message_TE_TE_LS_Sum_TO_ID
#define RTDS_MSG_SEND_Message_TE_TE_LS_Sum_TO_ID(RECEIVER, RTDS_PARAM1, RTDS_PARAM2, RTDS_PARAM3, RTDS_PARAM4) \
	{ \
	RTDS_msgData = (unsigned char *)new RTDS_Message_TE_TE_LS_Sum_data(); \
	(((RTDS_Message_TE_TE_LS_Sum_data*)RTDS_msgData)->param1) = (RTDS_PARAM1); \
	(((RTDS_Message_TE_TE_LS_Sum_data*)RTDS_msgData)->param2) = (RTDS_PARAM2); \
	(((RTDS_Message_TE_TE_LS_Sum_data*)RTDS_msgData)->param3) = (RTDS_PARAM3); \
	((RTDS_Message_TE_TE_LS_Sum_data*)RTDS_msgData)->param4 = RTDS_PARAM4; \
	RTDS_MSG_QUEUE_SEND_TO_ID(Message_TE_TE_LS_Sum, sizeof(RTDS_Message_TE_TE_LS_Sum_data), RTDS_msgData, RECEIVER); \
	}
#endif /* RTDS_MSG_SEND_Message_TE_TE_LS_Sum_TO_ID defined */

/* MACROS FOR SENDING MESSAGE Message_TE_TE_LS_Sum TO ENVIRONMENT */

#ifndef RTDS_MSG_SEND_Message_TE_TE_LS_Sum_TO_ENV
#define RTDS_MSG_SEND_Message_TE_TE_LS_Sum_TO_ENV(RTDS_PARAM1, RTDS_PARAM2, RTDS_PARAM3, RTDS_PARAM4) \
	{ \
	RTDS_msgData = (unsigned char *)new RTDS_Message_TE_TE_LS_Sum_data(); \
	(((RTDS_Message_TE_TE_LS_Sum_data*)RTDS_msgData)->param1) = (RTDS_PARAM1); \
	(((RTDS_Message_TE_TE_LS_Sum_data*)RTDS_msgData)->param2) = (RTDS_PARAM2); \
	(((RTDS_Message_TE_TE_LS_Sum_data*)RTDS_msgData)->param3) = (RTDS_PARAM3); \
	((RTDS_Message_TE_TE_LS_Sum_data*)RTDS_msgData)->param4 = RTDS_PARAM4; \
	RTDS_MSG_QUEUE_SEND_TO_ENV(Message_TE_TE_LS_Sum, sizeof(RTDS_Message_TE_TE_LS_Sum_data), RTDS_msgData); \
	}
#endif /* RTDS_MSG_SEND_Message_TE_TE_LS_Sum_TO_ENV defined */

#ifndef RTDS_MSG_SEND_Message_TE_TE_LS_Sum_TO_ENV_W_MACRO
#define RTDS_MSG_SEND_Message_TE_TE_LS_Sum_TO_ENV_W_MACRO(MACRO_NAME, RTDS_PARAM1, RTDS_PARAM2, RTDS_PARAM3, RTDS_PARAM4) \
	{ \
	RTDS_msgData = (unsigned char *)new RTDS_Message_TE_TE_LS_Sum_data(); \
	(((RTDS_Message_TE_TE_LS_Sum_data*)RTDS_msgData)->param1) = (RTDS_PARAM1); \
	(((RTDS_Message_TE_TE_LS_Sum_data*)RTDS_msgData)->param2) = (RTDS_PARAM2); \
	(((RTDS_Message_TE_TE_LS_Sum_data*)RTDS_msgData)->param3) = (RTDS_PARAM3); \
	((RTDS_Message_TE_TE_LS_Sum_data*)RTDS_msgData)->param4 = RTDS_PARAM4; \
	MACRO_NAME(Message_TE_TE_LS_Sum, sizeof(RTDS_Message_TE_TE_LS_Sum_data), RTDS_msgData); \
	}
#endif /* RTDS_MSG_SEND_Message_TE_TE_LS_Sum_TO_ENV defined */

/* MACRO FOR RECEPTION OF MESSAGE Message_TE_TE_LL_Ala */

#ifndef RTDS_MSG_RECEIVE_Message_TE_TE_LL_Ala
#define RTDS_MSG_RECEIVE_Message_TE_TE_LL_Ala(RTDS_PARAM1, RTDS_PARAM2, RTDS_PARAM3, RTDS_PARAM4, RTDS_PARAM5) \
	{ \
	RTDS_msgData = (unsigned char *)(RTDS_currentContext->currentMessage->pData); \
	if ( RTDS_msgData != NULL ) \
		{ \
		(RTDS_PARAM1) = (((RTDS_Message_TE_TE_LL_Ala_data*)RTDS_msgData)->param1); \
		(RTDS_PARAM2) = (((RTDS_Message_TE_TE_LL_Ala_data*)RTDS_msgData)->param2); \
		(RTDS_PARAM3) = (((RTDS_Message_TE_TE_LL_Ala_data*)RTDS_msgData)->param3); \
		RTDS_PARAM4 = ((RTDS_Message_TE_TE_LL_Ala_data*)RTDS_msgData)->param4; \
		(RTDS_PARAM5) = (((RTDS_Message_TE_TE_LL_Ala_data*)RTDS_msgData)->param5); \
		} \
	else \
		{ \
		RTDS_MSG_INPUT_ERROR; \
		} \
	}
#endif /* RTDS_MSG_RECEIVE_Message_TE_TE_LL_Ala defined */

/* MACRO FOR SENDING MESSAGE Message_TE_TE_LL_Ala TO A PROCESS NAME */

#ifndef RTDS_MSG_SEND_Message_TE_TE_LL_Ala_TO_NAME
#define RTDS_MSG_SEND_Message_TE_TE_LL_Ala_TO_NAME(RECEIVER, RECEIVER_NUMBER, RTDS_PARAM1, RTDS_PARAM2, RTDS_PARAM3, RTDS_PARAM4, RTDS_PARAM5) \
	{ \
	RTDS_msgData = (unsigned char *)new RTDS_Message_TE_TE_LL_Ala_data(); \
	(((RTDS_Message_TE_TE_LL_Ala_data*)RTDS_msgData)->param1) = (RTDS_PARAM1); \
	(((RTDS_Message_TE_TE_LL_Ala_data*)RTDS_msgData)->param2) = (RTDS_PARAM2); \
	(((RTDS_Message_TE_TE_LL_Ala_data*)RTDS_msgData)->param3) = (RTDS_PARAM3); \
	((RTDS_Message_TE_TE_LL_Ala_data*)RTDS_msgData)->param4 = RTDS_PARAM4; \
	(((RTDS_Message_TE_TE_LL_Ala_data*)RTDS_msgData)->param5) = (RTDS_PARAM5); \
	RTDS_MSG_QUEUE_SEND_TO_NAME(Message_TE_TE_LL_Ala, sizeof(RTDS_Message_TE_TE_LL_Ala_data), RTDS_msgData, RECEIVER, RECEIVER_NUMBER); \
	}
#endif /* RTDS_MSG_SEND_Message_TE_TE_LL_Ala_TO_NAME defined */

/* MACRO FOR SENDING MESSAGE Message_TE_TE_LL_Ala TO A PROCESS ID */

#ifndef RTDS_MSG_SEND_Message_TE_TE_LL_Ala_TO_ID
#define RTDS_MSG_SEND_Message_TE_TE_LL_Ala_TO_ID(RECEIVER, RTDS_PARAM1, RTDS_PARAM2, RTDS_PARAM3, RTDS_PARAM4, RTDS_PARAM5) \
	{ \
	RTDS_msgData = (unsigned char *)new RTDS_Message_TE_TE_LL_Ala_data(); \
	(((RTDS_Message_TE_TE_LL_Ala_data*)RTDS_msgData)->param1) = (RTDS_PARAM1); \
	(((RTDS_Message_TE_TE_LL_Ala_data*)RTDS_msgData)->param2) = (RTDS_PARAM2); \
	(((RTDS_Message_TE_TE_LL_Ala_data*)RTDS_msgData)->param3) = (RTDS_PARAM3); \
	((RTDS_Message_TE_TE_LL_Ala_data*)RTDS_msgData)->param4 = RTDS_PARAM4; \
	(((RTDS_Message_TE_TE_LL_Ala_data*)RTDS_msgData)->param5) = (RTDS_PARAM5); \
	RTDS_MSG_QUEUE_SEND_TO_ID(Message_TE_TE_LL_Ala, sizeof(RTDS_Message_TE_TE_LL_Ala_data), RTDS_msgData, RECEIVER); \
	}
#endif /* RTDS_MSG_SEND_Message_TE_TE_LL_Ala_TO_ID defined */

/* MACROS FOR SENDING MESSAGE Message_TE_TE_LL_Ala TO ENVIRONMENT */

#ifndef RTDS_MSG_SEND_Message_TE_TE_LL_Ala_TO_ENV
#define RTDS_MSG_SEND_Message_TE_TE_LL_Ala_TO_ENV(RTDS_PARAM1, RTDS_PARAM2, RTDS_PARAM3, RTDS_PARAM4, RTDS_PARAM5) \
	{ \
	RTDS_msgData = (unsigned char *)new RTDS_Message_TE_TE_LL_Ala_data(); \
	(((RTDS_Message_TE_TE_LL_Ala_data*)RTDS_msgData)->param1) = (RTDS_PARAM1); \
	(((RTDS_Message_TE_TE_LL_Ala_data*)RTDS_msgData)->param2) = (RTDS_PARAM2); \
	(((RTDS_Message_TE_TE_LL_Ala_data*)RTDS_msgData)->param3) = (RTDS_PARAM3); \
	((RTDS_Message_TE_TE_LL_Ala_data*)RTDS_msgData)->param4 = RTDS_PARAM4; \
	(((RTDS_Message_TE_TE_LL_Ala_data*)RTDS_msgData)->param5) = (RTDS_PARAM5); \
	RTDS_MSG_QUEUE_SEND_TO_ENV(Message_TE_TE_LL_Ala, sizeof(RTDS_Message_TE_TE_LL_Ala_data), RTDS_msgData); \
	}
#endif /* RTDS_MSG_SEND_Message_TE_TE_LL_Ala_TO_ENV defined */

#ifndef RTDS_MSG_SEND_Message_TE_TE_LL_Ala_TO_ENV_W_MACRO
#define RTDS_MSG_SEND_Message_TE_TE_LL_Ala_TO_ENV_W_MACRO(MACRO_NAME, RTDS_PARAM1, RTDS_PARAM2, RTDS_PARAM3, RTDS_PARAM4, RTDS_PARAM5) \
	{ \
	RTDS_msgData = (unsigned char *)new RTDS_Message_TE_TE_LL_Ala_data(); \
	(((RTDS_Message_TE_TE_LL_Ala_data*)RTDS_msgData)->param1) = (RTDS_PARAM1); \
	(((RTDS_Message_TE_TE_LL_Ala_data*)RTDS_msgData)->param2) = (RTDS_PARAM2); \
	(((RTDS_Message_TE_TE_LL_Ala_data*)RTDS_msgData)->param3) = (RTDS_PARAM3); \
	((RTDS_Message_TE_TE_LL_Ala_data*)RTDS_msgData)->param4 = RTDS_PARAM4; \
	(((RTDS_Message_TE_TE_LL_Ala_data*)RTDS_msgData)->param5) = (RTDS_PARAM5); \
	MACRO_NAME(Message_TE_TE_LL_Ala, sizeof(RTDS_Message_TE_TE_LL_Ala_data), RTDS_msgData); \
	}
#endif /* RTDS_MSG_SEND_Message_TE_TE_LL_Ala_TO_ENV defined */

/* MACRO FOR RECEPTION OF MESSAGE Message_TE_TE_LS_FA */

#ifndef RTDS_MSG_RECEIVE_Message_TE_TE_LS_FA
#define RTDS_MSG_RECEIVE_Message_TE_TE_LS_FA(RTDS_PARAM1, RTDS_PARAM2, RTDS_PARAM3, RTDS_PARAM4) \
	{ \
	RTDS_msgData = (unsigned char *)(RTDS_currentContext->currentMessage->pData); \
	if ( RTDS_msgData != NULL ) \
		{ \
		(RTDS_PARAM1) = (((RTDS_Message_TE_TE_LS_FA_data*)RTDS_msgData)->param1); \
		(RTDS_PARAM2) = (((RTDS_Message_TE_TE_LS_FA_data*)RTDS_msgData)->param2); \
		(RTDS_PARAM3) = (((RTDS_Message_TE_TE_LS_FA_data*)RTDS_msgData)->param3); \
		(RTDS_PARAM4) = (((RTDS_Message_TE_TE_LS_FA_data*)RTDS_msgData)->param4); \
		} \
	else \
		{ \
		RTDS_MSG_INPUT_ERROR; \
		} \
	}
#endif /* RTDS_MSG_RECEIVE_Message_TE_TE_LS_FA defined */

/* MACRO FOR SENDING MESSAGE Message_TE_TE_LS_FA TO A PROCESS NAME */

#ifndef RTDS_MSG_SEND_Message_TE_TE_LS_FA_TO_NAME
#define RTDS_MSG_SEND_Message_TE_TE_LS_FA_TO_NAME(RECEIVER, RECEIVER_NUMBER, RTDS_PARAM1, RTDS_PARAM2, RTDS_PARAM3, RTDS_PARAM4) \
	{ \
	RTDS_msgData = (unsigned char *)new RTDS_Message_TE_TE_LS_FA_data(); \
	(((RTDS_Message_TE_TE_LS_FA_data*)RTDS_msgData)->param1) = (RTDS_PARAM1); \
	(((RTDS_Message_TE_TE_LS_FA_data*)RTDS_msgData)->param2) = (RTDS_PARAM2); \
	(((RTDS_Message_TE_TE_LS_FA_data*)RTDS_msgData)->param3) = (RTDS_PARAM3); \
	(((RTDS_Message_TE_TE_LS_FA_data*)RTDS_msgData)->param4) = (RTDS_PARAM4); \
	RTDS_MSG_QUEUE_SEND_TO_NAME(Message_TE_TE_LS_FA, sizeof(RTDS_Message_TE_TE_LS_FA_data), RTDS_msgData, RECEIVER, RECEIVER_NUMBER); \
	}
#endif /* RTDS_MSG_SEND_Message_TE_TE_LS_FA_TO_NAME defined */

/* MACRO FOR SENDING MESSAGE Message_TE_TE_LS_FA TO A PROCESS ID */

#ifndef RTDS_MSG_SEND_Message_TE_TE_LS_FA_TO_ID
#define RTDS_MSG_SEND_Message_TE_TE_LS_FA_TO_ID(RECEIVER, RTDS_PARAM1, RTDS_PARAM2, RTDS_PARAM3, RTDS_PARAM4) \
	{ \
	RTDS_msgData = (unsigned char *)new RTDS_Message_TE_TE_LS_FA_data(); \
	(((RTDS_Message_TE_TE_LS_FA_data*)RTDS_msgData)->param1) = (RTDS_PARAM1); \
	(((RTDS_Message_TE_TE_LS_FA_data*)RTDS_msgData)->param2) = (RTDS_PARAM2); \
	(((RTDS_Message_TE_TE_LS_FA_data*)RTDS_msgData)->param3) = (RTDS_PARAM3); \
	(((RTDS_Message_TE_TE_LS_FA_data*)RTDS_msgData)->param4) = (RTDS_PARAM4); \
	RTDS_MSG_QUEUE_SEND_TO_ID(Message_TE_TE_LS_FA, sizeof(RTDS_Message_TE_TE_LS_FA_data), RTDS_msgData, RECEIVER); \
	}
#endif /* RTDS_MSG_SEND_Message_TE_TE_LS_FA_TO_ID defined */

/* MACROS FOR SENDING MESSAGE Message_TE_TE_LS_FA TO ENVIRONMENT */

#ifndef RTDS_MSG_SEND_Message_TE_TE_LS_FA_TO_ENV
#define RTDS_MSG_SEND_Message_TE_TE_LS_FA_TO_ENV(RTDS_PARAM1, RTDS_PARAM2, RTDS_PARAM3, RTDS_PARAM4) \
	{ \
	RTDS_msgData = (unsigned char *)new RTDS_Message_TE_TE_LS_FA_data(); \
	(((RTDS_Message_TE_TE_LS_FA_data*)RTDS_msgData)->param1) = (RTDS_PARAM1); \
	(((RTDS_Message_TE_TE_LS_FA_data*)RTDS_msgData)->param2) = (RTDS_PARAM2); \
	(((RTDS_Message_TE_TE_LS_FA_data*)RTDS_msgData)->param3) = (RTDS_PARAM3); \
	(((RTDS_Message_TE_TE_LS_FA_data*)RTDS_msgData)->param4) = (RTDS_PARAM4); \
	RTDS_MSG_QUEUE_SEND_TO_ENV(Message_TE_TE_LS_FA, sizeof(RTDS_Message_TE_TE_LS_FA_data), RTDS_msgData); \
	}
#endif /* RTDS_MSG_SEND_Message_TE_TE_LS_FA_TO_ENV defined */

#ifndef RTDS_MSG_SEND_Message_TE_TE_LS_FA_TO_ENV_W_MACRO
#define RTDS_MSG_SEND_Message_TE_TE_LS_FA_TO_ENV_W_MACRO(MACRO_NAME, RTDS_PARAM1, RTDS_PARAM2, RTDS_PARAM3, RTDS_PARAM4) \
	{ \
	RTDS_msgData = (unsigned char *)new RTDS_Message_TE_TE_LS_FA_data(); \
	(((RTDS_Message_TE_TE_LS_FA_data*)RTDS_msgData)->param1) = (RTDS_PARAM1); \
	(((RTDS_Message_TE_TE_LS_FA_data*)RTDS_msgData)->param2) = (RTDS_PARAM2); \
	(((RTDS_Message_TE_TE_LS_FA_data*)RTDS_msgData)->param3) = (RTDS_PARAM3); \
	(((RTDS_Message_TE_TE_LS_FA_data*)RTDS_msgData)->param4) = (RTDS_PARAM4); \
	MACRO_NAME(Message_TE_TE_LS_FA, sizeof(RTDS_Message_TE_TE_LS_FA_data), RTDS_msgData); \
	}
#endif /* RTDS_MSG_SEND_Message_TE_TE_LS_FA_TO_ENV defined */

/* MACRO FOR RECEPTION OF MESSAGE SN_LN_Idle */

#ifndef RTDS_MSG_RECEIVE_SN_LN_Idle
#define RTDS_MSG_RECEIVE_SN_LN_Idle(RTDS_PARAM1, RTDS_PARAM2, RTDS_PARAM3, RTDS_PARAM4, RTDS_PARAM5) \
	{ \
	RTDS_msgData = (unsigned char *)(RTDS_currentContext->currentMessage->pData); \
	if ( RTDS_msgData != NULL ) \
		{ \
		(RTDS_PARAM1) = (((RTDS_SN_LN_Idle_data*)RTDS_msgData)->param1); \
		(RTDS_PARAM2) = (((RTDS_SN_LN_Idle_data*)RTDS_msgData)->param2); \
		(RTDS_PARAM3) = (((RTDS_SN_LN_Idle_data*)RTDS_msgData)->param3); \
		RTDS_PARAM4 = ((RTDS_SN_LN_Idle_data*)RTDS_msgData)->param4; \
		RTDS_PARAM5 = ((RTDS_SN_LN_Idle_data*)RTDS_msgData)->param5; \
		} \
	else \
		{ \
		RTDS_MSG_INPUT_ERROR; \
		} \
	}
#endif /* RTDS_MSG_RECEIVE_SN_LN_Idle defined */

/* MACRO FOR SENDING MESSAGE SN_LN_Idle TO A PROCESS NAME */

#ifndef RTDS_MSG_SEND_SN_LN_Idle_TO_NAME
#define RTDS_MSG_SEND_SN_LN_Idle_TO_NAME(RECEIVER, RECEIVER_NUMBER, RTDS_PARAM1, RTDS_PARAM2, RTDS_PARAM3, RTDS_PARAM4, RTDS_PARAM5) \
	{ \
	RTDS_msgData = (unsigned char *)new RTDS_SN_LN_Idle_data(); \
	(((RTDS_SN_LN_Idle_data*)RTDS_msgData)->param1) = (RTDS_PARAM1); \
	(((RTDS_SN_LN_Idle_data*)RTDS_msgData)->param2) = (RTDS_PARAM2); \
	(((RTDS_SN_LN_Idle_data*)RTDS_msgData)->param3) = (RTDS_PARAM3); \
	((RTDS_SN_LN_Idle_data*)RTDS_msgData)->param4 = RTDS_PARAM4; \
	((RTDS_SN_LN_Idle_data*)RTDS_msgData)->param5 = RTDS_PARAM5; \
	RTDS_MSG_QUEUE_SEND_TO_NAME(SN_LN_Idle, sizeof(RTDS_SN_LN_Idle_data), RTDS_msgData, RECEIVER, RECEIVER_NUMBER); \
	}
#endif /* RTDS_MSG_SEND_SN_LN_Idle_TO_NAME defined */

/* MACRO FOR SENDING MESSAGE SN_LN_Idle TO A PROCESS ID */

#ifndef RTDS_MSG_SEND_SN_LN_Idle_TO_ID
#define RTDS_MSG_SEND_SN_LN_Idle_TO_ID(RECEIVER, RTDS_PARAM1, RTDS_PARAM2, RTDS_PARAM3, RTDS_PARAM4, RTDS_PARAM5) \
	{ \
	RTDS_msgData = (unsigned char *)new RTDS_SN_LN_Idle_data(); \
	(((RTDS_SN_LN_Idle_data*)RTDS_msgData)->param1) = (RTDS_PARAM1); \
	(((RTDS_SN_LN_Idle_data*)RTDS_msgData)->param2) = (RTDS_PARAM2); \
	(((RTDS_SN_LN_Idle_data*)RTDS_msgData)->param3) = (RTDS_PARAM3); \
	((RTDS_SN_LN_Idle_data*)RTDS_msgData)->param4 = RTDS_PARAM4; \
	((RTDS_SN_LN_Idle_data*)RTDS_msgData)->param5 = RTDS_PARAM5; \
	RTDS_MSG_QUEUE_SEND_TO_ID(SN_LN_Idle, sizeof(RTDS_SN_LN_Idle_data), RTDS_msgData, RECEIVER); \
	}
#endif /* RTDS_MSG_SEND_SN_LN_Idle_TO_ID defined */

/* MACROS FOR SENDING MESSAGE SN_LN_Idle TO ENVIRONMENT */

#ifndef RTDS_MSG_SEND_SN_LN_Idle_TO_ENV
#define RTDS_MSG_SEND_SN_LN_Idle_TO_ENV(RTDS_PARAM1, RTDS_PARAM2, RTDS_PARAM3, RTDS_PARAM4, RTDS_PARAM5) \
	{ \
	RTDS_msgData = (unsigned char *)new RTDS_SN_LN_Idle_data(); \
	(((RTDS_SN_LN_Idle_data*)RTDS_msgData)->param1) = (RTDS_PARAM1); \
	(((RTDS_SN_LN_Idle_data*)RTDS_msgData)->param2) = (RTDS_PARAM2); \
	(((RTDS_SN_LN_Idle_data*)RTDS_msgData)->param3) = (RTDS_PARAM3); \
	((RTDS_SN_LN_Idle_data*)RTDS_msgData)->param4 = RTDS_PARAM4; \
	((RTDS_SN_LN_Idle_data*)RTDS_msgData)->param5 = RTDS_PARAM5; \
	RTDS_MSG_QUEUE_SEND_TO_ENV(SN_LN_Idle, sizeof(RTDS_SN_LN_Idle_data), RTDS_msgData); \
	}
#endif /* RTDS_MSG_SEND_SN_LN_Idle_TO_ENV defined */

#ifndef RTDS_MSG_SEND_SN_LN_Idle_TO_ENV_W_MACRO
#define RTDS_MSG_SEND_SN_LN_Idle_TO_ENV_W_MACRO(MACRO_NAME, RTDS_PARAM1, RTDS_PARAM2, RTDS_PARAM3, RTDS_PARAM4, RTDS_PARAM5) \
	{ \
	RTDS_msgData = (unsigned char *)new RTDS_SN_LN_Idle_data(); \
	(((RTDS_SN_LN_Idle_data*)RTDS_msgData)->param1) = (RTDS_PARAM1); \
	(((RTDS_SN_LN_Idle_data*)RTDS_msgData)->param2) = (RTDS_PARAM2); \
	(((RTDS_SN_LN_Idle_data*)RTDS_msgData)->param3) = (RTDS_PARAM3); \
	((RTDS_SN_LN_Idle_data*)RTDS_msgData)->param4 = RTDS_PARAM4; \
	((RTDS_SN_LN_Idle_data*)RTDS_msgData)->param5 = RTDS_PARAM5; \
	MACRO_NAME(SN_LN_Idle, sizeof(RTDS_SN_LN_Idle_data), RTDS_msgData); \
	}
#endif /* RTDS_MSG_SEND_SN_LN_Idle_TO_ENV defined */

/* MACRO FOR RECEPTION OF MESSAGE SN_TN_HaveGroupId */

#ifndef RTDS_MSG_RECEIVE_SN_TN_HaveGroupId
#define RTDS_MSG_RECEIVE_SN_TN_HaveGroupId(RTDS_PARAM1, RTDS_PARAM2, RTDS_PARAM3, RTDS_PARAM4) \
	{ \
	RTDS_msgData = (unsigned char *)(RTDS_currentContext->currentMessage->pData); \
	if ( RTDS_msgData != NULL ) \
		{ \
		(RTDS_PARAM1) = (((RTDS_SN_TN_HaveGroupId_data*)RTDS_msgData)->param1); \
		(RTDS_PARAM2) = (((RTDS_SN_TN_HaveGroupId_data*)RTDS_msgData)->param2); \
		(RTDS_PARAM3) = (((RTDS_SN_TN_HaveGroupId_data*)RTDS_msgData)->param3); \
		RTDS_PARAM4 = ((RTDS_SN_TN_HaveGroupId_data*)RTDS_msgData)->param4; \
		} \
	else \
		{ \
		RTDS_MSG_INPUT_ERROR; \
		} \
	}
#endif /* RTDS_MSG_RECEIVE_SN_TN_HaveGroupId defined */

/* MACRO FOR SENDING MESSAGE SN_TN_HaveGroupId TO A PROCESS NAME */

#ifndef RTDS_MSG_SEND_SN_TN_HaveGroupId_TO_NAME
#define RTDS_MSG_SEND_SN_TN_HaveGroupId_TO_NAME(RECEIVER, RECEIVER_NUMBER, RTDS_PARAM1, RTDS_PARAM2, RTDS_PARAM3, RTDS_PARAM4) \
	{ \
	RTDS_msgData = (unsigned char *)new RTDS_SN_TN_HaveGroupId_data(); \
	(((RTDS_SN_TN_HaveGroupId_data*)RTDS_msgData)->param1) = (RTDS_PARAM1); \
	(((RTDS_SN_TN_HaveGroupId_data*)RTDS_msgData)->param2) = (RTDS_PARAM2); \
	(((RTDS_SN_TN_HaveGroupId_data*)RTDS_msgData)->param3) = (RTDS_PARAM3); \
	((RTDS_SN_TN_HaveGroupId_data*)RTDS_msgData)->param4 = RTDS_PARAM4; \
	RTDS_MSG_QUEUE_SEND_TO_NAME(SN_TN_HaveGroupId, sizeof(RTDS_SN_TN_HaveGroupId_data), RTDS_msgData, RECEIVER, RECEIVER_NUMBER); \
	}
#endif /* RTDS_MSG_SEND_SN_TN_HaveGroupId_TO_NAME defined */

/* MACRO FOR SENDING MESSAGE SN_TN_HaveGroupId TO A PROCESS ID */

#ifndef RTDS_MSG_SEND_SN_TN_HaveGroupId_TO_ID
#define RTDS_MSG_SEND_SN_TN_HaveGroupId_TO_ID(RECEIVER, RTDS_PARAM1, RTDS_PARAM2, RTDS_PARAM3, RTDS_PARAM4) \
	{ \
	RTDS_msgData = (unsigned char *)new RTDS_SN_TN_HaveGroupId_data(); \
	(((RTDS_SN_TN_HaveGroupId_data*)RTDS_msgData)->param1) = (RTDS_PARAM1); \
	(((RTDS_SN_TN_HaveGroupId_data*)RTDS_msgData)->param2) = (RTDS_PARAM2); \
	(((RTDS_SN_TN_HaveGroupId_data*)RTDS_msgData)->param3) = (RTDS_PARAM3); \
	((RTDS_SN_TN_HaveGroupId_data*)RTDS_msgData)->param4 = RTDS_PARAM4; \
	RTDS_MSG_QUEUE_SEND_TO_ID(SN_TN_HaveGroupId, sizeof(RTDS_SN_TN_HaveGroupId_data), RTDS_msgData, RECEIVER); \
	}
#endif /* RTDS_MSG_SEND_SN_TN_HaveGroupId_TO_ID defined */

/* MACROS FOR SENDING MESSAGE SN_TN_HaveGroupId TO ENVIRONMENT */

#ifndef RTDS_MSG_SEND_SN_TN_HaveGroupId_TO_ENV
#define RTDS_MSG_SEND_SN_TN_HaveGroupId_TO_ENV(RTDS_PARAM1, RTDS_PARAM2, RTDS_PARAM3, RTDS_PARAM4) \
	{ \
	RTDS_msgData = (unsigned char *)new RTDS_SN_TN_HaveGroupId_data(); \
	(((RTDS_SN_TN_HaveGroupId_data*)RTDS_msgData)->param1) = (RTDS_PARAM1); \
	(((RTDS_SN_TN_HaveGroupId_data*)RTDS_msgData)->param2) = (RTDS_PARAM2); \
	(((RTDS_SN_TN_HaveGroupId_data*)RTDS_msgData)->param3) = (RTDS_PARAM3); \
	((RTDS_SN_TN_HaveGroupId_data*)RTDS_msgData)->param4 = RTDS_PARAM4; \
	RTDS_MSG_QUEUE_SEND_TO_ENV(SN_TN_HaveGroupId, sizeof(RTDS_SN_TN_HaveGroupId_data), RTDS_msgData); \
	}
#endif /* RTDS_MSG_SEND_SN_TN_HaveGroupId_TO_ENV defined */

#ifndef RTDS_MSG_SEND_SN_TN_HaveGroupId_TO_ENV_W_MACRO
#define RTDS_MSG_SEND_SN_TN_HaveGroupId_TO_ENV_W_MACRO(MACRO_NAME, RTDS_PARAM1, RTDS_PARAM2, RTDS_PARAM3, RTDS_PARAM4) \
	{ \
	RTDS_msgData = (unsigned char *)new RTDS_SN_TN_HaveGroupId_data(); \
	(((RTDS_SN_TN_HaveGroupId_data*)RTDS_msgData)->param1) = (RTDS_PARAM1); \
	(((RTDS_SN_TN_HaveGroupId_data*)RTDS_msgData)->param2) = (RTDS_PARAM2); \
	(((RTDS_SN_TN_HaveGroupId_data*)RTDS_msgData)->param3) = (RTDS_PARAM3); \
	((RTDS_SN_TN_HaveGroupId_data*)RTDS_msgData)->param4 = RTDS_PARAM4; \
	MACRO_NAME(SN_TN_HaveGroupId, sizeof(RTDS_SN_TN_HaveGroupId_data), RTDS_msgData); \
	}
#endif /* RTDS_MSG_SEND_SN_TN_HaveGroupId_TO_ENV defined */

/* MACRO FOR RECEPTION OF MESSAGE TN_SN_StopMessageLogging */

#ifndef RTDS_MSG_RECEIVE_TN_SN_StopMessageLogging
#define RTDS_MSG_RECEIVE_TN_SN_StopMessageLogging(RTDS_PARAM1, RTDS_PARAM2, RTDS_PARAM3) \
	{ \
	RTDS_msgData = (unsigned char *)(RTDS_currentContext->currentMessage->pData); \
	if ( RTDS_msgData != NULL ) \
		{ \
		(RTDS_PARAM1) = (((RTDS_TN_SN_StopMessageLogging_data*)RTDS_msgData)->param1); \
		(RTDS_PARAM2) = (((RTDS_TN_SN_StopMessageLogging_data*)RTDS_msgData)->param2); \
		(RTDS_PARAM3) = (((RTDS_TN_SN_StopMessageLogging_data*)RTDS_msgData)->param3); \
		} \
	else \
		{ \
		RTDS_MSG_INPUT_ERROR; \
		} \
	}
#endif /* RTDS_MSG_RECEIVE_TN_SN_StopMessageLogging defined */

/* MACRO FOR SENDING MESSAGE TN_SN_StopMessageLogging TO A PROCESS NAME */

#ifndef RTDS_MSG_SEND_TN_SN_StopMessageLogging_TO_NAME
#define RTDS_MSG_SEND_TN_SN_StopMessageLogging_TO_NAME(RECEIVER, RECEIVER_NUMBER, RTDS_PARAM1, RTDS_PARAM2, RTDS_PARAM3) \
	{ \
	RTDS_msgData = (unsigned char *)new RTDS_TN_SN_StopMessageLogging_data(); \
	(((RTDS_TN_SN_StopMessageLogging_data*)RTDS_msgData)->param1) = (RTDS_PARAM1); \
	(((RTDS_TN_SN_StopMessageLogging_data*)RTDS_msgData)->param2) = (RTDS_PARAM2); \
	(((RTDS_TN_SN_StopMessageLogging_data*)RTDS_msgData)->param3) = (RTDS_PARAM3); \
	RTDS_MSG_QUEUE_SEND_TO_NAME(TN_SN_StopMessageLogging, sizeof(RTDS_TN_SN_StopMessageLogging_data), RTDS_msgData, RECEIVER, RECEIVER_NUMBER); \
	}
#endif /* RTDS_MSG_SEND_TN_SN_StopMessageLogging_TO_NAME defined */

/* MACRO FOR SENDING MESSAGE TN_SN_StopMessageLogging TO A PROCESS ID */

#ifndef RTDS_MSG_SEND_TN_SN_StopMessageLogging_TO_ID
#define RTDS_MSG_SEND_TN_SN_StopMessageLogging_TO_ID(RECEIVER, RTDS_PARAM1, RTDS_PARAM2, RTDS_PARAM3) \
	{ \
	RTDS_msgData = (unsigned char *)new RTDS_TN_SN_StopMessageLogging_data(); \
	(((RTDS_TN_SN_StopMessageLogging_data*)RTDS_msgData)->param1) = (RTDS_PARAM1); \
	(((RTDS_TN_SN_StopMessageLogging_data*)RTDS_msgData)->param2) = (RTDS_PARAM2); \
	(((RTDS_TN_SN_StopMessageLogging_data*)RTDS_msgData)->param3) = (RTDS_PARAM3); \
	RTDS_MSG_QUEUE_SEND_TO_ID(TN_SN_StopMessageLogging, sizeof(RTDS_TN_SN_StopMessageLogging_data), RTDS_msgData, RECEIVER); \
	}
#endif /* RTDS_MSG_SEND_TN_SN_StopMessageLogging_TO_ID defined */

/* MACROS FOR SENDING MESSAGE TN_SN_StopMessageLogging TO ENVIRONMENT */

#ifndef RTDS_MSG_SEND_TN_SN_StopMessageLogging_TO_ENV
#define RTDS_MSG_SEND_TN_SN_StopMessageLogging_TO_ENV(RTDS_PARAM1, RTDS_PARAM2, RTDS_PARAM3) \
	{ \
	RTDS_msgData = (unsigned char *)new RTDS_TN_SN_StopMessageLogging_data(); \
	(((RTDS_TN_SN_StopMessageLogging_data*)RTDS_msgData)->param1) = (RTDS_PARAM1); \
	(((RTDS_TN_SN_StopMessageLogging_data*)RTDS_msgData)->param2) = (RTDS_PARAM2); \
	(((RTDS_TN_SN_StopMessageLogging_data*)RTDS_msgData)->param3) = (RTDS_PARAM3); \
	RTDS_MSG_QUEUE_SEND_TO_ENV(TN_SN_StopMessageLogging, sizeof(RTDS_TN_SN_StopMessageLogging_data), RTDS_msgData); \
	}
#endif /* RTDS_MSG_SEND_TN_SN_StopMessageLogging_TO_ENV defined */

#ifndef RTDS_MSG_SEND_TN_SN_StopMessageLogging_TO_ENV_W_MACRO
#define RTDS_MSG_SEND_TN_SN_StopMessageLogging_TO_ENV_W_MACRO(MACRO_NAME, RTDS_PARAM1, RTDS_PARAM2, RTDS_PARAM3) \
	{ \
	RTDS_msgData = (unsigned char *)new RTDS_TN_SN_StopMessageLogging_data(); \
	(((RTDS_TN_SN_StopMessageLogging_data*)RTDS_msgData)->param1) = (RTDS_PARAM1); \
	(((RTDS_TN_SN_StopMessageLogging_data*)RTDS_msgData)->param2) = (RTDS_PARAM2); \
	(((RTDS_TN_SN_StopMessageLogging_data*)RTDS_msgData)->param3) = (RTDS_PARAM3); \
	MACRO_NAME(TN_SN_StopMessageLogging, sizeof(RTDS_TN_SN_StopMessageLogging_data), RTDS_msgData); \
	}
#endif /* RTDS_MSG_SEND_TN_SN_StopMessageLogging_TO_ENV defined */



#endif /* defined(_RTDS_MESSAGES_H_) */

