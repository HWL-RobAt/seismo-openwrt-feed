/*SX*/
/**
 * @file te_receiver.h
 * @date Aug 17, 2008
 * @author Ronald Kluth
 *
 * @brief Declaration of class te_receiver, part of `boost_substitute`
 */

#ifndef TE_RECEIVER_H_INCLUDED
#define TE_RECEIVER_H_INCLUDED

#include "common.h"
#include "message.h"
#include "network_stack.h"
#include "RTDS_SDLPROCESS.h"

#include "PA_APGeneralProtocol.h"
#include "PA_APEWProtocol.h"
#include "PA_APManagingProtocol.h"

#include "XMLStreamingLogger.h"

class te_receiver: public RTDS::SDLProcess {
public:
    RTDS::MessageQueueT<Message*> networkQueue;

    te_receiver(RTDS::Logger& l)
    :	SDLProcess( l ),
        networkQueue()
    {
	logger.logProcessCreation(msgQueue.writer, "te_receiver", 0);
    }

    virtual int main();

    void SDLSend( Message* msg );

    void decodeAPEWProtocol( AP_GeneralProtocol::TYPE_APEWProtocol& msg, IPAddress& sender );
    void decodeAPManagingProtocol( AP_GeneralProtocol::TYPE_APManagingProtocol& msg, IPAddress& sender);

};

#endif
