/*SX*/
#ifndef BLOCK_TE_H_INCLUDED
#define BLOCK_TE_H_INCLUDED

#include <boost/asio.hpp>

#include "define.h"
#include "RTDS_SDLBLOCK.h"
#include "RTDS_gen.h"
//#include "blockClass_Node.h"

#include "network_stack.h" // is in ../boost_src
#include "te_sender.h"
#include "te_receiver.h"

#include "XMLStreamingLogger.h"

struct block_te : public RTDS::SDLBlock
{
public:
  te_receiver receiver;
  NetworkStack stack;
  te_sender sender;


  block_te(RTDS::Logger& logger)
  :   RTDS::SDLBlock(logger),
	  receiver(logger),
      stack(RTDS::SDLProcess::ioService, *receiver.networkQueue.writer, SEND_PORT, RECEIVE_PORT),
      sender(stack, logger)
  {
    embed(sender, RTDS_process_te_sender);
    embed(receiver, RTDS_process_te_receiver);
//	  embed(sender, 98);
//	  embed(receiver, 99);

  }

  void activate()
  {
	  sender.activate();
	  receiver.activate();
  }
};

#endif
