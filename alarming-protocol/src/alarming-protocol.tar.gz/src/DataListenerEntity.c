/*SX*//** @file
 *  Generated file, find templates in SX folders
 */
#include <boost/thread/thread.hpp>
#include <boost/bind.hpp>

#include "RTDS_gen.h"
#include "DataListenerEntity.h"
#include "RTDS_messages.h"

#define RTDS_PROCESS_NUMBER RTDS_process_DataListenerEntity
#define RTDS_PROCESS_NAME DataListenerEntity

/*
** PROCESS DataListenerEntity:
** ---------------------------
*/

DataListenerEntity::DataListenerEntity(RTDS::Logger& logger)
: SDLProcess(logger)
{
    RTDS_LOG_PROCESS_CREATION(msgQueue.writer, "DataListenerEntity", cover);
}

int DataListenerEntity::main()
{
    short RTDS_transitionExecuted;
  int RTDS_savedSdlState = 0;

  tSensorData sensorData;

  #ifdef BOOST
  DataListener dl(pipeName);
  #endif
  RTDS_MSG_DATA_DECL

  // silence warning; this variable is not usually used
  RTDS_savedSdlState += 0;

  /* starts stdio.run() asynchronous stops when isRunnings destructor is destroyed */
  boost::thread _workThread_t(boost::bind(&boost::asio::io_service::run, &ioService));
  std::auto_ptr<boost::asio::io_service::work> _workThread_ptr(isRunning);
  isRunning = 0;

  /* declare framework-side variables for the process */

  /* Initial transition */
  // {{{ action
  #ifdef BOOST
  while (true) {
  //LOGS(DLE, "waiting for packet");
  RSDPSensorPacket sp = dl.getNextSP();
  //LOGS(DLE, "received packet. sending now.");
  sensorData.timeindex = sp.timestamp;
  sensorData.northsouth = sp.chan1;
  sensorData.eastwest = sp.chan2;
  sensorData.z = sp.chan3;
  RTDS_MSG_SEND_nextRecord_TO_NAME("SignalAnalysingEntity", RTDS_process_SignalAnalysingEntity,   sensorData);
  }
#endif

#ifdef ODEMX
//do nothing MSDP_Event.h will do all the work
sleep();
#endif

///////////////////// Normally, you will not get here
// }}} action
RTDS_MSG_SEND_nextRecord_TO_NAME("SignalAnalysingEntity", RTDS_process_SignalAnalysingEntity, sensorData);
RTDS_PROCESS_KILL;
// odemx/bricks/RTDS_Proc_loopStart
while (true) {
// loop start ends
/* peek new message from queue */
currentMessage = msgQRead();
RTDS_LOG_MESSAGE_RECEIVE(&currentMessage->sender, msgQueue.writer,
currentMessage->sequenceNumber, getCurrentTime());
/* Double switch state / signal */
RTDS_transitionExecuted = 1;
switch(RTDS_currentContext->sdlState)
  {
  default:
    RTDS_transitionExecuted = 0;
    break;
  } /* End of switch(RTDS_currentContext->sdlState) */
// odemx/bricks/RTDS_Proc_end
delete currentMessage;
}; // end of while(true)
// no return here, since this brick does not know the return type
// end ends
}

/* private methods */
