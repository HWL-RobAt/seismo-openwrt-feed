/*SX*/
/**
 * @file
 * @date Aug 17, 2008
 * @author Ronald Kluth
 *
 * @brief Definition of te_receiver functions.
 * This file is part of `boost_substitute`.
 */

#include "te_receiver.h"
#include "RTDS_gen.h"
#include "RTDS_messages.h"

#include <iostream>
#include <memory>
#include <boost/thread/thread.hpp>
#include <boost/bind.hpp>

using namespace AP_GeneralProtocol;

int te_receiver::main() {
    /* starts stdio.run() asynchronous stops when isRunnings destructor is destroyed
     * FIXME: This comment is incomprehensible.
     */
    boost::thread _workThread_t(boost::bind(&boost::asio::io_service::run, &ioService));
    std::auto_ptr<boost::asio::io_service::work> _workThread_ptr(isRunning);
    isRunning = 0;

    while (true) {
//	std::cout << "attempting to read message" << std::endl;
	Message* msg = networkQueue.reader->get();
//	std::cout << "received message" << std::endl;
	try {
	    SDLSend(msg);
	} catch (...) {
	    std::cerr << "FATAL ERROR while decoding received ASN.1 message" << std::endl;
	}
    }
    return 0;
}

void te_receiver::decodeAPEWProtocol(TYPE_APEWProtocol& decodedMessage_mAPEWProtocol,
	IPAddress& sender) {
    void* RTDS_msgData = 0;

    switch (decodedMessage_mAPEWProtocol.present()) {
    case AP_GeneralProtocol::TYPE_APEWProtocol::CHOICE_mSN_LN_Idle: {
	std::cout << "SN_LN_Idle" << std::endl;
	TYPE_SN_LN_Idle decodedMessage_mSN_LN_Idle = decodedMessage_mAPEWProtocol.VAR_mSN_LN_Idle();

	tDateTime gpsTimeStamp(decodedMessage_mSN_LN_Idle.VAR_gpsTimeStamp());
	tSensorAccelerationAverage noiseAverage(decodedMessage_mSN_LN_Idle.VAR_noiseAverage());
	double batteryVoltage = -1;
	if (decodedMessage_mSN_LN_Idle.batteryVoltagePresent()) {
	    batteryVoltage = decodedMessage_mSN_LN_Idle.VAR_batteryVoltage();
	}
	double valueFourthChannel = 0;
	if (decodedMessage_mSN_LN_Idle.valueFourthChannelPresent()) {
	    valueFourthChannel = decodedMessage_mSN_LN_Idle.VAR_valueFourthChannel();
	}

	RTDS_MSG_SEND_SN_LN_Idle_TO_NAME(
		"LE",
		RTDS_process_LeadingEntity,
		sender,
		gpsTimeStamp,
		noiseAverage,
		batteryVoltage,
		valueFourthChannel );
	break;
    }
    case AP_GeneralProtocol::TYPE_APEWProtocol::CHOICE_mSN_LN_Detection: {
	std::cout << "SN_LN_Detection" << std::endl;
	TYPE_SN_LN_Detection decodedMessage_mSN_LN_Detection =
		decodedMessage_mAPEWProtocol.VAR_mSN_LN_Detection();

	tDateTime gpsTimeStamp(decodedMessage_mSN_LN_Detection.VAR_gpsTimeStamp());

	tDateTime tp(decodedMessage_mSN_LN_Detection.VAR_tp());

	tSensorAcceleration a_max(decodedMessage_mSN_LN_Detection.VAR_a_max());

	tSensorVelocity v_max(decodedMessage_mSN_LN_Detection.VAR_v_max());

	tSensorDisplacement d_max(decodedMessage_mSN_LN_Detection.VAR_d_max());

	tSensorAccelerationAverage noiseAverage(decodedMessage_mSN_LN_Detection.VAR_noiseAverage());

	double valueFourthChannel = 0;
	if (decodedMessage_mSN_LN_Detection.valueFourthChannelPresent())
	    valueFourthChannel = decodedMessage_mSN_LN_Detection.VAR_valueFourthChannel();

	double sta_lta_TriggerValue = decodedMessage_mSN_LN_Detection.VAR_sta_lta_TriggerValue();

	RTDS_MSG_SEND_SN_LN_Detection_TO_NAME(
		"LE",
		RTDS_process_LeadingEntity,
		sender,
		gpsTimeStamp,
		tp,
		a_max,
		v_max,
		d_max,
		noiseAverage,
		valueFourthChannel,
		sta_lta_TriggerValue);
	break;
    }
    case AP_GeneralProtocol::TYPE_APEWProtocol::CHOICE_mSN_LN_Description: {
	std::cout << "SN_LN_Description" << std::endl;
	TYPE_SN_LN_Description decodedMessage_mSN_LN_Description =
		decodedMessage_mAPEWProtocol.VAR_mSN_LN_Description();

	tDateTime param2(decodedMessage_mSN_LN_Description.VAR_gpsTimeStamp());

	tDateTime param3(decodedMessage_mSN_LN_Description.VAR_tp());

	tWaveType param4;
	if (decodedMessage_mSN_LN_Description.VAR_waveType()
		== TYPE_APEWProtocol_GEN_8::LIT_pWave()) {
	    param4 = PWave;
	} else if (decodedMessage_mSN_LN_Description.VAR_waveType()
		== TYPE_APEWProtocol_GEN_8::LIT_sWave()) {
	    param4 = SWave;
	} else {
	    std::cerr << "SN_LN_Description: decoded incorrect waveType" << std::endl;
	}

	tSensorAcceleration param5(decodedMessage_mSN_LN_Description.VAR_pga());

	tSensorVelocity param6(decodedMessage_mSN_LN_Description.VAR_pgv());

	tSensorDisplacement param7(decodedMessage_mSN_LN_Description.VAR_pgd());

	tSensorAccelerationAverage param8(decodedMessage_mSN_LN_Description.VAR_noiseAverage());

	double param9 = 0;
	if (decodedMessage_mSN_LN_Description.predominantPeriodPresent()) {
	    param9 = decodedMessage_mSN_LN_Description.VAR_predominantPeriod();
	}

	double param10 = decodedMessage_mSN_LN_Description.VAR_cav();

	double param11 = decodedMessage_mSN_LN_Description.VAR_ariasIntensity();

	double param12 = 0;
	if (decodedMessage_mSN_LN_Description.valueFourthChannelPresent())
	    param12 = decodedMessage_mSN_LN_Description.VAR_valueFourthChannel();

	RTDS_MSG_SEND_SN_LN_Description_TO_NAME(
		"LE",
		RTDS_process_LeadingEntity,
		sender,
		param2,
		param3,
		param4,
		param5,
		param6,
		param7,
		param8,
		param9,
		param10,
		param11,
		param12);
	break;
    }
    case AP_GeneralProtocol::TYPE_APEWProtocol::CHOICE_mSN_LN_Summary: {
	std::cout << "SN_LN_Summary" << std::endl;
	TYPE_SN_LN_Summary decodedMessage_mSN_LN_Summary =
		decodedMessage_mAPEWProtocol.VAR_mSN_LN_Summary();

	tDateTime param2(decodedMessage_mSN_LN_Summary.VAR_gpsTimeStamp());

	tDateTime param3(decodedMessage_mSN_LN_Summary.VAR_t_p());

	tDateTime param4(decodedMessage_mSN_LN_Summary.VAR_t_s());

	tDateTime param5(decodedMessage_mSN_LN_Summary.VAR_t_end());

	tSensorAcceleration param6(decodedMessage_mSN_LN_Summary.VAR_pga());

	tSensorVelocity param7(decodedMessage_mSN_LN_Summary.VAR_pgv());

	tSensorDisplacement param8(decodedMessage_mSN_LN_Summary.VAR_pgd());

	tSensorAccelerationAverage param9(decodedMessage_mSN_LN_Summary.VAR_noiseAverage());

	double param10 = decodedMessage_mSN_LN_Summary.VAR_cav();

	double param11 = decodedMessage_mSN_LN_Summary.VAR_ariasIntensity();

	double param12 = 0;
	if (decodedMessage_mSN_LN_Summary.valueFourthChannelPresent())
	    param12 = decodedMessage_mSN_LN_Summary.VAR_valueFourthChannel();

	double param13 = 0;
	if (decodedMessage_mSN_LN_Summary.batteryVoltagePresent())
	    param13 = decodedMessage_mSN_LN_Summary.VAR_batteryVoltage();

	RTDS_MSG_SEND_SN_LN_Summary_TO_NAME(
		"LE",
		RTDS_process_LeadingEntity,
		sender,
		param2,
		param3,
		param4,
		param5,
		param6,
		param7,
		param8,
		param9,
		param10,
		param11,
		param12,
		param13);
	break;
    }
    case AP_GeneralProtocol::TYPE_APEWProtocol::CHOICE_mSN_LN_PositionChange: {
	std::cout << "SN_LN_PositionChange" << std::endl;
	TYPE_SN_LN_PositionChange decodedMessage_mSN_LN_PositionChange =
		decodedMessage_mAPEWProtocol.VAR_mSN_LN_PositionChange();

	tDateTime param2(decodedMessage_mSN_LN_PositionChange.VAR_gpsTimeStamp());

	tGeographicCoordinate param3(decodedMessage_mSN_LN_PositionChange.VAR_oldCoordinate());

	tGeographicCoordinate param4(decodedMessage_mSN_LN_PositionChange.VAR_newCoordinate());

	RTDS_MSG_SEND_SN_LN_PositionChange_TO_NAME(
		"LE",
		RTDS_process_LeadingEntity,
		sender,
		param2,
		param3,
		param4);
	break;
    }
    case AP_GeneralProtocol::TYPE_APEWProtocol::CHOICE_mLN_SN_FalseAlarm: {
	std::cout << "LN_SN_FalseAlarm" << std::endl;
	TYPE_LN_SN_FalseAlarm decodedMessage_mLN_SN_FalseAlarm =
		decodedMessage_mAPEWProtocol.VAR_mLN_SN_FalseAlarm();

	tDateTime param2(decodedMessage_mLN_SN_FalseAlarm.VAR_gpsTimeStamp());

	tDateTime param3(decodedMessage_mLN_SN_FalseAlarm.VAR_timeOfFalseAlarm());

	RTDS_MSG_SEND_LN_SN_FalseAlarm_TO_NAME(
		"SE",
		RTDS_process_SensingEntity,
		sender,
		param2,
		param3);
	break;
    }
    case AP_GeneralProtocol::TYPE_APEWProtocol::CHOICE_mLN_SN_Describe: {
	std::cout << "LN_SN_Describe" << std::endl;
	TYPE_LN_SN_Describe decodedMessage_mLN_SN_Describe =
		decodedMessage_mAPEWProtocol.VAR_mLN_SN_Describe();

	tDateTime param2(decodedMessage_mLN_SN_Describe.VAR_gpsTimeStamp());

	EventID param3 = 0;
	if (decodedMessage_mLN_SN_Describe.eventPresent()) {
	    param3 = decodedMessage_mLN_SN_Describe.VAR_event();
	}

	RTDS_MSG_SEND_LN_SN_Describe_TO_NAME(
		"SE",
		RTDS_process_SensingEntity,
		sender,
		param2,
		param3);
	break;
    }
    case AP_GeneralProtocol::TYPE_APEWProtocol::CHOICE_mLN_SN_Summarise: {
	std::cout << "LN_SN_Summarise" << std::endl;
	TYPE_LN_SN_Summarise decodedMessage_mLN_SN_Summarise =
		decodedMessage_mAPEWProtocol.VAR_mLN_SN_Summarise();

	tDateTime param2(decodedMessage_mLN_SN_Summarise.VAR_gpsTimeStamp());

	EventID param3;
	if (decodedMessage_mLN_SN_Summarise.eventPresent()) {
	    param3 = decodedMessage_mLN_SN_Summarise.VAR_event();
	}

	RTDS_MSG_SEND_LN_SN_Summarise_TO_NAME(
		"SE",
		RTDS_process_SensingEntity,
		sender,
		param2,
		param3);
	break;
    }
    case AP_GeneralProtocol::TYPE_APEWProtocol::CHOICE_mLN_LN_Idle: {
	std::cout << "LN_LN_Idle" << std::endl;
	TYPE_LN_LN_Idle decodedMessage_mLN_LN_Idle = decodedMessage_mAPEWProtocol.VAR_mLN_LN_Idle();

	tDateTime param2(decodedMessage_mLN_LN_Idle.VAR_gpsTimeStamp());

	TYPE_APEWProtocol_GEN_10 ASN1operativeSNs = decodedMessage_mLN_LN_Idle.VAR_operativeSNs();
	ip_vec param3;

	for (int i = 1; i <= ASN1operativeSNs.lengthAsLong(); ++i) {
	    param3.push_back((const char*) ASN1operativeSNs(i));
	}

	TYPE_APEWProtocol_GEN_11 ASN1inoperativeSNs =
		decodedMessage_mLN_LN_Idle.VAR_inoperativeSNs();
	inop_vec param4;

	for (int i = 1; i <= ASN1inoperativeSNs.lengthAsLong(); ++i)
	    param4.push_back((TYPE_InoperativeSNInfo) ASN1inoperativeSNs(i));

	tSensorAccelerationAverage param5(decodedMessage_mLN_LN_Idle.VAR_noiseAverage());

	RTDS_MSG_SEND_LN_LN_Idle_TO_NAME(
		"LE",
		RTDS_process_LeadingEntity,
		sender,
		param2,
		param3,
		param4,
		param5);
	break;
    }
    case AP_GeneralProtocol::TYPE_APEWProtocol::CHOICE_mLN_LN_Detection: {
	std::cout << "LN_LN_Detection" << std::endl;
	TYPE_LN_LN_Detection decodedMessage_mLN_LN_Detection =
		decodedMessage_mAPEWProtocol.VAR_mLN_LN_Detection();

	tDateTime param2(decodedMessage_mLN_LN_Detection.VAR_gpsTimeStamp());

	EventID param3 = decodedMessage_mLN_LN_Detection.VAR_event();

	TYPE_APEWProtocol_GEN_12 ASN1triggeredSNs =
		decodedMessage_mLN_LN_Detection.VAR_triggeredSNs();
	trig_vec param4;

	for (int j = 1; j <= ASN1triggeredSNs.lengthAsLong(); ++j)
	    param4.push_back((TYPE_TriggeredSNInfo) ASN1triggeredSNs(j));

	TYPE_APEWProtocol_GEN_13 ASN1inoperativeSNs =
		decodedMessage_mLN_LN_Detection.VAR_inoperativeSNs();
	inop_vec param5;

	for (int i = 1; i <= ASN1inoperativeSNs.lengthAsLong(); ++i)
	    param5.push_back((TYPE_InoperativeSNInfo) ASN1inoperativeSNs(i));

	tSensorAccelerationAverage param6(
		decodedMessage_mLN_LN_Detection.VAR_noiseAveragePreEvent());

	RTDS_MSG_SEND_LN_LN_Detection_TO_NAME(
		"LE",
		RTDS_process_LeadingEntity,
		sender,
		param2,
		param3,
		param4,
		param5,
		param6);
	break;
    }
    case AP_GeneralProtocol::TYPE_APEWProtocol::CHOICE_mLN_LN_Alarm: {
	std::cout << "LN_LN_Alarm" << std::endl;
	TYPE_LN_LN_Alarm decodedMessage_mLN_LN_Alarm =
		decodedMessage_mAPEWProtocol.VAR_mLN_LN_Alarm();

	tDateTime param2(decodedMessage_mLN_LN_Alarm.VAR_gpsTimeStamp());

	EventID param3 = decodedMessage_mLN_LN_Alarm.VAR_event();

	TYPE_APEWProtocol_GEN_14 ASN1decisionMakingSNs =
		decodedMessage_mLN_LN_Alarm.VAR_decisionMakingSNs();
	trig_vec param4;

	for (int i = 1; i <= ASN1decisionMakingSNs.lengthAsLong(); ++i)
	    param4.push_back((TYPE_TriggeredSNInfo) ASN1decisionMakingSNs(i));

	RTDS_MSG_SEND_LN_LN_Alarm_TO_NAME(
		"LE",
		RTDS_process_LeadingEntity,
		sender,
		param2,
		param3,
		param4);
	break;
    }
    case AP_GeneralProtocol::TYPE_APEWProtocol::CHOICE_mLN_LN_Description: {
	std::cout << "LN_LN_Description" << std::endl;
	TYPE_LN_LN_Description decodedMessage_mLN_LN_Description =
		decodedMessage_mAPEWProtocol.VAR_mLN_LN_Description();

	tDateTime param2(decodedMessage_mLN_LN_Description.VAR_gpsTimeStamp());

	EventID param3 = 0;
	if (decodedMessage_mLN_LN_Description.eventPresent()) {
	    param3 = decodedMessage_mLN_LN_Description.VAR_event();
	}

	RTDS_MSG_SEND_LN_LN_Description_TO_NAME(
		"LE",
		RTDS_process_LeadingEntity,
		sender,
		param2,
		param3);
	break;
    }
    case AP_GeneralProtocol::TYPE_APEWProtocol::CHOICE_mLN_EN_Alarm: {
	std::cout << "LN_EN_Alarm" << std::endl;
	TYPE_LN_EN_Alarm decodedMessage_mLN_EN_Alarm =
		decodedMessage_mAPEWProtocol.VAR_mLN_EN_Alarm();

	tDateTime param2(decodedMessage_mLN_EN_Alarm.VAR_gpsTimeStamp());

	EventID param3 = decodedMessage_mLN_EN_Alarm.VAR_event();

	TYPE_APEWProtocol_GEN_15 ASN1decisionMakingSNs =
		decodedMessage_mLN_EN_Alarm.VAR_decisionMakingSNs();
	trig_vec param4;

	for (int i = 1; i <= ASN1decisionMakingSNs.lengthAsLong(); ++i)
	    param4.push_back((TYPE_TriggeredSNInfo) ASN1decisionMakingSNs(i));

	RTDS_MSG_SEND_LN_EN_Alarm_TO_NAME(
		"GatewayEntity",
		RTDS_process_GatewayEntity,
		sender,
		param2,
		param3,
		param4);
	break;
    }
    case AP_GeneralProtocol::TYPE_APEWProtocol::CHOICE_mLN_EN_Summary: {
	std::cout << "LN_EN_Summary" << std::endl;
	TYPE_LN_EN_Summary decodedMessage_mLN_EN_Summary =
		decodedMessage_mAPEWProtocol.VAR_mLN_EN_Summary();

	tDateTime param2(decodedMessage_mLN_EN_Summary.VAR_gpsTimeStamp());

	EventID param3 = decodedMessage_mLN_EN_Summary.VAR_event();

	TYPE_APEWProtocol_GEN_16 ASN1operativeSNs =
		decodedMessage_mLN_EN_Summary.VAR_operativeSNs();
	ip_vec param4;

	for (int i = 1; i <= ASN1operativeSNs.lengthAsLong(); ++i)
	    param4.push_back(IPAddress(ASN1operativeSNs(i)));

	TYPE_APEWProtocol_GEN_17 ASN1inoperativeSNs =
		decodedMessage_mLN_EN_Summary.VAR_inoperativeSNs();
	inop_vec param5;

	for (int i = 1; i <= ASN1inoperativeSNs.lengthAsLong(); ++i)
	    param5.push_back((TYPE_InoperativeSNInfo) ASN1inoperativeSNs(i));

	TYPE_APEWProtocol_GEN_18 ASN1decisionMakers =
		decodedMessage_mLN_EN_Summary.VAR_decisionMakingSNs();
	status_vec param6;

	for (int i = 1; i <= ASN1decisionMakers.lengthAsLong(); ++i)
	    param6.push_back((TYPE_StatusSNInfo) ASN1decisionMakers(i));

	double param7 = decodedMessage_mLN_EN_Summary.VAR_ariasIntensity();

	RTDS_MSG_SEND_LN_EN_Summary_TO_NAME(
		"GatewayEntity",
		RTDS_process_GatewayEntity,
		sender,
		param2,
		param3,
		param4,
		param5,
		param6,
		param7);
	break;
    }
    default:
	std::cerr << "Unknown EWProtocol message type" << std::endl;
    }
}

void te_receiver::decodeAPManagingProtocol(
	TYPE_APManagingProtocol& decodedMessage_mAPManagingProtocol, IPAddress& sender) {
    void* RTDS_msgData;
    switch (decodedMessage_mAPManagingProtocol.present()) {
    case AP_GeneralProtocol::TYPE_APManagingProtocol::CHOICE_mTN_SN_AssignLeadershipForGroup: {
	std::cout << "TN_SN_AssignLeadershipForGroup" << std::endl;
	TYPE_TN_SN_AssignLeadershipForGroup decodedMessage_mTN_SN_AssignLeadershipForGroup =
		decodedMessage_mAPManagingProtocol.VAR_mTN_SN_AssignLeadershipForGroup();

	tDateTime param2(decodedMessage_mTN_SN_AssignLeadershipForGroup.VAR_gpsTimeStamp());

	TYPE_APManagingProtocol_GEN_1 ASN1groupMembers =
		decodedMessage_mTN_SN_AssignLeadershipForGroup.VAR_groupMembers();
	ip_vec param3;

	for (int i = 1; i <= ASN1groupMembers.lengthAsLong(); ++i) {
	    param3.push_back((const char*) ASN1groupMembers(i));
	}

	GroupID param4 = decodedMessage_mTN_SN_AssignLeadershipForGroup.VAR_groupID();

	RTDS_MSG_SEND_TN_SN_AssignLeadershipForGroup_TO_NAME(
		"SE",
		RTDS_process_ManagingEntity,
		sender,
		param2,
		param3,
		param4);
	break;
    }
    case AP_GeneralProtocol::TYPE_APManagingProtocol::CHOICE_mTN_LN_AssignLNsInNetwork: {
	std::cout << "TN_LN_AssignLNsInNetwork" << std::endl;
	TYPE_TN_LN_AssignLNsInNetwork decodedMessage_mTN_LN_AssignLNsInNetwork =
		decodedMessage_mAPManagingProtocol.VAR_mTN_LN_AssignLNsInNetwork();

	tDateTime param2(decodedMessage_mTN_LN_AssignLNsInNetwork.VAR_gpsTimeStamp());

	TYPE_APManagingProtocol_GEN_2 ASN1leadingNodesInNetwork =
		decodedMessage_mTN_LN_AssignLNsInNetwork.VAR_leadingNodesInNetwork();
	ip_vec param3;

	for (int i = 1; i <= ASN1leadingNodesInNetwork.lengthAsLong(); ++i) {
	    param3.push_back((const char*) ASN1leadingNodesInNetwork(i));
	}

	RTDS_MSG_SEND_TN_LN_AssignLNsInNetwork_TO_NAME(
		"LE",
		RTDS_process_ManagingEntity,
		sender,
		param2,
		param3);
	break;
    }
    case AP_GeneralProtocol::TYPE_APManagingProtocol::CHOICE_mTN_LN_AssignGNsInNetwork: {
	std::cout << "TN_LN_AssignGNsInNetwork" << std::endl;
	TYPE_TN_LN_AssignGNsInNetwork decodedMessage_mTN_LN_AssignGNsInNetwork =
		decodedMessage_mAPManagingProtocol.VAR_mTN_LN_AssignGNsInNetwork();

	tDateTime param2(decodedMessage_mTN_LN_AssignGNsInNetwork.VAR_gpsTimeStamp());

	TYPE_APManagingProtocol_GEN_3 ASN1gatewayNodesInNetwork =
		decodedMessage_mTN_LN_AssignGNsInNetwork.VAR_gatewayNodesInNetwork();
	ip_vec param3;

	for (int i = 1; i <= ASN1gatewayNodesInNetwork.lengthAsLong(); ++i) {
	    param3.push_back((const char*) ASN1gatewayNodesInNetwork(i));
	}

	RTDS_MSG_SEND_TN_LN_AssignGNsInNetwork_TO_NAME(
		"LE",
		RTDS_process_ManagingEntity,
		sender,
		param2,
		param3);
	break;
    }
    case AP_GeneralProtocol::TYPE_APManagingProtocol::CHOICE_mLN_SN_PrimaryLN: {
	std::cout << "TN_SN_PrimaryLN" << std::endl;
	TYPE_LN_SN_PrimaryLN decodedMessage_mLN_SN_PrimaryLN =
		decodedMessage_mAPManagingProtocol.VAR_mLN_SN_PrimaryLN();

	tDateTime param2(decodedMessage_mLN_SN_PrimaryLN.VAR_gpsTimeStamp());

	IPAddress param3 = (const char*) decodedMessage_mLN_SN_PrimaryLN.VAR_leadingNode();

	GroupID param4 = decodedMessage_mLN_SN_PrimaryLN.VAR_groupID();

	RTDS_MSG_SEND_LN_SN_PrimaryLN_TO_NAME(
		"SE",
		RTDS_process_SensingEntity,
		sender,
		param2,
		param3,
		param4);
	break;
    }
    case AP_GeneralProtocol::TYPE_APManagingProtocol::CHOICE_mLN_SN_SecondaryLN: {
	std::cout << "TN_SN_SecondaryLN" << std::endl;
	TYPE_LN_SN_SecondaryLN decodedMessage_mLN_SN_SecondaryLN =
		decodedMessage_mAPManagingProtocol.VAR_mLN_SN_SecondaryLN();

	tDateTime param2(decodedMessage_mLN_SN_SecondaryLN.VAR_gpsTimeStamp());

	IPAddress param3 = (const char*) decodedMessage_mLN_SN_SecondaryLN.VAR_leadingNode();

	GroupID param4 = decodedMessage_mLN_SN_SecondaryLN.VAR_groupID();

	RTDS_MSG_SEND_LN_SN_SecondaryLN_TO_NAME(
		"SE",
		RTDS_process_SensingEntity,
		sender,
		param2,
		param3,
		param4);
	break;
    }
    case AP_GeneralProtocol::TYPE_APManagingProtocol::CHOICE_mTN_SN_UseMSDP: {
	std::cout << "TN_SN_UseMSDP" << std::endl;
	TYPE_TN_SN_UseMSDP decodedMessage_mTN_SN_UseMSDP =
		decodedMessage_mAPManagingProtocol.VAR_mTN_SN_UseMSDP();

	tDateTime param2(decodedMessage_mTN_SN_UseMSDP.VAR_gpsTimeStamp());

	tDateTime param3(decodedMessage_mTN_SN_UseMSDP.VAR_simulationRunStartTime());

	tDateTime param4(decodedMessage_mTN_SN_UseMSDP.VAR_modelTimeStartTime());

	std::string param5 = (const char*) decodedMessage_mTN_SN_UseMSDP.VAR_sensorDataFile();

	RTDS_MSG_SEND_TN_SN_UseMSDP_TO_NAME(
		"SE",
		RTDS_process_ManagingEntity,
		sender,
		param2,
		param3,
		param4,
		param5);
	break;
    }
    case AP_GeneralProtocol::TYPE_APManagingProtocol::CHOICE_mTN_SN_AskGroupId: {
	std::cout << "TN_SN_AskGroupId" << std::endl;
	TYPE_TN_SN_AskGroupId decodedMessage_mTN_SN_AskGroupId =
		decodedMessage_mAPManagingProtocol.VAR_mTN_SN_AskGroupId();

	tDateTime param2(decodedMessage_mTN_SN_AskGroupId.VAR_gpsTimeStamp());

	RTDS_MSG_SEND_TN_SN_AskGroupId_TO_NAME(
		"SE",
		RTDS_process_ManagingEntity,
		sender,
		param2);
	break;
    }
    case AP_GeneralProtocol::TYPE_APManagingProtocol::CHOICE_mSN_TN_HaveGroupId: {
	std::cout << "SN_TN_HaveGroupId" << std::endl;
	/*TYPE_SN_TN_HaveGroupId decodedMessage_mSN_TN_HaveGroupId = decodedMessage_mAPManagingProtocol.VAR_mSN_TN_HaveGroupId();

	tDateTime param2( decodedMessage_mSN_TN_HaveGroupId.VAR_gpsTimeStamp() );

	IPAddress param3 = (const char*) decodedMessage_mSN_TN_HaveGroupId.VAR_leadingNode();

	GroupID param4 = decodedMessage_mSN_TN_HaveGroupId.VAR_groupID();

	RTDS_MSG_SEND_SN_TN_HaveGroupId_TO_NAME(
		"SE",
		RTDS_process_SensingEntity,
		sender,
		param2,
		param3,
		param4);*/
	break;
    }
    case AP_GeneralProtocol::TYPE_APManagingProtocol::CHOICE_mTN_SN_ConfigureSetKeyValue: {
	std::cout << "TN_SN_ConfigureSetKeyValue" << std::endl;
	TYPE_TN_SN_ConfigureSetKeyValue decodedMessage_mTN_SN_ConfigureSetKeyValue =
		decodedMessage_mAPManagingProtocol.VAR_mTN_SN_ConfigureSetKeyValue();

	tDateTime param2(decodedMessage_mTN_SN_ConfigureSetKeyValue.VAR_gpsTimeStamp());

	TYPE_APManagingProtocol_GEN_5 asn1keyValuesSet =
		decodedMessage_mTN_SN_ConfigureSetKeyValue.VAR_keyValuesSet();
	key_vec param3;

	//while( !( emptySet.equal( ASN1gatewayNodesInNetwork ) ) )
	for (int i = 1; i <= asn1keyValuesSet.lengthAsLong(); ++i) {
	    //std::cerr <<i ;
	    //ASN1gatewayNodesInNetworkdecoded.push_back(IA5StringToString( SITE_STATIC_CAST(SDLIA5String, ASN1gatewayNodesInNetwork(i))));
	    param3.push_back((tKeyValuePair) asn1keyValuesSet(i));
	}

	//std::string param4 = (const char*)( decodedMessage_mTN_SN_ConfigureSetKeyValue.VAR_value() );

	//tDateTime param5( decodedMessage_mTN_SN_ConfigureSetKeyValue.VAR_notValidBefore());

	RTDS_MSG_SEND_TN_SN_ConfigureSetKeyValue_TO_NAME(
		"SE",
		RTDS_process_ManagingEntity,
		sender,
		param2,
		param3);
	break;
    }
    case AP_GeneralProtocol::TYPE_APManagingProtocol::CHOICE_mTN_SN_CloseMessageLogfile: {
	std::cout << "TN_SN_CloseMessageLogfile" << std::endl;

	TYPE_TN_SN_CloseMessageLogfile decodedMessage_mTN_SN_CloseMessageLogfile =
		decodedMessage_mAPManagingProtocol.VAR_mTN_SN_CloseMessageLogfile();

	tDateTime param2(decodedMessage_mTN_SN_CloseMessageLogfile.VAR_gpsTimeStamp());

	tDateTime param3(decodedMessage_mTN_SN_CloseMessageLogfile.VAR_executeTime());

	RTDS_MSG_SEND_TN_SN_CloseMessageLogfile_TO_NAME(
		"SE",
		RTDS_process_ManagingEntity,
		sender,
		param2,
		param3);
	break;
    }
    case AP_GeneralProtocol::TYPE_APManagingProtocol::CHOICE_mTN_SN_StartMessageLogging: // to SE
    {
	std::cout << "TN_SN_StartMessageLogging" << std::endl;

	TYPE_TN_SN_StartMessageLogging decodedMessage_mTN_SN_StartMessageLogging =
		decodedMessage_mAPManagingProtocol.VAR_mTN_SN_StartMessageLogging();

	tDateTime param2(decodedMessage_mTN_SN_StartMessageLogging.VAR_gpsTimeStamp());

	tDateTime param3(decodedMessage_mTN_SN_StartMessageLogging.VAR_executeTime());

	RTDS_MSG_SEND_TN_SN_StartMessageLogging_TO_NAME(
		"SE",
		RTDS_process_ManagingEntity,
		sender,
		param2,
		param3);
	break;
    }
    case AP_GeneralProtocol::TYPE_APManagingProtocol::CHOICE_mTN_SN_StopMessageLogging: // to SE
    {
	std::cout << "TN_SN_StopMessageLogging" << std::endl;

	TYPE_TN_SN_StopMessageLogging decodedMessage_mTN_SN_StopMessageLogging =
		decodedMessage_mAPManagingProtocol.VAR_mTN_SN_StopMessageLogging();

	tDateTime param2(decodedMessage_mTN_SN_StopMessageLogging.VAR_gpsTimeStamp());

	tDateTime param3(decodedMessage_mTN_SN_StopMessageLogging.VAR_executeTime());

	RTDS_MSG_SEND_TN_SN_StopMessageLogging_TO_NAME(
		"SE",
		RTDS_process_ManagingEntity,
		sender,
		param2,
		param3);
	break;
    }
    default:
	std::cerr << "Managing, unknown message type: " << decodedMessage_mAPManagingProtocol.present() << std::endl;
    }
}

void te_receiver::SDLSend(Message* msg) {
    //	cout << "received asn1 from: " << msg -> sender << " msg: " << bytestream2Hex( msg -> content ) << endl;
    std::cout << "received asn1 from: " << msg -> sender << std::endl;

    XMLStreamingLogger* xmlLogger = dynamic_cast<XMLStreamingLogger*> (&logger);
    long long timestamp = getCurrentTime();
    TYPE_APGeneralProtocol decodedMessage = decode(msg -> content.c_str(), msg -> content.length());

    // TODO: we need the actual ASN1 switch here, unfortunately...
    // NetworkStack only has the ASN1 string, it can't derive a type

    switch (decodedMessage.present()) {
    case AP_GeneralProtocol::TYPE_APGeneralProtocol::CHOICE_mAPEWProtocol:
	decodeAPEWProtocol(decodedMessage.VAR_mAPEWProtocol(), msg -> sender);
	if (xmlLogger)
	    xmlLogger->logExternReceive(
		    msg -> sender,
		    msgQueue.writer,
		    getCRCInterNode(msg -> sender, localIP, msg -> content),
		    timestamp
	    );
	break;
    case AP_GeneralProtocol::TYPE_APGeneralProtocol::CHOICE_mAPManagingProtocol:
	decodeAPManagingProtocol(decodedMessage.VAR_mAPManagingProtocol(), msg->sender);
	if (xmlLogger)
	    xmlLogger->logExternReceive(
		    msg -> sender,
		    msgQueue.writer,
		    getCRCInterNode(msg -> sender, localIP, msg -> content.c_str()),
		    timestamp
	    );
	break;
    }

    // clean up, should work because RTDS_MSG_SEND_XXX macros copy the data
    delete msg;
}
