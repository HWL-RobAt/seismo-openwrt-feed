/**
 * @file receive_connection.cpp
 * @date Aug 17, 2008
 * @author Ronald Kluth
 *
 * @brief Definition of ReceiveConnection functions
 */

#include "receive_connection.h"
#include "network_stack.h"

ReceiveConnection::ReceiveConnection( boost::asio::io_service& io_service,
									  NetworkStack& ns )
:	networkStack( ns ),
	tcpSocket( io_service )
{
	//cout << "ReceiveConnection() " << this << endl;
}

ReceiveConnection::~ReceiveConnection()
{
	//cout << "~ReceiveConnection() " << this << endl;
}

ReceiveConnection::pointer
ReceiveConnection::create( boost::asio::io_service& io_service, NetworkStack& ns )
{
	return ReceiveConnection::pointer( new ReceiveConnection( io_service, ns ) );
}

tcp::socket&
ReceiveConnection::socket()
{
	return tcpSocket;
}

void
ReceiveConnection::asyncRead()
{
	//cout << "ReceiveConnection::asyncRead() " << this << endl;

	// start asynchronous read operation, filling the buffer till
	// it contains a newline, deal with result in handleRead()
	boost::asio::async_read( socket(), receiveBuffer, boost::asio::transfer_all(),
			boost::bind( &ReceiveConnection::handleRead, shared_from_this(),
					boost::asio::placeholders::error,
					boost::asio::placeholders::bytes_transferred ) );
}

void
ReceiveConnection::handleRead( const boost::system::error_code& error,
							   size_t bytes_transferred )
{
//	std::cout << "ReceiveConnection::handleRead() " << ": bytes transferred: " << bytes_transferred << std::endl;

	if( error == boost::asio::error::eof )
	{
		char* tmp = (char*) malloc(bytes_transferred);

			receiveBuffer.commit(bytes_transferred);
			// put received response from buffer into a string
			std::istream is( &receiveBuffer );
			is.read(tmp, bytes_transferred);
			std::string response(tmp, bytes_transferred);
			free( tmp );
		// get sender and receiver IP
		std::string fromIP = socket().remote_endpoint().address().to_string();
		std::string ownIP = socket().local_endpoint().address().to_string();

		// pass the received response upward to the player
		networkStack.receivedMessage( response, fromIP, ownIP );
	}
	else
	{
		// networkStack.handleReadError( error, bytes_transferred );
		std::cout << "ReceiveConnection::handleRead(): unexpected error code: "
				  << error << std::endl;
	}
}
