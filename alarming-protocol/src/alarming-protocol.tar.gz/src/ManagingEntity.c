/*SX*//** @file
 *  Generated file, find templates in SX folders
 */
#include <boost/thread/thread.hpp>
#include <boost/bind.hpp>

#include "RTDS_gen.h"
#include "ManagingEntity.h"
#include "RTDS_messages.h"

#define RTDS_PROCESS_NUMBER RTDS_process_ManagingEntity
#define RTDS_PROCESS_NAME ManagingEntity

/*
** PROCESS ManagingEntity:
** -----------------------
*/

ManagingEntity::ManagingEntity(RTDS::Logger& logger)
: SDLProcess(logger)
{
    RTDS_LOG_PROCESS_CREATION(msgQueue.writer, "ManagingEntity", cover);
}

int ManagingEntity::main()
{
    short RTDS_transitionExecuted;
  int RTDS_savedSdlState = 0;

  IPAddress              LE_IP = "000.000.000.000";
  IPAddress              myIP = "000.000.000.000";
  IPAddress              sender;
  ip_vec                 SNs, LNs, GNs;
  ip_vec                 tempSN, tempLN, tempGN;
  GroupID                gID;
  tDateTime              gpsTimeStamp, executeTime;
  tDateTime              simulationRunStartTime, modelTimeStartTime;
  std::string            IA5String;
  tSharedData            *mySharedData = 0;
  std::vector<tKeyValuePair> keyValueSet;
  XMLStreamingLogger* xmllogger = dynamic_cast<XMLStreamingLogger*>(&logger);
  RTDS_MSG_DATA_DECL

  // silence warning; this variable is not usually used
  RTDS_savedSdlState += 0;

  /* starts stdio.run() asynchronous stops when isRunnings destructor is destroyed */
  boost::thread _workThread_t(boost::bind(&boost::asio::io_service::run, &ioService));
  std::auto_ptr<boost::asio::io_service::work> _workThread_ptr(isRunning);
  isRunning = 0;

  /* declare framework-side variables for the process */

  /* Initial transition */
  RTDS_SDL_STATE_SET(Idle);
  // odemx/bricks/RTDS_Proc_loopStart
  while (true) {
  // loop start ends
  /* peek new message from queue */
  currentMessage = msgQRead();
  RTDS_LOG_MESSAGE_RECEIVE(&currentMessage->sender, msgQueue.writer,
  currentMessage->sequenceNumber, getCurrentTime());
  /* Double switch state / signal */
  RTDS_transitionExecuted = 1;
  switch(RTDS_currentContext->sdlState)
    {
    /* Transitions for state Idle */
    case Idle:
      switch(RTDS_currentContext->currentMessage->messageNumber)
        {
        /* Transition for state Idle - message TN_SN_CloseMessageLogfile */
        case TN_SN_CloseMessageLogfile:
          RTDS_MSG_RECEIVE_TN_SN_CloseMessageLogfile(      sender,       gpsTimeStamp,       executeTime);
          xmllogger->createNewLog();
          RTDS_SDL_STATE_SET(Idle);
          break;
        /* Transition for state Idle - message TN_SN_ConfigureSetKeyValue */
        case TN_SN_ConfigureSetKeyValue:
          RTDS_MSG_RECEIVE_TN_SN_ConfigureSetKeyValue(          sender,           gpsTimeStamp,           keyValueSet);
          LOGS(ME, "received  TN_SN_ConfigureSetKeyValue with");
          for (size_t i = 0; i < keyValueSet.size(); i++)
            {
            LOGS(ME, keyValueSet[i].key << ":" << keyValueSet[i].value);  
            }

          for (size_t i = 0; i < keyValueSet.size(); i++)
            {
            if (keyValueSet[i].key == "SAMPLERATE")
              {
              mySharedData->SAMPLERATE   = atoi( (keyValueSet[i].value).c_str() );
              LOGS(ME, mySharedData->SAMPLERATE);
              }
            if (keyValueSet[i].key == "PSHORTWINDOW")
              {
              mySharedData->PSHORTWINDOW = atof( (keyValueSet[i].value).c_str() );
              LOGS(ME, mySharedData->PSHORTWINDOW);
              }
            if (keyValueSet[i].key == "PSLRATIO")
              {
              mySharedData->PSLRATIO     = atoi( (keyValueSet[i].value).c_str() );
              LOGS(ME, mySharedData->PSLRATIO);
              }
            if (keyValueSet[i].key == "PDELAY")
              {
              mySharedData->PDELAY       = atof( (keyValueSet[i].value).c_str() );
              LOGS(ME, mySharedData->PDELAY);
              }
            if (keyValueSet[i].key == "PGAMMA")
              {
              mySharedData->PGAMMA       = atoi( (keyValueSet[i].value).c_str() );
              LOGS(ME, mySharedData->PGAMMA);
              }
            if (keyValueSet[i].key == "PCUTOFF")
              {
              mySharedData->PCUTOFF      = atof( (keyValueSet[i].value).c_str() );
              LOGS(ME, mySharedData->PCUTOFF);
              }
            if (keyValueSet[i].key == "SSHORTWINDOW")
              {
              mySharedData->SSHORTWINDOW = atof( (keyValueSet[i].value).c_str() );
              LOGS(ME, mySharedData->SSHORTWINDOW);
              }
            if (keyValueSet[i].key == "SCUTOFF")
              {
              mySharedData->SCUTOFF      = atof( (keyValueSet[i].value).c_str() );
              LOGS(ME, mySharedData->SCUTOFF);
              }
            }
          RTDS_SDL_STATE_SET(Idle);
          break;
        /* Transition for state Idle - message SendPShared */
        case SendPShared:
          RTDS_MSG_RECEIVE_SendPShared(          mySharedData);
          RTDS_SDL_STATE_SET(Idle);
          break;
        /* Transition for state Idle - message TN_SN_StartMessageLogging */
        case TN_SN_StartMessageLogging:
          RTDS_MSG_RECEIVE_TN_SN_StartMessageLogging(          sender,           gpsTimeStamp,           executeTime);
          // do sth.
          RTDS_SDL_STATE_SET(Idle);
          break;
        /* Transition for state Idle - message TN_SN_StopMessageLogging */
        case TN_SN_StopMessageLogging:
          RTDS_MSG_RECEIVE_TN_SN_StopMessageLogging(          sender,           gpsTimeStamp,           executeTime);
          // do sth.
          RTDS_SDL_STATE_SET(Idle);
          break;
        /* Transition for state Idle - message TN_SN_AskGroupId */
        case TN_SN_AskGroupId:
          RTDS_MSG_RECEIVE_TN_SN_AskGroupId(          sender,           gpsTimeStamp);
          gpsTimeStamp.unixTime = time(0);
          gpsTimeStamp.msFraction = 0;
          RTDS_MSG_SEND_SN_TN_HaveGroupId_TO_NAME("te_sender", RTDS_process_te_sender,           sender,           getCurrentGPSTime(this),           LE_IP,           gID);
          RTDS_SDL_STATE_SET(Idle);
          break;
        /* Transition for state Idle - message TN_LN_AssignGNsInNetwork */
        case TN_LN_AssignGNsInNetwork:
          RTDS_MSG_RECEIVE_TN_LN_AssignGNsInNetwork(          sender,           gpsTimeStamp,           tempGN);
          LE_IP = getMyLocalIP(this);
          myIP = LE_IP;
          RTDS_MSG_SEND_GNsInNetwork_TO_NAME("LeadingEntity", RTDS_process_LeadingEntity,           tempGN);
          RTDS_SDL_STATE_SET(Idle);
          break;
        /* Transition for state Idle - message TN_SN_UseMSDP */
        case TN_SN_UseMSDP:
          RTDS_MSG_RECEIVE_TN_SN_UseMSDP(          sender,           gpsTimeStamp,           simulationRunStartTime,           modelTimeStartTime,           IA5String);
          // do sth. with file ?
          RTDS_SDL_STATE_SET(Idle);
          break;
        /* Transition for state Idle - message TN_SN_AssignLeadershipForGroup */
        case TN_SN_AssignLeadershipForGroup:
          RTDS_MSG_RECEIVE_TN_SN_AssignLeadershipForGroup(          sender,           gpsTimeStamp,           tempSN,           gID);
          LE_IP = getMyLocalIP(this);
          myIP = LE_IP;
          RTDS_MSG_SEND_StartLN_TO_NAME("LeadingEntity", RTDS_process_LeadingEntity,           LE_IP,           tempSN,           gID);
          RTDS_SDL_STATE_SET(Idle);
          break;
        /* Transition for state Idle - message TN_LN_AssignLNsInNetwork */
        case TN_LN_AssignLNsInNetwork:
          RTDS_MSG_RECEIVE_TN_LN_AssignLNsInNetwork(          sender,           gpsTimeStamp,           tempLN);
          LE_IP = getMyLocalIP(this);
          myIP = LE_IP;
          RTDS_MSG_SEND_LNsInNetwork_TO_NAME("LeadingEntity", RTDS_process_LeadingEntity,           tempLN);
          RTDS_SDL_STATE_SET(Idle);
          break;
        default:
          RTDS_transitionExecuted = 0;
          break;
        } /* End of switch on message */
      break;
    default:
      RTDS_transitionExecuted = 0;
      break;
    } /* End of switch(RTDS_currentContext->sdlState) */
  // odemx/bricks/RTDS_Proc_end
  delete currentMessage;
  }; // end of while(true)
// no return here, since this brick does not know the return type
// end ends
}

/* private methods */
