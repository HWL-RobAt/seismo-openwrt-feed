/**
 * @file send_connection.cpp
 * @date Aug 17, 2008
 * @author Ronald Kluth
 *
 * @brief Definition of SendConnection functions
 */

#include "send_connection.h"
#include "network_stack.h"

SendConnection::SendConnection( boost::asio::io_service& io_service,
							    NetworkStack& ns, const std::string& message )
:	networkStack( ns ),
	tcpSocket( io_service )
{
	// write message to stream buffer, add '\n' to mark end of message
	std::ostream sendBufferStream( &sendBuffer );
	sendBufferStream << message;

	std::cout << "SendConnection() " << this
			  << "Size: " << message.length() << std::endl;
}

SendConnection::~SendConnection()
{
	std::cout << "~SendConnection() " << this << std::endl;
}

SendConnection::pointer
SendConnection::create( boost::asio::io_service& io_service, NetworkStack& ns,
						const std::string& message )
{
	return SendConnection::pointer( new SendConnection( io_service, ns, message ) );
}

boost::asio::ip::tcp::socket&
SendConnection::socket()
{
	return tcpSocket;
}

void
SendConnection::asyncConnect( boost::asio::ip::tcp::endpoint peerEndpoint )
{
	socket().async_connect( peerEndpoint,
			boost::bind( &SendConnection::handleConnect, shared_from_this(),
					boost::asio::placeholders::error ) );
}

void
SendConnection::handleConnect( const boost::system::error_code& error )
{
	if( ! error )
	{
		//cout << "SendConnection::handleConnect() " << this << endl;
		asyncWrite();
	}
	else
	{
		// networkStack.handleConnectError( error );
	}
}

void
SendConnection::asyncWrite()
{
	//cout << "SendConnection::send( " << msg << " ) " << this << endl;

	// start asynchronous write operation, deal with result in handleWrite()
	boost::asio::async_write( socket(), sendBuffer,
			boost::bind( &SendConnection::handleWrite, shared_from_this(),
					boost::asio::placeholders::error,
					boost::asio::placeholders::bytes_transferred ) );
}

void
SendConnection::handleWrite( const boost::system::error_code& error,
							size_t bytes_transferred )
{
	std::cout << "SendConnection::handleWrite()"
			  << ": bytes transferred: " << bytes_transferred << std::endl;

	if( ! error )
	{
		//cout << "SendConnection::handleWrite() " << this << ": bytes transferred: " << bytes_transferred << endl;

		// doing nothing here will cause this object to terminate;
		// as it is handled by a shared pointer, it should then
		// automatically be destroyed
	}
	else
	{
		// networkStack.handleWriteError( error, bytes_transferred );
	}
}
