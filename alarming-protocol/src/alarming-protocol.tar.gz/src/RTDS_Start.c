#include "RTDS_gen.h"
#include "SingleNode.h"

#ifndef SX_INIT
#define SX_INIT sx_init()
#endif

void SX_INIT
  {

  /* SEMAPHORE CREATIONS */

  /* PROCESS CREATIONS */
  RTDS_STARTUP_PROCESS_CREATE("GatewayEntity", RTDS_process_GatewayEntity, GatewayEntity, RTDS_DEFAULT_PROCESS_PRIORITY);
  RTDS_STARTUP_PROCESS_CREATE("ManagingEntity", RTDS_process_ManagingEntity, ManagingEntity, RTDS_DEFAULT_PROCESS_PRIORITY);
  RTDS_STARTUP_PROCESS_CREATE("te_sender", RTDS_process_te_sender, te_sender, RTDS_DEFAULT_PROCESS_PRIORITY);
  RTDS_STARTUP_PROCESS_CREATE("te_receiver", RTDS_process_te_receiver, te_receiver, RTDS_DEFAULT_PROCESS_PRIORITY);
  RTDS_STARTUP_PROCESS_CREATE("SignalAnalysingEntity", RTDS_process_SignalAnalysingEntity, SignalAnalysingEntity, RTDS_DEFAULT_PROCESS_PRIORITY);
  RTDS_STARTUP_PROCESS_CREATE("DataListenerEntity", RTDS_process_DataListenerEntity, DataListenerEntity, RTDS_DEFAULT_PROCESS_PRIORITY);
  RTDS_STARTUP_PROCESS_CREATE("LeadingEntity", RTDS_process_LeadingEntity, LeadingEntity, RTDS_DEFAULT_PROCESS_PRIORITY);
  RTDS_STARTUP_PROCESS_CREATE("SensingEntity", RTDS_process_SensingEntity, SensingEntity, RTDS_DEFAULT_PROCESS_PRIORITY);

  }
