/**
 * @file receive_connection.h
 * @date Aug 17, 2008
 * @author Ronald Kluth
 *
 * @brief Declaration of class ReceiveConnection
 */

#ifndef RECEIVE_CONNECTION_H_
#define RECEIVE_CONNECTION_H_

#include <boost/asio.hpp>
#include <boost/enable_shared_from_this.hpp>

// forward declaration
class NetworkStack;

/**
 * @class ReceiveConnection
 * @brief objects of this type represent one side of a tcp connection,
 * which in this case has receiving capability, but no sending
 */
class ReceiveConnection:
	public boost::enable_shared_from_this< ReceiveConnection >
{
private:
	// data describing one connection endpoint
	NetworkStack& networkStack; ///< creator network interface
	boost::asio::ip::tcp::socket tcpSocket; ///< the connected local socket
	boost::asio::streambuf receiveBuffer; ///< buffer for reception

public:
	/// shared pointers are the only way to access objects of this class
	typedef boost::shared_ptr< ReceiveConnection > pointer;

	/// creation with shared pointer
	static pointer create( boost::asio::io_service& io_service,
						   NetworkStack& ns );

	/// attempt to read a complete line, reads until '\n'
	void asyncRead();
	/**
	 * @brief handler function, called when receiveBuffer contains newline,
	 * forwards the received message by means of networkStack.receivedMessage()
	 */
	void handleRead( const boost::system::error_code& error,
			  		 std::size_t bytes_transferred );

	/// get a reference to the local socket object
	boost::asio::ip::tcp::socket& socket();

	/// destructor
	~ReceiveConnection();
private:
	/// private constructor to require the use of create()
	ReceiveConnection( boost::asio::io_service& io_service, NetworkStack& ns );
};

#endif /* RECEIVE_CONNECTION_H_ */
