/*SX*//** @file
 *  Generated file, find templates in SX folders
 */
#include <boost/thread/thread.hpp>
#include <boost/bind.hpp>

#include "RTDS_gen.h"
#include "LeadingEntity.h"
#include "RTDS_messages.h"

#define RTDS_PROCESS_NUMBER RTDS_process_LeadingEntity
#define RTDS_PROCESS_NAME LeadingEntity

/*
** PROCESS LeadingEntity:
** ----------------------
*/

LeadingEntity::LeadingEntity(RTDS::Logger& logger)
: SDLProcess(logger)
{
    RTDS_LOG_PROCESS_CREATION(msgQueue.writer, "LeadingEntity", cover);
}

int LeadingEntity::main()
{
    short RTDS_transitionExecuted;
  int RTDS_savedSdlState = 0;

  class local
    {
    public:
    static void update_timestamp(const status_vec& vec_status,
    const IPAddress& sender, const tDateTime& gpsTimeStamp)
      {
      foreach (tStatusSNInfo status, vec_status)
        {
        if (status.sourceSN == sender)
          {
          status.gpsTimeStamp.unixTime = gpsTimeStamp.unixTime;
          status.gpsTimeStamp.msFraction = gpsTimeStamp.msFraction;
          break;
          }
        }
      }

    static void check_inoperative(const status_vec& vec_status,
    ip_vec& vec_operative, inop_vec& vec_inoperative,
    const tDateTime& gpsTimeStamp)
      {
      // Wenn das letzte Signal eines Nodes 60 Sekunden zurueckliegt,
      // wird er auf die Inoperativeliste gesetzt
      for (size_t m = 0; m < vec_operative.size(); m++)
        {
        for (size_t n = 0; n < vec_status.size(); n++)
          {
          if (vec_status[n].sourceSN == vec_operative[m])
            {
            if (vec_status[n].gpsTimeStamp.unixTime + 60 < gpsTimeStamp.unixTime)
              {
              tInoperativeSNInfo newElement(vec_status[n].gpsTimeStamp,
              vec_operative[m], linkDown);
              vec_inoperative.push_back(newElement);
              vec_operative.erase(vec_operative.begin()+m);      
              }
            }
          }
        }
      }

    static void reset_bool_map(bool_map& inf)
      {
      bool_map::iterator it;
      for(it = inf.begin(); it != inf.end(); it++)
      it->second = false;
      }
    };
  size_t snTriggerCount  = 0;
  size_t lnTriggerCount  = 0;
  size_t SECount  = 0;
  size_t LECount  = 0;
  size_t GNCount  = 0;

  bool_map SEInf, LEInf, LEAla;

  IPAddress   sender   = "000.000.000.000";
  IPAddress   myIP     = "000.000.000.000";
  tDateTime   gpsTimeStamp, tp, t_max, ts, tend, timeOfFalseAlarm;
  GroupID     gID;
  EventID     event;
  tWaveType   waveType;

  ip_vec      SNs, LNs, GNs, tempSN, tempLN, tempGN;
  ip_vec      vec_operative, vec_tempOp;
  inop_vec    vec_inoperative, vec_tempInop;
  trig_vec    vec_triggered, vec_tempTriggered, vec_alaTriggered;
  status_vec  vec_status, vec_decisions, vec_tempStatus, vec_tempDecisions;

  tSensorAcceleration              a_max, pga;
  tSensorVelocity                  v_max, pgv;
  tSensorDisplacement              d_max, pgd;
  tSensorAccelerationAverage       noiseAverage;
  tSensorAccelerationAverage       noiseAveragePreEvent;

  double      sta_lta_TriggerValue,batteryVoltage, valueFourthChannel;
  double      cav, predominantPeriod, ariasIntensity;
  RTDS_MSG_DATA_DECL

  // silence warning; this variable is not usually used
  RTDS_savedSdlState += 0;

  /* starts stdio.run() asynchronous stops when isRunnings destructor is destroyed */
  boost::thread _workThread_t(boost::bind(&boost::asio::io_service::run, &ioService));
  std::auto_ptr<boost::asio::io_service::work> _workThread_ptr(isRunning);
  isRunning = 0;

  /* declare framework-side variables for the process */

  /* Initial transition */
  snTriggerCount = 0;
  lnTriggerCount = 0;
  RTDS_SDL_STATE_SET(groupIdle);
  // odemx/bricks/RTDS_Proc_loopStart
  while (true) {
  // loop start ends
  /* peek new message from queue */
  currentMessage = msgQRead();
  RTDS_LOG_MESSAGE_RECEIVE(&currentMessage->sender, msgQueue.writer,
  currentMessage->sequenceNumber, getCurrentTime());
  /* Double switch state / signal */
  RTDS_transitionExecuted = 1;
  switch(RTDS_currentContext->sdlState)
    {
    /* Transitions for state groupIdle */
    case groupIdle:
      switch(RTDS_currentContext->currentMessage->messageNumber)
        {
        /* Transition for state groupIdle - message SN_LN_Description */
        case SN_LN_Description:
          RTDS_MSG_RECEIVE_SN_LN_Description(      sender,       gpsTimeStamp,       tp,       waveType,       pga,       pgv,       pgd,       noiseAverage,       predominantPeriod,       cav,       ariasIntensity,       valueFourthChannel);
          // {{{ prepare alarm Desc
            {
            LOGS(LE, myIP << " LE/groupIdl/recSNLNDesc");

            //aktualisieren der triggervalues
            for (size_t p = 0 ;p < vec_triggered.size(); p++) {
            if (vec_triggered[p].sourceSN == sender) {
            //exist = true; 
            vec_triggered[p].gpsTimeStamp.unixTime = gpsTimeStamp.unixTime;
            vec_triggered[p].gpsTimeStamp.msFraction = gpsTimeStamp.msFraction;
            vec_triggered[p].tp.unixTime = tp.unixTime;
            vec_triggered[p].tp.msFraction = tp.msFraction;
            if (vec_triggered[p].az_max < pga.z) {
            vec_triggered[p].az_max = pga.z;
            vec_triggered[p].t_max.unixTime = gpsTimeStamp.unixTime; 
            vec_triggered[p].t_max.msFraction = gpsTimeStamp.msFraction;
            }
          if (vec_triggered[p].max_noise < noiseAverage.acceleration.z) {
          vec_triggered[p].max_noise = noiseAverage.acceleration.z;
          }
        vec_triggered[p].valueFourthChannel = valueFourthChannel;
        }
      }

    for (size_t k = 0; k < vec_status.size(); k++) {
    if (vec_status[k].sourceSN == sender) {
    vec_status[k].gpsTimeStamp.unixTime = gpsTimeStamp.unixTime;
    vec_status[k].gpsTimeStamp.msFraction = gpsTimeStamp.msFraction;
    vec_status[k].pga = pga;
    vec_status[k].pgv = pgv;
    vec_status[k].pgd = pgd;
    vec_status[k].predominantPeriod = predominantPeriod;
    vec_status[k].cav = cav;
    vec_status[k].ariasIntensity = ariasIntensity;
    vec_status[k].valueFourthChannel = valueFourthChannel;
    break;
    }
  }
}
// }}} prepare alarm Desc
// {{{ update inop SN/LN
local::check_inoperative(vec_status, vec_operative, vec_inoperative, gpsTimeStamp);
// }}} update inop
RTDS_RESET_TIMER(t_idle);
RTDS_SET_TIMER(t_preAlarm, T_PREALARM);
sendMessageViaNoti("ews", 4, "groupIdle -> preAlarm");
RTDS_SDL_STATE_SET(preAlarm);
break;
/* Transition for state groupIdle - message LN_LN_Detection */
case LN_LN_Detection:
  RTDS_MSG_RECEIVE_LN_LN_Detection(sender, gpsTimeStamp, event, vec_tempTriggered, vec_tempInop, noiseAveragePreEvent);
  // {{{ Action 22
    {
    LEInf[sender] = true;
    bool exist = false;

    LECount = 0;
    lnTriggerCount = 0;

    std::map<std::string,bool>::iterator it;
    for (it = LEInf.begin(); it != LEInf.end(); it++)
      {
      if (it->second == true)
      lnTriggerCount++;
      }

    LOGS(LE, "lnTriggerCount is now " << lnTriggerCount);

    // Liste der getriggerten aktualisieren; hinzufuegen von allen unbekannten IPs
    for (size_t k = 0; k < vec_tempTriggered.size(); k++)
      {
      exist = false;
      for (size_t j = 0; j < vec_triggered.size(); j++)
        {
        LOGS(LE, vec_tempTriggered[k].sourceSN <<" "<< vec_triggered[j].sourceSN);
        if (vec_tempTriggered[k].sourceSN == vec_triggered[j].sourceSN)
          {
          exist = true;
          break;
          }
        }
      if (!exist)
      vec_triggered.push_back(vec_tempTriggered[k]);
      }

    local::update_timestamp(vec_status, sender, gpsTimeStamp);
    local::check_inoperative(vec_status, vec_operative, vec_inoperative, gpsTimeStamp);
    }
  // }}} Action 22
  RTDS_SET_TIMER(t_preAlarm, T_PREALARM);
  if ( lnTriggerCount == NUM_TRIGGER )
    {
    sysAl1:
    RTDS_RESET_TIMER(t_preAlarm);
    RTDS_RESET_TIMER(t_LNsDetection);
    Alarm_to_all_LN(RTDS_currentContext, myIP, LNs, LEAla, event, vec_alaTriggered); RTDS_SDL_STATE_SET(RTDS_sdlStatePrev);
    Describe_to_all_SN(RTDS_currentContext, SNs, SEInf, event, myIP); RTDS_SDL_STATE_SET(RTDS_sdlStatePrev);
    a2GN:
    foreach(IPAddress gn, GNs) {
    LOGS(LE, "LE_prelarm sending LN_EN_Ala from " << myIP << " to " << gn);
    LOGS(LE, "LE_grpAlarm sending LN_EN_Ala from " << myIP << " to " << gn);
    RTDS_MSG_SEND_LN_EN_Alarm_TO_NAME("te_sender", RTDS_process_te_sender,     gn,     getCurrentGPSTime(this),     event,     vec_alaTriggered);
    }
  sendMessageViaNoti("ews", 5, "-> systemAlarm");
  RTDS_SDL_STATE_SET(systemAlarm);
  break;
  }
else
  {
  // breathe deeply
  // Do not remove this empty task, needed for the foreach loop below.
  foreach(IPAddress ln, LNs) {
  RTDS_MSG_SEND_LN_LN_Description_TO_NAME("te_sender", RTDS_process_te_sender,   ln,   getCurrentGPSTime(this),   event);
  }
}
sendMessageViaNoti("ews", 4, "groupIdle -> preAlarm");
RTDS_SDL_STATE_SET(preAlarm);
break;
/* Transition for state groupIdle - message SN_LN_Detection */
case SN_LN_Detection:
  RTDS_MSG_RECEIVE_SN_LN_Detection(sender, gpsTimeStamp, tp, a_max, v_max, d_max, noiseAverage, valueFourthChannel, sta_lta_TriggerValue);
  // {{{ prepare alarm Det
    {
    bool dexist = false;
    snTriggerCount++;
    LOGS(LE, myIP << " LE/groupIdl/recSNLNDet from " << sender);
    LOGS(LE, "snTriggerCount is now " << snTriggerCount);

    // merken, dass dieser Node getriggered hat
    SEInf[sender] = true;

    /* DEBUG
    std::map<std::string,bool>::iterator it;
    for (it = SEInf.begin(); it != SEInf.end(); it++) {
    LOGS(LE, "SEInf: " << it->first << " " << it->second);
    }
  */

  // add new node to the triggered list
  tTriggeredSNInfo newElement;
  newElement.sourceSN = sender;
  newElement.gpsTimeStamp.unixTime = gpsTimeStamp.unixTime;
  newElement.gpsTimeStamp.msFraction = gpsTimeStamp.msFraction;
  newElement.currentSensorValues = a_max;
  newElement.tp.unixTime = tp.unixTime;
  newElement.tp.msFraction = tp.msFraction;
  newElement.az_max = a_max.z;
  newElement.t_max.unixTime = gpsTimeStamp.unixTime; 
  newElement.t_max.msFraction = gpsTimeStamp.msFraction;
  newElement.max_noise = noiseAverage.acceleration.z;
  newElement.valueFourthChannel = valueFourthChannel;
  newElement.sta_lta_TriggerValue = sta_lta_TriggerValue;
  vec_triggered.push_back(newElement);

  size_t sender_status;
  bool found = false;
  for (sender_status = 0; sender_status < vec_status.size(); sender_status++)
    {
    if (vec_status[sender_status].sourceSN == sender)
      {
      found = true;   
      vec_status[sender_status].gpsTimeStamp.unixTime = gpsTimeStamp.unixTime;
      vec_status[sender_status].gpsTimeStamp.msFraction = gpsTimeStamp.msFraction;
      vec_status[sender_status].pga = a_max;
      vec_status[sender_status].pgv = v_max;
      vec_status[sender_status].pgd = d_max;
      vec_status[sender_status].valueFourthChannel = valueFourthChannel;
      break;
      } 
    }
  for (size_t u = 0; u < vec_decisions.size(); u++)
    {
    if (vec_decisions[u].sourceSN == sender)
      {
      dexist = true;
      for (size_t v = 0; v < vec_status.size(); v++)
        {
        if (vec_decisions[u].sourceSN == vec_status[v].sourceSN) {
        vec_decisions[u] = vec_status[v];
        break;
        }
      }
    break;
    }
  }
if (!dexist && found)
vec_decisions.push_back(vec_status[sender_status]);
}
// }}} prepare alarm Det
// {{{ update inop SN/LN
local::check_inoperative(vec_status, vec_operative, vec_inoperative, gpsTimeStamp);
// }}} update inop
RTDS_RESET_TIMER(t_idle);
RTDS_SET_TIMER(t_preAlarm, T_PREALARM);
sendMessageViaNoti("ews", 4, "groupIdle -> preAlarm");
RTDS_SDL_STATE_SET(preAlarm);
break;
/* Transition for state groupIdle - message LN_LN_Alarm */
case LN_LN_Alarm:
  RTDS_MSG_RECEIVE_LN_LN_Alarm(sender, gpsTimeStamp, event, vec_tempTriggered);
  // {{{ Action 7
    {
    LOGS(LE, myIP << " LE/groupIdl/recLNLNAlarm");
    SECount = 0;
    LECount = 0;
    LEInf[sender] = true;
    LEAla[sender] = true;

    // merken welche alarming triggered gesendet wurde
    vec_alaTriggered = vec_tempTriggered;

    // oder plus die eigenen
    /*for (size_t k = 0; k < vec_tempTriggered->size(); k++)
      {
      for (size_t j = 0; j < vec_alaTriggered.size(); j++)
        {
        if ((*vec_tempGroup)[k].sourceSN == vec_alaTriggered[j].sourceSN)
          {
          continue;
          }
        vec_alaTriggered.push_back((*vec_tempGroup)[k]);
        }

      }*/

    local::update_timestamp(vec_status, sender, gpsTimeStamp);
    local::check_inoperative(vec_status, vec_operative, vec_inoperative, gpsTimeStamp);
    }
  // }}} Action 7
  goto sysAl1;
/* Transition for state groupIdle - message StartLN */
case StartLN:
  RTDS_MSG_RECEIVE_StartLN(  myIP,   tempSN,   gID);
  RTDS_SET_TIMER(t_idle, T_IDLELN);
  // {{{ start LN
    {
    LOGS(LE, "StartLN received, gid: " << gID << ", SNs: " << tempSN.size());

    SECount = 0;
    foreach (IPAddress sn, tempSN)
      {
      SEInf[sn] = false;

      SNs.push_back(sn);
      vec_operative.push_back(sn);

      tStatusSNInfo newElement;
      newElement.sourceSN = sn;
      newElement.gpsTimeStamp.unixTime = time(0);
      vec_status.push_back(newElement);
      }

    }
  // }}} start LN
  RTDS_label1:
  if ( SECount < SNs.size() )
    {
    if ( SNs[SECount] == myIP )
      {
      RTDS_MSG_SEND_LN_SN_PrimaryLN_TO_NAME("SensingEntity", RTDS_process_SensingEntity,       SNs[SECount],       getCurrentGPSTime(this),       SNs[SECount],       gID);
      }
    else
      {
      RTDS_MSG_SEND_LN_SN_PrimaryLN_TO_NAME("te_sender", RTDS_process_te_sender,       SNs[SECount],       getCurrentGPSTime(this),       SNs[SECount],       gID);
      }
    SECount++;
    }
  else
    {
    break;
    }
  goto RTDS_label1;
/* Transition for state groupIdle - message t_idle */
case t_idle:
  RTDS_SET_TIMER(t_idle, T_IDLELN);
  LECount = 0;
  RTDS_label2:
  if ( LECount < LNs.size() )
    {
    if ( LNs[LECount] == myIP )
      {
      }
    else
      {
      RTDS_MSG_SEND_LN_LN_Idle_TO_NAME("te_sender", RTDS_process_te_sender,       LNs[LECount],       getCurrentGPSTime(this),       vec_operative,       vec_inoperative,       noiseAveragePreEvent);
      }
    LOGS(LE, "sending LNLNDet to " << LNs[LECount]);
    LECount++;
    }
  else
    {
    break;
    }
  goto RTDS_label2;
/* Transition for state groupIdle - message LN_LN_Idle */
case LN_LN_Idle:
  RTDS_MSG_RECEIVE_LN_LN_Idle(  sender,   gpsTimeStamp,   vec_tempOp,   vec_tempInop,   noiseAveragePreEvent);
  // {{{ update op
  LOGS(LE, myIP << " LE/groupIdl/recLNLNIdle");
    {
    bool exist = false;
    // 
    // Operativelisten aktualisieren
    //
    for (size_t l = 0; l < vec_tempInop.size(); ++l)
      {
      for (size_t i = 0; i < vec_inoperative.size(); ++i)
        {
        if (vec_inoperative[i].sourceSN == vec_tempInop[l].sourceSN)
          {
          exist = true;
          break;
          }
        }
      if (!exist)
        {
        vec_inoperative.push_back(vec_tempInop[l]);
        for (size_t d = 0; d < vec_operative.size(); ++d)
          {
          if (vec_operative[d] == vec_tempInop[l].sourceSN)
            {
            vec_operative.erase(vec_operative.begin() + d);
            }
          }
        exist = false;
        }
      }
    }
  // }}} update op
  // {{{ update inop IDLE
    {
    LOGS(LE, myIP << " LE/groupIdl/recSNLNIdl#LNLNIdl");

    local::update_timestamp(vec_status, sender, gpsTimeStamp);
    local::check_inoperative(vec_status, vec_operative, vec_inoperative, gpsTimeStamp);
    }
  // }}} update inop IDLE
  break;
/* Transition for state groupIdle - message SN_LN_Idle */
case SN_LN_Idle:
  RTDS_MSG_RECEIVE_SN_LN_Idle(  sender,   gpsTimeStamp,   noiseAverage,   batteryVoltage,   valueFourthChannel);
  // {{{ update inop IDLE
    {
    LOGS(LE, myIP << " LE/groupIdl/recSNLNIdl#LNLNIdl");

    local::update_timestamp(vec_status, sender, gpsTimeStamp);
    local::check_inoperative(vec_status, vec_operative, vec_inoperative, gpsTimeStamp);
    }
  // }}} update inop IDLE
  break;
/* Transition for state groupIdle - message t_LNsDetection */
case t_LNsDetection:
  snTriggerCount = 0;
  lnTriggerCount = 0;
  LEInf[myIP] = false;
  break;
/* Transition for state groupIdle - message LNsInNetwork */
case LNsInNetwork:
  RTDS_MSG_RECEIVE_LNsInNetwork(  tempLN);
  // {{{ record LNs
  foreach (IPAddress ln, tempLN)
    {
    LNs.push_back(ln);
    LEInf[ln] = false;
    LEAla[ln] = false;
    }
  /* DEBUG
  std::map<std::string,bool>::iterator it;
  for (it = LEInf.begin(); it != LEInf.end(); it++)
    {
    LOGS(LE, "LEInf: " << it->first << " " << it->second);
    }
  */
  // }}} record LNs
  break;
/* Transition for state groupIdle - message SN_LN_Summary */
case SN_LN_Summary:
  RTDS_MSG_RECEIVE_SN_LN_Summary(  sender,   gpsTimeStamp,   tp,   ts,   tend,   pga,   pgv,   pgd,   noiseAverage,   cav,   ariasIntensity,   valueFourthChannel,   batteryVoltage);
  LOGS(LE, myIP << " LE/groupIdl/recSNLNSummary");
  break;
/* Transition for state groupIdle - message t_preAlarm */
case t_preAlarm:
  snTriggerCount = 0;
  LEInf[myIP] = false;
  break;
/* Transition for state groupIdle - message GNsInNetwork */
case GNsInNetwork:
  RTDS_MSG_RECEIVE_GNsInNetwork(  tempGN);
  // {{{ record GNs
  foreach (IPAddress gn, tempGN) {
  GNs.push_back(gn);
  }
// }}} record GNs
break;
default:
  RTDS_transitionExecuted = 0;
  break;
} /* End of switch on message */
break;
    /* Transitions for state groupAlarm */
    case groupAlarm:
      switch(RTDS_currentContext->currentMessage->messageNumber)
        {
        /* Transition for state groupAlarm - message t_LNsDetection */
        case t_LNsDetection:
          RTDS_RESET_TIMER(t_preAlarm);
          // {{{ reset vars LN
          LOGS(LE, myIP << " LE/preAlarm/rect_LNsDetection");
          snTriggerCount = 0;
          lnTriggerCount = 0;
          local::reset_bool_map(SEInf);
          local::reset_bool_map(LEInf);
          // TODO why not LEAla ?
          // }}} reset vars LN
          SECount = 0;
          RTDS_label3:
          if ( SECount < SNs.size() )
            {
            if ( SNs[SECount] == myIP )
              {
              RTDS_MSG_SEND_LN_SN_FalseAlarm_TO_NAME("SensingEntity", RTDS_process_SensingEntity,               SNs[SECount],               getCurrentGPSTime(this),               timeOfFalseAlarm);
              }
            else
              {
              RTDS_MSG_SEND_LN_SN_FalseAlarm_TO_NAME("te_sender", RTDS_process_te_sender,               SNs[SECount],               getCurrentGPSTime(this),               timeOfFalseAlarm);
              }
            SECount++;
            }
          else
            {
            RTDS_SET_TIMER(t_idle, T_IDLELN);
            sendMessageViaNoti("ews", 4, "groupAlarm/preAlarm -> groupIdle");
            RTDS_SDL_STATE_SET(groupIdle);
            break;
            }
          goto RTDS_label3;
        /* Transition for state groupAlarm - message LN_LN_Detection */
        case LN_LN_Detection:
          RTDS_MSG_RECEIVE_LN_LN_Detection(          sender,           gpsTimeStamp,           event,           vec_tempTriggered,           vec_tempInop,           noiseAveragePreEvent);
          // {{{ Action 75
            {
            LOGS(LE, myIP << " LE/grouplarm/recLNLNDet from " << sender);

            LEInf[sender] = true;
            lnTriggerCount = 0;

            std::map<std::string,bool>::iterator it;
            for (it = LEInf.begin(); it != LEInf.end(); it++) {
            if (it->second)
            lnTriggerCount++;
            }
          LOGS(LE, "lnTriggerCount is now " << lnTriggerCount);

          bool exist = false;
          // Liste der getriggerten aktualisieren; hinzufügen von allen unbekannten IPs
          for (size_t k = 0; k < vec_tempTriggered.size(); k++) {
          exist = false;
          for (size_t j = 0; j < vec_triggered.size(); j++) {
          LOGS(LE, vec_tempTriggered[k].sourceSN <<" "<< vec_triggered[j].sourceSN);
          if (vec_tempTriggered[k].sourceSN == vec_triggered[j].sourceSN) {
          exist = true;
          break;
          }
        }
      if (!exist) {
      vec_triggered.push_back(vec_tempTriggered[k]);
      }
    }

  local::update_timestamp(vec_status, sender, gpsTimeStamp);
  local::check_inoperative(vec_status, vec_operative, vec_inoperative, gpsTimeStamp);
  }
// }}} Action 75
RTDS_SET_TIMER(t_LNsDetection, T_LNSDETECTION);
if ( lnTriggerCount >= NUM_TRIGGER )
  {
  RTDS_RESET_TIMER(t_preAlarm);
  RTDS_RESET_TIMER(t_LNsDetection);
  // eigener sysalarm
  vec_alaTriggered = vec_triggered;
  }
else
  {
  Describe_to_all_SN(RTDS_currentContext, SNs, SEInf, event, myIP); RTDS_SDL_STATE_SET(RTDS_sdlStatePrev);
  break;
  }
Describe_to_all_SN(RTDS_currentContext, SNs, SEInf, event, myIP); RTDS_SDL_STATE_SET(RTDS_sdlStatePrev);
Alarm_to_all_LN(RTDS_currentContext, myIP, LNs, LEInf, event, vec_alaTriggered); RTDS_SDL_STATE_SET(RTDS_sdlStatePrev);
goto a2GN;
/* Transition for state groupAlarm - message LN_LN_Alarm */
case LN_LN_Alarm:
  RTDS_MSG_RECEIVE_LN_LN_Alarm(sender, gpsTimeStamp, event, vec_tempTriggered);
  RTDS_RESET_TIMER(t_preAlarm);
  RTDS_RESET_TIMER(t_LNsDetection);
  // {{{ Action 74
    {
    LOGS(LE, myIP << " LE/grouplarm/rectLNLNAlarm #LN_EN_Alarm will ignore own triggered");

    LEInf[sender] = true;
    LEAla[sender] = true;

    // wenn ein Alarm kommt dann ist dessen vec als  alaTriggered_vec für LN_EN_Ala zu nehmen.
    vec_alaTriggered = vec_tempTriggered;

    // oder plus die eigenen
    /*for (size_t k = 0; k < vec_tempTriggered->size(); k++) {
    for (size_t j = 0; j < vec_alaTriggered.size(); j++) {
    if ((*vec_tempGroup)[k].sourceSN == vec_alaTriggered[j].sourceSN) {
    continue;
    }
  vec_alaTriggered.push_back((*vec_tempGroup)[k]);
  }

}*/

local::update_timestamp(vec_status, sender, gpsTimeStamp);
local::check_inoperative(vec_status, vec_operative, vec_inoperative, gpsTimeStamp);
//delete vec_tempStatus;
}
// }}} Action 74
Describe_to_all_SN(RTDS_currentContext, SNs, SEInf, event, myIP); RTDS_SDL_STATE_SET(RTDS_sdlStatePrev);
Alarm_to_all_LN(RTDS_currentContext, myIP, LNs, LEInf, event, vec_alaTriggered); RTDS_SDL_STATE_SET(RTDS_sdlStatePrev);
goto a2GN;
/* Transition for state groupAlarm - message SN_LN_Description */
case SN_LN_Description:
  RTDS_MSG_RECEIVE_SN_LN_Description(sender, gpsTimeStamp, tp, waveType, pga, pgv, pgd, noiseAverage, predominantPeriod, cav, ariasIntensity, valueFourthChannel);
  // {{{ Action 53
    {
    LOGS(LE, myIP << " LE/groupAla/recSNLNDesc");
    //aktualisieren der triggervalues
    for (size_t p = 0 ;p < vec_triggered.size(); p++) {
    if (vec_triggered[p].sourceSN == sender) {
    vec_triggered[p].gpsTimeStamp.unixTime = gpsTimeStamp.unixTime;
    vec_triggered[p].gpsTimeStamp.msFraction = gpsTimeStamp.msFraction;
    // TODO what about currentSensorValues
    vec_triggered[p].tp.unixTime = tp.unixTime;
    vec_triggered[p].tp.msFraction = tp.msFraction;
    if (vec_triggered[p].az_max < pga.z) {
    vec_triggered[p].az_max = pga.z;
    vec_triggered[p].t_max.unixTime = gpsTimeStamp.unixTime; 
    vec_triggered[p].t_max.msFraction = gpsTimeStamp.msFraction;
    }
  if (vec_triggered[p].max_noise < noiseAverage.acceleration.z) {
  vec_triggered[p].max_noise = noiseAverage.acceleration.z;
  }
vec_triggered[p].valueFourthChannel = valueFourthChannel;
// TODO what about sta_lta_TriggerValue
break; // can be only one, optimize
}
}

for (size_t k = 0; k < vec_status.size(); k++) {
if (vec_status[k].sourceSN == sender) {
vec_status[k].gpsTimeStamp.unixTime = gpsTimeStamp.unixTime;
vec_status[k].gpsTimeStamp.msFraction = gpsTimeStamp.msFraction;
vec_status[k].pga = pga;
vec_status[k].pgv = pgv;
vec_status[k].pgd = pgd;
vec_status[k].predominantPeriod = predominantPeriod;
vec_status[k].cav = cav;
vec_status[k].ariasIntensity = ariasIntensity;
vec_status[k].valueFourthChannel = valueFourthChannel;
break;
}  
for (size_t u = 0; u < vec_decisions.size(); u++) {
if (vec_decisions[u].sourceSN == sender) {
vec_decisions[u] = vec_status[k];
break; // can be only one, optimize
}
}
}
}
// }}} Action 53
break;
/* Transition for state groupAlarm - message SN_LN_Detection */
case SN_LN_Detection:
  RTDS_MSG_RECEIVE_SN_LN_Detection(sender, gpsTimeStamp, tp, a_max, v_max, d_max, noiseAverage, valueFourthChannel, sta_lta_TriggerValue);
  // {{{ Action 52
    {
    LOGS(LE, myIP << " LE/grouplarm/recSNLNDet#LNLNIdl#SNLNIdl#SNLNSummary");
    bool exist = false;

    for (size_t j = 0; j < vec_triggered.size(); j++) {
    if (vec_triggered[j].sourceSN == sender) {
    exist = true;
    vec_triggered[j].gpsTimeStamp.unixTime = gpsTimeStamp.unixTime;
    vec_triggered[j].gpsTimeStamp.msFraction = gpsTimeStamp.msFraction;
    vec_triggered[j].currentSensorValues = a_max;
    vec_triggered[j].tp.unixTime = tp.unixTime;
    vec_triggered[j].tp.msFraction = tp.msFraction;
    if (vec_triggered[j].az_max < a_max.z) {
    vec_triggered[j].az_max = a_max.z;
    vec_triggered[j].t_max.unixTime = gpsTimeStamp.unixTime; 
    vec_triggered[j].t_max.msFraction = gpsTimeStamp.msFraction;
    }
  if (vec_triggered[j].max_noise < noiseAverage.acceleration.z) {
  vec_triggered[j].max_noise = noiseAverage.acceleration.z;
  }
vec_triggered[j].valueFourthChannel = valueFourthChannel;
vec_triggered[j].sta_lta_TriggerValue = sta_lta_TriggerValue;
break; // can be only one, optimize
}
}
if (!exist) {
tTriggeredSNInfo newElement;
newElement.sourceSN = sender;
newElement.gpsTimeStamp.unixTime = gpsTimeStamp.unixTime;
newElement.gpsTimeStamp.msFraction = gpsTimeStamp.msFraction;
newElement.currentSensorValues = a_max;
newElement.tp.unixTime = tp.unixTime;
newElement.tp.msFraction = tp.msFraction;
newElement.az_max = a_max.z;
newElement.t_max.unixTime = gpsTimeStamp.unixTime; 
newElement.t_max.msFraction = gpsTimeStamp.msFraction;
newElement.max_noise = noiseAverage.acceleration.z;
newElement.valueFourthChannel = valueFourthChannel;
newElement.sta_lta_TriggerValue = sta_lta_TriggerValue;
vec_triggered.push_back(newElement);
}
for (size_t l = 0; l < vec_status.size(); l++) {
if (vec_status[l].sourceSN == sender) {     
vec_status[l].gpsTimeStamp.unixTime = gpsTimeStamp.unixTime;
vec_status[l].gpsTimeStamp.msFraction = gpsTimeStamp.msFraction;
vec_status[l].pga = a_max;
vec_status[l].pgv = v_max;
vec_status[l].pgd = d_max;
vec_status[l].valueFourthChannel = valueFourthChannel;
break; // can be only one, optimize
} 
}

local::update_timestamp(vec_status, sender, gpsTimeStamp);
local::check_inoperative(vec_status, vec_operative, vec_inoperative, gpsTimeStamp);
}
// }}} Action 52
break;
/* Transition for state groupAlarm - message LN_LN_Idle */
case LN_LN_Idle:
  RTDS_MSG_RECEIVE_LN_LN_Idle(sender, gpsTimeStamp, vec_tempOp, vec_tempInop, noiseAveragePreEvent);
  // {{{ Action 51
    {
    LOGS(LE, myIP << " LE/grouplarm/recSNLNDet#LNLNIdl#SNLNIdl#SNLNSummary");

    bool exist = false;

    // 
    // Operativelisten aktualisieren
    //
    for (size_t l = 0; l < vec_tempInop.size(); l++) {
    for (size_t i = 0; i < vec_inoperative.size(); i++) {
    if (vec_inoperative[i].sourceSN == vec_tempInop[l].sourceSN) {
    exist = true;
    break;
    }
  }
if (!exist) {
vec_inoperative.push_back(vec_tempInop[l]);
for (size_t d = 0; d < vec_operative.size(); d++) {
if (vec_operative[d] == vec_tempInop[l].sourceSN) {
vec_operative.erase(vec_operative.begin()+d);
}
}
exist = false;
}
}
//delete vec_tempInop;
//delete vec_tempop;

local::update_timestamp(vec_status, sender, gpsTimeStamp);
local::check_inoperative(vec_status, vec_operative, vec_inoperative, gpsTimeStamp);
}
// }}} Action 51
break;
/* Transition for state groupAlarm - message SN_LN_Idle */
case SN_LN_Idle:
/* Transition for state groupAlarm - message SN_LN_Summary */
case SN_LN_Summary:
  switch(RTDS_currentContext->currentMessage->messageNumber)
    {
    case SN_LN_Idle:
      RTDS_MSG_RECEIVE_SN_LN_Idle(sender, gpsTimeStamp, noiseAverage, batteryVoltage, valueFourthChannel);
      break;
    case SN_LN_Summary:
      RTDS_MSG_RECEIVE_SN_LN_Summary(sender, gpsTimeStamp, tp, ts, tend, pga, pgv, pgd, noiseAverage, cav, ariasIntensity, valueFourthChannel, batteryVoltage);
      break;
    } /* End of switch on message */
  // {{{ update inop
    {
    LOGS(LE, myIP << " LE/grouplarm/recSNLNDet#LNLNIdl#SNLNIdl#SNLNSummary");
    local::update_timestamp(vec_status, sender, gpsTimeStamp);
    local::check_inoperative(vec_status, vec_operative, vec_inoperative, gpsTimeStamp);
    }
  // }}} update inop
  break;
default:
  RTDS_transitionExecuted = 0;
  break;
} /* End of switch on message */
break;
/* Transitions for state systemAlarm */
case systemAlarm:
  switch(RTDS_currentContext->currentMessage->messageNumber)
    {
    /* Transition for state systemAlarm - message SN_LN_Summary */
    case SN_LN_Summary:
      RTDS_MSG_RECEIVE_SN_LN_Summary(  sender,   gpsTimeStamp,   tp,   ts,   tend,   pga,   pgv,   pgd,   noiseAverage,   cav,   ariasIntensity,   valueFourthChannel,   batteryVoltage);
      RTDS_SET_TIMER(t_alarmFinished, T_ALARM_FINISHED);
      foreach(IPAddress gn, GNs) {
      LOGS(LE, myIP << " LE/sysAla/recSNLNSummary");
      LOGS(LE, myIP << " LE/sysAla/sendLNENSummary to " << GNs[GNCount]);
      RTDS_MSG_SEND_LN_EN_Summary_TO_NAME("te_sender", RTDS_process_te_sender,       GNs[GNCount],       getCurrentGPSTime(this),       event,       vec_operative,       vec_inoperative,       vec_decisions,       ariasIntensity);
      }
    SECount = 0;
    RTDS_label4:
    if ( SECount < SNs.size() )
      {
      if ( SNs[SECount] == myIP )
        {
        RTDS_MSG_SEND_LN_SN_Summarise_TO_NAME("SensingEntity", RTDS_process_SensingEntity,         SNs[SECount],         getCurrentGPSTime(this),         event);
        }
      else
        {
        RTDS_MSG_SEND_LN_SN_Summarise_TO_NAME("te_sender", RTDS_process_te_sender,         SNs[SECount],         getCurrentGPSTime(this),         event);
        }
      SECount++;
      }
    else
      {
      sendMessageViaNoti("ews", 4, "systemAlarm -> alarmFinished");
      LOGS(LE, myIP << " *****going to alarmFinished");
      RTDS_SDL_STATE_SET(alarmFinished);
      break;
      }
    goto RTDS_label4;
  /* Transition for state systemAlarm - message * */
  default:
    // {{{ debug/inop

    //DEBUG
    if (RTDS_currentContext->currentMessage->messageNumber == SN_LN_Description) {
    LOGS(LE, myIP << " LE/sysAla/recSNLNDesc");
    size_t k;
    for (k = 0; k < vec_status.size(); k++) {
    if (vec_status[k].sourceSN == sender) {
    vec_status[k].gpsTimeStamp.unixTime = gpsTimeStamp.unixTime;
    vec_status[k].gpsTimeStamp.msFraction = gpsTimeStamp.msFraction;
    vec_status[k].pga = pga;
    vec_status[k].pgv = pgv;
    vec_status[k].pgd = pgd;
    vec_status[k].predominantPeriod = predominantPeriod;
    vec_status[k].cav = cav;
    vec_status[k].ariasIntensity = ariasIntensity;
    vec_status[k].valueFourthChannel = valueFourthChannel;
    break;
    }
  }
for (size_t u = 0; u < vec_decisions.size(); u++) {
if (vec_decisions[u].sourceSN == sender) {
vec_decisions[u] = vec_status[k];
break;
}
}
}
else {
LOGS(LE, myIP << " LE/sysAla/recOther");
}
//ENDDEBUG

local::update_timestamp(vec_status, sender, gpsTimeStamp);
local::check_inoperative(vec_status, vec_operative, vec_inoperative, gpsTimeStamp);

/*if (RTDS_currentContext->currentMessage->messageNumber == LN_LN_Detection) {
//delete vec_tempTriggered;
LOGS(LE, myIP << " LE/sysAla/recLNLNDet");
}
if (RTDS_currentContext->currentMessage->messageNumber == LN_LN_Idle) {
//delete vec_tempInop;
//delete vec_tempop;
LOGS(LE, myIP << " LE/sysAla/recLNLNIdl");
}
if (RTDS_currentContext->currentMessage->messageNumber == LN_LN_Alarm) {
//delete  vec_tempStatus;
LOGS(LE, myIP << " LE/sysAla/recLNLNAla");
}
if (RTDS_currentContext->currentMessage->messageNumber == SN_LN_Idle) {
LOGS(LE, myIP << " LE/sysAla/recSNLNIdl");
}
if (RTDS_currentContext->currentMessage->messageNumber == SN_LN_Detection) {
LOGS(LE, myIP << " LE/sysAla/recSNLNDet");
}
if (RTDS_currentContext->currentMessage->messageNumber == t_LNsDetection) {
LOGS(LE, myIP << " LE/sysAla/recSNLNtLNsDet");
}
if (RTDS_currentContext->currentMessage->messageNumber == t_idle) {
LOGS(LE, myIP << " LE/sysAla/rectidle");
}
if (RTDS_currentContext->currentMessage->messageNumber == t_preAlarm) {
LOGS(LE, myIP << " LE/sysAla/rectpreAla");
}*/

// }}} debug/inop
RTDS_SDL_STATE_SET(systemAlarm);
break;
} /* End of switch on message */
break;
/* Transitions for state alarmFinished */
case alarmFinished:
  switch(RTDS_currentContext->currentMessage->messageNumber)
    {
    /* Transition for state alarmFinished - message SN_LN_Summary */
    case SN_LN_Summary:
      RTDS_MSG_RECEIVE_SN_LN_Summary(  sender,   gpsTimeStamp,   tp,   ts,   tend,   pga,   pgv,   pgd,   noiseAverage,   cav,   ariasIntensity,   valueFourthChannel,   batteryVoltage);
      LOGS(LE, myIP << " LE/alarmFinished/recSNLNSummary");
      LOGS(LE, myIP << " vec_status.size() " << vec_status.size());
      foreach(IPAddress gn, GNs) {
      RTDS_MSG_SEND_LN_EN_Summary_TO_NAME("te_sender", RTDS_process_te_sender,       GNs[GNCount],       getCurrentGPSTime(this),       event,       vec_operative,       vec_inoperative,       vec_decisions,       ariasIntensity);
      }
    break;
  /* Transition for state alarmFinished - message t_alarmFinished */
  case t_alarmFinished:
    // {{{ reset finished
    LOGS(LE, myIP << " LE/alarmFinished/rectAlaFinished");

    vec_triggered.clear();
    vec_alaTriggered.clear();
    vec_decisions.clear();

    local::reset_bool_map(SEInf);
    local::reset_bool_map(LEInf);
    local::reset_bool_map(LEAla);

    lnTriggerCount = 0;
    // }}} reset finished
    RTDS_SET_TIMER(t_idle, T_IDLELN);
    sendMessageViaNoti("ews", 4, "Idle after Alarm Finished");
    RTDS_SDL_STATE_SET(groupIdle);
    break;
  /* Transition for state alarmFinished - message * */
  default:
    // {{{ inop
    LOGS(LE, myIP << " LE/alaFinished/recOther");
    local::update_timestamp(vec_status, sender, gpsTimeStamp);
    local::check_inoperative(vec_status, vec_operative, vec_inoperative, gpsTimeStamp);
    // }}} inop
    break;
  } /* End of switch on message */
break;
/* Transitions for state preAlarm */
case preAlarm:
  switch(RTDS_currentContext->currentMessage->messageNumber)
    {
    /* Transition for state preAlarm - message t_LNsDetection */
    case t_LNsDetection:
      RTDS_RESET_TIMER(t_preAlarm);
      // {{{ reset vars LN
      LOGS(LE, myIP << " LE/preAlarm/rect_LNsDetection");
      snTriggerCount = 0;
      lnTriggerCount = 0;
      local::reset_bool_map(SEInf);
      local::reset_bool_map(LEInf);
      // TODO why not LEAla ?
      // }}} reset vars LN
      SECount = 0;
      RTDS_label5:
      if ( SECount < SNs.size() )
        {
        if ( SNs[SECount] == myIP )
          {
          RTDS_MSG_SEND_LN_SN_FalseAlarm_TO_NAME("SensingEntity", RTDS_process_SensingEntity,           SNs[SECount],           getCurrentGPSTime(this),           timeOfFalseAlarm);
          }
        else
          {
          RTDS_MSG_SEND_LN_SN_FalseAlarm_TO_NAME("te_sender", RTDS_process_te_sender,           SNs[SECount],           getCurrentGPSTime(this),           timeOfFalseAlarm);
          }
        SECount++;
        }
      else
        {
        RTDS_SET_TIMER(t_idle, T_IDLELN);
        sendMessageViaNoti("ews", 4, "groupAlarm/preAlarm -> groupIdle");
        RTDS_SDL_STATE_SET(groupIdle);
        break;
        }
      goto RTDS_label5;
    /* Transition for state preAlarm - message t_preAlarm */
    case t_preAlarm:
      RTDS_RESET_TIMER(t_LNsDetection);
      // {{{ reset vars
      LOGS(LE, myIP << " LE/preAlarm/rectpreAlarm");
      snTriggerCount = 0;
      // TODO why not lnTriggerCount ?
      local::reset_bool_map(SEInf);
      local::reset_bool_map(LEInf);
      // TODO why not LEAla ?
      // }}} reset vars
      SECount = 0;
      RTDS_label6:
      if ( SECount < SNs.size() )
        {
        if ( SNs[SECount] == myIP )
          {
          RTDS_MSG_SEND_LN_SN_FalseAlarm_TO_NAME("SensingEntity", RTDS_process_SensingEntity,           SNs[SECount],           getCurrentGPSTime(this),           timeOfFalseAlarm);
          }
        else
          {
          RTDS_MSG_SEND_LN_SN_FalseAlarm_TO_NAME("te_sender", RTDS_process_te_sender,           SNs[SECount],           getCurrentGPSTime(this),           timeOfFalseAlarm);
          }
        SECount++;
        }
      else
        {
        RTDS_SET_TIMER(t_idle, T_IDLELN);
        sendMessageViaNoti("ews", 4, "groupAlarm/preAlarm -> groupIdle");
        RTDS_SDL_STATE_SET(groupIdle);
        break;
        }
      goto RTDS_label6;
    /* Transition for state preAlarm - message LN_LN_Detection */
    case LN_LN_Detection:
      RTDS_MSG_RECEIVE_LN_LN_Detection(      sender,       gpsTimeStamp,       event,       vec_tempTriggered,       vec_tempInop,       noiseAveragePreEvent);
      // {{{ Actions 13
        {
        LOGS(LE, myIP << " LE/preAlarm/recLNLNDet from " << sender);

        LEInf[sender] = true;
        bool exist = false;

        lnTriggerCount = 0;

        std::map<std::string,bool>::iterator it;
        for (it = LEInf.begin(); it != LEInf.end(); it++)
          {
          if (it->second == true)
          lnTriggerCount++;
          }

        LOGS(LE, "lnTriggerCount is now " << lnTriggerCount);
        /* DEBUG
        std::map<std::string,bool>::iterator it;
        for (it = LEInf.begin(); it != LEInf.end(); it++)
        LOGS(LE, "LEInf: " << it->first << " " << it->second);
        */

        // Liste der getriggerten aktualisieren; hinzufügen von allen unbekannten IPs
        for (size_t k = 0; k < vec_tempTriggered.size(); k++)
          {
          exist = false;
          for (size_t j = 0; j < vec_triggered.size(); j++)
            {
            LOGS(LE, vec_tempTriggered[k].sourceSN <<" "<< vec_triggered[j].sourceSN);
            if (vec_tempTriggered[k].sourceSN == vec_triggered[j].sourceSN)
              {
              exist = true;
              break;
              }
            }
          if (!exist) {
          vec_triggered.push_back(vec_tempTriggered[k]);
          }
        }

      local::update_timestamp(vec_status, sender, gpsTimeStamp);
      local::check_inoperative(vec_status, vec_operative, vec_inoperative, gpsTimeStamp);
      }
    // }}} Actions 13
    if ( lnTriggerCount >= NUM_TRIGGER )
      {
      }
    else
      {
      RTDS_SDL_STATE_SET(preAlarm);
      break;
      }
    RTDS_RESET_TIMER(t_preAlarm);
    RTDS_RESET_TIMER(t_LNsDetection);
    sysAl2:
    Alarm_to_all_LN(RTDS_currentContext, myIP, LNs, LEAla, event, vec_alaTriggered); RTDS_SDL_STATE_SET(RTDS_sdlStatePrev);
    Describe_to_all_SN(RTDS_currentContext, SNs, SEInf, event, myIP); RTDS_SDL_STATE_SET(RTDS_sdlStatePrev);
    goto a2GN;
  /* Transition for state preAlarm - message LN_LN_Alarm */
  case LN_LN_Alarm:
    RTDS_MSG_RECEIVE_LN_LN_Alarm(    sender,     gpsTimeStamp,     event,     vec_tempTriggered);
    RTDS_RESET_TIMER(t_preAlarm);
    RTDS_RESET_TIMER(t_LNsDetection);
      {
      LOGS(LE, myIP << " LE/preAlarm/recLNLNAla");
      SECount = 0;
      LECount = 0;

      LEInf[sender] = true;
      LEAla[sender] = true;

      // merken welche alarming triggered gesendet wurde
      vec_alaTriggered = vec_tempTriggered;

      // oder plus die eigenen
      /*for (size_t k = 0; k < vec_tempTriggered->size(); k++) {
      for (size_t j = 0; j < vec_alaTriggered.size(); j++) {
      if ((*vec_tempGroup)[k].sourceSN == vec_alaTriggered[j].sourceSN) {
      continue;
      }
    vec_alaTriggered.push_back((*vec_tempGroup)[k]);
    }

  }*/

local::update_timestamp(vec_status, sender, gpsTimeStamp);
local::check_inoperative(vec_status, vec_operative, vec_inoperative, gpsTimeStamp);
}
goto sysAl2;
/* Transition for state preAlarm - message SN_LN_Detection */
case SN_LN_Detection:
  RTDS_MSG_RECEIVE_SN_LN_Detection(sender, gpsTimeStamp, tp, a_max, v_max, d_max, noiseAverage, valueFourthChannel, sta_lta_TriggerValue);
  // {{{ Action 14
    {
    snTriggerCount++;
    LOGS(LE, myIP << " LE/groupIdl/recSNLNDet from " << sender);
    LOGS(LE, "snTriggerCount is now " << snTriggerCount);

    // merken dass dieser Node getriggered hat
    SEInf[sender] = true;

    /* DEBUG
    std::map<std::string,bool>::iterator it;
    for (it = SEInf.begin(); it != SEInf.end(); it++)
    LOGS(LE, "SEInf: " << it->first << " " << it->second);
    */

    // add new node to the triggered list
    tTriggeredSNInfo newElement;
    newElement.sourceSN = sender;
    newElement.gpsTimeStamp.unixTime = gpsTimeStamp.unixTime;
    newElement.gpsTimeStamp.msFraction = gpsTimeStamp.msFraction;
    newElement.currentSensorValues = a_max;
    newElement.tp.unixTime = tp.unixTime;
    newElement.tp.msFraction = tp.msFraction;
    newElement.az_max = a_max.z;
    newElement.t_max.unixTime = gpsTimeStamp.unixTime; 
    newElement.t_max.msFraction = gpsTimeStamp.msFraction;
    newElement.max_noise = noiseAverage.acceleration.z;
    newElement.valueFourthChannel = valueFourthChannel;
    newElement.sta_lta_TriggerValue = sta_lta_TriggerValue;
    vec_triggered.push_back(newElement);

    bool dexist = false;
    size_t l;
    for (l = 0; l < vec_status.size(); l++)
      {
      if (vec_status[l].sourceSN == sender)
        {
        vec_status[l].gpsTimeStamp.unixTime = gpsTimeStamp.unixTime;
        vec_status[l].gpsTimeStamp.msFraction = gpsTimeStamp.msFraction;
        vec_status[l].pga = a_max;
        vec_status[l].pgv = v_max;
        vec_status[l].pgd = d_max;
        vec_status[l].valueFourthChannel = valueFourthChannel;
        break;
        } 
      }
    for (size_t u = 0; u < vec_decisions.size(); u++)
      {
      if (vec_decisions[u].sourceSN == sender)
        {
        dexist = true;
        for (size_t v = 0; v < vec_status.size(); v++)
          {
          if (vec_decisions[u].sourceSN == vec_status[v].sourceSN)
            {
            vec_decisions[u] = vec_status[v];
            break;
            }
          }
        break;
        }
      }
    if (!dexist) {
    vec_decisions.push_back(vec_status[l]);
    }

  local::check_inoperative(vec_status, vec_operative, vec_inoperative, gpsTimeStamp);
  }
// }}} Action 14
if ( snTriggerCount > SNs.size() / 2 )
  {
  LEInf[myIP] = true;
  lnTriggerCount++;
  LOGS(LE, "lnTriggerCount is now " << lnTriggerCount);

  // da die eigene gruppe getriggered hat, ist dies auch der alarming vektor
  vec_alaTriggered = vec_triggered;
  if ( lnTriggerCount >= NUM_TRIGGER )
    {
    }
  else
    {
    RTDS_RESET_TIMER(t_preAlarm);
    RTDS_SET_TIMER(t_LNsDetection, T_LNSDETECTION);
    grAla:
    LECount = 0;
    RTDS_label7:
    if ( LECount < LNs.size() )
      {
      if ( LNs[LECount] == myIP )
        {
        }
      else
        {
        RTDS_MSG_SEND_LN_LN_Description_TO_NAME("te_sender", RTDS_process_te_sender,         LNs[LECount],         getCurrentGPSTime(this),         event);
        RTDS_MSG_SEND_LN_LN_Detection_TO_NAME("te_sender", RTDS_process_te_sender,         LNs[LECount],         getCurrentGPSTime(this),         event,         vec_triggered,         vec_inoperative,         noiseAverage);
        }
      LOGS(LE, "sending LNLNDet to " << LNs[LECount]);
      LECount++;
      }
    else
      {
      Describe_to_all_SN(RTDS_currentContext, SNs, SEInf, event, myIP); RTDS_SDL_STATE_SET(RTDS_sdlStatePrev);
      sendMessageViaNoti("ews", 4, "Group Alarm");
      RTDS_SDL_STATE_SET(groupAlarm);
      break;
      }
    goto RTDS_label7;
    }
  }
else
  {
  RTDS_SET_TIMER(t_preAlarm, T_PREALARM);
  RTDS_SDL_STATE_SET(preAlarm);
  break;
  }
RTDS_RESET_TIMER(t_preAlarm);
RTDS_RESET_TIMER(t_LNsDetection);
goto sysAl2;
/* Transition for state preAlarm - message SN_LN_Description */
case SN_LN_Description:
  RTDS_MSG_RECEIVE_SN_LN_Description(sender, gpsTimeStamp, tp, waveType, pga, pgv, pgd, noiseAverage, predominantPeriod, cav, ariasIntensity, valueFourthChannel);
  // {{{ Action 15
    {
    LOGS(LE, myIP << " LE/preAla/recSNLNDesc");

    //aktualisieren der triggervalues
    for (size_t p = 0 ;p < vec_triggered.size(); p++)
      {
      if (vec_triggered[p].sourceSN == sender)
        {
        vec_triggered[p].gpsTimeStamp.unixTime = gpsTimeStamp.unixTime;
        vec_triggered[p].gpsTimeStamp.msFraction = gpsTimeStamp.msFraction;
        vec_triggered[p].tp.unixTime = tp.unixTime;
        vec_triggered[p].tp.msFraction = tp.msFraction;
        if (vec_triggered[p].az_max < pga.z)
          {
          vec_triggered[p].az_max = pga.z;
          vec_triggered[p].t_max.unixTime = gpsTimeStamp.unixTime; 
          vec_triggered[p].t_max.msFraction = gpsTimeStamp.msFraction;
          }
        if (vec_triggered[p].max_noise < noiseAverage.acceleration.z)
          {
          vec_triggered[p].max_noise = noiseAverage.acceleration.z;
          }
        vec_triggered[p].valueFourthChannel = valueFourthChannel;
        }
      }

    for (size_t k = 0; k < vec_status.size(); k++)
      {
      if (vec_status[k].sourceSN == sender)
        {
        vec_status[k].gpsTimeStamp.unixTime = gpsTimeStamp.unixTime;
        vec_status[k].gpsTimeStamp.msFraction = gpsTimeStamp.msFraction;
        vec_status[k].pga = pga;
        vec_status[k].pgv = pgv;
        vec_status[k].pgd = pgd;
        vec_status[k].predominantPeriod = predominantPeriod;
        vec_status[k].cav = cav;
        vec_status[k].ariasIntensity = ariasIntensity;
        vec_status[k].valueFourthChannel = valueFourthChannel;
        break;
        }
      }

    local::check_inoperative(vec_status, vec_operative, vec_inoperative, gpsTimeStamp);
    }
  // }}} Action 15
  if ( snTriggerCount > SNs.size() / 2 )
    {
    LEInf[myIP] = true;
    lnTriggerCount++;
    LOGS(LE, "lnTriggerCount is now " << lnTriggerCount);

    // da die eigene gruppe getriggered hat, ist dies auch der alarming vektor
    vec_alaTriggered = vec_triggered;
    if ( lnTriggerCount >= NUM_TRIGGER )
      {
      }
    else
      {
      RTDS_RESET_TIMER(t_preAlarm);
      RTDS_SET_TIMER(t_LNsDetection, T_LNSDETECTION);
      goto grAla;
      }
    }
  else
    {
    RTDS_SET_TIMER(t_preAlarm, T_PREALARM);
    RTDS_SDL_STATE_SET(preAlarm);
    break;
    }
  RTDS_RESET_TIMER(t_preAlarm);
  RTDS_RESET_TIMER(t_LNsDetection);
  goto sysAl2;
/* Transition for state preAlarm - message SN_LN_Idle */
case SN_LN_Idle:
/* Transition for state preAlarm - message SN_LN_Summary */
case SN_LN_Summary:
  switch(RTDS_currentContext->currentMessage->messageNumber)
    {
    case SN_LN_Idle:
      RTDS_MSG_RECEIVE_SN_LN_Idle(  sender,   gpsTimeStamp,   noiseAverage,   batteryVoltage,   valueFourthChannel);
      break;
    case SN_LN_Summary:
      RTDS_MSG_RECEIVE_SN_LN_Summary(  sender,   gpsTimeStamp,   tp,   ts,   tend,   pga,   pgv,   pgd,   noiseAverage,   cav,   ariasIntensity,   valueFourthChannel,   batteryVoltage);
      break;
    } /* End of switch on message */
  // {{{ update inop preAlarm
  LOGS(LE, myIP << " LE/prelarm/recLNLNIdl#SNLNIdl#SNLNSummary");
  local::update_timestamp(vec_status, sender, gpsTimeStamp);
  local::check_inoperative(vec_status, vec_operative, vec_inoperative, gpsTimeStamp);
  // }}} update inop preAlarm
  break;
/* Transition for state preAlarm - message LN_LN_Idle */
case LN_LN_Idle:
  RTDS_MSG_RECEIVE_LN_LN_Idle(  sender,   gpsTimeStamp,   vec_tempOp,   vec_tempInop,   noiseAverage);
  // {{{ update op/inop preAlarm
  LOGS(LE, myIP << " LE/prelarm/recLNLNIdl#SNLNIdl#SNLNSummary");
    {
    bool exist = false;

    // 
    // Operativelisten aktualisieren
    //
    for (size_t l = 0; l < vec_tempInop.size(); l++)
      {
      for (size_t i = 0; i < vec_inoperative.size(); i++)
        {
        if (vec_inoperative[i].sourceSN == vec_tempInop[l].sourceSN)
          {
          exist = true;
          break;
          }
        }
      if (!exist) {
      vec_inoperative.push_back(vec_tempInop[l]);
      for (size_t d = 0; d < vec_operative.size(); d++)
        {
        if (vec_operative[d] == vec_tempInop[l].sourceSN)
          {
          vec_operative.erase(vec_operative.begin()+d);
          }
        }
      exist = false;
      }
    }
  }

local::update_timestamp(vec_status, sender, gpsTimeStamp);
local::check_inoperative(vec_status, vec_operative, vec_inoperative, gpsTimeStamp);
// }}} update op/inop preAlarm
break;
default:
  RTDS_transitionExecuted = 0;
  break;
} /* End of switch on message */
break;
default:
  RTDS_transitionExecuted = 0;
  break;
} /* End of switch(RTDS_currentContext->sdlState) */
if ( ! RTDS_transitionExecuted )
  {
  switch(RTDS_currentContext->currentMessage->messageNumber)
    {
    case GNsInNetwork:
    /* Transition for state * - message GNsInNetwork */
    RTDS_MSG_SAVE(RTDS_currentContext->currentMessage);
    break;
    case LNsInNetwork:
    /* Transition for state * - message LNsInNetwork */
    RTDS_MSG_SAVE(RTDS_currentContext->currentMessage);
    break;
    } /* End of switch on message */
  } /* End of transition execution test */
// odemx/bricks/RTDS_Proc_end
delete currentMessage;
}; // end of while(true)
// no return here, since this brick does not know the return type
// end ends
}

/* private methods */
void LeadingEntity::Alarm_to_all_LN(RTDS_GlobalProcessInfo * RTDS_currentContext, IPAddress myIP, const ip_vec& LNs, bool_map& LE_Inf_Ala, EventID event, const trig_vec& vec_alaTriggered)
{
    short RTDS_transitionExecuted;
  int RTDS_savedSdlState = 0;

  size_t LECount = 0;
  RTDS_MSG_DATA_DECL

  // silence warning; this variable is not usually used
  RTDS_savedSdlState += 0;

  /* declare framework-side variables for the method */

  /* Initial transition */
  do	/* Dummy do/while(0) to be able to do 'break's */
    {
    RTDS_label1:
    if ( LECount < LNs.size() )
      {
      if ( !(LE_Inf_Ala[LNs[LECount]]) )
        {
        if ( LNs[LECount] == myIP )
          {
          }
        else
          {
          RTDS_MSG_SEND_LN_LN_Alarm_TO_NAME("te_sender", RTDS_process_te_sender,           LNs[LECount],           getCurrentGPSTime(this),           event,           vec_alaTriggered);
          }
        LE_Inf_Ala[LNs[LECount]] = true;
        }
      LECount++;
      }
    else
      {
      RTDS_PROCEDURE_CLEAN_UP; return;
      }
    goto RTDS_label1;
    } while (0);
  // odemx/bricks/RTDS_Proc_loopStart
  while (true) {
  // loop start ends
  /* peek new message from queue */
  currentMessage = msgQRead();
  RTDS_LOG_MESSAGE_RECEIVE(&currentMessage->sender, msgQueue.writer,
  currentMessage->sequenceNumber, getCurrentTime());
  /* Double switch state / signal */
  RTDS_transitionExecuted = 1;
  switch(RTDS_currentContext->sdlState)
    {
    default:
      RTDS_transitionExecuted = 0;
      break;
    } /* End of switch(RTDS_currentContext->sdlState) */
  // odemx/bricks/RTDS_Proc_end
  delete currentMessage;
  }; // end of while(true)
// no return here, since this brick does not know the return type
// end ends
}

void LeadingEntity::Describe_to_all_SN(RTDS_GlobalProcessInfo * RTDS_currentContext, const ip_vec& SNs, bool_map& SEInf, EventID event, const IPAddress& myIP)
{
    short RTDS_transitionExecuted;
  int RTDS_savedSdlState = 0;

  size_t SECount = 0;
  RTDS_MSG_DATA_DECL

  // silence warning; this variable is not usually used
  RTDS_savedSdlState += 0;

  /* declare framework-side variables for the method */

  /* Initial transition */
  do	/* Dummy do/while(0) to be able to do 'break's */
    {
    RTDS_label1:
    if ( SECount < SNs.size() )
      {
      if ( SNs[SECount] == myIP )
        {
        RTDS_MSG_SEND_LN_SN_Describe_TO_NAME("SensingEntity", RTDS_process_SensingEntity,         SNs[SECount],         getCurrentGPSTime(this),         event);
        }
      else
        {
        RTDS_MSG_SEND_LN_SN_Describe_TO_NAME("te_sender", RTDS_process_te_sender,         SNs[SECount],         getCurrentGPSTime(this),         event);
        }
      SEInf[SNs[SECount]] = true;
      SECount++;
      }
    else
      {
      RTDS_PROCEDURE_CLEAN_UP; return;
      }
    goto RTDS_label1;
    } while (0);
  // odemx/bricks/RTDS_Proc_loopStart
  while (true) {
  // loop start ends
  /* peek new message from queue */
  currentMessage = msgQRead();
  RTDS_LOG_MESSAGE_RECEIVE(&currentMessage->sender, msgQueue.writer,
  currentMessage->sequenceNumber, getCurrentTime());
  /* Double switch state / signal */
  RTDS_transitionExecuted = 1;
  switch(RTDS_currentContext->sdlState)
    {
    default:
      RTDS_transitionExecuted = 0;
      break;
    } /* End of switch(RTDS_currentContext->sdlState) */
  // odemx/bricks/RTDS_Proc_end
  delete currentMessage;
  }; // end of while(true)
// no return here, since this brick does not know the return type
// end ends
}

