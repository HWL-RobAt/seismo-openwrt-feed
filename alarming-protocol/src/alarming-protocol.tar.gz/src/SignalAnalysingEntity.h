/*SX*//** @file
 *  Generated file, find templates in SX folders
 */

#ifndef SIGNALANALYSINGENTITY_UP_H_INCLUDED
#define SIGNALANALYSINGENTITY_UP_H_INCLUDED
#ifndef _SIGNALANALYSINGENTITY_H_
#define _SIGNALANALYSINGENTITY_H_

#include "blockClass_Node.h"

#endif
#endif

#ifndef SIGNALANALYSINGENTITY_H_INCLUDED
#define SIGNALANALYSINGENTITY_H_INCLUDED

#include "RTDS_SDLPROCESS.h"

/**@brief The process SignalAnalysingEntity 
 */
class SignalAnalysingEntity : public RTDS::SDLProcess {
public:

    /**@brief Constructor.
     */
    SignalAnalysingEntity(RTDS::Logger& logger = RTDS::emptyLogger);

    /**@brief Lifeline of this process.
     */
    virtual int main();

private:
    
};

#ifndef _SIGNALANALYSINGENTITY_H_
#define _SIGNALANALYSINGENTITY_H_

#include "blockClass_Node.h"

#endif

#endif
