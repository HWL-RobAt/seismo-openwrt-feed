/*SX*//** @file
 *  Generated file, find templates in SX folders
 */
#include <boost/thread/thread.hpp>
#include <boost/bind.hpp>

#include "RTDS_gen.h"
#include "SignalAnalysingEntity.h"
#include "RTDS_messages.h"

#define RTDS_PROCESS_NUMBER RTDS_process_SignalAnalysingEntity
#define RTDS_PROCESS_NAME SignalAnalysingEntity

/*
** PROCESS SignalAnalysingEntity:
** ------------------------------
*/

SignalAnalysingEntity::SignalAnalysingEntity(RTDS::Logger& logger)
: SDLProcess(logger)
{
    RTDS_LOG_PROCESS_CREATION(msgQueue.writer, "SignalAnalysingEntity", cover);
}

int SignalAnalysingEntity::main()
{
    short RTDS_transitionExecuted;
  int RTDS_savedSdlState = 0;

  es_signal_analysing::SignalAnalyser* signalAnalyser;
  bool pWave = false; 
  bool sWave = false; 
  bool endOfEvent = false; 
  tSensorData data; 
  IPAddress myIP = "000.000.000.000";
  tSensorData tempNoise;
  tSharedData *SharedData = new tSharedData();
  XMLStreamingLogger* xmllogger = dynamic_cast<XMLStreamingLogger*>(&logger);
  RTDS_MSG_DATA_DECL

  // silence warning; this variable is not usually used
  RTDS_savedSdlState += 0;

  /* starts stdio.run() asynchronous stops when isRunnings destructor is destroyed */
  boost::thread _workThread_t(boost::bind(&boost::asio::io_service::run, &ioService));
  std::auto_ptr<boost::asio::io_service::work> _workThread_ptr(isRunning);
  isRunning = 0;

  /* declare framework-side variables for the process */

  /* Initial transition */
  RTDS_MSG_SEND_SendPShared_TO_NAME("SensingEntity", RTDS_process_SensingEntity,   SharedData);
  RTDS_MSG_SEND_SendPShared_TO_NAME("ManagingEntity", RTDS_process_ManagingEntity,   SharedData);
  signalAnalyser = 
  new es_signal_analysing::SignalAnalyser(
  SharedData->SAMPLERATE, 
  SharedData->PSHORTWINDOW, 
  SharedData->PSLRATIO, 
  SharedData->PDELAY, 
  SharedData->PGAMMA, 
  globalPWaveTriggerThreshold, 
  SharedData->SSHORTWINDOW, 
  SharedData->SCUTOFF);
  LOGS(SAE, "\n" << SharedData << " Starting Signalanalyser:\n"
  << "SAMPLERATE: " << SharedData->SAMPLERATE
  << " PSHORTWINDOW: " << SharedData->PSHORTWINDOW
  << " PSLRATIO: " << SharedData->PSLRATIO
  << " PDELAY: " << SharedData->PDELAY
  << " PGAMMA: " << SharedData->PGAMMA
  << " PCUTOFF: " << globalPWaveTriggerThreshold
  << " SSHORTWINDOW: " << SharedData->SSHORTWINDOW
  << " SCUTOFF: " << SharedData->SCUTOFF
  );
  RTDS_SDL_STATE_SET(noEvent);
  // odemx/bricks/RTDS_Proc_loopStart
  while (true) {
  // loop start ends
  /* peek new message from queue */
  currentMessage = msgQRead();
  RTDS_LOG_MESSAGE_RECEIVE(&currentMessage->sender, msgQueue.writer,
  currentMessage->sequenceNumber, getCurrentTime());
  /* Double switch state / signal */
  RTDS_transitionExecuted = 1;
  switch(RTDS_currentContext->sdlState)
    {
    /* Transitions for state noEvent */
    case noEvent:
      switch(RTDS_currentContext->currentMessage->messageNumber)
        {
        /* Transition for state noEvent - message nextRecord */
        case nextRecord:
          RTDS_MSG_RECEIVE_nextRecord(      data);
          // {{{ pwave detection
          signalAnalyser->processNextRecord(data.timeindex, data.northsouth, data.eastwest, data.z);
          pWave = signalAnalyser->isPTriggered();

          if (xmllogger)
          xmllogger->logStateVariable(msgQueue.writer, signalAnalyser->getStaLtaValue(),getCurrentTime(),"P_WAVE_SNR");

          // put sensor data into shared memory
          if (pWave) {
          // only record the first time of pWave
          if (SharedData->tp.unixTime == 0) {
          LOGS(SAE, "### FIRST P-WAVE in " << SharedData << " ###");
          SharedData->tp.unixTime = time(0);
          SharedData->tp.msFraction = 0;
          }
        SharedData->waveType = PWave;
        SharedData->sta_lta_TriggerValue = signalAnalyser->getStaLtaValue();
        LOGS(SAE, "pWave sta_lta_TriggerValue: " << SharedData->sta_lta_TriggerValue);

        // only record max values
        if (signalAnalyser->P->Pam().second > SharedData->a_max.z)
        SharedData->a_max.z = signalAnalyser->P->Pam().second;
        if (signalAnalyser->P->Pvm().second > SharedData->v_max.z)
        SharedData->v_max.z = signalAnalyser->P->Pvm().second;
        if (signalAnalyser->P->Pdm().second > SharedData->d_max.z)
        SharedData->d_max.z = signalAnalyser->P->Pdm().second;
        }

      //SharedData->noiseAverage.acceleration.e = 0;
      //SharedData->noiseAverage.acceleration.n = 0;
      SharedData->noiseAverage.acceleration.z = signalAnalyser->P->Pam().second;
      SharedData->noiseAverage.timeWindowLength = SharedData->PSHORTWINDOW * SharedData->PSLRATIO;
      SharedData->batteryVoltage = 0.0;
      SharedData->valueFourthChannel = 0.0;

      // not available in pWave

      /*SharedData->ts;
      SharedData->tend;
      SharedData->pga;
      SharedData->pgv;
      SharedData->pgd;
      SharedData->predominantPeriod;
      SharedData->cav;
      SharedData->ariasIntensity;
      */
      // }}} pwave detection
      if ( !(pWave) )
        {
        break;
        }
      else if ( pWave )
        {
        LOGS(SAE, "\n\n****PWave Detected Sending EventDetected*************************" );
        sendMessageViaNoti("ews", 4, "SAE: noEvent -> eventDetected");
        RTDS_MSG_QUEUE_SEND_TO_NAME(EventDetected, 0, NULL, "SensingEntity", RTDS_process_SensingEntity);
        RTDS_SET_TIMER(t_Swave, T_SAE_SWAVE);
        RTDS_SDL_STATE_SET(eventDetected);
        break;
        }
    default:
      RTDS_transitionExecuted = 0;
      break;
    } /* End of switch on message */
  break;
/* Transitions for state eventDescribed */
case eventDescribed:
  switch(RTDS_currentContext->currentMessage->messageNumber)
    {
    /* Transition for state eventDescribed - message t_EventFinished */
    case t_EventFinished:
      RTDS_MSG_QUEUE_SEND_TO_NAME(EventFinished, 0, NULL, "SensingEntity", RTDS_process_SensingEntity);
      RTDS_RESET_TIMER(t_EventDescribed);
      signalAnalyser->reset();
      sendMessageViaNoti("ews", 4, "SAE: eventDescribed -> noEvent");
      RTDS_SDL_STATE_SET(noEvent);
      break;
    /* Transition for state eventDescribed - message t_EventDescribed */
    case t_EventDescribed:
      RTDS_MSG_QUEUE_SEND_TO_NAME(EventDescribed, 0, NULL, "SensingEntity", RTDS_process_SensingEntity);
      RTDS_SET_TIMER(t_EventDescribed, T_SAE_EVENTDESCRIBED);
      break;
    /* Transition for state eventDescribed - message nextRecord */
    case nextRecord:
      RTDS_MSG_RECEIVE_nextRecord(      data);
      // {{{ description
      signalAnalyser->processNextRecord(data.timeindex, data.northsouth, data.eastwest, data.z);

      if (xmllogger)
      xmllogger->logStateVariable(msgQueue.writer, signalAnalyser->getStaLtaValue(),getCurrentTime(),"P_WAVE_SNR");

      // put sensor data into shared memory
      SharedData->sta_lta_TriggerValue = signalAnalyser->getStaLtaValue();
      LOGS(SAE, "sta_lta_TriggerValue: " << SharedData->sta_lta_TriggerValue);
      // only record max values
      if (signalAnalyser->S->PGAm().second > SharedData->pga.z) {
      SharedData->pga.z = signalAnalyser->S->PGAm().second;
      SharedData->pga.n = signalAnalyser->S->PGAn().second;
      SharedData->pga.e = signalAnalyser->S->PGAe().second;
      }
    if (signalAnalyser->S->PGVm().second > SharedData->pgv.z) {
    SharedData->pgv.z = signalAnalyser->S->PGVm().second;
    SharedData->pgv.n = signalAnalyser->S->PGVn().second;
    SharedData->pgv.e = signalAnalyser->S->PGVe().second;
    }
  if (signalAnalyser->S->PGDm().second > SharedData->pgd.z) {
  SharedData->pgd.z = signalAnalyser->S->PGDm().second;
  SharedData->pgd.n = signalAnalyser->S->PGDn().second;
  SharedData->pgd.e = signalAnalyser->S->PGDe().second;
  }

SharedData->cav = signalAnalyser->S->CAVsz();
SharedData->ariasIntensity = signalAnalyser->S->ARIsz();

SharedData->noiseAverage.acceleration.e = signalAnalyser->S->PGAe().second;;
SharedData->noiseAverage.acceleration.n = signalAnalyser->S->PGAn().second;;
SharedData->noiseAverage.acceleration.z = signalAnalyser->S->PGAm().second;
SharedData->noiseAverage.timeWindowLength = SharedData->PSHORTWINDOW * SharedData->PSLRATIO;
SharedData->batteryVoltage = 0.0;
SharedData->valueFourthChannel = 0.0;

// not clear
/*
SharedData->tend;
SharedData->predominantPeriod;
*/

endOfEvent = false;
// }}} description
if ( !(endOfEvent) )
  {
  break;
  }
RTDS_MSG_QUEUE_SEND_TO_NAME(EventFinished, 0, NULL, "SensingEntity", RTDS_process_SensingEntity);
RTDS_RESET_TIMER(t_EventDescribed);
signalAnalyser->reset();
sendMessageViaNoti("ews", 4, "SAE: eventDescribed -> noEvent");
RTDS_SDL_STATE_SET(noEvent);
break;
default:
  RTDS_transitionExecuted = 0;
  break;
} /* End of switch on message */
break;
/* Transitions for state eventDetected */
case eventDetected:
  switch(RTDS_currentContext->currentMessage->messageNumber)
    {
    /* Transition for state eventDetected - message nextRecord */
    case nextRecord:
      RTDS_MSG_RECEIVE_nextRecord(  data);
      // {{{ swave detection
      signalAnalyser->processNextRecord(data.timeindex, data.northsouth, data.eastwest, data.z);
      sWave = signalAnalyser->isSTriggered();

      // update the pga, pgv, pgd values and take only the max values
      if (signalAnalyser->S->PGAm().second > SharedData->pga.z) {
      SharedData->pga.z = signalAnalyser->S->PGAm().second;
      SharedData->pga.n = signalAnalyser->S->PGAn().second;
      SharedData->pga.e = signalAnalyser->S->PGAe().second;
      }
    if (signalAnalyser->S->PGVm().second > SharedData->pgv.z) {
    SharedData->pgv.z = signalAnalyser->S->PGVm().second;
    SharedData->pgv.n = signalAnalyser->S->PGVn().second;
    SharedData->pgv.e = signalAnalyser->S->PGVe().second;
    }
  if (signalAnalyser->S->PGDm().second > SharedData->pgd.z) {
  SharedData->pgd.z = signalAnalyser->S->PGDm().second;
  SharedData->pgd.n = signalAnalyser->S->PGDn().second;
  SharedData->pgd.e = signalAnalyser->S->PGDe().second;
  }

if (xmllogger)
xmllogger->logStateVariable(msgQueue.writer, signalAnalyser->getStaLtaValue(),getCurrentTime(),"P_WAVE_SNR");

// put sensor data into shared memory
if (sWave) {
// only record the first time of sWave
if (SharedData->ts.unixTime == 0) {
LOGS(SAE, "### FIRST S-WAVE in " << SharedData << " ###");
SharedData->ts.unixTime = time(0);
SharedData->ts.msFraction = 0;
}
SharedData->waveType = SWave;
SharedData->sta_lta_TriggerValue = signalAnalyser->getStaLtaValue();
LOGS(SAE, "sWave sta_lta_TriggerValue: " << SharedData->sta_lta_TriggerValue);

SharedData->cav = signalAnalyser->S->CAVsz();
SharedData->ariasIntensity = signalAnalyser->S->ARIsz();
} else {
// only if pWave noiseAverage should be saved
//SharedData->noiseAveragePreEvent.acceleration.e = 0;
//ShkaredData.noiseAveragePreEvent.acceleration.n = 0;
//SharedData->noiseAveragePreEvent.acceleration.z = signalAnalyser->S->Pam().second;
//SharedData->noiseAveragePreEvent.timeWindowLength = SharedData->PSHORTWINDOW * SharedData->PSLRATIO;
}

SharedData->noiseAverage.acceleration.e = signalAnalyser->S->PGAe().second;
SharedData->noiseAverage.acceleration.n = signalAnalyser->S->PGAn().second;
SharedData->noiseAverage.acceleration.z = signalAnalyser->S->PGAm().second;
SharedData->noiseAverage.timeWindowLength = SharedData->PSHORTWINDOW * SharedData->PSLRATIO;
SharedData->batteryVoltage = 0.0;
SharedData->valueFourthChannel = 0.0;

// not clear
/*
SharedData->tend;
SharedData->predominantPeriod;
*/

// }}} swave detection
if ( !(sWave) )
  {
  break;
  }
else if ( sWave )
  {
  LOGS(SAE, "\n\n****SWave Detected Sending EventDescribed*************************" );
  sendMessageViaNoti("ews", 4, "SAE: eventDetected -> eventDescribed");
  RTDS_MSG_QUEUE_SEND_TO_NAME(EventDescribed, 0, NULL, "SensingEntity", RTDS_process_SensingEntity);
  RTDS_SET_TIMER(t_EventFinished, T_SAE_EVENTFINISHED);
  RTDS_SET_TIMER(t_EventDescribed, T_SAE_EVENTDESCRIBED);
  RTDS_RESET_TIMER(t_Swave);
  RTDS_SDL_STATE_SET(eventDescribed);
  break;
  }
/* Transition for state eventDetected - message t_Swave */
case t_Swave:
  RTDS_MSG_QUEUE_SEND_TO_NAME(NoEvent, 0, NULL, "SensingEntity", RTDS_process_SensingEntity);
  signalAnalyser->reset();
  sendMessageViaNoti("ews", 4, "SAE: eventDetected -> noEvent");
  RTDS_SDL_STATE_SET(noEvent);
  break;
default:
  RTDS_transitionExecuted = 0;
  break;
} /* End of switch on message */
break;
default:
  RTDS_transitionExecuted = 0;
  break;
} /* End of switch(RTDS_currentContext->sdlState) */
// odemx/bricks/RTDS_Proc_end
delete currentMessage;
}; // end of while(true)
// no return here, since this brick does not know the return type
// end ends
}

/* private methods */
