
#include "RTDS_SDLBLOCK.h"

namespace RTDS
{
  using std::vector;
  
  void SDLBlock::embed(MessageQueue::qWriter& writer, unsigned id)
  {
    if (context.size() <= id)
      context.resize(id+1, 0);
    context[id] = &writer;
    
    if (cover)
      cover->embed(writer, id);
  }
  
  SDLBlock::SDLBlock(Logger& _logger)
  : cover(0),
    logger(_logger)
  {}
  
  void SDLBlock::embed(SDLBlock& block)
  {
    vector<MessageQueue::qWriter*>::iterator iter;
    unsigned id;
    block.cover = this;
    
    iter = block.context.begin(); id = 0;
    while (iter != block.context.end())
    {
      if (*iter)
        embed(**iter, id);
      ++id;
      ++iter;
    }
  }
  
  void SDLBlock::embed(SDLProcess& process, unsigned id)
  {
    embed(*process.msgQueue.writer, id);
    process.cover = this;
  }
  
  MessageQueue::qWriter* SDLBlock::getMsgQWriterByID(unsigned id) const
  {
    if (context.size() <= id || !context[id])
      return (cover) ? cover->getMsgQWriterByID(id) : 0;
    
    return context[id];
  }
}
