/** @file
 * @brief XML logger, part of `shared_src`
 * @date 28.06.2008
 * @author Ingmar Eveslage, Michael Piefel
 */

#include "XMLStreamingLogger.h"
#include "RTDS_MSGQUEUE.h"
#include <sstream>
#include <iostream>
#include <sys/time.h>
#include <stdint.h>
#include <cstdio>

#ifdef BOOST
#include <boost/interprocess/sync/interprocess_mutex.hpp>
#include <boost/interprocess/sync/scoped_lock.hpp>
#endif

#include <csignal>
#include <algorithm>
#include <stdexcept>
#include <map>
#include <boost/lexical_cast.hpp>
#include "logging.h"

// Helper and configuration ///////////////////////////////////////////////////////////////////////
const int MAX_MSG_PER_FILE = 10000;

template <class T> inline string to_string (const T& t) {
    return boost::lexical_cast<std::string>(t);
}

typedef std::map<RTDS::Logger::ID, int> pointer_map;
template <> inline string to_string (const RTDS::Logger::ID& pointer) {
    if (pointer == 0)
	return "0";
    static pointer_map ids;  ///< a map to store integers for pointers
    static int next_id = 0;  ///< the next integer to use as a substitute

    pointer_map::iterator this_pointer = ids.find(pointer);
    if (this_pointer == ids.end())
	this_pointer = ids.insert(std::pair<RTDS::Logger::ID, int>(pointer, ++next_id)).first;

    return boost::lexical_cast<std::string>(this_pointer->second);
}

/** Determine current real time in milliseconds.
 *  @return the number of milliseconds since the epoch
 */
uint64_t getCurrentRealTime() {
    struct timeval cur;
    gettimeofday(&cur, NULL);

    uint64_t currentMilliSec;
    currentMilliSec = uint64_t(cur.tv_sec) * 1000;
    currentMilliSec += cur.tv_usec / 1000;
    return currentMilliSec;
}

// Implementation of class XMLStreamingLogger /////////////////////////////////////////////////////
XMLStreamingLogger::XMLStreamingLogger(string stationName, string fileName, string ipAddress,
	const int* groupId, float longitude, float latitude, float height,
	string comment, int logLevel, bool diffable_logs)
: 	message_counter(0),
	file_counter(0),
	base_filename(fileName),
	stationName(stationName),
	ipAddress(ipAddress),
	groupId(groupId),
	longitude(longitude),
	latitude(latitude),
	height(height),
	comment(comment),
	currentFileName(""),
	compress_logs(!diffable_logs),
	split_files(!diffable_logs),
	use_time_stamp(!diffable_logs)
{
    createLogLevel(logLevel);
    createdLoggerList.push_back(this);

    //signal(SIGINT, XMLStreamingLoggerSignalHandler);
#ifdef BOOST
    signal(SIGSEGV, XMLStreamingLoggerSignalHandler);
    signal(SIGTERM, XMLStreamingLoggerSignalHandler);
#endif
    createNewXMLFile();
}

XMLStreamingLogger::~XMLStreamingLogger() {
	close();

	std::_List_iterator<XMLStreamingLogger*> temp = find(createdLoggerList.begin(), createdLoggerList.end(), this);
	if(temp != createdLoggerList.end())
		createdLoggerList.erase(temp);
}

void XMLStreamingLogger::close() {
#ifdef BOOST
	boost::interprocess::scoped_lock<boost::interprocess::interprocess_mutex> lock(myMutex);
	LOGS(XMLLOG, "mutex locked ");
#endif

	//close messageList
	myXMLWriter->CloseLasttag();
	LOGS(XMLLOG, filename << ": last tag closed");

	myXMLWriter->Createtag("processList");

	std::list<ProcessInstance>::iterator processIterator;
	for (processIterator = processInstanceList.begin(); processIterator != processInstanceList.end(); processIterator++) {
		myXMLWriter->AddAtributes("id", to_string(processIterator->processID));
		if(processIterator->hasGID)
			myXMLWriter->AddAtributes("gid", to_string(processIterator->gid));
		myXMLWriter->Createtag("process");
		myXMLWriter->CreateChild("listed_type_id", processIterator->processType);
		//myXMLWriter->CreateChild("description", processIterator->description);
		myXMLWriter->CloseLasttag();
	}
	LOGS(XMLLOG, filename << ": pl finished ");

	myXMLWriter->CloseAlltags();
	LOGS(XMLLOG, filename << ": closealltags ");

	delete myXMLWriter;

	if (compress_logs) {
		string command = "gzip " + filename + "&";
		system(command.c_str());
		LOGS(XMLLOG, filename << ": compressed");
	}

}

void XMLStreamingLogger::step_message_counter() {
    ++message_counter;
    if (split_files && message_counter >= MAX_MSG_PER_FILE) {
	message_counter = 0;
	createNewLog();
    }
}

void XMLStreamingLogger::logSend(ID sender, ID destinationID, long long simTime, const char* messageType,
	const RTDS::MsgHeader* messageContent, int sequenceNumber)
{
	// if messageType is in currentLogLevel, then message is not logged
	if(currentLogLevel.count(messageType))
		return;
	step_message_counter();
#ifdef BOOST
	boost::interprocess::scoped_lock<boost::interprocess::interprocess_mutex> lock(myMutex);
#endif
	myXMLWriter->AddAtributes("id", to_string(sequenceNumber));
	myXMLWriter->Createtag("innerNodeMessage");
	myXMLWriter->CreateChild("source_id", to_string(sender));
	myXMLWriter->CreateChild("time_index", to_string(simTime));
	myXMLWriter->CreateChild("listed_type_id", messageType);
	myXMLWriter->CreateChild("content",
		to_string(messageContent->dataLength) + " " +
		to_string((ID) &(messageContent->sender)) + " " +
		to_string(messageContent->sequenceNumber));
	myXMLWriter->CreateChild("destination_id", to_string(destinationID));
	myXMLWriter->CloseLasttag();
}

void XMLStreamingLogger::logReceive(ID sender, ID receiver, int sequenceNumber, long long simTime)
{
	//TODO handle receive
	step_message_counter();
#ifdef BOOST
	boost::interprocess::scoped_lock<boost::interprocess::interprocess_mutex> lock(myMutex);
#endif
	myXMLWriter->AddAtributes("id", to_string(sequenceNumber));
	myXMLWriter->Createtag("receivedMessage");
	myXMLWriter->CreateChild("source_id", to_string(receiver));
	myXMLWriter->CreateChild("time_index", to_string(simTime));
	myXMLWriter->CreateChild("sender_id", to_string(sender));
	myXMLWriter->CloseLasttag();
}

void XMLStreamingLogger::logExternSend(ID sender, string receiver, string messageType, long long simTime, string aSN1Msg, unsigned int sequenceNumber)
{
	// if messageType is in currentLogLevel, then message is not logged
	if(currentLogLevel.count(messageType))
		return;
	step_message_counter();
#ifdef BOOST
	boost::interprocess::scoped_lock<boost::interprocess::interprocess_mutex> lock(myMutex);
#endif
	myXMLWriter->AddAtributes("id", to_string(sequenceNumber));
	myXMLWriter->Createtag("interNodeMessage");
	myXMLWriter->CreateChild("source_id", to_string(sender));
	myXMLWriter->CreateChild("time_index", to_string(simTime));
	myXMLWriter->CreateChild("listed_type_id", messageType);
	if( !aSN1Msg.empty() )
		myXMLWriter->CreateChild("content", aSN1Msg);
	myXMLWriter->CreateChild("destination_ip", receiver);
	myXMLWriter->CloseLasttag();
}

void XMLStreamingLogger::logExternReceive(string sender, ID receiver, unsigned int sequenceNumber, long long simTime)
{
	//TODO: handle receive
	step_message_counter();
#ifdef BOOST
	boost::interprocess::scoped_lock<boost::interprocess::interprocess_mutex> lock(myMutex);
#endif
	myXMLWriter->AddAtributes("id", to_string(sequenceNumber));
	myXMLWriter->Createtag("receivedMessage");
	myXMLWriter->CreateChild("source_id", to_string(receiver));
	myXMLWriter->CreateChild("time_index", to_string(simTime));
	myXMLWriter->CreateChild("sender_ip", sender);
	myXMLWriter->CloseLasttag();
}

void XMLStreamingLogger::logProcessCreation(ID processID, const char* processType, ID gid)
{
#ifdef BOOST
	boost::interprocess::scoped_lock<boost::interprocess::interprocess_mutex> lock(myMutex);
#endif
	ProcessInstance* newProcess = new ProcessInstance();
	newProcess->hasGID = true;
	newProcess->gid = gid;
	newProcess->processID = processID;
	newProcess->processType = processType;

	processInstanceList.push_back(*newProcess);
}

void XMLStreamingLogger::logSetTimer(ID processID, int sequenceNumber, const char* timerName, long long currentTime, int duration)
{
	// if timerName is in currentLogLevel, then message is not logged
	if(currentLogLevel.count(timerName))
		return;
	step_message_counter();
#ifdef BOOST
	boost::interprocess::scoped_lock<boost::interprocess::interprocess_mutex> lock(myMutex);
#endif
	myXMLWriter->AddAtributes("timer_id", to_string(sequenceNumber));
	myXMLWriter->Createtag("timerStartMessage");
	myXMLWriter->CreateChild("source_id", to_string(processID));
	myXMLWriter->CreateChild("time_index", to_string(currentTime));
	myXMLWriter->CreateChild("name", timerName);
	myXMLWriter->CreateChild("duration", to_string(duration));
	myXMLWriter->CloseLasttag();
}
void XMLStreamingLogger::logResetTimer(ID processID, int sequenceNumber, const char* timerName, long long currentTime)
{
	// if timerName is in currentLogLevel, then message is not logged
	if(currentLogLevel.count(timerName))
		return;
	step_message_counter();
#ifdef BOOST
	boost::interprocess::scoped_lock<boost::interprocess::interprocess_mutex> lock(myMutex);
#endif
	myXMLWriter->AddAtributes("timer_id", to_string(sequenceNumber));
	myXMLWriter->Createtag("timerStopMessage");
	myXMLWriter->CreateChild("source_id", to_string(processID));
	myXMLWriter->CreateChild("time_index", to_string(currentTime));
	myXMLWriter->CreateChild("name", timerName);
	myXMLWriter->CloseLasttag();
}
void XMLStreamingLogger::logFireTimer(ID processID, int sequenceNumber, long long currentTime)
{
	//TODO: handle timer fire
	step_message_counter();
#ifdef BOOST
	boost::interprocess::scoped_lock<boost::interprocess::interprocess_mutex> lock(myMutex);
#endif
	myXMLWriter->AddAtributes("timer_id", to_string(sequenceNumber));
	myXMLWriter->Createtag("timerFireMessage");
	myXMLWriter->CreateChild("source_id", to_string(processID));
	myXMLWriter->CreateChild("time_index", to_string(currentTime));
	myXMLWriter->CloseLasttag();
}

void XMLStreamingLogger::logStateChange(ID processID, const char* newState, long long simTime)
{
	//if newState is not in currentLogLevel, then message is logged
	if(currentLogLevel.find(newState) != currentLogLevel.end())
		return;
	step_message_counter();
#ifdef BOOST
	boost::interprocess::scoped_lock<boost::interprocess::interprocess_mutex> lock(myMutex);
#endif
	myXMLWriter->Createtag("stateChangeMessage");
	myXMLWriter->CreateChild("source_id", to_string(processID));
	myXMLWriter->CreateChild("time_index", to_string(simTime));
	myXMLWriter->CreateChild("name", newState);
	myXMLWriter->CloseLasttag();
}

void XMLStreamingLogger::logStateVariable(ID processID, double content, long long simTime, string name)
{
	step_message_counter();
#ifdef BOOST
	boost::interprocess::scoped_lock<boost::interprocess::interprocess_mutex> lock(myMutex);
#endif
	myXMLWriter->Createtag("stateVariableMessage");
	myXMLWriter->CreateChild("source_id", to_string(processID));
	myXMLWriter->CreateChild("time_index", to_string(simTime));
	myXMLWriter->CreateChild("name", name);
	
//FIXME bad bugfix of stdlibc++ 4.1.2
	char str[40];
	sprintf(str, "%f", content);
	myXMLWriter->CreateChild("contentDouble", to_string(str));
	myXMLWriter->CloseLasttag();
  //}
}

void XMLStreamingLogger::logStateVariable(ID processID, int content, long long simTime, string name)
{
	step_message_counter();
#ifdef BOOST
	boost::interprocess::scoped_lock<boost::interprocess::interprocess_mutex> lock(myMutex);
#endif
	myXMLWriter->Createtag("stateVariableMessage");
	myXMLWriter->CreateChild("source_id", to_string(processID));
	myXMLWriter->CreateChild("time_index", to_string(simTime));
	myXMLWriter->CreateChild("name", name);
	myXMLWriter->CreateChild("contentInteger", to_string(content));
	myXMLWriter->CloseLasttag();
  //}
}

void XMLStreamingLogger::logStateVariable(ID processID, string content, long long simTime, string name)
{
	step_message_counter();
#ifdef BOOST
	boost::interprocess::scoped_lock<boost::interprocess::interprocess_mutex> lock(myMutex);
#endif
	myXMLWriter->Createtag("stateVariableMessage");
	myXMLWriter->CreateChild("source_id", to_string(processID));
	myXMLWriter->CreateChild("time_index", to_string(simTime));
	myXMLWriter->CreateChild("name", name);
	myXMLWriter->CreateChild("contentString", content);
	myXMLWriter->CloseLasttag();
  //}
}

void XMLStreamingLogger::createNewLog()
{
	close();
#ifdef BOOST
	boost::interprocess::scoped_lock<boost::interprocess::interprocess_mutex> lock(myMutex);
#endif
	createNewXMLFile();
}


// Member for signal handling
std::list<XMLStreamingLogger*> XMLStreamingLogger::createdLoggerList;

void XMLStreamingLogger::XMLStreamingLoggerSignalHandler(int sig) {
    LOGS_ALWAYS(XMLLOG, "SIGNAL gefangen");
    //throw std::runtime_error("test");
    while (!createdLoggerList.empty()) {
	LOGS(XMLLOG, "get loggerlist and call delete ");
	XMLStreamingLogger* temp = createdLoggerList.front();
	delete temp;
    }

    switch (sig) {
    case SIGSEGV:
	LOGS_ALWAYS(XMLLOG, "SIGSEGV gefangen");
	break;
    case SIGTERM:
	LOGS_ALWAYS(XMLLOG, "SIGTERM gefangen");
	break;
    }
    exit(sig);

}


// creates a new XML file with its header
void XMLStreamingLogger::createNewXMLFile() {
    filename = "";

    if (base_filename.compare("") == 0) {
	filename = stationName;
    } else {
	filename = base_filename;
    }
    if (use_time_stamp) {
	filename.append("_");
	filename.append(to_string(time(0)));
    }
    if (split_files) {
	filename.append("_");
	filename.append(to_string(++file_counter));
    }
    filename.append(".xml");

    LOGS(XMLLOG, "creating_new_log: " << filename);

    // the XML must be valid according to SOSEWINNodeLog.xsd located in DBAT de.hub.sam.es.dbat.ems.file.msc
    myXMLWriter = new xmlwriter(filename);
    myXMLWriter->AddAtributes("xmlns:xsi", "http://www.w3.org/2001/XMLSchema-instance");
    if (currentFileName.compare("") != 0)
	myXMLWriter->AddAtributes("previous_logfile", currentFileName);
    if (use_time_stamp) {
	myXMLWriter->AddAtributes("start_time", to_string(getCurrentRealTime()));
	myXMLWriter->AddAtributes("creator_svn_version", CREATOR_SVN_VERSION);
    }
    currentFileName = filename;
    myXMLWriter->Createtag("SOSEWINNodeLog");

    string stationIdString;
    stationIdString.append(stationName);
    if (!ipAddress.empty()) {
	stationIdString.append("@");
	stationIdString.append(ipAddress);
    }

    myXMLWriter->AddAtributes("idString", stationIdString);

    myXMLWriter->Createtag("station");
    if (groupId != 0)
	myXMLWriter->CreateChild("gid", to_string(*groupId));
    myXMLWriter->CreateChild("name", stationName);
    if (!ipAddress.empty())
	myXMLWriter->CreateChild("ip", ipAddress);
//    myXMLWriter->CreateChild("network_name",); // TODO add network name
//FIXME bad bugfix of stdlibc++ 4.1.2
	char str[40];
	sprintf(str, "%f", longitude);
    myXMLWriter->CreateChild("longitude", to_string(str));
	sprintf(str, "%f", latitude);
    myXMLWriter->CreateChild("latitude", to_string(str));
	sprintf(str, "%f", height);
    myXMLWriter->CreateChild("height", to_string(str));
	
    if (!comment.empty())
	myXMLWriter->CreateChild("comment", comment);

    myXMLWriter->CloseLasttag();
    myXMLWriter->Createtag("messageList");
}

void XMLStreamingLogger::createLogLevel(int logLevel) {
    if (logLevel > 0) {
	currentLogLevel.insert("SN_LN_Idle");
	currentLogLevel.insert("LN_LN_Idle");
    }
}
