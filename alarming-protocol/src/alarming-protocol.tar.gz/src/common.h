/** @file
 * @brief Common code, part of `shared_src`
 */

#ifndef _COMMON_H_
#define _COMMON_H_

#include <string>
#include <vector>
#include <list>
#include <map>
#include <time.h>
#include <algorithm>
#include <iostream>

#include "PA_APGeneralProtocol.h"
#include "PA_APEWProtocol.h"
#include "PA_APManagingProtocol.h"
#include "RTDS_SDLPROCESS.h"

using namespace AP_GeneralProtocol;

const unsigned int NUM_TRIGGER = 3;
const int T_LNSDETECTION = 5000;
const int T_PREALARM = 5000;
const int T_IDLE = 6000;
const int T_IDLELN = 6000;
const int T_DETECTION = 100000;
const int T_DESCRIPTION = 3000;
const int T_ALARM_FINISHED = 5000;
const int T_SUMMARISE = 5000;
const int T_STOP_SUMMARISE = 32000;
const int T_SAE_SWAVE = 5000;
const int T_SAE_EVENTDESCRIBED = 5000;
const int T_SAE_EVENTFINISHED = 100000;
const bool ENABLE_SN_LN_STATUS = true;

typedef std::string IPAddress;

typedef double Acceleration;
typedef double Velocity;
typedef double Displacement;
typedef double Frequency;
typedef int EventID;
typedef int GroupID;

enum tResult {pwave, no_pwave, swave, no_swave, endOfEvent};
enum tWaveType {PWave=1, SWave=2};
enum tBreakDownReason {linkDown=1, batteryLow=2};

extern std::string bytestream2Hex(const std::string& bytestring);
extern std::string hex2Bytestream(const std::string& hexstring);
extern std::string encode( const AP_GeneralProtocol::TYPE_APGeneralProtocol& generalMessage );
extern AP_GeneralProtocol::TYPE_APGeneralProtocol decode( const char* bytes, size_t length );
//extern TYPE_APManagingProtocol_GEN_4 stringToGen4(const std::string s);
extern SDLIA5String stringToIA5String(const std::string& s);
extern std::string IA5StringToString(const SDLIA5String& s);

extern std::string localIP;
extern std::string pipeName;
extern float globalPWaveTriggerThreshold;

/* The identity cast implements a logical identity. For all types except strings
 * it is the real identity, only C++ strings are converted indo IA5 strings.
 */
template<typename ElemType>
inline ElemType wrap_ia5(const ElemType& elem) {
    return elem;
}

inline SDLIA5String wrap_ia5(const std::string& elem) {
    return stringToIA5String(elem);
}

template<typename ReturnType, typename ElemType>
ReturnType makeSet(const std::vector<ElemType>& vec) {
    ReturnType set;
    int n = 1;
    for (typename std::vector<ElemType>::const_iterator i = vec.begin(); i != vec.end(); ++i) {
	//LOGS(COMMON, " Adding to Set now");
	set(SITE_STATIC_CAST(SITE_SDL_INT, n)) = wrap_ia5(*i);
	++n;
    }
    return set;
}

//no ASN.1 message
struct tSensorData {
    long long timeindex;
    float northsouth;
    float eastwest;
    float z;
    tSensorData() :
	timeindex(0),
	northsouth(0.0f),
	eastwest(0.0f),
	z(0.0f)
    { }
};

extern bool operator==( const tSensorData& first, const tSensorData& second );

/** Yet another time type to add on the heap of C time types already present.
 *  Needed like a hole in the head, but has conversions to and from TYPE_DateTime. */
struct tDateTime {
    time_t unixTime;   ///< seconds since the epoch
    time_t msFraction; ///< milliseconds, same type as unixTime for alignment

    tDateTime():
	unixTime(0),
	msFraction(0)
    { }

    tDateTime(const TYPE_DateTime& asn):
	unixTime(asn.VAR_unixTime()),
	msFraction(asn.VAR_msFraction())
    { }
    operator TYPE_DateTime() const {
	TYPE_DateTime res(unixTime, msFraction);
	return res;
    }
};
extern std::ostream& operator <<(std::ostream& os, const tDateTime& op);
extern bool operator==( const tDateTime& first, const tDateTime& second );

extern tDateTime getCurrentGPSTime(RTDS::SDLProcess* process);

extern IPAddress getMyLocalIP(RTDS::SDLProcess* process);

extern unsigned int getCRCInterNode(const void * sender, const std::string& receiver, const std::string& message );
extern unsigned int getCRCInterNode(const std::string& sender, const std::string& receiver, const std::string& message );

extern void sendMessageViaNoti(std::string serviceIdentifier, int level, std::string message);

/// A pair of two strings with an optional validity time stamp
struct tKeyValuePair {
    std::string key;
    std::string value;
    tDateTime notValidBefore;

    tKeyValuePair() :
	key(),
	value()
    { }

    tKeyValuePair(const std::string& a, const std::string& b):
	key(a),
	value(b)
    { }

    tKeyValuePair( const TYPE_KeyValuePair& asn ):
	key(asn.VAR_key()),
	value(asn.VAR_value()),
	notValidBefore(asn.VAR_notValidBefore())
    { }

    operator TYPE_KeyValuePair() const {
	TYPE_KeyValuePair res(stringToIA5String(key), stringToIA5String(value), notValidBefore);
	return res;
    }
};
extern std::ostream& operator << (std::ostream& os, tKeyValuePair& op);
extern bool operator==( const tKeyValuePair& first, const tKeyValuePair& second );

struct tGeographicCoordinate {
    double latitude;
    double longitude;
    double height;

    tGeographicCoordinate():
	latitude(0),
	longitude(0),
	height(0)
    { }

    tGeographicCoordinate( const TYPE_GeographicCoordinate& asn ):
	latitude(asn.VAR_latitude()),
	longitude(asn.VAR_longitude()),
	height(asn.VAR_height())
    { }

    operator TYPE_GeographicCoordinate() const {
	TYPE_GeographicCoordinate res(latitude, longitude, height);
	return res;
    }
};
extern std::ostream& operator <<(std::ostream& os, const tGeographicCoordinate& op);
extern bool operator==( const tGeographicCoordinate& first, const tGeographicCoordinate& second );

struct tSensorAcceleration {
    Acceleration e;
    Acceleration n;
    Acceleration z;

    tSensorAcceleration():
	e(0.0),
	n(0.0),
	z(0.0)
    { }
    tSensorAcceleration(const TYPE_SensorAcceleration& asn):
	e(asn.VAR_e()),
	n(asn.VAR_n()),
	z(asn.VAR_z())
    { }

    operator TYPE_SensorAcceleration() const {
	TYPE_SensorAcceleration res(e, n, z);
	return res;
    }
};
extern std::ostream& operator <<(std::ostream& os, const tSensorAcceleration& op);
extern bool operator==(const tSensorAcceleration& first, const tSensorAcceleration& second);

struct tSensorAccelerationAverage {
    tSensorAcceleration acceleration;
    int timeWindowLength;

    tSensorAccelerationAverage():
	timeWindowLength(0)
    { }
    tSensorAccelerationAverage(const TYPE_SensorAccelerationAverage& asn):
	acceleration(asn.VAR_acceleration()),
	timeWindowLength(asn.VAR_timeWindowLength())
    { }

    operator TYPE_SensorAccelerationAverage() const {
	TYPE_SensorAccelerationAverage res(acceleration, timeWindowLength);
	return res;
    }
};
extern std::ostream& operator <<(std::ostream& os, tSensorAccelerationAverage& op);
extern bool operator==( const tSensorAccelerationAverage& first, const tSensorAccelerationAverage& second );

struct tSensorVelocity {
    Velocity e;
    Velocity n;
    Velocity z;

    tSensorVelocity():
	e(0.0),
	n(0.0),
	z(0.0)
    { }
    tSensorVelocity(const TYPE_SensorVelocity& asn):
	e(asn.VAR_e()),
	n(asn.VAR_n()),
	z(asn.VAR_z())
    { }

    operator TYPE_SensorVelocity() const {
	TYPE_SensorVelocity res(e, n, z);
	return res;
    }
};
extern std::ostream& operator <<(std::ostream& os, const tSensorVelocity& op);
extern bool operator==( const tSensorVelocity& first, const tSensorVelocity& second );

struct tSensorDisplacement {
    Displacement e;
    Displacement n;
    Displacement z;

    tSensorDisplacement():
	e(0.0),
	n(0.0),
	z(0.0)
    { }
    tSensorDisplacement(const TYPE_SensorDisplacement& asn):
	e(asn.VAR_e()),
	n(asn.VAR_n()),
	z(asn.VAR_z())
    { }

    operator TYPE_SensorDisplacement() const {
	TYPE_SensorDisplacement res(e, n, z);
	return res;
    }
};
extern std::ostream& operator <<(std::ostream& os, const tSensorDisplacement& op);
extern bool operator==( const tSensorDisplacement& first, const tSensorDisplacement& second );

struct tResponseSpectra {
    tSensorAcceleration a_0_3sec;
    tSensorAcceleration a_1sec;
    tSensorAcceleration a_3sec;

    // needed for automatic calls of default constructors of complex members
    tResponseSpectra() {
    }
    tResponseSpectra(const TYPE_ResponseSpectra& asn):
	a_0_3sec(asn.VAR_a_0_3sec()),
	a_1sec(asn.VAR_a_1sec()),
	a_3sec(asn.VAR_a_3sec())
    { }

    operator TYPE_ResponseSpectra() const {
	TYPE_ResponseSpectra res(a_0_3sec, a_1sec, a_3sec);
	return res;
    }
};
extern std::ostream& operator <<(std::ostream& os, tResponseSpectra& op);
extern bool operator==(const tResponseSpectra& first, const tResponseSpectra& second);

struct tInoperativeSNInfo {
    tDateTime lastOperativeAt;
    IPAddress sourceSN;
    tBreakDownReason reason;

    tInoperativeSNInfo():
	sourceSN("000.000.000.000")
    { }

    tInoperativeSNInfo(tDateTime lastOperativeAt, IPAddress sourceSN, tBreakDownReason reason):
	lastOperativeAt(lastOperativeAt),
	sourceSN(sourceSN),
	reason(reason)
    { }

    // copy-ctr
    tInoperativeSNInfo(const tInoperativeSNInfo& other):
	lastOperativeAt(other.lastOperativeAt),
	sourceSN(other.sourceSN),
	reason(other.reason)
    { }

    // operator=
    tInoperativeSNInfo& operator=(const tInoperativeSNInfo& other) {
	if (this != &other) { // make sure not same object
	    lastOperativeAt = other.lastOperativeAt;
	    sourceSN = other.sourceSN;
	    reason = other.reason;
	}
	return *this; // Return ref for multiple assignment
    }

    tInoperativeSNInfo(const TYPE_InoperativeSNInfo& asn):
	lastOperativeAt(asn.VAR_lastOperativeAt()),
	sourceSN(asn.VAR_sourceSN()),
	// can only cast int to enum; VAR_reason is of type long
	reason(tBreakDownReason((int) asn.VAR_reason()))
    { }
    operator TYPE_InoperativeSNInfo() const {
	TYPE_InoperativeSNInfo res(lastOperativeAt, stringToIA5String(sourceSN), reason);
	return res;
    }
};
extern std::ostream& operator <<(std::ostream& os, const tInoperativeSNInfo& op);
extern bool operator==( const tInoperativeSNInfo& first, const tInoperativeSNInfo& second );

struct tTriggeredSNInfo {
    tDateTime gpsTimeStamp;
    IPAddress sourceSN;
    tSensorAcceleration currentSensorValues;
    tDateTime tp;
    Acceleration az_max;
    tDateTime t_max;
    double max_noise;
    double valueFourthChannel;
    double sta_lta_TriggerValue;

    tTriggeredSNInfo():
	sourceSN("000.000.000.000"),
	az_max(0.0),
	max_noise(0.0),
	valueFourthChannel(0.0),
	sta_lta_TriggerValue(0.0)
    { }

    // copy-ctr
    tTriggeredSNInfo(const tTriggeredSNInfo& other):
	gpsTimeStamp(other.gpsTimeStamp),
	sourceSN(other.sourceSN),
	currentSensorValues(other.currentSensorValues),
	tp(other.tp),
	az_max(other.az_max),
	t_max(other.t_max),
	max_noise(other.max_noise),
	valueFourthChannel(other.valueFourthChannel),
	sta_lta_TriggerValue(other.sta_lta_TriggerValue)
    { }
    // operator=
    tTriggeredSNInfo& operator=(const tTriggeredSNInfo& other) {
	if (this != &other) { // make sure not same object
	    gpsTimeStamp = other.gpsTimeStamp;
	    sourceSN = other.sourceSN;
	    currentSensorValues = other.currentSensorValues;
	    tp = other.tp;
	    az_max = other.az_max;
	    t_max = other.t_max;
	    max_noise = other.max_noise;
	    valueFourthChannel = other.valueFourthChannel;
	    sta_lta_TriggerValue = other.sta_lta_TriggerValue;
	}
	return *this; // Return ref for multiple assignment
    }

    tTriggeredSNInfo(const TYPE_TriggeredSNInfo& asn):
	gpsTimeStamp(asn.VAR_gpsTimeStamp()),
	sourceSN(asn.VAR_sourceSN()),
	currentSensorValues(asn.VAR_currentSensorValues()),
	tp(asn.VAR_tp()),
	az_max(asn.VAR_az_max()),
	t_max(asn.VAR_t_max()),
	max_noise(asn.VAR_max_noise()),
	valueFourthChannel(asn.VAR_valueFourthChannel()),
	sta_lta_TriggerValue(asn.VAR_sta_lta_TriggerValue())
    { }
    operator TYPE_TriggeredSNInfo() const {
	TYPE_TriggeredSNInfo res(gpsTimeStamp, stringToIA5String(sourceSN), currentSensorValues,
		tp, az_max, t_max, max_noise, valueFourthChannel, sta_lta_TriggerValue);
	return res;
    }
};
extern std::ostream& operator <<(std::ostream& os, const tTriggeredSNInfo& op);
extern bool operator==( const tTriggeredSNInfo& first, const tTriggeredSNInfo& second );

struct tStatusSNInfo {
    tDateTime gpsTimeStamp;
    IPAddress sourceSN;
    tSensorAcceleration pga;
    tSensorVelocity pgv;
    tSensorDisplacement pgd;
    double predominantPeriod;
    double cav;
    double instrumentalIntensity;
    double ariasIntensity;
    double valueFourthChannel;
    tResponseSpectra responseSpectra;

    tStatusSNInfo():
	sourceSN("000.000.000.000"),
	predominantPeriod(0.0),
	cav(0.0),
	instrumentalIntensity(0.0),
	ariasIntensity(0.0),
	valueFourthChannel(0.0)
    { }

    // copy-ctr
    tStatusSNInfo(const tStatusSNInfo& other):
	gpsTimeStamp(other.gpsTimeStamp),
	sourceSN(other.sourceSN),
	pga(other.pga),
	pgv(other.pgv),
	pgd(other.pgd),
	predominantPeriod(other.predominantPeriod),
	cav(other.cav),
	instrumentalIntensity(other.instrumentalIntensity),
	ariasIntensity(other.ariasIntensity),
	valueFourthChannel(other.valueFourthChannel),
	responseSpectra(other.responseSpectra)
    { }
    // operator=
    tStatusSNInfo& operator=(const tStatusSNInfo& other) {
	if (this != &other) { // make sure not same object
	    gpsTimeStamp = other.gpsTimeStamp;
	    sourceSN = other.sourceSN;
	    pga = other.pga;
	    pgv = other.pgv;
	    pgd = other.pgd;
	    predominantPeriod = other.predominantPeriod;
	    cav = other.cav;
	    instrumentalIntensity = other.instrumentalIntensity;
	    ariasIntensity = other.ariasIntensity;
	    valueFourthChannel = other.valueFourthChannel;
	    responseSpectra = other.responseSpectra;
	}
	return *this; // Return ref for multiple assignment
    }

    tStatusSNInfo(const TYPE_StatusSNInfo& asn):
	gpsTimeStamp(asn.VAR_gpsTimeStamp()),
	sourceSN(asn.VAR_sourceSN()),
	pga(asn.VAR_pga()),
	pgv(asn.VAR_pgv()),
	pgd(asn.VAR_pgd()),
	predominantPeriod(asn.VAR_predominantPeriod()),
	cav(asn.VAR_cav()),
	instrumentalIntensity(asn.VAR_instrumentalIntensity()),
	ariasIntensity(asn.VAR_ariasIntensity()),
	valueFourthChannel(asn.VAR_valueFourthChannel()),
	responseSpectra(asn.VAR_responseSpectra())
    { }

    operator TYPE_StatusSNInfo() const {
	TYPE_StatusSNInfo res(gpsTimeStamp, stringToIA5String(sourceSN), pga, pgv, pgd,
		predominantPeriod, cav, instrumentalIntensity, ariasIntensity, valueFourthChannel,
		responseSpectra);
	return res;
    }
};
extern std::ostream& operator <<(std::ostream& os, const tStatusSNInfo& op);
extern bool operator==(const tStatusSNInfo& first, const tStatusSNInfo& second);

struct tSharedData {
    tSensorAccelerationAverage noiseAverage;
    tSensorAccelerationAverage noiseAveragePreEvent;
    double batteryVoltage;
    double valueFourthChannel;
    tDateTime tp;
    tDateTime ts;
    tDateTime tend;
    tWaveType waveType;
    tSensorAcceleration pga;
    tSensorVelocity pgv;
    tSensorDisplacement pgd;
    tSensorAcceleration a_max;
    tSensorVelocity v_max;
    tSensorDisplacement d_max;
    double predominantPeriod;
    double cav;
    double ariasIntensity;
    double sta_lta_TriggerValue;
    // signalAnalyserValues
    int SAMPLERATE;
    double PSHORTWINDOW;
    int PSLRATIO;
    double PDELAY;
    int PGAMMA;
    double PCUTOFF;
    double SSHORTWINDOW;
    double SCUTOFF;

    tSharedData():
	batteryVoltage (0.0),
	valueFourthChannel (0.0),
	waveType (PWave),
	predominantPeriod (0.0),
	cav (0.0),
	ariasIntensity (0.0),
	sta_lta_TriggerValue (0.0),
	// signalAnalyser default values
	SAMPLERATE (50),
	PSHORTWINDOW (0.2),
	PSLRATIO (50),
	PDELAY (1.0),
	PGAMMA (6),
	PCUTOFF (5.0),
	SSHORTWINDOW (0.6),
	SCUTOFF (100.0)
    { }
};

typedef std::vector<tStatusSNInfo> status_vec;
typedef std::vector<tTriggeredSNInfo> trig_vec;
typedef std::vector<tInoperativeSNInfo> inop_vec;
typedef std::vector<IPAddress> ip_vec;
typedef std::map<std::string,bool> bool_map;
typedef std::vector<tKeyValuePair> key_vec;
#endif
