/*SX*/
/*SX*/
/**
 * @file te_sender.h
 * @date Aug 17, 2008
 * @author Ronald Kluth
 *
 * @brief Declaration of class te_sender, part of `boost_substitute`
 */

#ifndef TE_SENDER_H_INCLUDED
#define TE_SENDER_H_INCLUDED

#include "common.h"
#include "message.h"
#include "network_stack.h"
#include "RTDS_SDLPROCESS.h"

#include "PA_APGeneralProtocol.h"
#include "PA_APEWProtocol.h"
#include "PA_APManagingProtocol.h"

#include <string>
#include <vector>
#include <cstdlib>

#include "XMLStreamingLogger.h"

class te_sender: public RTDS::SDLProcess {
private:
    /// the network interface, called stack to stick closely to the simulation
    NetworkStack& stack;

public:
    te_sender(NetworkStack& s, RTDS::Logger& _logger)
    :   SDLProcess(_logger),
        stack(s)
    {
	logger.logProcessCreation(msgQueue.writer, "te_sender", 0);
    }

    // TODO: life cycle in boost ???
    virtual int main();

    // no parameters needed, handled internally through member data
    void send();

private:
    void send_and_log(const char * message_name,
    	const std::string& message_ber, const IPAddress& receiver);
};

#endif
