/*SX*//** @file
 *  Generated file, find templates in SX folders
 */

#ifndef GATEWAYENTITY_UP_H_INCLUDED
#define GATEWAYENTITY_UP_H_INCLUDED
#ifndef _GATEWAYENTITY_H_
#define _GATEWAYENTITY_H_

#include "blockClass_Node.h"

#endif
#endif

#ifndef GATEWAYENTITY_H_INCLUDED
#define GATEWAYENTITY_H_INCLUDED

#include "RTDS_SDLPROCESS.h"

/**@brief The process GatewayEntity 
 */
class GatewayEntity : public RTDS::SDLProcess {
public:

    /**@brief Constructor.
     */
    GatewayEntity(RTDS::Logger& logger = RTDS::emptyLogger);

    /**@brief Lifeline of this process.
     */
    virtual int main();

private:
    
};

#ifndef _GATEWAYENTITY_H_
#define _GATEWAYENTITY_H_

#include "blockClass_Node.h"

#endif

#endif
