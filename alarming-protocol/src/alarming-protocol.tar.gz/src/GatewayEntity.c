/*SX*//** @file
 *  Generated file, find templates in SX folders
 */
#include <boost/thread/thread.hpp>
#include <boost/bind.hpp>

#include "RTDS_gen.h"
#include "GatewayEntity.h"
#include "RTDS_messages.h"

#define RTDS_PROCESS_NUMBER RTDS_process_GatewayEntity
#define RTDS_PROCESS_NAME GatewayEntity

/*
** PROCESS GatewayEntity:
** ----------------------
*/

GatewayEntity::GatewayEntity(RTDS::Logger& logger)
: SDLProcess(logger)
{
    RTDS_LOG_PROCESS_CREATION(msgQueue.writer, "GatewayEntity", cover);
}

int GatewayEntity::main()
{
    short RTDS_transitionExecuted;
  int RTDS_savedSdlState = 0;

  IPAddress sender;
  tDateTime date;
  EventID event;
  status_vec temp_statvec;
  ip_vec temp_ipvec;
  inop_vec temp_inopvec;
  double ariasIntensity;
  trig_vec temp_triggered;
  RTDS_MSG_DATA_DECL

  // silence warning; this variable is not usually used
  RTDS_savedSdlState += 0;

  /* starts stdio.run() asynchronous stops when isRunnings destructor is destroyed */
  boost::thread _workThread_t(boost::bind(&boost::asio::io_service::run, &ioService));
  std::auto_ptr<boost::asio::io_service::work> _workThread_ptr(isRunning);
  isRunning = 0;

  /* declare framework-side variables for the process */

  /* Initial transition */
  RTDS_SDL_STATE_SET(Idle);
  // odemx/bricks/RTDS_Proc_loopStart
  while (true) {
  // loop start ends
  /* peek new message from queue */
  currentMessage = msgQRead();
  RTDS_LOG_MESSAGE_RECEIVE(&currentMessage->sender, msgQueue.writer,
  currentMessage->sequenceNumber, getCurrentTime());
  /* Double switch state / signal */
  RTDS_transitionExecuted = 1;
  switch(RTDS_currentContext->sdlState)
    {
    /* Transitions for state Idle */
    case Idle:
      switch(RTDS_currentContext->currentMessage->messageNumber)
        {
        /* Transition for state Idle - message LN_EN_Alarm */
        case LN_EN_Alarm:
          RTDS_MSG_RECEIVE_LN_EN_Alarm(      sender,       date,       event,       temp_triggered);
            {
            LOGS(GE, "### GatewayEntity received LN_EN_Alarm from " << sender << " ###");

            int size = temp_triggered.size();
            LOGS(GE, "The Nodes recorded the following data:\n");
            for (int i = 0; i < size; i++) {
            LOGS(GE, temp_triggered[i] << "\n");
            }
          //delete temp_vec;
          }
        RTDS_SDL_STATE_SET(Idle);
        break;
      /* Transition for state Idle - message LN_EN_Summary */
      case LN_EN_Summary:
        RTDS_MSG_RECEIVE_LN_EN_Summary(        sender,         date,         event,         temp_ipvec,         temp_inopvec,         temp_statvec,         ariasIntensity);
          {
          LOGS(GE, "### GatewayEntity received LN_EN_Summary from " << sender << " ###");

          int size1 = temp_statvec.size();
          int size2 = temp_ipvec.size();
          int size3 = temp_inopvec.size();

          LOGS(GE, "The are " << size2 << " active nodes in the group:");
          for (int i = 0; i < size2; i++) {
          LOGS(GE, temp_ipvec[i] << "\n");
          }

        LOGS(GE, "The are " << size3 << " inactive nodes in the group:");
        for (int j = 0; j < size3; j++) {
        LOGS(GE, temp_inopvec[j] << "\n");
        }

      LOGS(GE, "The following " << size1 << " nodes in the group contributed to the decision:");
      for (int k = 0; k < size1; k++) {
      LOGS(GE, temp_statvec[k] << "\n");
      }
    //delete temp_vec;
    }
  RTDS_SDL_STATE_SET(Idle);
  break;
default:
  RTDS_transitionExecuted = 0;
  break;
} /* End of switch on message */
break;
default:
  RTDS_transitionExecuted = 0;
  break;
} /* End of switch(RTDS_currentContext->sdlState) */
// odemx/bricks/RTDS_Proc_end
delete currentMessage;
}; // end of while(true)
// no return here, since this brick does not know the return type
// end ends
}

/* private methods */
