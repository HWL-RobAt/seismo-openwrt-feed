/** @file
 * @brief Common code, part of `shared_src`
 */

#include "common.h"

#include <sys/time.h>
#include <boost/format.hpp>
#include <boost/crc.hpp>
#include "RTDS_SDLPROCESS.h"
#include "RTDS_SDLBLOCK.h"
#include "logging.h"
#include "blockClass_Node.h"

#ifdef BOOST
#include <cstdlib>
#include <cstring>
#include <iostream>
#include <boost/asio.hpp>
#include <boost/bind.hpp>
#include <boost/shared_ptr.hpp>
#endif

std::string localIP;
#ifdef BOOST
std::string pipeName; // Pipe name set in main and read in data listener
#endif
float globalPWaveTriggerThreshold;

using namespace AP_GeneralProtocol;

/// Encode as ASN.1 BER
std::string encode(const TYPE_APGeneralProtocol& generalMessage) {
    SDLAny a = generalMessage.encode(asn_ber);
    SDLOctetString ocs = a.octet_string();
    const char* bytes = (const char*) ocs;
    size_t length = ocs.Len();

    std::ostringstream byteStream;
    for (size_t i = 0; i < length; ++i)
	byteStream << bytes[i];

    std::string ret = byteStream.str();

    if (length != ret.length())
	LOGS_ALWAYS(COMMON, "Error: Error while encoding " << length << " " << ret.length());
    return ret;
}

/// Decode from ASN.1 BER, just hope its the correct type.
TYPE_APGeneralProtocol decode(const char* bytes, size_t length) {
    TYPE_APGeneralProtocol decodedMessage;

    try {
	// fill the bytes into a buffer
	AsnBuf buffer(const_cast<char*> (bytes), length);
	// put back the bytes within the buffer into the Any type
	SDLAny convert(buffer, length);
	// decode the Any to the top level type
	decodedMessage = TYPE_APGeneralProtocol(convert);
    } catch (SDLError& e) {
	LOGS_ALWAYS(COMMON, "Exception in te_receiver::decode(): " << e.message);
    }

    return decodedMessage;
}

/** Convert some bytes into the corresponding hex representation.
 * Weirdly, they come in a string. Used for debugging.
 */
std::string bytestream2Hex(const std::string& bytestring) {
    int length = bytestring.length();
    const char* bytes = bytestring.c_str();
    std::ostringstream byteStream;
    for (int i = 0; i < length; ++i)
	// one byte, two digits
	byteStream << INT2HEX(bytes[i]>>4) << INT2HEX(bytes[i]);
    return byteStream.str();
}

/// The opposite of byteStream2Hex. Not used at all. Better that way.
std::string hex2Bytestream(const std::string& hexstring) {
    int length = hexstring.length();
    if (length % 2 != 0) {
	LOGS_ALWAYS(COMMON, "Not a byte stream");
	return "";
    }
    const char* hexdigits = hexstring.c_str();
    std::ostringstream byteStream;
    for (int i = 0; i < length; i += 2)
	byteStream << (char) (HEX2INT(hexdigits[i]) * 16 + HEX2INT(hexdigits[i+1]));
    return byteStream.str();
}

/// Convert a C++ string into an IA5 string.
SDLIA5String stringToIA5String(const std::string& s) {
    //LOGS(COMMON, s <<" with length" << s.length()<< " will be generated to ASN.1");
    SDLIA5String tmp(s.c_str(), s.length());
    //LOGS(COMMON, "done with generating ASN1:" << s);;
    return tmp;
}

/// Convert an IA5 string into a C++ string.
std::string IA5StringToString(const SDLIA5String& s) {
    std::ostringstream IA5S;

    // convert IA5String to a string, via a stream
    s.Print(IA5S);
    std::string ret = IA5S.str();

    // remove first and last char
    return ret.substr(1, ret.length() - 2);
}

tDateTime getCurrentGPSTime(RTDS::SDLProcess* process) {
    long long cur = process->getCurrentTime();
    tDateTime currentTime;
    currentTime.unixTime = cur / 1000;
    currentTime.msFraction = cur % 1000;
    //LOGS(COMMON, "called getCurrentGPSTime(): " << currentTime);
    return currentTime;
}

IPAddress getMyLocalIP(RTDS::SDLProcess* process) {
#ifdef BOOST
	return localIP;
#endif
#ifdef ODEMX
	//take the surrounding block
	RTDS::SDLBlock* block = process -> getCover();
	//this is a blockClass_node
	blockClass_Node* node = (blockClass_Node*) block;
	return node->p_block_te->stack.ip;
#endif
	return "";
}

void sendMessageViaNoti(std::string serviceIdentifier, int level, std::string message) {
    //only on target platform
#ifdef BOOST
    boost::asio::io_service io_service;

    // create peer endpoint with given parameters
    boost::asio::ip::tcp::endpoint
    peerEndpoint( boost::asio::ip::address::from_string( "127.0.0.1" ), 40001 );

    boost::asio::ip::tcp::socket socket(io_service);
    socket.connect(peerEndpoint);

    boost::asio::streambuf sendBuffer;
    std::ostream sendBufferStream( &sendBuffer );
    sendBufferStream << serviceIdentifier << "#" << level << "#" << message << std::endl;

    boost::asio::write(socket, sendBuffer, boost::asio::transfer_all());

    std::cout << "m-noti message: " << serviceIdentifier << "#" << level << "#" << message << std::endl;

    socket.close();
#endif
}

/**
 * Create fake message IDs for messages external to the system (between nodes).
 */
unsigned int getCRCInterNode(const std::string& sender, const std::string& receiver, const std::string& message ) {
    boost::crc_32_type result;
    //process sender
    int length = sender.length();
    for(int i = 0; i < length; ++i)
	result.process_byte(sender.c_str()[i]);
    //process receiver
    length = receiver.length();
    for(int i = 0; i < length; ++i)
	result.process_byte(receiver.c_str()[i]);
    //process message
    length = message.length();
    for(int i = 0; i < length; ++i)
	result.process_byte(message.c_str()[i]);
    LOGS(COMMON, " CRC: " << result.checksum() << " sender: " << sender << " receiver: " << receiver << " message: " << bytestream2Hex(message));
    return result.checksum();
}

bool operator==(const tSensorData& first, const tSensorData& second) {
    return (first.timeindex == second.timeindex)
	&& (first.northsouth == second.northsouth)
	&& (first.eastwest == second.eastwest)
	&& (first.z == second.z);
}

bool operator==(const tDateTime& first, const tDateTime& second) {
    return (first.unixTime == second.unixTime)
	&& (first.msFraction == second.msFraction);
}


std::ostream& operator <<(std::ostream& os, const tDateTime& op) {
    tm *nun = localtime(&op.unixTime);
    os << boost::format("%d.%d.%d") % nun->tm_mday % (nun->tm_mon + 1) % (nun->tm_year + 1900);
    os << " - ";
    os << boost::format("%d:%02d:%02d,%03d") % nun->tm_hour % nun->tm_min % nun->tm_sec % op.msFraction;
    return os;
}

bool operator==(const tKeyValuePair& first, const tKeyValuePair& second) {
    return (first.key == second.key)
	&& (first.value == second.value)
	&& (first.notValidBefore == second.notValidBefore);
}

std::ostream& operator <<(std::ostream& os, tKeyValuePair& op) {
    os << "  key: " << op.key << " value: " << op.value << " notValidBefore: " << op.notValidBefore;
    return os;
}

bool operator==(const tGeographicCoordinate& first, const tGeographicCoordinate& second) {
    return (first.latitude == second.latitude)
	&& (first.longitude == second.longitude)
	&& (first.height == second.height);
}

std::ostream& operator <<(std::ostream& os, const tGeographicCoordinate& op) {
    os << "  latitude: " << op.latitude << " longitude: " << op.longitude << " height: "
	    << op.height;
    return os;
}

bool operator==(const tSensorAcceleration& first, const tSensorAcceleration& second) {
    return (first.e == second.e)
	&& (first.n == second.n)
	&& (first.z == second.z);
}

std::ostream& operator <<(std::ostream& os, const tSensorAcceleration& op) {
    os << "e: " << op.e << " n: " << op.n << " z: " << op.z;
    return os;
}

bool operator==(const tSensorAccelerationAverage& first, const tSensorAccelerationAverage& second) {
    return (first.acceleration == second.acceleration)
	&& (first.timeWindowLength == second.timeWindowLength);
}

std::ostream& operator <<(std::ostream& os, const tSensorAccelerationAverage& op) {
    os << "  acceleration: " << op.acceleration << "\n  timeWindowLength: " << op.timeWindowLength;
    return os;
}

bool operator==(const tSensorVelocity& first, const tSensorVelocity& second) {
    return (first.e == second.e)
	&& (first.n == second.n)
	&& (first.z == second.z);
}

std::ostream& operator <<(std::ostream& os, const tSensorVelocity& op) {
    os << "e: " << op.e << " n: " << op.n << " z: " << op.z;
    return os;
}

bool operator==(const tSensorDisplacement& first, const tSensorDisplacement& second) {
    return (first.e == second.e)
	&& (first.n == second.n)
	&& (first.z == second.z);
}

std::ostream& operator <<(std::ostream& os, const tSensorDisplacement& op) {
    os << "e: " << op.e << " n: " << op.n << " z: " << op.z;
    return os;
}

bool operator==(const tResponseSpectra& first, const tResponseSpectra& second) {
    return (first.a_0_3sec == second.a_0_3sec)
	&& (first.a_1sec == second.a_1sec)
	&& (first.a_3sec == second.a_3sec);
}

std::ostream& operator <<(std::ostream& os, const tResponseSpectra& op) {
    os << " a_0_3sec: " << op.a_0_3sec << "\n a_1sec: " << op.a_1sec << "\n a_3sec: " << op.a_3sec;
    return os;
}

bool operator==(const tInoperativeSNInfo& first, const tInoperativeSNInfo& second) {
    return (first.lastOperativeAt == second.lastOperativeAt)
		&&(first.sourceSN == second.sourceSN)
		&&(first.reason == second.reason);
}

std::ostream& operator <<(std::ostream& os, const tInoperativeSNInfo& op) {
    os << "  lastOperativeAt:\n " << op.lastOperativeAt << "  ip: " << op.sourceSN
	    << "  reason:\n " << op.reason;
    return os;
}

bool operator==(const tTriggeredSNInfo& first, const tTriggeredSNInfo& second) {
    return (first.gpsTimeStamp == second.gpsTimeStamp)
	&&(first.sourceSN == second.sourceSN)
	&&(first.currentSensorValues == second.currentSensorValues)
	&&(first.tp == second.tp)
	&&(first.az_max == second.az_max)
	&&(first.t_max == second.t_max)
	&&(first.max_noise == second.max_noise)
	&&(first.valueFourthChannel == second.valueFourthChannel)
	&&(first.sta_lta_TriggerValue == second.sta_lta_TriggerValue);
}

std::ostream& operator <<(std::ostream& os, const tTriggeredSNInfo& op) {
    os << "gpsTimeStamp:" << op.gpsTimeStamp << "\nip:" << op.sourceSN
	    << " currentSensorValues:" << op.currentSensorValues << "\ntp:" << op.tp
	    << " az_max:" << op.az_max << "\nt_max:" << op.t_max << " max_noise:" << op.max_noise
	    << "\nvalueFourthChannel:" << op.valueFourthChannel << " sta_lta_TriggerValue:"
	    << op.sta_lta_TriggerValue;
    return os;
}

bool operator==(const tStatusSNInfo& first, const tStatusSNInfo& second) {
    return (first.gpsTimeStamp == second.gpsTimeStamp)
	&&(first.sourceSN == second.sourceSN)
	&&(first.pga == second.pga)
	&&(first.pgv == second.pgv)
	&&(first.pgd == second.pgd)
	&&(first.predominantPeriod == second.predominantPeriod)
	&&(first.cav == second.cav)
	&&(first.instrumentalIntensity == second.instrumentalIntensity)
	&&(first.valueFourthChannel == second.valueFourthChannel)
	&&(first.responseSpectra == second.responseSpectra);
}

std::ostream& operator <<(std::ostream& os, const tStatusSNInfo& op) {
    os << "sourceSN: " << op.sourceSN << "\ngpsTimeStamp: " << op.gpsTimeStamp << "\npga: "
	    << op.pga << "\npgv: " << op.pgv << "\npgd: " << op.pgd << "\npredominantPeriod: "
	    << op.predominantPeriod << " cav: " << op.cav << " instrumentalIntensity: "
	    << op.instrumentalIntensity << "\nresponseSpectra:\n" << op.responseSpectra;
    return os;
}
