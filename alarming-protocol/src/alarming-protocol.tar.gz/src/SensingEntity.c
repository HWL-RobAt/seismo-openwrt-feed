/*SX*//** @file
 *  Generated file, find templates in SX folders
 */
#include <boost/thread/thread.hpp>
#include <boost/bind.hpp>

#include "RTDS_gen.h"
#include "SensingEntity.h"
#include "RTDS_messages.h"

#define RTDS_PROCESS_NUMBER RTDS_process_SensingEntity
#define RTDS_PROCESS_NAME SensingEntity

/*
** PROCESS SensingEntity:
** ----------------------
*/

SensingEntity::SensingEntity(RTDS::Logger& logger)
: SDLProcess(logger)
{
    RTDS_LOG_PROCESS_CREATION(msgQueue.writer, "SensingEntity", cover);
}

int SensingEntity::main()
{
    short RTDS_transitionExecuted;
  int RTDS_savedSdlState = 0;

  std::string LE_IP = "000.000.000.000";
  std::string myIP  = "000.000.000.000";
  //std::string LE_IP_Sec[16];

  bool hasLeader = false;
  IPAddress  sender,receiver;
  double     sta_lta_TriggerValue,batteryVoltage;
  double     valueFourthChannel, cav, predominantPeriod, ariasIntensity;

  GroupID                gID;
  EventID                event;
  std::vector<IPAddress> operativeSNs,SNs;
  ip_vec                 tempSN;
  tInoperativeSNInfo     inoperativeSNs;
  tTriggeredSNInfo       triggeredSNs;
  std::vector<tStatusSNInfo>      vec_status, vec_decisions;
  status_vec                      vec_tempStatus, vec_tempDecisions;
  tWaveType              waveType;

  tDateTime                        gpsTimeStamp, timeOfFalseAlarm;
  tDateTime                        tp, t_max, ts, tend;
  tSensorAcceleration              a_max, pga;
  tSensorVelocity                  v_max, pgv;
  tSensorDisplacement              d_max, pgd;
  tSensorAccelerationAverage       noiseAverage;
  tSensorAccelerationAverage       noiseAveragePreEvent;
  tSharedData *mySharedData = 0;
  RTDS_MSG_DATA_DECL

  // silence warning; this variable is not usually used
  RTDS_savedSdlState += 0;

  /* starts stdio.run() asynchronous stops when isRunnings destructor is destroyed */
  boost::thread _workThread_t(boost::bind(&boost::asio::io_service::run, &ioService));
  std::auto_ptr<boost::asio::io_service::work> _workThread_ptr(isRunning);
  isRunning = 0;

  /* declare framework-side variables for the process */

  /* Initial transition */
  RTDS_SET_TIMER(t_Idle, T_IDLE);
  RTDS_SDL_STATE_SET(Idle);
  // odemx/bricks/RTDS_Proc_loopStart
  while (true) {
  // loop start ends
  /* peek new message from queue */
  currentMessage = msgQRead();
  RTDS_LOG_MESSAGE_RECEIVE(&currentMessage->sender, msgQueue.writer,
  currentMessage->sequenceNumber, getCurrentTime());
  /* Double switch state / signal */
  RTDS_transitionExecuted = 1;
  switch(RTDS_currentContext->sdlState)
    {
    /* Transitions for state eventDescribed */
    case eventDescribed:
      switch(RTDS_currentContext->currentMessage->messageNumber)
        {
        /* Transition for state eventDescribed - message t_Description */
        case t_Description:
        /* Transition for state eventDescribed - message EventDescribed */
        case EventDescribed:
          if ( hasLeader )
            {
            // {{{ SN_LN_Description params
            /*if (RTDS_currentContext->currentMessage->messageNumber == SN_LN_Description) {
            LOGS(SE, myIP << " SE/evDescr/rect_Description:");
            } else {
          LOGS(SE, myIP << " SE/evDescr/recEventDesc:");
          }*/
        gpsTimeStamp.unixTime = time(0);
        gpsTimeStamp.msFraction = 0;
        tp = mySharedData->tp;
        waveType = mySharedData->waveType;
        pga = mySharedData->pga;
        pgv = mySharedData->pgv;
        pgd = mySharedData->pgd;
        noiseAverage = mySharedData->noiseAverage;
        predominantPeriod = mySharedData->predominantPeriod;
        cav = mySharedData->cav;
        ariasIntensity = mySharedData->ariasIntensity;
        valueFourthChannel = mySharedData->valueFourthChannel;

        LOGS(SE, myIP << " SE/evDescr/sendSNLNDesc to: " << LE_IP);
        // }}} SN_LN_Description params
        if ( LE_IP == myIP )
          {
          RTDS_MSG_SEND_SN_LN_Description_TO_NAME("LeadingEntity", RTDS_process_LeadingEntity,           LE_IP,           getCurrentGPSTime(this),           tp,           waveType,           pga,           pgv,           pgd,           noiseAverage,           predominantPeriod,           cav,           ariasIntensity,           valueFourthChannel);
          }
        else
          {
          RTDS_MSG_SEND_SN_LN_Description_TO_NAME("te_sender", RTDS_process_te_sender,           LE_IP,           getCurrentGPSTime(this),           tp,           waveType,           pga,           pgv,           pgd,           noiseAverage,           predominantPeriod,           cav,           ariasIntensity,           valueFourthChannel);
          }
        }
      RTDS_SET_TIMER(t_Description, T_DESCRIPTION);
      RTDS_SDL_STATE_SET(eventDescribed);
      break;
    /* Transition for state eventDescribed - message LN_SN_FalseAlarm */
    case LN_SN_FalseAlarm:
      RTDS_MSG_RECEIVE_LN_SN_FalseAlarm(      sender,       gpsTimeStamp,       timeOfFalseAlarm);
      RTDS_RESET_TIMER(t_Description);
      // {{{ SN_LN_Idle params
      LOGS(SE, myIP << " SE/evDesc/recLNSNFA:");

      gpsTimeStamp.unixTime = time(0);
      gpsTimeStamp.msFraction = 0;
      noiseAverage = mySharedData->noiseAverage;
      batteryVoltage = mySharedData->batteryVoltage;
      valueFourthChannel = mySharedData->valueFourthChannel;

      LOGS(SE, myIP << " SE/evDesc/sendSNLNIdle to: " << sender);
      // }}} SN_LN_Idle params
      if ( LE_IP == myIP )
        {
        RTDS_MSG_SEND_SN_LN_Idle_TO_NAME("LeadingEntity", RTDS_process_LeadingEntity,         LE_IP,         getCurrentGPSTime(this),         noiseAverage,         batteryVoltage,         valueFourthChannel);
        }
      else
        {
        RTDS_MSG_SEND_SN_LN_Idle_TO_NAME("te_sender", RTDS_process_te_sender,         LE_IP,         getCurrentGPSTime(this),         noiseAverage,         batteryVoltage,         valueFourthChannel);
        }
      RTDS_SET_TIMER(t_Idle, T_IDLE);
      RTDS_SDL_STATE_SET(Idle);
      break;
    /* Transition for state eventDescribed - message LN_SN_Summarise */
    case LN_SN_Summarise:
      RTDS_MSG_RECEIVE_LN_SN_Summarise(      sender,       gpsTimeStamp,       event);
      // {{{ SN_LN_Summary params
      /*if (RTDS_currentContext->currentMessage->messageNumber == LN_SN_Summarise) {
      LOGS(SE, myIP << " SE/evDesc/recLNSNSummarize:");
      } else {
    LOGS(SE, myIP << " SE/evDesc/recEventFinished:");
    }*/

  gpsTimeStamp.unixTime = time(0);
  gpsTimeStamp.msFraction = 0;
  tp = mySharedData->tp;
  ts = mySharedData->ts;
  tend = mySharedData->tend;
  pga = mySharedData->pga;
  pgv = mySharedData->pgv;
  pgd = mySharedData->pgd;
  noiseAverage = mySharedData->noiseAverage;
  cav = mySharedData->cav;
  ariasIntensity = mySharedData->ariasIntensity;
  valueFourthChannel = mySharedData->valueFourthChannel;
  batteryVoltage = mySharedData->batteryVoltage;
  // }}} SN_LN_Summary params
  if ( LE_IP == myIP )
    {
    RTDS_MSG_SEND_SN_LN_Summary_TO_NAME("LeadingEntity", RTDS_process_LeadingEntity,     LE_IP,     getCurrentGPSTime(this),     tp,     ts,     tend,     pga,     pgv,     pgd,     noiseAverage,     cav,     ariasIntensity,     valueFourthChannel,     batteryVoltage);
    }
  else
    {
    RTDS_MSG_SEND_SN_LN_Summary_TO_NAME("te_sender", RTDS_process_te_sender,     LE_IP,     getCurrentGPSTime(this),     tp,     ts,     tend,     pga,     pgv,     pgd,     noiseAverage,     cav,     ariasIntensity,     valueFourthChannel,     batteryVoltage);
    }
  RTDS_RESET_TIMER(t_Description);
  RTDS_SET_TIMER(t_Idle, T_IDLE);
  RTDS_SET_TIMER(t_Summarise, T_SUMMARISE);
  RTDS_SET_TIMER(t_Stop_Summarise, T_STOP_SUMMARISE);
  RTDS_SDL_STATE_SET(eventFinished);
  break;
/* Transition for state eventDescribed - message EventFinished */
case EventFinished:
  if ( hasLeader )
    {
    // {{{ SN_LN_Summary params
    /*if (RTDS_currentContext->currentMessage->messageNumber == LN_SN_Summarise) {
    LOGS(SE, myIP << " SE/evDesc/recLNSNSummarize:");
    } else {
  LOGS(SE, myIP << " SE/evDesc/recEventFinished:");
  }*/

gpsTimeStamp.unixTime = time(0);
gpsTimeStamp.msFraction = 0;
tp = mySharedData->tp;
ts = mySharedData->ts;
tend = mySharedData->tend;
pga = mySharedData->pga;
pgv = mySharedData->pgv;
pgd = mySharedData->pgd;
noiseAverage = mySharedData->noiseAverage;
cav = mySharedData->cav;
ariasIntensity = mySharedData->ariasIntensity;
valueFourthChannel = mySharedData->valueFourthChannel;
batteryVoltage = mySharedData->batteryVoltage;
// }}} SN_LN_Summary params
if ( LE_IP == myIP )
  {
  RTDS_MSG_SEND_SN_LN_Summary_TO_NAME("LeadingEntity", RTDS_process_LeadingEntity,   LE_IP,   getCurrentGPSTime(this),   tp,   ts,   tend,   pga,   pgv,   pgd,   noiseAverage,   cav,   ariasIntensity,   valueFourthChannel,   batteryVoltage);
  }
else
  {
  RTDS_MSG_SEND_SN_LN_Summary_TO_NAME("te_sender", RTDS_process_te_sender,   LE_IP,   getCurrentGPSTime(this),   tp,   ts,   tend,   pga,   pgv,   pgd,   noiseAverage,   cav,   ariasIntensity,   valueFourthChannel,   batteryVoltage);
  }
}
RTDS_RESET_TIMER(t_Description);
RTDS_SET_TIMER(t_Idle, T_IDLE);
RTDS_SET_TIMER(t_Summarise, T_SUMMARISE);
RTDS_SET_TIMER(t_Stop_Summarise, T_STOP_SUMMARISE);
RTDS_SDL_STATE_SET(eventFinished);
break;
/* Transition for state eventDescribed - message t_Detection */
case t_Detection:
/* Transition for state eventDescribed - message t_Idle */
case t_Idle:
/* Transition for state eventDescribed - message NoEvent */
case NoEvent:
/* Transition for state eventDescribed - message EventDetected */
case EventDetected:
/* Transition for state eventDescribed - message LN_SN_Describe */
case LN_SN_Describe:
/* Transition for state eventDescribed - message LN_SN_PrimaryLN */
case LN_SN_PrimaryLN:
/* Transition for state eventDescribed - message LN_SN_SecondaryLN */
case LN_SN_SecondaryLN:
  switch(RTDS_currentContext->currentMessage->messageNumber)
    {
    case LN_SN_Describe:
      RTDS_MSG_RECEIVE_LN_SN_Describe(sender, gpsTimeStamp, event);
      break;
    case LN_SN_PrimaryLN:
      RTDS_MSG_RECEIVE_LN_SN_PrimaryLN(sender, gpsTimeStamp, LE_IP, gID);
      break;
    case LN_SN_SecondaryLN:
      RTDS_MSG_RECEIVE_LN_SN_SecondaryLN(sender, gpsTimeStamp, LE_IP, gID);
      break;
    } /* End of switch on message */
  // unexpected input
  break;
default:
  RTDS_transitionExecuted = 0;
  break;
} /* End of switch on message */
break;
/* Transitions for state Idle */
case Idle:
  switch(RTDS_currentContext->currentMessage->messageNumber)
    {
    /* Transition for state Idle - message SendPShared */
    case SendPShared:
      RTDS_MSG_RECEIVE_SendPShared(  mySharedData);
      RTDS_SDL_STATE_SET(Idle);
      break;
    /* Transition for state Idle - message LN_SN_PrimaryLN */
    case LN_SN_PrimaryLN:
    /* Transition for state Idle - message LN_SN_SecondaryLN */
    case LN_SN_SecondaryLN:
      switch(RTDS_currentContext->currentMessage->messageNumber)
        {
        case LN_SN_PrimaryLN:
          RTDS_MSG_RECEIVE_LN_SN_PrimaryLN(      LE_IP,       gpsTimeStamp,       myIP,       gID);
          break;
        case LN_SN_SecondaryLN:
          RTDS_MSG_RECEIVE_LN_SN_SecondaryLN(      LE_IP,       gpsTimeStamp,       myIP,       gID);
          break;
        } /* End of switch on message */
      hasLeader = true;
      goIdle:
      // {{{ SN_LN_Idle params

      gpsTimeStamp.unixTime = time(0);
      gpsTimeStamp.msFraction = 0;
      noiseAverage = mySharedData->noiseAverage;
      batteryVoltage = mySharedData->batteryVoltage;
      valueFourthChannel = mySharedData->valueFourthChannel;

      // }}} SN_LN_Idle params
      if ( LE_IP == myIP )
        {
        RTDS_MSG_SEND_SN_LN_Idle_TO_NAME("LeadingEntity", RTDS_process_LeadingEntity,         LE_IP,         getCurrentGPSTime(this),         noiseAverage,         batteryVoltage,         valueFourthChannel);
        }
      else
        {
        RTDS_MSG_SEND_SN_LN_Idle_TO_NAME("te_sender", RTDS_process_te_sender,         LE_IP,         getCurrentGPSTime(this),         noiseAverage,         batteryVoltage,         valueFourthChannel);
        }
      RTDS_SET_TIMER(t_Idle, T_IDLE);
      break;
    /* Transition for state Idle - message EventDetected */
    case EventDetected:
      RTDS_RESET_TIMER(t_Idle);
      if ( hasLeader )
        {
        // {{{ SN_LN_Detection params
        LOGS(SE, "SE/Idle/recEventDetected " << myIP);

        gpsTimeStamp.unixTime = time(0);
        gpsTimeStamp.msFraction = 0;
        tp = mySharedData->tp;
        a_max = mySharedData->a_max;
        v_max = mySharedData->v_max;
        d_max = mySharedData->d_max;
        noiseAverage = mySharedData->noiseAverage;
        valueFourthChannel = mySharedData->valueFourthChannel;
        sta_lta_TriggerValue = mySharedData->sta_lta_TriggerValue;

        LOGS(SE, myIP << " SE/Idle/sendSNLNDet to: " << LE_IP);
        // }}} SN_LN_Detection params
        if ( LE_IP == myIP )
          {
          RTDS_MSG_SEND_SN_LN_Detection_TO_NAME("LeadingEntity", RTDS_process_LeadingEntity,           LE_IP,           getCurrentGPSTime(this),           tp,           a_max,           v_max,           d_max,           noiseAverage,           valueFourthChannel,           sta_lta_TriggerValue);
          }
        else
          {
          RTDS_MSG_SEND_SN_LN_Detection_TO_NAME("te_sender", RTDS_process_te_sender,           LE_IP,           getCurrentGPSTime(this),           tp,           a_max,           v_max,           d_max,           noiseAverage,           valueFourthChannel,           sta_lta_TriggerValue);
          }
        }
      RTDS_SET_TIMER(t_Detection, T_DETECTION);
      RTDS_SDL_STATE_SET(eventDetected);
      break;
    /* Transition for state Idle - message LN_SN_Describe */
    case LN_SN_Describe:
      RTDS_MSG_RECEIVE_LN_SN_Describe(      sender,       gpsTimeStamp,       event);
      RTDS_RESET_TIMER(t_Idle);
      // {{{ SN_LN_Description params
      /*if (RTDS_currentContext->currentMessage->messageNumber == LN_SN_Alarm) {
      LOGS(SE, myIP << " SE/Idle/recLNSNAla:");
      }
    if (RTDS_currentContext->currentMessage->messageNumber == LN_SN_Describe) {
    LOGS(SE, myIP << " SE/Idle/recLNSNDesc:");
    }*/
  gpsTimeStamp.unixTime = time(0);
  gpsTimeStamp.msFraction = 0;
  tp = mySharedData->tp;
  waveType = mySharedData->waveType;
  pga = mySharedData->pga;
  pgv = mySharedData->pgv;
  pgd = mySharedData->pgd;
  noiseAverage = mySharedData->noiseAverage;
  predominantPeriod = mySharedData->predominantPeriod;
  cav = mySharedData->cav;
  ariasIntensity = mySharedData->ariasIntensity;
  valueFourthChannel = mySharedData->valueFourthChannel;

  //DEBUG
  LOGS(SE, myIP << " SE/Idle/sendSNLNDesc to: " << LE_IP);
  /*LOGS(SE, " gPSTimeStamp: " << gpsTimeStamp);
  LOGS(SE, " tp: " << tp);
  LOGS(SE, " waveType: " <<  " " << waveType);
  LOGS(SE, " pga: " <<  " " << pga);
  LOGS(SE, " pgv: " <<  " " << pgv);
  LOGS(SE, " pgd: " <<  " " << pgd);
  LOGS(SE, " noiseAverage: " <<  " " << noiseAverage);
  LOGS(SE, " predominantPeriod: " <<  " " << predominantPeriod);
  LOGS(SE, " cav: " <<  " " << cav);
  LOGS(SE, " ariasIntensity: " <<  " " << ariasIntensity);
  LOGS(SE, " valueFourthChannel: " <<  " " << valueFourthChannel);
  LOGS(SE, " valueFourthChannel: " <<  " " << valueFourthChannel);*/
  //ENDDEBUG
  // }}} SN_LN_Description params
  if ( LE_IP == myIP )
    {
    RTDS_MSG_SEND_SN_LN_Description_TO_NAME("LeadingEntity", RTDS_process_LeadingEntity,     LE_IP,     getCurrentGPSTime(this),     tp,     waveType,     pga,     pgv,     pgd,     noiseAverage,     predominantPeriod,     cav,     ariasIntensity,     valueFourthChannel);
    }
  else
    {
    RTDS_MSG_SEND_SN_LN_Description_TO_NAME("te_sender", RTDS_process_te_sender,     LE_IP,     getCurrentGPSTime(this),     tp,     waveType,     pga,     pgv,     pgd,     noiseAverage,     predominantPeriod,     cav,     ariasIntensity,     valueFourthChannel);
    }
  RTDS_SET_TIMER(t_Description, T_DESCRIPTION);
  RTDS_SDL_STATE_SET(eventDescribed);
  break;
/* Transition for state Idle - message t_Idle */
case t_Idle:
  if ( ENABLE_SN_LN_STATUS && hasLeader )
    {
    goto goIdle;
    }
  RTDS_SET_TIMER(t_Idle, T_IDLE);
  break;
/* Transition for state Idle - message NoEvent */
case NoEvent:
/* Transition for state Idle - message EventDescribed */
case EventDescribed:
/* Transition for state Idle - message EventFinished */
case EventFinished:
/* Transition for state Idle - message t_Detection */
case t_Detection:
/* Transition for state Idle - message t_Description */
case t_Description:
/* Transition for state Idle - message LN_SN_FalseAlarm */
case LN_SN_FalseAlarm:
/* Transition for state Idle - message LN_SN_Summarise */
case LN_SN_Summarise:
  switch(RTDS_currentContext->currentMessage->messageNumber)
    {
    case LN_SN_FalseAlarm:
      RTDS_MSG_RECEIVE_LN_SN_FalseAlarm(  sender,   gpsTimeStamp,   timeOfFalseAlarm);
      break;
    case LN_SN_Summarise:
      RTDS_MSG_RECEIVE_LN_SN_Summarise(  sender,   gpsTimeStamp,   event);
      break;
    } /* End of switch on message */
  // unexpected input
  break;
default:
  RTDS_transitionExecuted = 0;
  break;
} /* End of switch on message */
break;
/* Transitions for state eventFinished */
case eventFinished:
  switch(RTDS_currentContext->currentMessage->messageNumber)
    {
    /* Transition for state eventFinished - message EventDetected */
    case EventDetected:
      RTDS_RESET_TIMER(t_Idle);
      if ( hasLeader )
        {
        // {{{ SN_LN_Detection params
        LOGS(SE, "SE/Idle/recEventDetected " << myIP);

        gpsTimeStamp.unixTime = time(0);
        gpsTimeStamp.msFraction = 0;
        tp = mySharedData->tp;
        a_max = mySharedData->a_max;
        v_max = mySharedData->v_max;
        d_max = mySharedData->d_max;
        noiseAverage = mySharedData->noiseAverage;
        valueFourthChannel = mySharedData->valueFourthChannel;
        sta_lta_TriggerValue = mySharedData->sta_lta_TriggerValue;

        LOGS(SE, myIP << " SE/Idle/sendSNLNDet to: " << LE_IP);
        // }}} SN_LN_Detection params
        if ( LE_IP == myIP )
          {
          RTDS_MSG_SEND_SN_LN_Detection_TO_NAME("LeadingEntity", RTDS_process_LeadingEntity,           LE_IP,           getCurrentGPSTime(this),           tp,           a_max,           v_max,           d_max,           noiseAverage,           valueFourthChannel,           sta_lta_TriggerValue);
          }
        else
          {
          RTDS_MSG_SEND_SN_LN_Detection_TO_NAME("te_sender", RTDS_process_te_sender,           LE_IP,           getCurrentGPSTime(this),           tp,           a_max,           v_max,           d_max,           noiseAverage,           valueFourthChannel,           sta_lta_TriggerValue);
          }
        }
      RTDS_SET_TIMER(t_Detection, T_DETECTION);
      RTDS_SDL_STATE_SET(eventDetected);
      break;
    /* Transition for state eventFinished - message LN_SN_Describe */
    case LN_SN_Describe:
      RTDS_MSG_RECEIVE_LN_SN_Describe(      sender,       gpsTimeStamp,       event);
      RTDS_RESET_TIMER(t_Idle);
      // {{{ SN_LN_Description params
      /*if (RTDS_currentContext->currentMessage->messageNumber == LN_SN_Alarm) {
      LOGS(SE, myIP << " SE/Idle/recLNSNAla:");
      }
    if (RTDS_currentContext->currentMessage->messageNumber == LN_SN_Describe) {
    LOGS(SE, myIP << " SE/Idle/recLNSNDesc:");
    }*/
  gpsTimeStamp.unixTime = time(0);
  gpsTimeStamp.msFraction = 0;
  tp = mySharedData->tp;
  waveType = mySharedData->waveType;
  pga = mySharedData->pga;
  pgv = mySharedData->pgv;
  pgd = mySharedData->pgd;
  noiseAverage = mySharedData->noiseAverage;
  predominantPeriod = mySharedData->predominantPeriod;
  cav = mySharedData->cav;
  ariasIntensity = mySharedData->ariasIntensity;
  valueFourthChannel = mySharedData->valueFourthChannel;

  //DEBUG
  LOGS(SE, myIP << " SE/Idle/sendSNLNDesc to: " << LE_IP);
  /*LOGS(SE, " gPSTimeStamp: " << gpsTimeStamp);
  LOGS(SE, " tp: " << tp);
  LOGS(SE, " waveType: " <<  " " << waveType);
  LOGS(SE, " pga: " <<  " " << pga);
  LOGS(SE, " pgv: " <<  " " << pgv);
  LOGS(SE, " pgd: " <<  " " << pgd);
  LOGS(SE, " noiseAverage: " <<  " " << noiseAverage);
  LOGS(SE, " predominantPeriod: " <<  " " << predominantPeriod);
  LOGS(SE, " cav: " <<  " " << cav);
  LOGS(SE, " ariasIntensity: " <<  " " << ariasIntensity);
  LOGS(SE, " valueFourthChannel: " <<  " " << valueFourthChannel);
  LOGS(SE, " valueFourthChannel: " <<  " " << valueFourthChannel);*/
  //ENDDEBUG
  // }}} SN_LN_Description params
  if ( LE_IP == myIP )
    {
    RTDS_MSG_SEND_SN_LN_Description_TO_NAME("LeadingEntity", RTDS_process_LeadingEntity,     LE_IP,     getCurrentGPSTime(this),     tp,     waveType,     pga,     pgv,     pgd,     noiseAverage,     predominantPeriod,     cav,     ariasIntensity,     valueFourthChannel);
    }
  else
    {
    RTDS_MSG_SEND_SN_LN_Description_TO_NAME("te_sender", RTDS_process_te_sender,     LE_IP,     getCurrentGPSTime(this),     tp,     waveType,     pga,     pgv,     pgd,     noiseAverage,     predominantPeriod,     cav,     ariasIntensity,     valueFourthChannel);
    }
  RTDS_SET_TIMER(t_Description, T_DESCRIPTION);
  RTDS_SDL_STATE_SET(eventDescribed);
  break;
/* Transition for state eventFinished - message t_Idle */
case t_Idle:
  if ( ENABLE_SN_LN_STATUS && hasLeader )
    {
    goto goIdle;
    }
  RTDS_SET_TIMER(t_Idle, T_IDLE);
  break;
/* Transition for state eventFinished - message t_Stop_Summarise */
case t_Stop_Summarise:
  RTDS_SDL_STATE_SET(Idle);
  break;
/* Transition for state eventFinished - message t_Summarise */
case t_Summarise:
  if ( hasLeader )
    {
    // {{{ SN_LN_Summary params (finished)
    gpsTimeStamp.unixTime = time(0);
    gpsTimeStamp.msFraction = 0;
    tp = mySharedData->tp;
    ts = mySharedData->ts;
    tend = mySharedData->tend;
    pga = mySharedData->pga;
    pgv = mySharedData->pgv;
    pgd = mySharedData->pgd;
    noiseAverage = mySharedData->noiseAverage;
    cav = mySharedData->cav;
    ariasIntensity = mySharedData->ariasIntensity;
    valueFourthChannel = mySharedData->valueFourthChannel;
    batteryVoltage = mySharedData->batteryVoltage;
    // }}} SN_LN_Summary params (finished)
    if ( LE_IP == myIP )
      {
      RTDS_MSG_SEND_SN_LN_Summary_TO_NAME("LeadingEntity", RTDS_process_LeadingEntity,       LE_IP,       getCurrentGPSTime(this),       tp,       ts,       tend,       pga,       pgv,       pgd,       noiseAverage,       cav,       ariasIntensity,       valueFourthChannel,       batteryVoltage);
      }
    else
      {
      RTDS_MSG_SEND_SN_LN_Summary_TO_NAME("te_sender", RTDS_process_te_sender,       LE_IP,       getCurrentGPSTime(this),       tp,       ts,       tend,       pga,       pgv,       pgd,       noiseAverage,       cav,       ariasIntensity,       valueFourthChannel,       batteryVoltage);
      }
    }
  RTDS_SET_TIMER(t_Summarise, T_SUMMARISE);
  RTDS_SDL_STATE_SET(eventFinished);
  break;
default:
  RTDS_transitionExecuted = 0;
  break;
} /* End of switch on message */
break;
/* Transitions for state eventDetected */
case eventDetected:
  switch(RTDS_currentContext->currentMessage->messageNumber)
    {
    /* Transition for state eventDetected - message LN_SN_Describe */
    case LN_SN_Describe:
      RTDS_MSG_RECEIVE_LN_SN_Describe(  sender,   gpsTimeStamp,   event);
      RTDS_RESET_TIMER(t_Detection);
      // {{{ SN_LN_Description params
      /*if (RTDS_currentContext->currentMessage->messageNumber == LN_SN_Alarm) {
      LOGS(SE, myIP << " SE/evDet/recLNSNAla:");
      }
    if (RTDS_currentContext->currentMessage->messageNumber == LN_SN_Describe) {
    LOGS(SE, myIP << " SE/evDet/recLNSNDesc:");
    }
  else {
  LOGS(SE, myIP << " SE/evDet/recEventDesc:");
  }*/
gpsTimeStamp.unixTime = time(0);
gpsTimeStamp.msFraction = 0;
tp = mySharedData->tp;
waveType = mySharedData->waveType;
pga = mySharedData->pga;
pgv = mySharedData->pgv;
pgd = mySharedData->pgd;
noiseAverage = mySharedData->noiseAverage;
predominantPeriod = mySharedData->predominantPeriod;
cav = mySharedData->cav;
ariasIntensity = mySharedData->ariasIntensity;
valueFourthChannel = mySharedData->valueFourthChannel;

LOGS(SE, myIP << " SE/evDet/sendSNLNDesc to: " << LE_IP);
// }}} SN_LN_Description params
if ( LE_IP == myIP )
  {
  RTDS_MSG_SEND_SN_LN_Description_TO_NAME("LeadingEntity", RTDS_process_LeadingEntity,   LE_IP,   getCurrentGPSTime(this),   tp,   waveType,   pga,   pgv,   pgd,   noiseAverage,   predominantPeriod,   cav,   ariasIntensity,   valueFourthChannel);
  }
else
  {
  RTDS_MSG_SEND_SN_LN_Description_TO_NAME("te_sender", RTDS_process_te_sender,   LE_IP,   getCurrentGPSTime(this),   tp,   waveType,   pga,   pgv,   pgd,   noiseAverage,   predominantPeriod,   cav,   ariasIntensity,   valueFourthChannel);
  }
RTDS_SET_TIMER(t_Description, T_DESCRIPTION);
RTDS_SDL_STATE_SET(eventDescribed);
break;
/* Transition for state eventDetected - message LN_SN_FalseAlarm */
case LN_SN_FalseAlarm:
  RTDS_MSG_RECEIVE_LN_SN_FalseAlarm(sender, gpsTimeStamp, timeOfFalseAlarm);
  RTDS_RESET_TIMER(t_Detection);
  // {{{ SN_LN_Idle params
  /*if (RTDS_currentContext->currentMessage->messageNumber == LN_SN_FalseAlarm) {
  LOGS(SE, myIP << " SE/evDet/recLNSNFA:");
  } else {
LOGS(SE, myIP << " SE/evDet/recNoEvent");
}*/

gpsTimeStamp.unixTime = time(0);
gpsTimeStamp.msFraction = 0;
noiseAverage = mySharedData->noiseAverage;
batteryVoltage = mySharedData->batteryVoltage;
valueFourthChannel = mySharedData->valueFourthChannel;

LOGS(SE, myIP << " SE/evDet/sendSNLNIdle to: " << sender);
// }}} SN_LN_Idle params
if ( LE_IP == myIP )
  {
  RTDS_MSG_SEND_SN_LN_Idle_TO_NAME("LeadingEntity", RTDS_process_LeadingEntity,   LE_IP,   getCurrentGPSTime(this),   noiseAverage,   batteryVoltage,   valueFourthChannel);
  }
else
  {
  RTDS_MSG_SEND_SN_LN_Idle_TO_NAME("te_sender", RTDS_process_te_sender,   LE_IP,   getCurrentGPSTime(this),   noiseAverage,   batteryVoltage,   valueFourthChannel);
  }
RTDS_SET_TIMER(t_Idle, T_IDLE);
RTDS_SDL_STATE_SET(Idle);
break;
/* Transition for state eventDetected - message t_Detection */
case t_Detection:
  // {{{ SN_LN_Detection params
  LOGS(SE, "SE/evDetected/rect_Detection " << myIP);
  gpsTimeStamp.unixTime = time(0);
  gpsTimeStamp.msFraction = 0;
  tp = mySharedData->tp;
  a_max = mySharedData->a_max;
  v_max = mySharedData->v_max;
  d_max = mySharedData->d_max;
  noiseAverage = mySharedData->noiseAverage;
  valueFourthChannel = mySharedData->valueFourthChannel;
  sta_lta_TriggerValue = mySharedData->sta_lta_TriggerValue;

  LOGS(SE, myIP << " SE/evDet/sendSNLNDet to: " << LE_IP);
  // }}} SN_LN_Detection params
  if ( LE_IP == myIP )
    {
    RTDS_MSG_SEND_SN_LN_Detection_TO_NAME("LeadingEntity", RTDS_process_LeadingEntity,     LE_IP,     getCurrentGPSTime(this),     tp,     a_max,     v_max,     d_max,     noiseAverage,     valueFourthChannel,     sta_lta_TriggerValue);
    }
  else
    {
    RTDS_MSG_SEND_SN_LN_Detection_TO_NAME("te_sender", RTDS_process_te_sender,     LE_IP,     getCurrentGPSTime(this),     tp,     a_max,     v_max,     d_max,     noiseAverage,     valueFourthChannel,     sta_lta_TriggerValue);
    }
  RTDS_SET_TIMER(t_Detection, T_DETECTION);
  break;
/* Transition for state eventDetected - message NoEvent */
case NoEvent:
  if ( !(hasLeader) )
    {
    RTDS_RESET_TIMER(t_Detection);
    }
  else if ( hasLeader )
    {
    RTDS_RESET_TIMER(t_Detection);
    // {{{ SN_LN_Idle params
    /*if (RTDS_currentContext->currentMessage->messageNumber == LN_SN_FalseAlarm) {
    LOGS(SE, myIP << " SE/evDet/recLNSNFA:");
    } else {
  LOGS(SE, myIP << " SE/evDet/recNoEvent");
  }*/

gpsTimeStamp.unixTime = time(0);
gpsTimeStamp.msFraction = 0;
noiseAverage = mySharedData->noiseAverage;
batteryVoltage = mySharedData->batteryVoltage;
valueFourthChannel = mySharedData->valueFourthChannel;

LOGS(SE, myIP << " SE/evDet/sendSNLNIdle to: " << sender);
// }}} SN_LN_Idle params
if ( LE_IP == myIP )
  {
  RTDS_MSG_SEND_SN_LN_Idle_TO_NAME("LeadingEntity", RTDS_process_LeadingEntity,   LE_IP,   getCurrentGPSTime(this),   noiseAverage,   batteryVoltage,   valueFourthChannel);
  }
else
  {
  RTDS_MSG_SEND_SN_LN_Idle_TO_NAME("te_sender", RTDS_process_te_sender,   LE_IP,   getCurrentGPSTime(this),   noiseAverage,   batteryVoltage,   valueFourthChannel);
  }
}
RTDS_SET_TIMER(t_Idle, T_IDLE);
RTDS_SDL_STATE_SET(Idle);
break;
/* Transition for state eventDetected - message EventDescribed */
case EventDescribed:
  if ( !(hasLeader) )
    {
    RTDS_RESET_TIMER(t_Detection);
    }
  else if ( hasLeader )
    {
    RTDS_RESET_TIMER(t_Detection);
    // {{{ SN_LN_Description params
    /*if (RTDS_currentContext->currentMessage->messageNumber == LN_SN_Alarm) {
    LOGS(SE, myIP << " SE/evDet/recLNSNAla:");
    }
  if (RTDS_currentContext->currentMessage->messageNumber == LN_SN_Describe) {
  LOGS(SE, myIP << " SE/evDet/recLNSNDesc:");
  }
else {
LOGS(SE, myIP << " SE/evDet/recEventDesc:");
}*/
gpsTimeStamp.unixTime = time(0);
gpsTimeStamp.msFraction = 0;
tp = mySharedData->tp;
waveType = mySharedData->waveType;
pga = mySharedData->pga;
pgv = mySharedData->pgv;
pgd = mySharedData->pgd;
noiseAverage = mySharedData->noiseAverage;
predominantPeriod = mySharedData->predominantPeriod;
cav = mySharedData->cav;
ariasIntensity = mySharedData->ariasIntensity;
valueFourthChannel = mySharedData->valueFourthChannel;

LOGS(SE, myIP << " SE/evDet/sendSNLNDesc to: " << LE_IP);
// }}} SN_LN_Description params
if ( LE_IP == myIP )
  {
  RTDS_MSG_SEND_SN_LN_Description_TO_NAME("LeadingEntity", RTDS_process_LeadingEntity,   LE_IP,   getCurrentGPSTime(this),   tp,   waveType,   pga,   pgv,   pgd,   noiseAverage,   predominantPeriod,   cav,   ariasIntensity,   valueFourthChannel);
  }
else
  {
  RTDS_MSG_SEND_SN_LN_Description_TO_NAME("te_sender", RTDS_process_te_sender,   LE_IP,   getCurrentGPSTime(this),   tp,   waveType,   pga,   pgv,   pgd,   noiseAverage,   predominantPeriod,   cav,   ariasIntensity,   valueFourthChannel);
  }
}
RTDS_SET_TIMER(t_Description, T_DESCRIPTION);
RTDS_SDL_STATE_SET(eventDescribed);
break;
/* Transition for state eventDetected - message t_Idle */
case t_Idle:
/* Transition for state eventDetected - message EventDetected */
case EventDetected:
/* Transition for state eventDetected - message EventFinished */
case EventFinished:
/* Transition for state eventDetected - message t_Description */
case t_Description:
/* Transition for state eventDetected - message LN_SN_Summarise */
case LN_SN_Summarise:
/* Transition for state eventDetected - message LN_SN_PrimaryLN */
case LN_SN_PrimaryLN:
/* Transition for state eventDetected - message LN_SN_SecondaryLN */
case LN_SN_SecondaryLN:
  switch(RTDS_currentContext->currentMessage->messageNumber)
    {
    case LN_SN_Summarise:
      RTDS_MSG_RECEIVE_LN_SN_Summarise(sender, gpsTimeStamp, event);
      break;
    case LN_SN_PrimaryLN:
      RTDS_MSG_RECEIVE_LN_SN_PrimaryLN(sender, gpsTimeStamp, LE_IP, gID);
      break;
    case LN_SN_SecondaryLN:
      RTDS_MSG_RECEIVE_LN_SN_SecondaryLN(sender, gpsTimeStamp, LE_IP, gID);
      break;
    } /* End of switch on message */
  // unexpected input
  break;
default:
  RTDS_transitionExecuted = 0;
  break;
} /* End of switch on message */
break;
default:
  RTDS_transitionExecuted = 0;
  break;
} /* End of switch(RTDS_currentContext->sdlState) */
// odemx/bricks/RTDS_Proc_end
delete currentMessage;
}; // end of while(true)
// no return here, since this brick does not know the return type
// end ends
}

/* private methods */
