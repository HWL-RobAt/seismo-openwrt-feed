/*
 * logging.h
 *
 *  Created on: 02.12.2009
 *      Author: Michael Piefel
 *   Copyright: 2009 Humboldt-Universität zu Berlin
 */

#ifndef LOGGING_H_
#define LOGGING_H_

const bool CONSOLE_LOG_VERBOSE_CHATTER = true;
const bool CONSOLE_LOG_XMLLOG = false;
const bool CONSOLE_LOG_COMMON = false;
const bool CONSOLE_LOG_MESSAGE = false;
const bool CONSOLE_LOG_MAIN = false;
const bool CONSOLE_LOG_MSDP = false;
const bool CONSOLE_LOG_TN = false;
const bool CONSOLE_LOG_TE = false;
const bool CONSOLE_LOG_ME = false;
const bool CONSOLE_LOG_SE = false;
const bool CONSOLE_LOG_LE = true;
const bool CONSOLE_LOG_SAE = false;
const bool CONSOLE_LOG_DLE = false;
const bool CONSOLE_LOG_GE = false;
const bool CONSOLE_LOG_DESCRIBE = true;

/// Always log (to stderr), formatted; in order to use the macro, <cstdio> must have been included.
#define LOGF_ALWAYS(DOMAIN, _fmt, ...) \
	std::fprintf(stderr, "[" #DOMAIN "] " _fmt "\n", __VA_ARGS__)
/// Always log (to cerr), stream-like; in order to use the macro, <iostream> must have been included.
#define LOGS_ALWAYS(DOMAIN, EXPR) \
	std::cerr << "[" #DOMAIN "] " << EXPR << std::endl;

/// Verbose log (to stdout), formatted; in order to use the macro, <cstdio> must have been included.
#define LOGF(DOMAIN, _fmt, ...) \
    if (CONSOLE_LOG_VERBOSE_CHATTER && CONSOLE_LOG_##DOMAIN) \
	std::fprintf(stdout, "[" #DOMAIN "] " _fmt "\n", __VA_ARGS__)
/// Verbose log (to cout), stream-like; in order to use the macro, <iostream> must have been included.
#define LOGS(DOMAIN, EXPR) \
    if (CONSOLE_LOG_VERBOSE_CHATTER && CONSOLE_LOG_##DOMAIN) \
	std::cout << "[" #DOMAIN "] " << EXPR << std::endl;

#endif /* LOGGING_H_ */
