/*SX*//** @file
 *  Generated file, find templates in SX folders
 */

#ifndef LEADINGENTITY_UP_H_INCLUDED
#define LEADINGENTITY_UP_H_INCLUDED
#ifndef _LEADINGENTITY_H_
#define _LEADINGENTITY_H_

#include "blockClass_Node.h"




#endif
#endif

#ifndef LEADINGENTITY_H_INCLUDED
#define LEADINGENTITY_H_INCLUDED

#include "RTDS_SDLPROCESS.h"

/**@brief The process LeadingEntity 
 */
class LeadingEntity : public RTDS::SDLProcess {
public:

    /**@brief Constructor.
     */
    LeadingEntity(RTDS::Logger& logger = RTDS::emptyLogger);

    /**@brief Lifeline of this process.
     */
    virtual int main();

private:
    
	/**@brief Method Alarm_to_all_LN 
	 * @param RTDS_GlobalProcessInfo * RTDS_currentContext 
	 * @param IPAddress myIP 
	 * @param const ip_vec& LNs 
	 * @param bool_map& LE_Inf_Ala 
	 * @param EventID event 
	 * @param const trig_vec& vec_alaTriggered 
	 */
	void Alarm_to_all_LN(RTDS_GlobalProcessInfo * RTDS_currentContext, IPAddress myIP, const ip_vec& LNs, bool_map& LE_Inf_Ala, EventID event, const trig_vec& vec_alaTriggered);
    
	/**@brief Method Describe_to_all_SN 
	 * @param RTDS_GlobalProcessInfo * RTDS_currentContext 
	 * @param const ip_vec& SNs 
	 * @param bool_map& SEInf 
	 * @param EventID event 
	 * @param const IPAddress& myIP 
	 */
	void Describe_to_all_SN(RTDS_GlobalProcessInfo * RTDS_currentContext, const ip_vec& SNs, bool_map& SEInf, EventID event, const IPAddress& myIP);
    
};

#ifndef _LEADINGENTITY_H_
#define _LEADINGENTITY_H_

#include "blockClass_Node.h"




#endif

#endif
