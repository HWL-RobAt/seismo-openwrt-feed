/*SX*//** @file
 *  Generated file, find templates in SX folders
 */

#ifndef DATALISTENERENTITY_UP_H_INCLUDED
#define DATALISTENERENTITY_UP_H_INCLUDED
#ifndef _DATALISTENERENTITY_H_
#define _DATALISTENERENTITY_H_

#include "blockClass_Node.h"

#endif
#endif

#ifndef DATALISTENERENTITY_H_INCLUDED
#define DATALISTENERENTITY_H_INCLUDED

#include "RTDS_SDLPROCESS.h"

/**@brief The process DataListenerEntity 
 */
class DataListenerEntity : public RTDS::SDLProcess {
public:

    /**@brief Constructor.
     */
    DataListenerEntity(RTDS::Logger& logger = RTDS::emptyLogger);

    /**@brief Lifeline of this process.
     */
    virtual int main();

private:
    
};

#ifndef _DATALISTENERENTITY_H_
#define _DATALISTENERENTITY_H_

#include "blockClass_Node.h"

#endif

#endif
