
#include "RTDS_SDLTIMER.h"
#include <boost/bind.hpp>

namespace RTDS
{
  using namespace boost::posix_time;
  using namespace boost;
  
  SDLTimer::SDLTimer(SDLProcess& receiver, int messageID)
  : rcv(receiver),
    msgID(messageID),
    timer(receiver.ioService)
  {}
  
  void SDLTimer::removeFromSchedule()
  {
    timer.cancel();
  }
  
  void SDLTimer::scheduleIn(long delay)
  {
    timer.expires_from_now(boost::posix_time::millisec(delay));
    timer.async_wait(bind(&SDLTimer::handler, this,
                          boost::asio::placeholders::error));
  }
  
  void SDLTimer::handler(const boost::system::error_code& error)
  {
    if (!error)
    {
	  RTDS::MsgHeader* msg = new RTDS::MsgHeader(msgID, *rcv.msgQueue.writer, 0, 0);
	  msg->sequenceNumber = 0;
	  
	  rcv.msgQSend(rcv.msgQueue.writer, msg);
    }
  }
}
