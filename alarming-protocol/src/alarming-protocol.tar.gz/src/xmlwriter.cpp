/** @file
 * @brief XML writer, part of `shared_src`
 * @author Ingmar Eveslage, Michael Piefel
 */

#include "xmlwriter.h"
#include <cstdarg>
#include <cstdio>

inline void xmlwriter::indent() {
    std::fprintf(fp, "\n");

    for (int i = 0; i < indent_level; ++i)
	std::fprintf(fp, "\t");
}

xmlwriter::xmlwriter(const std::string& fileName)
:	sXmlFile(fileName),
	fp(std::fopen(sXmlFile.c_str(),"w")),
	indent_level(0)
{
    if (!fp)
	std::printf("Unable to open output file");
    else
	std::fprintf(fp, "<?xml version=\"1.0\" encoding=\"UTF-8\" \?>");
}

xmlwriter::~xmlwriter() {
    if (fp != NULL)
	std::fclose(fp);

    vectAttrData.clear();
}


void xmlwriter::Createtag(const std::string& tag) {
    indent();
    std::fprintf(fp, "<%s", tag.c_str());
	
    // add attributes
    while (vectAttrData.size() > 1) {
	std::fprintf(fp, " %s=", vectAttrData.back().c_str());
	vectAttrData.pop_back();
	std::fprintf(fp, "\"%s\"", vectAttrData.back().c_str());
	vectAttrData.pop_back();
    }

    vectAttrData.clear();

    std::fprintf(fp, ">");
    tagStack.push(tag);
    ++indent_level;
}

void xmlwriter::CloseLasttag() {
    --indent_level;
    indent();
    std::fprintf(fp, "</%s>", tagStack.top().c_str());
    tagStack.pop();
}

void xmlwriter::CloseAlltags() {
    while (tagStack.size()) {
	--indent_level;
	indent();

	std::fprintf(fp, "</%s>", tagStack.top().c_str());
	tagStack.pop();
    }
}

void xmlwriter::CreateChild(const std::string& tag, const std::string& value) {
    indent();
    std::fprintf(fp, "<%s", tag.c_str());

    // add attributes
    while (vectAttrData.size() > 1) {
	std::fprintf(fp, " %s=", vectAttrData.back().c_str());
	vectAttrData.pop_back();
	std::fprintf(fp, "\"%s\"", vectAttrData.back().c_str());
	vectAttrData.pop_back();
    }

    vectAttrData.clear();

    // add value and close tag
    std::fprintf(fp, ">%s</%s>", value.c_str(), tag.c_str());
}

void xmlwriter::AddAtributes(const std::string& key, const std::string& val) {
    vectAttrData.push_back(val);
    vectAttrData.push_back(key);
}

void xmlwriter::AddComment(const std::string& comment) {
    indent();
    std::fprintf(fp, "<!--%s-->", comment.c_str());
}
