#ifndef _SINGLENODE_H_
#define _SINGLENODE_H_



#include "common.h"

#endif
