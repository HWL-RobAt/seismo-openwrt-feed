/** @file
 * @brief XML writer, part of `shared_src`
 * @author Ingmar Eveslage, Michael Piefel
 */

#ifndef xmlwriter_h
#define xmlwriter_h

#include <string>
#include <vector>
#include <stack>

class xmlwriter {
    std::string sXmlFile;

    FILE *fp;
    int indent_level;

    std::vector<std::string> vectAttrData;
    std::stack<std::string> tagStack;

    void indent();

public:

    /* ***** Constructor/Destructor */

    xmlwriter(const std::string& fileName);

    ~xmlwriter();

    /* ***** Methods */

    void CreateChild(const std::string& tag, const std::string& value);

    void Createtag(const std::string& tag);

    void CloseLasttag();

    void CloseAlltags();

    void AddAtributes(const std::string& name, const std::string& value);

    void AddComment(const std::string& comment);

    bool isValid() const {
	return fp;
    }

};

#endif

