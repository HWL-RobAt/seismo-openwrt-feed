/*SX*/
/**
 * @file te_sender.cpp
 * @date Aug 17, 2008
 * @author Ronald Kluth
 *
 * @brief Definition of te_sender functions.
 * This file is part of `boost_substitute`.
 */
#include "common.h"
#include "te_sender.h"
#include "te_receiver.h"
#include "RTDS_gen.h"
#include "RTDS_messages.h"
#include <iostream>
#include <boost/thread/thread.hpp>
#include <boost/bind.hpp>

using namespace AP_GeneralProtocol;

// helper functions ///////////////////////////////////////////////////////////////////////////////

/**
 * Encode a message in ASN.1, wrapping it in an EW and then a general protocol message.
 * @param choice the type of the message, as an enumeration value of the EWProtocol choice
 * @param message any message that can be part of the EWProtocol choice
 * @return the ASN.1 BER encoded string
 */
std::string encode_EW_message(unsigned int choice, const SDLType& message) {
    // wrap the actual message in an EW message: TYPE_APEWProtocol( msg type enum value, actual msg )
    const TYPE_APEWProtocol ewMessage( choice, message );

    // wrap the EW message in a general protocol message: TYPE_APGeneralProtocol( protocol type enum value, actual msg )
    const TYPE_APGeneralProtocol generalMessage( TYPE_APGeneralProtocol::CHOICE_mAPEWProtocol, ewMessage );

    return encode( generalMessage );
}

/**
 * Encode a message in ASN.1, wrapping it in an managing and then a general protocol message.
 * @param choice the type of the message, as an enumeration value of the EWProtocol choice
 * @param message any message that can be part of the EWProtocol choice
 * @return the ASN.1 BER encoded string
 */
std::string encode_man_message(unsigned int choice, const SDLType& message) {
    // wrap the actual message in an managing message: TYPE_APManagingProtocol( msg type enum value, actual msg )
    const TYPE_APManagingProtocol manMessage( choice, message );

    // wrap the EW message in a general protocol message: TYPE_APGeneralProtocol( protocol type enum value, actual msg )
    const TYPE_APGeneralProtocol generalMessage( TYPE_APGeneralProtocol::CHOICE_mAPManagingProtocol, manMessage );

    return encode( generalMessage );
}


// implementation of class te_sender //////////////////////////////////////////////////////////////
int te_sender::main() {
    /* starts stdio.run() asynchronous stops when isRunnings destructor is destroyed */
    boost::thread _workThread_t(boost::bind(&boost::asio::io_service::run, &ioService));
    std::auto_ptr<boost::asio::io_service::work> _workThread_ptr(isRunning);
    isRunning = 0;

    while (true) {
	currentMessage = msgQRead();
	RTDS_LOG_MESSAGE_RECEIVE( &currentMessage->sender , msgQueue.writer , currentMessage->sequenceNumber, getCurrentTime());
	//cout << "TE sending: " << currentMessage->messageNumber << endl;
	send();
    }

    return 0;
}

void te_sender::send() {
    switch (currentMessage->messageNumber) {
    case SN_LN_Idle: // to LN
    {
	RTDS_SN_LN_Idle_data* data = new RTDS_SN_LN_Idle_data;
	RTDS_MSG_RECEIVE_SN_LN_Idle(
		data->param1,
		data->param2,
		data->param3,
		data->param4,
		data->param5 );
	//receiver = getReceiver( data->param1 );

	// encode ASN1: the receiver (param1) is not part of the data
	// create an object of the actual message data type
	const TYPE_SN_LN_Idle actualMessage( data->param2, data->param3, data->param4, data->param5);

	const std::string message_ber = encode_EW_message(
		TYPE_APEWProtocol::CHOICE_mSN_LN_Idle, actualMessage);
	send_and_log("SN_LN_Idle", message_ber, data->param1);
	break;
    }
    case SN_LN_Detection: // to LN
    {
	RTDS_SN_LN_Detection_data* data = new RTDS_SN_LN_Detection_data;

	RTDS_MSG_RECEIVE_SN_LN_Detection(
		data->param1,
		data->param2,
		data->param3,
		data->param4,
		data->param5,
		data->param6,
		data->param7,
		data->param8,
		data->param9 );


	// encode ASN1: the receiver (param1) is not part of the data
	// create an object of the actual message data type
	const TYPE_SN_LN_Detection actualMessage( data->param2, data->param3, data->param4, data->param5, data->param6, data->param7, data->param8, data->param9 );

	const std::string message_ber = encode_EW_message(
		TYPE_APEWProtocol::CHOICE_mSN_LN_Detection, actualMessage);
	send_and_log("SN_LN_Detection", message_ber, data->param1);
	break;
    }
    case SN_LN_Description: // to LN
    {
	RTDS_SN_LN_Description_data* data = new RTDS_SN_LN_Description_data;

	RTDS_MSG_RECEIVE_SN_LN_Description(
		data->param1,
		data->param2,
		data->param3,
		data->param4,
		data->param5,
		data->param6,
		data->param7,
		data->param8,
		data->param9,
		data->param10,
		data->param11,
		data->param12 );

	// encode ASN1: the receiver (param1) is not part of the data
	// create an object of the actual message data type
	TYPE_APEWProtocol_GEN_8 wavetype;
	if(data->param4 == PWave)
	    wavetype = TYPE_APEWProtocol_GEN_8::LIT_pWave();
	else
	    wavetype = TYPE_APEWProtocol_GEN_8::LIT_sWave();

	const TYPE_SN_LN_Description actualMessage( data->param2, data->param3,
		wavetype, data->param5, data->param6,
		data->param7, data->param8, data->param9, data->param10, data->param11,
		data->param12 );

	const std::string message_ber = encode_EW_message(
		TYPE_APEWProtocol::CHOICE_mSN_LN_Description, actualMessage);
	send_and_log("SN_LN_Description", message_ber, data->param1);
	break;
    }
    case SN_LN_Summary: // to LN
    {
	RTDS_SN_LN_Summary_data* data = new RTDS_SN_LN_Summary_data;

	RTDS_MSG_RECEIVE_SN_LN_Summary(
		data->param1,
		data->param2,
		data->param3,
		data->param4,
		data->param5,
		data->param6,
		data->param7,
		data->param8,
		data->param9,
		data->param10,
		data->param11,
		data->param12,
		data->param13 );

	// encode ASN1: the receiver (param1) is not part of the data
	// create an object of the actual message data type

	const TYPE_SN_LN_Summary actualMessage( data->param2, data->param3, data->param4, data->param5, data->param6, data->param7, data->param8, data->param9, data->param10, data->param11, data->param12, data->param13 );

	const std::string message_ber = encode_EW_message(
		TYPE_APEWProtocol::CHOICE_mSN_LN_Summary, actualMessage);
	send_and_log("SN_LN_Summary", message_ber, data->param1);
	break;
    }
    case SN_LN_PositionChange: // to LN
    {
	RTDS_SN_LN_PositionChange_data* data = new RTDS_SN_LN_PositionChange_data;

	RTDS_MSG_RECEIVE_SN_LN_PositionChange(
		data->param1,
		data->param2,
		data->param3,
		data->param4 );

	// encode ASN1: the receiver (param1) is not part of the data
	// create an object of the actual message data type

	const TYPE_SN_LN_PositionChange actualMessage( data->param2, data->param3, data->param4 );

	const std::string message_ber = encode_EW_message(
		TYPE_APEWProtocol::CHOICE_mSN_LN_PositionChange, actualMessage);
	send_and_log("SN_LN_PositionChange", message_ber, data->param1);
	break;
    }
    case LN_LN_Idle: // to neighbor LNs
    {
	RTDS_LN_LN_Idle_data* data = new RTDS_LN_LN_Idle_data;

	RTDS_MSG_RECEIVE_LN_LN_Idle(
		data->param1,
		data->param2,
		data->param3,
		data->param4,
		data->param5);

	// encode ASN1: the receiver (param1) is not part of the data
	// create an object of the actual message data type

	const TYPE_LN_LN_Idle actualMessage( data->param2,
		makeSet< TYPE_APEWProtocol_GEN_10, IPAddress >( data->param3 ),
		makeSet< TYPE_APEWProtocol_GEN_11, tInoperativeSNInfo >( data->param4 ),
		data->param5 );
	//	 TYPE_APEWProtocol_GEN_10 emptyset;
	//        std::cerr << emptyset.equal(makeSet< TYPE_APEWProtocol_GEN_10, IPAddress >( data->param3 )) << endl;
	const std::string message_ber = encode_EW_message(
		TYPE_APEWProtocol::CHOICE_mLN_LN_Idle, actualMessage);
	send_and_log("LN_LN_Idle", message_ber, data->param1);
	break;
    }
    case LN_LN_Detection: // to neighbor LNs
    {
	RTDS_LN_LN_Detection_data* data = new RTDS_LN_LN_Detection_data;

	RTDS_MSG_RECEIVE_LN_LN_Detection(
		data->param1,
		data->param2,
		data->param3,
		data->param4,
		data->param5,
		data->param6 );


	// encode ASN1: the receiver (param1) is not part of the data
	// create an object of the actual message data type
	const TYPE_LN_LN_Detection actualMessage( data->param2, data->param3,
		makeSet< TYPE_APEWProtocol_GEN_12 >( data->param4 ),
		makeSet< TYPE_APEWProtocol_GEN_13 >( data->param5 ),
		data->param6 );

	const std::string message_ber = encode_EW_message(
		TYPE_APEWProtocol::CHOICE_mLN_LN_Detection, actualMessage);
	send_and_log("LN_LN_Detection", message_ber, data->param1);
	break;
    }
    case LN_LN_Alarm: // to all LNs
    {
	RTDS_LN_LN_Alarm_data* data = new RTDS_LN_LN_Alarm_data;

	RTDS_MSG_RECEIVE_LN_LN_Alarm(
		data->param1,
		data->param2,
		data->param3,
		data->param4 );

	// encode ASN1: the receiver (param1) is not part of the data
	// create an object of the actual message data type
	const TYPE_LN_LN_Alarm actualMessage( data->param2, data->param3,
		makeSet< TYPE_APEWProtocol_GEN_14 >( data->param4 ) );

	const std::string message_ber = encode_EW_message(
		TYPE_APEWProtocol::CHOICE_mLN_LN_Alarm, actualMessage);

	send_and_log("LN_LN_Alarm", message_ber, data->param1);
	break;
    }
    case LN_LN_Description: // to LNs
    {
	RTDS_LN_LN_Description_data* data = new RTDS_LN_LN_Description_data;

	RTDS_MSG_RECEIVE_LN_LN_Description(
		data->param1,
		data->param2,
		data->param3 );

	// encode ASN1: the receiver (param1) is not part of the data
	// create an object of the actual message data type

	const TYPE_LN_LN_Description actualMessage( data->param2, data->param3 );

	const std::string message_ber = encode_EW_message(
		TYPE_APEWProtocol::CHOICE_mLN_LN_Description, actualMessage);
	send_and_log("LN_LN_Description", message_ber, data->param1);
	break;
    }
    case LN_SN_Describe: // to all SNs in group
    {
	RTDS_LN_SN_Describe_data* data = new RTDS_LN_SN_Describe_data;

	RTDS_MSG_RECEIVE_LN_SN_Describe(
		data->param1,
		data->param2,
		data->param3 );

	// encode ASN1: the receiver (param1) is not part of the data
	// create an object of the actual message data type#

	const TYPE_LN_SN_Describe actualMessage( data->param2, data->param3 );

	const std::string message_ber = encode_EW_message(
		TYPE_APEWProtocol::CHOICE_mLN_SN_Describe, actualMessage);
	send_and_log("LN_SN_Describe", message_ber, data->param1);
	break;
    }
    case LN_SN_PrimaryLN: // to all SNs in group
    {
	RTDS_LN_SN_PrimaryLN_data* data = new RTDS_LN_SN_PrimaryLN_data;

	RTDS_MSG_RECEIVE_LN_SN_PrimaryLN(
		data->param1,
		data->param2,
		data->param3,
		data->param4 );

	// encode ASN1: the receiver (param1) is not part of the data
	// create an object of the actual message data type

	const TYPE_LN_SN_PrimaryLN actualMessage( data->param2, stringToIA5String(data->param3), data->param4 );

	const std::string message_ber = encode_man_message(
		TYPE_APManagingProtocol::CHOICE_mLN_SN_PrimaryLN, actualMessage);
	send_and_log("LN_SN_PrimaryLN", message_ber, data->param1);
	break;
    }
    case LN_SN_SecondaryLN: // to all SNs in group
    {
	RTDS_LN_SN_SecondaryLN_data* data = new RTDS_LN_SN_SecondaryLN_data;

	RTDS_MSG_RECEIVE_LN_SN_SecondaryLN(
		data->param1,
		data->param2,
		data->param3,
		data->param4 );

	// encode ASN1: the receiver (param1) is not part of the data
	// create an object of the actual message data type

	const TYPE_LN_SN_SecondaryLN actualMessage( data->param2, stringToIA5String(data->param3), data->param4 );

	const std::string message_ber = encode_man_message(
		TYPE_APManagingProtocol::CHOICE_mLN_SN_SecondaryLN, actualMessage);
	send_and_log("LN_SN_SecondaryLN", message_ber, data->param1);
	break;
    }
    case LN_SN_Summarise: // to all SNs in group
    {
	RTDS_LN_SN_Summarise_data* data = new RTDS_LN_SN_Summarise_data;

	RTDS_MSG_RECEIVE_LN_SN_Summarise(
		data->param1,
		data->param2,
		data->param3 );

	// encode ASN1: the receiver (param1) is not part of the data
	// create an object of the actual message data type
	const TYPE_LN_SN_Summarise actualMessage( data->param2, data->param3 );

	const std::string message_ber = encode_EW_message(
		TYPE_APEWProtocol::CHOICE_mLN_SN_Summarise, actualMessage);
	send_and_log("LN_SN_Summarise", message_ber, data->param1);
	break;
    }
    case LN_SN_FalseAlarm: // to all SNs in group
    {
	RTDS_LN_SN_FalseAlarm_data* data = new RTDS_LN_SN_FalseAlarm_data;

	RTDS_MSG_RECEIVE_LN_SN_FalseAlarm(
		data->param1,
		data->param2,
		data->param3 );


	// encode ASN1: the receiver (param1) is not part of the data
	// create an object of the actual message data type

	const TYPE_LN_SN_FalseAlarm actualMessage( data->param2, data->param3 );

	const std::string message_ber = encode_EW_message(
		TYPE_APEWProtocol::CHOICE_mLN_SN_FalseAlarm, actualMessage);
	send_and_log("LN_SN_FalseAlarm", message_ber, data->param1);
	break;
    }
    case LN_EN_Summary: // to external node defined by message param1 ???
    {
	RTDS_LN_EN_Summary_data* data = new RTDS_LN_EN_Summary_data;

	RTDS_MSG_RECEIVE_LN_EN_Summary(
		data->param1,
		data->param2,
		data->param3,
		data->param4,
		data->param5,
		data->param6,
		data->param7 );

	//warning( this, string("te_sender::send(): message to EN: ") + data->param1 );
	// encode ASN1: the receiver (param1) is not part of the data
	// create an object of the actual message data type

	const TYPE_LN_EN_Summary actualMessage( data->param2, data->param3,
		makeSet< TYPE_APEWProtocol_GEN_16 >( data->param4 ),
		makeSet< TYPE_APEWProtocol_GEN_17 >( data->param5 ),
		makeSet< TYPE_APEWProtocol_GEN_18 >( data->param6 ),
		data->param7 );

	const std::string message_ber = encode_EW_message(
		TYPE_APEWProtocol::CHOICE_mLN_EN_Summary, actualMessage);
	send_and_log("LN_EN_Summary", message_ber, data->param1);
	break;
    }
    case LN_EN_Alarm: // to external node defined by message param1 ???
    {
	RTDS_LN_EN_Alarm_data* data = new RTDS_LN_EN_Alarm_data;

	RTDS_MSG_RECEIVE_LN_EN_Alarm(
		data->param1,
		data->param2,
		data->param3,
		data->param4 );

	//warning( this, "te_sender::send(): message to EN");

	// encode ASN1: the receiver (param1) is not part of the data
	// create an object of the actual message data type
	const TYPE_LN_EN_Alarm actualMessage( data->param2, data->param3,
		makeSet< TYPE_APEWProtocol_GEN_15 >( data->param4 ) );

	const std::string message_ber = encode_EW_message(
		TYPE_APEWProtocol::CHOICE_mLN_EN_Alarm, actualMessage);
	send_and_log("LN_EN_Alarm", message_ber, data->param1);
	break;
    }
    case SN_TN_HaveGroupId:
    {
	RTDS_SN_TN_HaveGroupId_data* data = new RTDS_SN_TN_HaveGroupId_data;

	RTDS_MSG_RECEIVE_SN_TN_HaveGroupId(
		data->param1,
		data->param2,
		data->param3,
		data->param4 );

	// encode ASN1: the receiver (param1) is not part of the data
	// create an object of the actual message data type

	const TYPE_SN_TN_HaveGroupId actualMessage( data->param2, stringToIA5String(data->param3), data->param4 );

	const std::string message_ber = encode_man_message(
		TYPE_APManagingProtocol::CHOICE_mSN_TN_HaveGroupId, actualMessage);
	send_and_log("SN_TN_HaveGroupId", message_ber, data->param1);
	break;
    }


    /*
     * the following cases involve Temporary Node (TN) messages which deal with
     * partitioning the whole network into groups, with leaders
     *
     * this may not be required for ODEMx simulations as the te_medium contains
     * all that information and can always be called upon to retrieve it
     *
     * the sender of such messages must be a temporary node
     */
    case TN_SN_AssignLeadershipForGroup:
    {
	RTDS_TN_SN_AssignLeadershipForGroup_data* data = new RTDS_TN_SN_AssignLeadershipForGroup_data;

	RTDS_MSG_RECEIVE_TN_SN_AssignLeadershipForGroup(
		data->param1,
		data->param2,
		data->param3,
		data->param4 );

	// encode ASN1: the receiver (param1) is not part of the data
	// create an object of the actual message data type
	const TYPE_TN_SN_AssignLeadershipForGroup actualMessage( data->param2, makeSet< TYPE_APManagingProtocol_GEN_1, IPAddress >(data->param3), data->param4 );

	const std::string message_ber = encode_man_message(
		TYPE_APManagingProtocol::CHOICE_mTN_SN_AssignLeadershipForGroup, actualMessage);
	send_and_log("TN_SN_AssignLeadershipForGroup", message_ber, data->param1);
	break;
    }
    case TN_LN_AssignLNsInNetwork:
    {
	RTDS_TN_LN_AssignLNsInNetwork_data* data = new RTDS_TN_LN_AssignLNsInNetwork_data;

	RTDS_MSG_RECEIVE_TN_LN_AssignLNsInNetwork(
		data->param1,
		data->param2,
		data->param3 );

	// encode ASN1: the receiver (param1) is not part of the data
	// create an object of the actual message data type
	const TYPE_TN_LN_AssignLNsInNetwork actualMessage( data->param2, makeSet< TYPE_APManagingProtocol_GEN_2, IPAddress >( data->param3 ) );

	const std::string message_ber = encode_man_message(
		TYPE_APManagingProtocol::CHOICE_mTN_LN_AssignLNsInNetwork, actualMessage);
	send_and_log("TN_LN_AssignLNsInNetwork", message_ber, data->param1);
	break;
    }
    case TN_LN_AssignGNsInNetwork:
    {
	RTDS_TN_LN_AssignGNsInNetwork_data* data = new RTDS_TN_LN_AssignGNsInNetwork_data;

	RTDS_MSG_RECEIVE_TN_LN_AssignGNsInNetwork(
		data->param1,
		data->param2,
		data->param3 );

	// encode ASN1: the receiver (param1) is not part of the data
	// create an object of the actual message data type
	const TYPE_TN_LN_AssignGNsInNetwork actualMessage( data->param2,
		makeSet< TYPE_APManagingProtocol_GEN_3, IPAddress >(data->param3 ) );

	const std::string message_ber = encode_man_message(
		TYPE_APManagingProtocol::CHOICE_mTN_LN_AssignGNsInNetwork, actualMessage);
	send_and_log("TN_LN_AssignGNsInNetwork", message_ber, data->param1);
	break;
    }
    case TN_SN_UseMSDP:
    {
	RTDS_TN_SN_UseMSDP_data* data = new RTDS_TN_SN_UseMSDP_data;

	RTDS_MSG_RECEIVE_TN_SN_UseMSDP(
		data->param1,
		data->param2,
		data->param3,
		data->param4,
		data->param5 );

	// encode ASN1: the receiver (param1) is not part of the data
	// create an object of the actual message data type
	const TYPE_TN_SN_UseMSDP actualMessage( data->param2, data->param3, data->param4, stringToIA5String(data->param5) );

	const std::string message_ber = encode_man_message(
		TYPE_APManagingProtocol::CHOICE_mTN_SN_UseMSDP, actualMessage);
	send_and_log("TN_SN_UseMSDP", message_ber, data->param1);
	break;
    }
    case TN_SN_AskGroupId:
    {
	RTDS_TN_SN_AskGroupId_data* data = new RTDS_TN_SN_AskGroupId_data;

	RTDS_MSG_RECEIVE_TN_SN_AskGroupId(
		data->param1,
		data->param2 );

	// encode ASN1: the receiver (param1) is not part of the data
	// create an object of the actual message data type

	const TYPE_TN_SN_AskGroupId actualMessage( data->param2 );

	const std::string message_ber = encode_man_message(
		TYPE_APManagingProtocol::CHOICE_mTN_SN_AskGroupId, actualMessage);
	send_and_log("TN_SN_AskGroupId", message_ber, data->param1);
	break;
    }
    case TN_SN_ConfigureSetKeyValue:
    {
	RTDS_TN_SN_ConfigureSetKeyValue_data* data = new RTDS_TN_SN_ConfigureSetKeyValue_data;

	RTDS_MSG_RECEIVE_TN_SN_ConfigureSetKeyValue(
		data->param1,
		data->param2,
		data->param3 );

	// encode ASN1: the receiver (param1) is not part of the data
	// create an object of the actual message data type
	const TYPE_TN_SN_ConfigureSetKeyValue actualMessage( data->param2,
		makeSet< TYPE_APManagingProtocol_GEN_5, tKeyValuePair >(data->param3 ) );

	const std::string message_ber = encode_man_message(
		TYPE_APManagingProtocol::CHOICE_mTN_SN_ConfigureSetKeyValue, actualMessage);
	send_and_log("TN_SN_ConfigureSetKeyValue", message_ber, data->param1);
	break;
    }
    case TN_SN_CloseMessageLogfile:
    {
	RTDS_TN_SN_CloseMessageLogfile_data* data = new RTDS_TN_SN_CloseMessageLogfile_data;

	RTDS_MSG_RECEIVE_TN_SN_CloseMessageLogfile(
		data->param1,
		data->param2,
		data->param3 );

	// encode ASN1: the receiver (param1) is not part of the data
	// create an object of the actual message data type
	const TYPE_TN_SN_CloseMessageLogfile actualMessage( data->param2, data->param3 );

	const std::string message_ber = encode_man_message(
		TYPE_APManagingProtocol::CHOICE_mTN_SN_CloseMessageLogfile, actualMessage);
	send_and_log("TN_SN_CloseMessageLogfile", message_ber, data->param1);
	break;
    }
    case TN_SN_StartMessageLogging:
    {
	RTDS_TN_SN_StartMessageLogging_data* data = new RTDS_TN_SN_StartMessageLogging_data;

	RTDS_MSG_RECEIVE_TN_SN_StartMessageLogging(
		data->param1,
		data->param2,
		data->param3 );

	// encode ASN1: the receiver (param1) is not part of the data
	// create an object of the actual message data type
	const TYPE_TN_SN_StartMessageLogging actualMessage( data->param2, data->param3 );

	const std::string message_ber = encode_man_message(
		TYPE_APManagingProtocol::CHOICE_mTN_SN_StartMessageLogging, actualMessage);
	send_and_log("TN_SN_StartMessageLogging", message_ber, data->param1);
	break;
    }
    case TN_SN_StopMessageLogging:
    {
	RTDS_TN_SN_StopMessageLogging_data* data = new RTDS_TN_SN_StopMessageLogging_data;

	RTDS_MSG_RECEIVE_TN_SN_StopMessageLogging(
		data->param1,
		data->param2,
		data->param3 );

	// encode ASN1: the receiver (param1) is not part of the data
	// create an object of the actual message data type
	const TYPE_TN_SN_StopMessageLogging actualMessage( data->param2, data->param3 );

	const std::string message_ber = encode_man_message(
		TYPE_APManagingProtocol::CHOICE_mTN_SN_StopMessageLogging, actualMessage);
	send_and_log("TN_SN_StopMessageLogging", message_ber, data->param1);
	break;
    }
    default:
	std::cerr << "ERROR: te_sender-> unknown message type" << std::endl;
	break;
    }

    // increase the message id counter for the next message
    ++sequenceNumber;
}

void te_sender::send_and_log(const char * message_name,
	const std::string& message_ber, const IPAddress& receiver) {
    XMLStreamingLogger* xmlLogger = dynamic_cast<XMLStreamingLogger*> (&logger);

    stack.connectAndSend(receiver, message_ber);

    if (xmlLogger)
	xmlLogger->logExternSend(
		msgQueue.writer,
		receiver,
		message_name,
		getCurrentTime(),
		bytestream2Hex(message_ber),
		getCRCInterNode(localIP, receiver, message_ber)
	);
}
