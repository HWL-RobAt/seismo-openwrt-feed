/**
 * @file main.cpp
 * @date Aug 17, 2008
 * @author Ronald Kluth
 *
 * @brief Entry point of the application.
 * This file is part of `boost_src`.
 */

#include <iostream>
#include <string>
#include <cstdlib>
#include <unistd.h>
#include <iostream>

#include "RTDS_MSGQUEUE.h"
#include "RTDS_SDLPROCESS.h"
#include "blockClass_Node.h"
#include "common.h"

#ifndef WIN32
#include <netinet/in.h>
#include <sys/ioctl.h>
#include <string.h>
#include <stdlib.h>
#include <stdio.h>
#include <net/if.h>
#include <arpa/inet.h>
char* getLocalIP(char* interface);
int uci_get(const char* name, char* result);
#endif



/*
 * Parameters:
 * 1:	file prefix for XML log files (default: timestamp)
 * 		to disable XML logging: filename: DISABLE_LOGGER
 * 2: 	pipe name for sensor data (default: /tmp/pipe_msdp)
 */
int main(int argc, char* argv[]) {
	float longitude = 0.0;
	float latitude = 0.0;
	float altitude = 0.0;
	std::string station_name;

	// XML log-file-prefix
	std::string fileName;
	if (argc > 1)
		fileName = argv[1];
	else
		fileName = "";

	// pipe-file-name
	if (argc > 2)
		pipeName = argv[2];
	else
		pipeName = "/tmp/pipe_msdp";

	//test m-noti
	std::string notiMessage = "ews started, reading from pipe: ";
	notiMessage += pipeName;
	sendMessageViaNoti("ews", 0, notiMessage);

#ifndef WIN32
	char str_lon[512];
	char str_lat[512];
	char str_alt[512];
	char str_name[512];
	char sta_lta_threshold[512];

	uci_get("seismo.installation.longitude", str_lon);
	uci_get("seismo.installation.latitude", str_lat);
	uci_get("seismo.installation.altitude", str_alt);
	uci_get("seismo.station.station_code", str_name);
	uci_get("seismo.oper_par.psnr", sta_lta_threshold);

	globalPWaveTriggerThreshold = atof(sta_lta_threshold);
	longitude = atof(str_lon);
	latitude = atof(str_lat);
	altitude = atof(str_alt);
	station_name = str_name;
#endif

#ifdef WIN32
	localIP = "1.1.1.1";
#else
	localIP = getLocalIP("ath1");
#endif

	// boost libs usually use exception handling
	try {
		// HACK: we are using dynamic memory to avoid a crash in the destructor
		RTDS::Logger* logger;
		if (fileName.compare("DISABLE_LOGGER") != 0) {
			logger = new XMLStreamingLogger(
				station_name,
				fileName,
				localIP,
				new int(1),
				longitude,
				latitude,
				altitude,
				"test node");
		} else {
			logger = &RTDS::emptyLogger;
		}
		blockClass_Node* node = new blockClass_Node(*logger);
		node->activate();

#ifdef WIN32
		string s;
		std::cin >> s;
#else
		RTDS::SDLProcess::ioService.run();
#endif
	} catch (std::exception& e) {
		// catch any boost exceptions that might be thrown
		std::cerr << "Exception: " << e.what() << std::endl;
	}
	return 0;
}

#ifndef WIN32
char* getLocalIP(char* interface) {
	struct ifreq ifa;
	struct sockaddr_in *i;
	int fd;

	if (strlen (interface) >= sizeof ifa.ifr_name) {
		fprintf (stderr, "%s is to long\n", interface);
		exit (EXIT_FAILURE);
	}

	strcpy (ifa.ifr_name, interface);

	if((fd = socket(AF_INET, SOCK_DGRAM, 0)) == -1) {
		perror ("socket");
		exit (EXIT_FAILURE);
	}

	if(ioctl(fd, SIOCGIFADDR, &ifa)) {
		perror ("ioctl");
		exit (EXIT_FAILURE);
	}

	i = (struct sockaddr_in*)&ifa.ifr_addr;
	return inet_ntoa(i->sin_addr);
}

/* Helper function, get value of an uci var */
int uci_get(const char* name, char* result){
	FILE *fpipe;
	char line[256];
	char command[256];

	sprintf(command, "uci get %s", name);

	if ( !(fpipe = (FILE*)popen(command,"r")) ){  // If fpipe is NULL
		return 0;
	}

	if(! fgets( line, sizeof line, fpipe)){
		pclose(fpipe);
		return 0;
	}

	// Erase out newline at the end
	if(line[strlen(line)-1]=='\n'){
		line[strlen(line)-1] = '\0';
	}

	strcpy(result, line);

	pclose(fpipe);
	return 1;
}

#endif
