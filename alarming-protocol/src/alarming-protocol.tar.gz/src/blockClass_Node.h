/*SX*//** @file
 *  Generated file, find templates in SX folders
 */

#ifndef BLOCKCLASS_NODE_UP_H_INCLUDED
#define BLOCKCLASS_NODE_UP_H_INCLUDED
#ifndef _BLOCKCLASS_NODE_H_
#define _BLOCKCLASS_NODE_H_

#include "common.h"
#include "SignalAnalyser.h"
#include "XMLStreamingLogger.h"
#include <iostream>
#ifdef BOOST
#include "data_listener.h"
#endif
#include <boost/foreach.hpp>
#define foreach BOOST_FOREACH
#include "logging.h"

#endif
#endif

#ifndef BLOCKCLASS_NODE_H_INCLUDED
#define BLOCKCLASS_NODE_H_INCLUDED

#include "RTDS_SDLBLOCK.h"
#include "RTDS_gen.h"

#include "GatewayEntity.h"
#include "ManagingEntity.h"
#include "SignalAnalysingEntity.h"
#include "DataListenerEntity.h"
#include "LeadingEntity.h"
#include "SensingEntity.h"

#include "block_te.h"

/**@brief The block blockClass_Node
 */
struct blockClass_Node : public RTDS::SDLBlock {
    GatewayEntity* p_GatewayEntity[1];
    ManagingEntity* p_ManagingEntity[1];
    SignalAnalysingEntity* p_SignalAnalysingEntity[1];
    DataListenerEntity* p_DataListenerEntity[1];
    LeadingEntity* p_LeadingEntity[1];
    SensingEntity* p_SensingEntity[1];
    block_te* p_block_te;
	
    /** Constructor for blockClass_Node.
     */
    blockClass_Node(RTDS::Logger& logger = RTDS::emptyLogger)
    : SDLBlock(logger)
    {
	p_block_te = new block_te(logger);
	embed(*p_block_te);
	for (int i = 0; i < 1; ++i) {
	    p_GatewayEntity[i] = new GatewayEntity(logger);
	    embed(*p_GatewayEntity[i], RTDS_process_GatewayEntity);
	}
	for (int i = 0; i < 1; ++i) {
	    p_ManagingEntity[i] = new ManagingEntity(logger);
	    embed(*p_ManagingEntity[i], RTDS_process_ManagingEntity);
	}
	for (int i = 0; i < 1; ++i) {
	    p_SignalAnalysingEntity[i] = new SignalAnalysingEntity(logger);
	    embed(*p_SignalAnalysingEntity[i], RTDS_process_SignalAnalysingEntity);
	}
	for (int i = 0; i < 1; ++i) {
	    p_DataListenerEntity[i] = new DataListenerEntity(logger);
	    embed(*p_DataListenerEntity[i], RTDS_process_DataListenerEntity);
	}
	for (int i = 0; i < 1; ++i) {
	    p_LeadingEntity[i] = new LeadingEntity(logger);
	    embed(*p_LeadingEntity[i], RTDS_process_LeadingEntity);
	}
	for (int i = 0; i < 1; ++i) {
	    p_SensingEntity[i] = new SensingEntity(logger);
	    embed(*p_SensingEntity[i], RTDS_process_SensingEntity);
	}
    }

    virtual void activate()
    {
	(*p_block_te).activate();
	
	for (int i = 0; i < 1; ++i)
	    (*p_GatewayEntity[i]).activate();
	
	for (int i = 0; i < 1; ++i)
	    (*p_ManagingEntity[i]).activate();
	
	for (int i = 0; i < 1; ++i)
	    (*p_SignalAnalysingEntity[i]).activate();
	
	for (int i = 0; i < 1; ++i)
	    (*p_DataListenerEntity[i]).activate();
	
	for (int i = 0; i < 1; ++i)
	    (*p_LeadingEntity[i]).activate();
	
	for (int i = 0; i < 1; ++i)
	    (*p_SensingEntity[i]).activate();
	
    }
};

#ifndef _BLOCKCLASS_NODE_H_
#define _BLOCKCLASS_NODE_H_

#include "common.h"
#include "SignalAnalyser.h"
#include "XMLStreamingLogger.h"
#include <iostream>
#ifdef BOOST
#include "data_listener.h"
#endif
#include <boost/foreach.hpp>
#define foreach BOOST_FOREACH
#include "logging.h"

#endif

#endif
