/**
 * @file network_stack.cpp
 * @date Aug 17, 2008
 * @author Ronald Kluth
 *
 * @brief Definition of NetworkStack functions
 */

#include "define.h"
#include "network_stack.h"
#include <iostream>

NetworkStack::NetworkStack( boost::asio::io_service& io_service, RTDS::MessageQueueT<Message*>::qWriter& writer,
		const unsigned short sendPort, const unsigned short receivePort )
:	io_service( io_service ),
	receiveQueue( writer ),
	acceptor( io_service )
	{
		listenToPort( receivePort );
	}

NetworkStack::~NetworkStack()
	{
		if( acceptor.is_open() )
			acceptor.close();
	}

/*
void
NetworkStack::inputData( Message& message )
{
	// TODO: extract data from message

	//connectAndSend(  peerIP, peerPort, messageString);
}
*/

void
NetworkStack::connectAndSend( const std::string& peerAddress,
							  //const unsigned short peerPort,
							  const std::string& message )
{
//	std::cout << "NetworkStack::connectAndSend()" << std::endl;
	//std::cout << "sending message: \"" << message << "\""<< std::endl;
	const unsigned short peerPort = RECEIVE_PORT;

	// create peer endpoint with given parameters
	boost::asio::ip::tcp::endpoint
		peerEndpoint( boost::asio::ip::address::from_string( peerAddress ), peerPort );

	// create a new connection object for this endpoint
	SendConnection::pointer newConnection =
		SendConnection::create( io_service, *this, message );

	// make a non-blocking connect call, which returns immediately
	newConnection -> asyncConnect( peerEndpoint );
}

void
NetworkStack::listenToPort( const unsigned short listenPort )
{
//	std::cout << "NetworkStack::listenToPort()" << std::endl;

	// if the local endpoint has not been opened,
	// do it now and start listening
	if( ! acceptor.is_open() )
	{
		localEndpoint = tcp::endpoint( tcp::v4(), listenPort );
		acceptor.open( localEndpoint.protocol() );
		acceptor.bind( localEndpoint );
		acceptor.listen();
	}

	// create a new connection object for this endpoint
	ReceiveConnection::pointer newConnection =
		ReceiveConnection::create( io_service, *this );

	// wait for a peer to connect to the connection's socket,
	// deal with result in handleAccept()
	acceptor.async_accept( newConnection -> socket(),
			boost::bind( &NetworkStack::handleAccept, this,
					boost::asio::placeholders::error, newConnection, listenPort ) );
}

void
NetworkStack::handleAccept( const boost::system::error_code& error,
							ReceiveConnection::pointer newConnection,
							const unsigned short listenPort )
{
//	std::cout << "NetworkStack::handleAccept()" << std::endl;

	if( ! error )
	{
		// attempt to read data from incoming connection
		newConnection -> asyncRead();

		// start a new asynchronous listening operation, needed
		// in order to be able to deal with many simultaneous connections
		listenToPort( listenPort );
	}
}

void
NetworkStack::receivedMessage( const std::string& msg, const std::string& fromIP,
		const std::string& ownIP )
{
//	std::cout << "NetworkStack::receivedMessage()" << std::endl;

	// pass the received message on to the te_receiver to determine what to do
	receiveQueue.put( new Message( msg, fromIP, ownIP ) );
}

/*
void
NetworkStack::setReceiver( const te_receiver* rec )
{
	receiver = rec;
}

const te_receiver*
NetworkStack::getReceiver() const
{
	return receiver;
}
*/
