/*SX*/
/* Project: /export/sosewin/ES/AlarmingProtocol/SingleNode/SingleNode.rdp */
/* Diagram: /export/sosewin/ES/AlarmingProtocol/SingleNode/SingleNode.rdd */



#include "RTDS_MACRO.h"

/* DEFINES FOR STATES */
#define groupIdle 1
#define eventDescribed 2
#define Idle 3
#define systemAlarm 4
#define idle 5
#define alarmFinished 6
#define preAlarm 7
#define noEvent 8
#define eventDetected 9
#define groupAlarm 10
#define eventFinished 11

/* DEFINES FOR SIGNALS AND TIMERS */
#define t_EventFinished 1
#define t_Description 2
#define t_Detection 3
#define Message_TE_TE_LS_Ala 4
#define TN_SN_ConfigureSetKeyValue 5
#define LN_SN_PrimaryLN 6
#define Message_TE_TE_TS_ALS 7
#define EventFinished 8
#define Message_TE_TE_SL_Sum 9
#define SN_LN_PositionChange 10
#define Message_TE_TE_TS_Use 11
#define Message_TE_TE_LS_Sec 12
#define SN_LN_Description 13
#define t_idle 14
#define Message_TE_TE_LS_Pri 15
#define NoEvent 16
#define StartLN 17
#define Message_TE_TE_SL_PoC 18
#define SN_LN_Summary 19
#define LNsInNetwork 20
#define t_LNsDetection 21
#define Message_TE_TE_LL_Det 22
#define LN_SN_FalseAlarm 23
#define t_Idle 24
#define t_Swave 25
#define LN_LN_Idle 26
#define LN_SN_Describe 27
#define nextRecord 28
#define TN_SN_AssignLeadershipForGroup 29
#define Message_TE_TE_TS_Ask 30
#define LN_EN_Alarm 31
#define Message_TE_TE_TL_ALN 32
#define Message_TE_TE_SL_Idl 33
#define TN_SN_StartMessageLogging 34
#define GNsInNetwork 35
#define Message_TE_TE_LL_Des 36
#define TN_SN_CloseMessageLogfile 37
#define t_Stop_Summarise 38
#define Message_TE_TE_TL_AGN 39
#define Message_TE_TE_LS_Des 40
#define t_preAlarm 41
#define Message_TE_TE_LE_Sum 42
#define SN_LN_Detection 43
#define LN_LN_Description 44
#define EventDescribed 45
#define TN_SN_AskGroupId 46
#define TN_LN_AssignLNsInNetwork 47
#define LN_EN_Summary 48
#define t_alarmFinished 49
#define Message_TE_TE_LL_Idl 50
#define EventDetected 51
#define LN_SN_SecondaryLN 52
#define SendPShared 53
#define LN_LN_Detection 54
#define TN_SN_UseMSDP 55
#define LN_SN_Summarise 56
#define TN_LN_AssignGNsInNetwork 57
#define Message_TE_TE_ST_Ans 58
#define SN_TN_HaveGroupId 59
#define Message_TE_TE_SL_Det 60
#define Message_TE_TE_SL_Des 61
#define LN_LN_Alarm 62
#define Message_TE_TE_LS_Sum 63
#define t_Summarise 64
#define Message_TE_TE_LL_Ala 65
#define t_EventDescribed 66
#define Message_TE_TE_LS_FA 67
#define SN_LN_Idle 68
#define Message_TE_TE_LE_Ala 69
#define TN_SN_StopMessageLogging 70

/* DEFINES FOR SEMAPHORES */

/* DEFINES FOR PROCESSES */
#define RTDS_process_GatewayEntity 1
#define RTDS_process_ManagingEntity 2
#define RTDS_process_te_sender 3
#define RTDS_process_te_receiver 4
#define RTDS_process_SignalAnalysingEntity 5
#define RTDS_process_DataListenerEntity 6
#define RTDS_process_LeadingEntity 7
#define RTDS_process_SensingEntity 8

/* PROCESS PROTOTYPES */
#include "GatewayEntity.h"
#include "ManagingEntity.h"
#include "LeadingEntity.h"
#include "te_receiver.h"
#include "SignalAnalysingEntity.h"
#include "DataListenerEntity.h"
#include "te_sender.h"
#include "SensingEntity.h"



