/** @file
 * @brief XML logger, part of `shared_src`
 * @date 28.06.2008
 * @author Ingmar Eveslage, Michael Piefel
 */

#ifndef XMLSTREAMINGLOGGER_H_INCLUDED
#define XMLSTREAMINGLOGGER_H_INCLUDED

#include "RTDS_LOGGER.h"
#include "xmlwriter.h"
#include <string>
#include <list>
#include <set>
#ifdef BOOST
#include <boost/interprocess/sync/interprocess_mutex.hpp>
#endif

using std::string;

enum ProcessType {
	LE,
	SE,
	TE,
	SAE,
	ME,
	unspecified
};

struct ProcessInstance {
	RTDS::Logger::ID processID;
	bool hasGID;
	RTDS::Logger::ID gid;
	string processType;
	string description;
};

static const string CREATOR_SVN_VERSION = "$Rev$";

/**
 * A logger that writes to an XML file.
 */
class XMLStreamingLogger : public RTDS::Logger
{
public:
	XMLStreamingLogger(string stationName, string fileName, string ipAddress,
		const int* groupId, float longitude, float latitude, float height,
		string comment, int logLevel = 0, bool diffable_logs = false);

	virtual ~XMLStreamingLogger();

	virtual void logProcessCreation(ID process, const char* processType, ID context);

	virtual void logSetTimer(ID process, int messageNumber, const char* timerName, long long currentTime, int duration);
	virtual void logResetTimer(ID process, int messageNumber, const char* timerName, long long currentTime);
	virtual void logFireTimer(ID process, int messageNumber, long long currentTime);

	virtual void logSend(ID sender, ID destination, long long simTime, const char* messageType,
		const RTDS::MsgHeader* messageContent, int sequenceNumber);
	virtual void logReceive(ID sender, ID receiver, int sequenceNumber, long long simTime);

	virtual void logStateChange(ID process, const char* newState, long long simTime);

	virtual void logStateVariable(ID process, double content, long long simTime, string name);
	virtual void logStateVariable(ID process, int content, long long simTime, string name);
	virtual void logStateVariable(ID process, string content, long long simTime, string name);

	void logExternSend(ID sender, string receiver, string messageType, long long simTime, string aSN1Msg, unsigned int sequenceNumber);
	void logExternReceive(string sender, ID receiver, unsigned int sequenceNumber, long long simTime);

	/**
	 * finalises the current log file and switches to another log file
	 */
	void createNewLog();
	
private:
	/// increase message count and create new file if the log becomes too large
	void step_message_counter();

	int message_counter;
	int file_counter;
	string base_filename;
	string filename;

	string stationName;
	string ipAddress;
	const int* groupId;
	float longitude;
	float latitude;
	float height;
	string comment;
	string currentFileName;

	const bool compress_logs;  ///< Whether to compress the log files (requires gzip)
	const bool split_files;    ///< Whether to split the log files when they grow too long.
	const bool use_time_stamp; ///< Whether to put time stamps in file names and the top of the log.

	xmlwriter* myXMLWriter;

	std::list<ProcessInstance> processInstanceList;

	static std::list<XMLStreamingLogger*> createdLoggerList;

	std::set<string> currentLogLevel;

#ifdef BOOST
	boost::interprocess::interprocess_mutex myMutex;
#endif

	static void XMLStreamingLoggerSignalHandler(int sig);
	void close();

	void createNewXMLFile();

	void createLogLevel(int logLevel);
};


#endif /* XMLSTREAMINGLOGGER_H_ */
