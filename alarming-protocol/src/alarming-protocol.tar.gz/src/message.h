/**
 * @file message.h
 * @date Aug 17, 2008
 * @author Ronald Kluth
 *
 * @brief Declaration of class Message
 */

#ifndef MESSAGE_H_INCLUDED
#define MESSAGE_H_INCLUDED

#include <string>
#include "common.h"

class Message
{
public:
	std::string content;
	IPAddress sender;
	IPAddress receiver;

	Message( const std::string& data, IPAddress from, IPAddress to );
};

#endif
