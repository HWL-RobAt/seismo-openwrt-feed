/* ===== PA_APGeneralProtocol.cxx ===== */

#include "PA_APGeneralProtocol.h"

#include "version.h"

#include "PA_APGeneralProtocol.h"
#define OPTIONS_RANGE_SHIFT 0LL
BEGIN_SITE_NAMESPACE(AP_GeneralProtocol)
int PA_APGeneralProtocol48889_has_been_changed=0;

static void check_package_versions()
{
    PA_APManagingProtocol507664_has_been_changed = 0;
    PA_APEWProtocol1241092_has_been_changed = 0;
}

implementASNPackageLib(PA_APGeneralProtocol)
PA_APGeneralProtocol::PA_APGeneralProtocol (const char * myname) :
SDLPackage(myname)
{
    SDL_LIB_3_28=1;
    SITE_CONSISTENCY_CHECK;
    _non_standard_compilation_option = " --case-sensitive --mangeling short";
} /* PA_APGeneralProtocol::PA_APGeneralProtocol */

void PA_APGeneralProtocol::init()
{
    SDLPackage::init();
    package_init(MY_PA_APManagingProtocol);
    package_init(MY_PA_APEWProtocol);
    TYPE_APGeneralProtocol::create()->init_type();
}/* PA_APGeneralProtocol:: init */

PA_APGeneralProtocol::~PA_APGeneralProtocol()
{
} /* PA_APGeneralProtocol::~PA_APGeneralProtocol */

PA_APGeneralProtocol*
PA_APGeneralProtocol::Instance()
{
    static PA_APGeneralProtocol * _instance = new PA_APGeneralProtocol("PA_APGeneralProtocol");
    return _instance;
} /* PA_APGeneralProtocol::Instance */

bool PA_APGeneralProtocol::datainfo(long index,
        SDLIA5String& var_name,SDLIA5String& var_type,SDLType*& var){

    switch(index) {
        default: return SDLPackage::datainfo(index-0,var_name,var_type,var);
    }
    return true;
} /* PA_APGeneralProtocol::datainfo */
END_SITE_NAMESPACE
