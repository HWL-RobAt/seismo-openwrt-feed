/* ===== PA_APEWProtocol.cxx ===== */

#include "PA_APEWProtocol.h"

#include "version.h"

#include "PA_APEWProtocol.h"
#define OPTIONS_RANGE_SHIFT 0LL
BEGIN_SITE_NAMESPACE(AP_GeneralProtocol)
int PA_APEWProtocol1241092_has_been_changed=0;

static void check_package_versions()
{
}

implementASNPackageLib(PA_APEWProtocol)
PA_APEWProtocol::PA_APEWProtocol (const char * myname) :
SDLPackage(myname)
{
    SDL_LIB_3_28=1;
    SITE_CONSISTENCY_CHECK;
    _non_standard_compilation_option = " --case-sensitive --mangeling short";
} /* PA_APEWProtocol::PA_APEWProtocol */

void PA_APEWProtocol::init()
{
    SDLPackage::init();
    TYPE_APEWProtocol::create()->init_type();
    TYPE_Acceleration::create()->init_type();
    TYPE_Velocity::create()->init_type();
    TYPE_Displacement::create()->init_type();
    TYPE_Frequency::create()->init_type();
    TYPE_IPAddress::create()->init_type();
    TYPE_EventID::create()->init_type();
    TYPE_GroupID::create()->init_type();
    TYPE_DateTime::create()->init_type();
    TYPE_GeographicCoordinate::create()->init_type();
    TYPE_SensorAccelerationAverage::create()->init_type();
    TYPE_SensorAcceleration::create()->init_type();
    TYPE_SensorVelocity::create()->init_type();
    TYPE_SensorDisplacement::create()->init_type();
    TYPE_SN_LN_Idle::create()->init_type();
    TYPE_SN_LN_Detection::create()->init_type();
    TYPE_SN_LN_Description::create()->init_type();
    TYPE_SN_LN_Summary::create()->init_type();
    TYPE_ResponseSpectra::create()->init_type();
    TYPE_SN_LN_PositionChange::create()->init_type();
    TYPE_StatusSNInfo::create()->init_type();
    TYPE_LN_SN_Alarm::create()->init_type();
    TYPE_LN_SN_FalseAlarm::create()->init_type();
    TYPE_LN_SN_Describe::create()->init_type();
    TYPE_LN_SN_Summarise::create()->init_type();
    TYPE_BreakdownReason::create()->init_type();
    TYPE_InoperativeSNInfo::create()->init_type();
    TYPE_TriggeredSNInfo::create()->init_type();
    TYPE_LN_LN_Idle::create()->init_type();
    TYPE_LN_LN_Detection::create()->init_type();
    TYPE_LN_LN_Alarm::create()->init_type();
    TYPE_LN_LN_Description::create()->init_type();
    TYPE_LN_EN_Alarm::create()->init_type();
    TYPE_LN_EN_Summary::create()->init_type();
    TYPE_APEWProtocol_GEN_1::create()->init_type();
    TYPE_APEWProtocol_GEN_2::create()->init_type();
    TYPE_APEWProtocol_GEN_3::create()->init_type();
    TYPE_APEWProtocol_GEN_4::create()->init_type();
    TYPE_APEWProtocol_GEN_5::create()->init_type();
    TYPE_APEWProtocol_GEN_6::create()->init_type();
    TYPE_APEWProtocol_GEN_7::create()->init_type();
    TYPE_APEWProtocol_GEN_8::create()->init_type();
    TYPE_APEWProtocol_GEN_9::create()->init_type();
    TYPE_APEWProtocol_GEN_10::create()->init_type();
    TYPE_APEWProtocol_GEN_11::create()->init_type();
    TYPE_APEWProtocol_GEN_12::create()->init_type();
    TYPE_APEWProtocol_GEN_13::create()->init_type();
    TYPE_APEWProtocol_GEN_14::create()->init_type();
    TYPE_APEWProtocol_GEN_15::create()->init_type();
    TYPE_APEWProtocol_GEN_16::create()->init_type();
    TYPE_APEWProtocol_GEN_17::create()->init_type();
    TYPE_APEWProtocol_GEN_18::create()->init_type();
}/* PA_APEWProtocol:: init */

PA_APEWProtocol::~PA_APEWProtocol()
{
} /* PA_APEWProtocol::~PA_APEWProtocol */

PA_APEWProtocol*
PA_APEWProtocol::Instance()
{
    static PA_APEWProtocol * _instance = new PA_APEWProtocol("PA_APEWProtocol");
    return _instance;
} /* PA_APEWProtocol::Instance */

bool PA_APEWProtocol::datainfo(long index,
        SDLIA5String& var_name,SDLIA5String& var_type,SDLType*& var){

    switch(index) {
        default: return SDLPackage::datainfo(index-0,var_name,var_type,var);
    }
    return true;
} /* PA_APEWProtocol::datainfo */
END_SITE_NAMESPACE
