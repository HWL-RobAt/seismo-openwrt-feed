/* ===== PA_APGeneralProtocol.h ===== */

#ifndef PA_APGeneralProtocol_H
#define PA_APGeneralProtocol_H
#include <sdlconfig.h>
#include "PA_APManagingProtocol.h"
#include "PA_APEWProtocol.h"
/* Note: DLL_SUPPORT depends on the sequence of includes,
         PA_APGeneralProtocol not! */
#ifdef PA_APGeneralProtocol_LIB
#define PA_APGeneralProtocol_API DllExport
#else
#define PA_APGeneralProtocol_API DllImport
#endif
#undef DLL_SUPPORT
#undef SDLARRAY_EXPORT
#ifdef PA_APGeneralProtocol_LIB
#define DLL_SUPPORT DllExport
#define SDLARRAY_EXPORT DllExport
#else
#define DLL_SUPPORT DllImport
#define SDLARRAY_EXPORT DllImport
#endif
#include <sdltimer.h>

BEGIN_SITE_NAMESPACE(AP_GeneralProtocol)

class PA_APGeneralProtocol_API TYPE_APGeneralProtocol;

class PA_APGeneralProtocol_API TYPE_APGeneralProtocol: public SDLChoice {
public:
    TYPE_APGeneralProtocol(const SDLAny&, AsnCodingSet rule_set=asn_ber);
    virtual const char* name() const { return "TYPE_APGeneralProtocol"; }
    virtual SDLType* copy()const;
    virtual void assign(const SDLType* t);
    static SDLType* create();
    virtual const SDLType* create_new() const;
    static const TYPE_APGeneralProtocol& convert(const TYPE_APGeneralProtocol&t) { return t; };
    
public:
    TYPE_APGeneralProtocol(unsigned int i,const SDLType& elem) { assign_field(i,elem); }
    TYPE_APGeneralProtocol(){}
    TYPE_APGeneralProtocol(const SDLNull& n):SDLChoice(n){}
    TYPE_APGeneralProtocol(const TYPE_APGeneralProtocol& base):SDLChoice(base){}
    enum {
        CHOICE_NoAssign,
        CHOICE_mAPEWProtocol,
        CHOICE_mAPManagingProtocol
    };
    const SDLBool& mAPEWProtocolPresent()const
    { return (_present == CHOICE_mAPEWProtocol)?SDLBool::SDLTrue():SDLBool::SDLFalse(); }
    TYPE_APEWProtocol& VAR_mAPEWProtocol() const;
    const SDLBool& mAPManagingProtocolPresent()const
    { return (_present == CHOICE_mAPManagingProtocol)?SDLBool::SDLTrue():SDLBool::SDLFalse(); }
    TYPE_APManagingProtocol& VAR_mAPManagingProtocol() const;
    void assign_field(unsigned int variant,const SDLType& elem);
    AsnLen bEnc(BUF_TYPE) const;
    AsnLen bEncContent(BUF_TYPE) const;
    void bDec(BUF_TYPE,AsnLen&);
    void bDecContent(BUF_TYPE,AsnTag,AsnLen,AsnLen&);
    AsnLen pEnc(BUF_TYPE2 b) const;
    void pDec(BUF_TYPE2 b);
    bool datainfo(long,SDLIA5String&,SDLIA5String&,SDLType*&,SDLType::infotype);
};

END_SITE_NAMESPACE
#include <sdlpackage.h>
#include <sdlblock.h>
#include <sdlchannel.h>
#include <sdlshell.h>

BEGIN_SITE_NAMESPACE(AP_GeneralProtocol)
extern int PA_APGeneralProtocol48889_has_been_changed;

class PA_APGeneralProtocol_API PA_APGeneralProtocol : public SDLPackage 
{
    declareSDLPackage(PA_APGeneralProtocol)
    PA_APGeneralProtocol(const char *);
public:
    void init();
    ~PA_APGeneralProtocol();
    static PA_APGeneralProtocol* Instance();
    bool datainfo(long,class SDLIA5String&,SDLIA5String&,SDLType*&);
    const char * get_namespace() const { return "AP_GeneralProtocol"; }
}; /* PA_APGeneralProtocol */

#define MY_PA_APGeneralProtocol (PA_APGeneralProtocol::Instance())

END_SITE_NAMESPACE
#endif
