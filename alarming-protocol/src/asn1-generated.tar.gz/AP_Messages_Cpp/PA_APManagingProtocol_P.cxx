/* ===== PA_APManagingProtocol_P.cxx ===== */

#include "PA_APManagingProtocol.h"
#include "version.h"

BEGIN_SITE_NAMESPACE(AP_GeneralProtocol)
TYPE_APManagingProtocol::TYPE_APManagingProtocol(const SDLAny& a, AsnCodingSet rule_set){                                      a.decode(this,rule_set); }

SDLType* TYPE_APManagingProtocol::copy()const { return new TYPE_APManagingProtocol(*this); }

void TYPE_APManagingProtocol::assign(const SDLType* t)
{
  const TYPE_APManagingProtocol *arg = SITE_DYNAMIC_CAST(const TYPE_APManagingProtocol*,t);
  if (!arg) SDLChoice::assign(t);
  else *this = *arg;
}

SDLType* TYPE_APManagingProtocol::create()
{
  static TYPE_APManagingProtocol* tmpl = new TYPE_APManagingProtocol;
  return tmpl;
}

const SDLType* TYPE_APManagingProtocol::create_new() const { return create(); }

TYPE_TN_SN_AssignLeadershipForGroup& TYPE_APManagingProtocol::VAR_mTN_SN_AssignLeadershipForGroup() const {
    if (_u && _present!=CHOICE_mTN_SN_AssignLeadershipForGroup) {
        delete _u; _u=0;
    }
    if(!_u) {
        _u = new TYPE_TN_SN_AssignLeadershipForGroup;
        _present = CHOICE_mTN_SN_AssignLeadershipForGroup;
    } else {
        SITEASSERT(SITE_DYNAMIC_CAST(TYPE_TN_SN_AssignLeadershipForGroup*,_u),
                   "dynamic cast failure for CHOICE element");
    }
    return *SITE_STATIC_CAST(TYPE_TN_SN_AssignLeadershipForGroup*,_u);
}

TYPE_TN_LN_AssignLNsInNetwork& TYPE_APManagingProtocol::VAR_mTN_LN_AssignLNsInNetwork() const {
    if (_u && _present!=CHOICE_mTN_LN_AssignLNsInNetwork) {
        delete _u; _u=0;
    }
    if(!_u) {
        _u = new TYPE_TN_LN_AssignLNsInNetwork;
        _present = CHOICE_mTN_LN_AssignLNsInNetwork;
    } else {
        SITEASSERT(SITE_DYNAMIC_CAST(TYPE_TN_LN_AssignLNsInNetwork*,_u),
                   "dynamic cast failure for CHOICE element");
    }
    return *SITE_STATIC_CAST(TYPE_TN_LN_AssignLNsInNetwork*,_u);
}

TYPE_TN_LN_AssignGNsInNetwork& TYPE_APManagingProtocol::VAR_mTN_LN_AssignGNsInNetwork() const {
    if (_u && _present!=CHOICE_mTN_LN_AssignGNsInNetwork) {
        delete _u; _u=0;
    }
    if(!_u) {
        _u = new TYPE_TN_LN_AssignGNsInNetwork;
        _present = CHOICE_mTN_LN_AssignGNsInNetwork;
    } else {
        SITEASSERT(SITE_DYNAMIC_CAST(TYPE_TN_LN_AssignGNsInNetwork*,_u),
                   "dynamic cast failure for CHOICE element");
    }
    return *SITE_STATIC_CAST(TYPE_TN_LN_AssignGNsInNetwork*,_u);
}

TYPE_LN_SN_PrimaryLN& TYPE_APManagingProtocol::VAR_mLN_SN_PrimaryLN() const {
    if (_u && _present!=CHOICE_mLN_SN_PrimaryLN) {
        delete _u; _u=0;
    }
    if(!_u) {
        _u = new TYPE_LN_SN_PrimaryLN;
        _present = CHOICE_mLN_SN_PrimaryLN;
    } else {
        SITEASSERT(SITE_DYNAMIC_CAST(TYPE_LN_SN_PrimaryLN*,_u),
                   "dynamic cast failure for CHOICE element");
    }
    return *SITE_STATIC_CAST(TYPE_LN_SN_PrimaryLN*,_u);
}

TYPE_LN_SN_SecondaryLN& TYPE_APManagingProtocol::VAR_mLN_SN_SecondaryLN() const {
    if (_u && _present!=CHOICE_mLN_SN_SecondaryLN) {
        delete _u; _u=0;
    }
    if(!_u) {
        _u = new TYPE_LN_SN_SecondaryLN;
        _present = CHOICE_mLN_SN_SecondaryLN;
    } else {
        SITEASSERT(SITE_DYNAMIC_CAST(TYPE_LN_SN_SecondaryLN*,_u),
                   "dynamic cast failure for CHOICE element");
    }
    return *SITE_STATIC_CAST(TYPE_LN_SN_SecondaryLN*,_u);
}

TYPE_TN_SN_UseMSDP& TYPE_APManagingProtocol::VAR_mTN_SN_UseMSDP() const {
    if (_u && _present!=CHOICE_mTN_SN_UseMSDP) {
        delete _u; _u=0;
    }
    if(!_u) {
        _u = new TYPE_TN_SN_UseMSDP;
        _present = CHOICE_mTN_SN_UseMSDP;
    } else {
        SITEASSERT(SITE_DYNAMIC_CAST(TYPE_TN_SN_UseMSDP*,_u),
                   "dynamic cast failure for CHOICE element");
    }
    return *SITE_STATIC_CAST(TYPE_TN_SN_UseMSDP*,_u);
}

TYPE_TN_SN_AskGroupId& TYPE_APManagingProtocol::VAR_mTN_SN_AskGroupId() const {
    if (_u && _present!=CHOICE_mTN_SN_AskGroupId) {
        delete _u; _u=0;
    }
    if(!_u) {
        _u = new TYPE_TN_SN_AskGroupId;
        _present = CHOICE_mTN_SN_AskGroupId;
    } else {
        SITEASSERT(SITE_DYNAMIC_CAST(TYPE_TN_SN_AskGroupId*,_u),
                   "dynamic cast failure for CHOICE element");
    }
    return *SITE_STATIC_CAST(TYPE_TN_SN_AskGroupId*,_u);
}

TYPE_SN_TN_HaveGroupId& TYPE_APManagingProtocol::VAR_mSN_TN_HaveGroupId() const {
    if (_u && _present!=CHOICE_mSN_TN_HaveGroupId) {
        delete _u; _u=0;
    }
    if(!_u) {
        _u = new TYPE_SN_TN_HaveGroupId;
        _present = CHOICE_mSN_TN_HaveGroupId;
    } else {
        SITEASSERT(SITE_DYNAMIC_CAST(TYPE_SN_TN_HaveGroupId*,_u),
                   "dynamic cast failure for CHOICE element");
    }
    return *SITE_STATIC_CAST(TYPE_SN_TN_HaveGroupId*,_u);
}

TYPE_TN_SN_ConfigureSetKeyValue& TYPE_APManagingProtocol::VAR_mTN_SN_ConfigureSetKeyValue() const {
    if (_u && _present!=CHOICE_mTN_SN_ConfigureSetKeyValue) {
        delete _u; _u=0;
    }
    if(!_u) {
        _u = new TYPE_TN_SN_ConfigureSetKeyValue;
        _present = CHOICE_mTN_SN_ConfigureSetKeyValue;
    } else {
        SITEASSERT(SITE_DYNAMIC_CAST(TYPE_TN_SN_ConfigureSetKeyValue*,_u),
                   "dynamic cast failure for CHOICE element");
    }
    return *SITE_STATIC_CAST(TYPE_TN_SN_ConfigureSetKeyValue*,_u);
}

TYPE_TN_SN_CloseMessageLogfile& TYPE_APManagingProtocol::VAR_mTN_SN_CloseMessageLogfile() const {
    if (_u && _present!=CHOICE_mTN_SN_CloseMessageLogfile) {
        delete _u; _u=0;
    }
    if(!_u) {
        _u = new TYPE_TN_SN_CloseMessageLogfile;
        _present = CHOICE_mTN_SN_CloseMessageLogfile;
    } else {
        SITEASSERT(SITE_DYNAMIC_CAST(TYPE_TN_SN_CloseMessageLogfile*,_u),
                   "dynamic cast failure for CHOICE element");
    }
    return *SITE_STATIC_CAST(TYPE_TN_SN_CloseMessageLogfile*,_u);
}

TYPE_TN_SN_StartMessageLogging& TYPE_APManagingProtocol::VAR_mTN_SN_StartMessageLogging() const {
    if (_u && _present!=CHOICE_mTN_SN_StartMessageLogging) {
        delete _u; _u=0;
    }
    if(!_u) {
        _u = new TYPE_TN_SN_StartMessageLogging;
        _present = CHOICE_mTN_SN_StartMessageLogging;
    } else {
        SITEASSERT(SITE_DYNAMIC_CAST(TYPE_TN_SN_StartMessageLogging*,_u),
                   "dynamic cast failure for CHOICE element");
    }
    return *SITE_STATIC_CAST(TYPE_TN_SN_StartMessageLogging*,_u);
}

TYPE_TN_SN_StopMessageLogging& TYPE_APManagingProtocol::VAR_mTN_SN_StopMessageLogging() const {
    if (_u && _present!=CHOICE_mTN_SN_StopMessageLogging) {
        delete _u; _u=0;
    }
    if(!_u) {
        _u = new TYPE_TN_SN_StopMessageLogging;
        _present = CHOICE_mTN_SN_StopMessageLogging;
    } else {
        SITEASSERT(SITE_DYNAMIC_CAST(TYPE_TN_SN_StopMessageLogging*,_u),
                   "dynamic cast failure for CHOICE element");
    }
    return *SITE_STATIC_CAST(TYPE_TN_SN_StopMessageLogging*,_u);
}

void TYPE_APManagingProtocol::assign_field(unsigned int variant,const SDLType& elem)
{
    switch(variant) {
        case CHOICE_mTN_SN_AssignLeadershipForGroup: VAR_mTN_SN_AssignLeadershipForGroup().assign(&elem); break;
        case CHOICE_mTN_LN_AssignLNsInNetwork: VAR_mTN_LN_AssignLNsInNetwork().assign(&elem); break;
        case CHOICE_mTN_LN_AssignGNsInNetwork: VAR_mTN_LN_AssignGNsInNetwork().assign(&elem); break;
        case CHOICE_mLN_SN_PrimaryLN: VAR_mLN_SN_PrimaryLN().assign(&elem); break;
        case CHOICE_mLN_SN_SecondaryLN: VAR_mLN_SN_SecondaryLN().assign(&elem); break;
        case CHOICE_mTN_SN_UseMSDP: VAR_mTN_SN_UseMSDP().assign(&elem); break;
        case CHOICE_mTN_SN_AskGroupId: VAR_mTN_SN_AskGroupId().assign(&elem); break;
        case CHOICE_mSN_TN_HaveGroupId: VAR_mSN_TN_HaveGroupId().assign(&elem); break;
        case CHOICE_mTN_SN_ConfigureSetKeyValue: VAR_mTN_SN_ConfigureSetKeyValue().assign(&elem); break;
        case CHOICE_mTN_SN_CloseMessageLogfile: VAR_mTN_SN_CloseMessageLogfile().assign(&elem); break;
        case CHOICE_mTN_SN_StartMessageLogging: VAR_mTN_SN_StartMessageLogging().assign(&elem); break;
        case CHOICE_mTN_SN_StopMessageLogging: VAR_mTN_SN_StopMessageLogging().assign(&elem); break;
        default : SDLASSERT(0,"wrong choice variant");
    }
    SDLASSERT(_u,"type error for choice variant");
} // TYPE_APManagingProtocol::assign_field

AsnLen TYPE_APManagingProtocol::bEnc(BUF_TYPE b) const {
    AsnLen elmtLen = bEncContent(b);
    return elmtLen;
} // TYPE_APManagingProtocol::bEnc

AsnLen TYPE_APManagingProtocol::bEncContent(BUF_TYPE b) const {
    AsnLen elmtLen;
    switch(_present) {
        case CHOICE_mTN_SN_AssignLeadershipForGroup :
            elmtLen = VAR_mTN_SN_AssignLeadershipForGroup().bEncContent(b);
            elmtLen += BEncDefLen(b,elmtLen);
            elmtLen += BEncTag1(b,UNIV,CONS,16);
            elmtLen += BEncDefLen(b,elmtLen);
            elmtLen += BEncTag1(b,CNTX,CONS,1);
            return elmtLen;
        case CHOICE_mTN_LN_AssignLNsInNetwork :
            elmtLen = VAR_mTN_LN_AssignLNsInNetwork().bEncContent(b);
            elmtLen += BEncDefLen(b,elmtLen);
            elmtLen += BEncTag1(b,UNIV,CONS,16);
            elmtLen += BEncDefLen(b,elmtLen);
            elmtLen += BEncTag1(b,CNTX,CONS,2);
            return elmtLen;
        case CHOICE_mTN_LN_AssignGNsInNetwork :
            elmtLen = VAR_mTN_LN_AssignGNsInNetwork().bEncContent(b);
            elmtLen += BEncDefLen(b,elmtLen);
            elmtLen += BEncTag1(b,UNIV,CONS,16);
            elmtLen += BEncDefLen(b,elmtLen);
            elmtLen += BEncTag1(b,CNTX,CONS,3);
            return elmtLen;
        case CHOICE_mLN_SN_PrimaryLN :
            elmtLen = VAR_mLN_SN_PrimaryLN().bEncContent(b);
            elmtLen += BEncDefLen(b,elmtLen);
            elmtLen += BEncTag1(b,UNIV,CONS,16);
            elmtLen += BEncDefLen(b,elmtLen);
            elmtLen += BEncTag1(b,CNTX,CONS,4);
            return elmtLen;
        case CHOICE_mLN_SN_SecondaryLN :
            elmtLen = VAR_mLN_SN_SecondaryLN().bEncContent(b);
            elmtLen += BEncDefLen(b,elmtLen);
            elmtLen += BEncTag1(b,UNIV,CONS,16);
            elmtLen += BEncDefLen(b,elmtLen);
            elmtLen += BEncTag1(b,CNTX,CONS,5);
            return elmtLen;
        case CHOICE_mTN_SN_UseMSDP :
            elmtLen = VAR_mTN_SN_UseMSDP().bEncContent(b);
            elmtLen += BEncDefLen(b,elmtLen);
            elmtLen += BEncTag1(b,UNIV,CONS,16);
            elmtLen += BEncDefLen(b,elmtLen);
            elmtLen += BEncTag1(b,CNTX,CONS,6);
            return elmtLen;
        case CHOICE_mTN_SN_AskGroupId :
            elmtLen = VAR_mTN_SN_AskGroupId().bEncContent(b);
            elmtLen += BEncDefLen(b,elmtLen);
            elmtLen += BEncTag1(b,UNIV,CONS,16);
            elmtLen += BEncDefLen(b,elmtLen);
            elmtLen += BEncTag1(b,CNTX,CONS,7);
            return elmtLen;
        case CHOICE_mSN_TN_HaveGroupId :
            elmtLen = VAR_mSN_TN_HaveGroupId().bEncContent(b);
            elmtLen += BEncDefLen(b,elmtLen);
            elmtLen += BEncTag1(b,UNIV,CONS,16);
            elmtLen += BEncDefLen(b,elmtLen);
            elmtLen += BEncTag1(b,CNTX,CONS,8);
            return elmtLen;
        case CHOICE_mTN_SN_ConfigureSetKeyValue :
            elmtLen = VAR_mTN_SN_ConfigureSetKeyValue().bEncContent(b);
            elmtLen += BEncDefLen(b,elmtLen);
            elmtLen += BEncTag1(b,UNIV,CONS,16);
            elmtLen += BEncDefLen(b,elmtLen);
            elmtLen += BEncTag1(b,CNTX,CONS,9);
            return elmtLen;
        case CHOICE_mTN_SN_CloseMessageLogfile :
            elmtLen = VAR_mTN_SN_CloseMessageLogfile().bEncContent(b);
            elmtLen += BEncDefLen(b,elmtLen);
            elmtLen += BEncTag1(b,UNIV,CONS,16);
            elmtLen += BEncDefLen(b,elmtLen);
            elmtLen += BEncTag1(b,CNTX,CONS,10);
            return elmtLen;
        case CHOICE_mTN_SN_StartMessageLogging :
            elmtLen = VAR_mTN_SN_StartMessageLogging().bEncContent(b);
            elmtLen += BEncDefLen(b,elmtLen);
            elmtLen += BEncTag1(b,UNIV,CONS,16);
            elmtLen += BEncDefLen(b,elmtLen);
            elmtLen += BEncTag1(b,CNTX,CONS,11);
            return elmtLen;
        case CHOICE_mTN_SN_StopMessageLogging :
            elmtLen = VAR_mTN_SN_StopMessageLogging().bEncContent(b);
            elmtLen += BEncDefLen(b,elmtLen);
            elmtLen += BEncTag1(b,UNIV,CONS,16);
            elmtLen += BEncDefLen(b,elmtLen);
            elmtLen += BEncTag1(b,CNTX,CONS,12);
            return elmtLen;
        default:;
    }
    ChoiceError("ERROR no valid field");
    return 0;
} // TYPE_APManagingProtocol::bEncContent

void TYPE_APManagingProtocol::bDec(BUF_TYPE b,AsnLen& bytesDecoded) {
    AsnTag tagId = BDecTag(b,bytesDecoded);
    AsnLen elmtLen = BDecLen(b,bytesDecoded);
    bDecContent(b,tagId,elmtLen,bytesDecoded);
} // TYPE_APManagingProtocol::bDec

void TYPE_APManagingProtocol::bDecContent(BUF_TYPE b,AsnTag tagId,
        AsnLen len, AsnLen& bytesDecoded) {
    AsnLen elmtLen = len, localBytesDecoded = 0;
    int pending_eoc = 0; // can be unused if implicit tagged 
    switch(tagId) {
        case MAKE_TAG_ID(CNTX,CONS,1):
            if (elmtLen == INDEFINITE_LEN) ++pending_eoc;
            tagId = BDecTag1(b,localBytesDecoded);
            if (tagId == MAKE_TAG_ID(UNIV,CONS,16)) {
              elmtLen = BDecLen(b,localBytesDecoded);
            } else { TagError(MAKE_TAG_ID(UNIV,CONS,16),tagId); return; }
            VAR_mTN_SN_AssignLeadershipForGroup().bDecContent(b,tagId,elmtLen,localBytesDecoded);
            break;
        case MAKE_TAG_ID(CNTX,CONS,2):
            if (elmtLen == INDEFINITE_LEN) ++pending_eoc;
            tagId = BDecTag1(b,localBytesDecoded);
            if (tagId == MAKE_TAG_ID(UNIV,CONS,16)) {
              elmtLen = BDecLen(b,localBytesDecoded);
            } else { TagError(MAKE_TAG_ID(UNIV,CONS,16),tagId); return; }
            VAR_mTN_LN_AssignLNsInNetwork().bDecContent(b,tagId,elmtLen,localBytesDecoded);
            break;
        case MAKE_TAG_ID(CNTX,CONS,3):
            if (elmtLen == INDEFINITE_LEN) ++pending_eoc;
            tagId = BDecTag1(b,localBytesDecoded);
            if (tagId == MAKE_TAG_ID(UNIV,CONS,16)) {
              elmtLen = BDecLen(b,localBytesDecoded);
            } else { TagError(MAKE_TAG_ID(UNIV,CONS,16),tagId); return; }
            VAR_mTN_LN_AssignGNsInNetwork().bDecContent(b,tagId,elmtLen,localBytesDecoded);
            break;
        case MAKE_TAG_ID(CNTX,CONS,4):
            if (elmtLen == INDEFINITE_LEN) ++pending_eoc;
            tagId = BDecTag1(b,localBytesDecoded);
            if (tagId == MAKE_TAG_ID(UNIV,CONS,16)) {
              elmtLen = BDecLen(b,localBytesDecoded);
            } else { TagError(MAKE_TAG_ID(UNIV,CONS,16),tagId); return; }
            VAR_mLN_SN_PrimaryLN().bDecContent(b,tagId,elmtLen,localBytesDecoded);
            break;
        case MAKE_TAG_ID(CNTX,CONS,5):
            if (elmtLen == INDEFINITE_LEN) ++pending_eoc;
            tagId = BDecTag1(b,localBytesDecoded);
            if (tagId == MAKE_TAG_ID(UNIV,CONS,16)) {
              elmtLen = BDecLen(b,localBytesDecoded);
            } else { TagError(MAKE_TAG_ID(UNIV,CONS,16),tagId); return; }
            VAR_mLN_SN_SecondaryLN().bDecContent(b,tagId,elmtLen,localBytesDecoded);
            break;
        case MAKE_TAG_ID(CNTX,CONS,6):
            if (elmtLen == INDEFINITE_LEN) ++pending_eoc;
            tagId = BDecTag1(b,localBytesDecoded);
            if (tagId == MAKE_TAG_ID(UNIV,CONS,16)) {
              elmtLen = BDecLen(b,localBytesDecoded);
            } else { TagError(MAKE_TAG_ID(UNIV,CONS,16),tagId); return; }
            VAR_mTN_SN_UseMSDP().bDecContent(b,tagId,elmtLen,localBytesDecoded);
            break;
        case MAKE_TAG_ID(CNTX,CONS,7):
            if (elmtLen == INDEFINITE_LEN) ++pending_eoc;
            tagId = BDecTag1(b,localBytesDecoded);
            if (tagId == MAKE_TAG_ID(UNIV,CONS,16)) {
              elmtLen = BDecLen(b,localBytesDecoded);
            } else { TagError(MAKE_TAG_ID(UNIV,CONS,16),tagId); return; }
            VAR_mTN_SN_AskGroupId().bDecContent(b,tagId,elmtLen,localBytesDecoded);
            break;
        case MAKE_TAG_ID(CNTX,CONS,8):
            if (elmtLen == INDEFINITE_LEN) ++pending_eoc;
            tagId = BDecTag1(b,localBytesDecoded);
            if (tagId == MAKE_TAG_ID(UNIV,CONS,16)) {
              elmtLen = BDecLen(b,localBytesDecoded);
            } else { TagError(MAKE_TAG_ID(UNIV,CONS,16),tagId); return; }
            VAR_mSN_TN_HaveGroupId().bDecContent(b,tagId,elmtLen,localBytesDecoded);
            break;
        case MAKE_TAG_ID(CNTX,CONS,9):
            if (elmtLen == INDEFINITE_LEN) ++pending_eoc;
            tagId = BDecTag1(b,localBytesDecoded);
            if (tagId == MAKE_TAG_ID(UNIV,CONS,16)) {
              elmtLen = BDecLen(b,localBytesDecoded);
            } else { TagError(MAKE_TAG_ID(UNIV,CONS,16),tagId); return; }
            VAR_mTN_SN_ConfigureSetKeyValue().bDecContent(b,tagId,elmtLen,localBytesDecoded);
            break;
        case MAKE_TAG_ID(CNTX,CONS,10):
            if (elmtLen == INDEFINITE_LEN) ++pending_eoc;
            tagId = BDecTag1(b,localBytesDecoded);
            if (tagId == MAKE_TAG_ID(UNIV,CONS,16)) {
              elmtLen = BDecLen(b,localBytesDecoded);
            } else { TagError(MAKE_TAG_ID(UNIV,CONS,16),tagId); return; }
            VAR_mTN_SN_CloseMessageLogfile().bDecContent(b,tagId,elmtLen,localBytesDecoded);
            break;
        case MAKE_TAG_ID(CNTX,CONS,11):
            if (elmtLen == INDEFINITE_LEN) ++pending_eoc;
            tagId = BDecTag1(b,localBytesDecoded);
            if (tagId == MAKE_TAG_ID(UNIV,CONS,16)) {
              elmtLen = BDecLen(b,localBytesDecoded);
            } else { TagError(MAKE_TAG_ID(UNIV,CONS,16),tagId); return; }
            VAR_mTN_SN_StartMessageLogging().bDecContent(b,tagId,elmtLen,localBytesDecoded);
            break;
        case MAKE_TAG_ID(CNTX,CONS,12):
            if (elmtLen == INDEFINITE_LEN) ++pending_eoc;
            tagId = BDecTag1(b,localBytesDecoded);
            if (tagId == MAKE_TAG_ID(UNIV,CONS,16)) {
              elmtLen = BDecLen(b,localBytesDecoded);
            } else { TagError(MAKE_TAG_ID(UNIV,CONS,16),tagId); return; }
            VAR_mTN_SN_StopMessageLogging().bDecContent(b,tagId,elmtLen,localBytesDecoded);
            break;
        default: TagError(0,tagId); return;
    } /* tag switch */
    bytesDecoded += localBytesDecoded;
    for(;pending_eoc>0;--pending_eoc) { BDecEoc(b,localBytesDecoded); }
    if ((len!=INDEFINITE_LEN) && (localBytesDecoded!=len)) { LengthError();return; }
    set_state(validValue);
} // TYPE_APManagingProtocol::bDecContent

AsnLen TYPE_APManagingProtocol::pEnc(BUF_TYPE2 b) const {
    int off, elmtLen;
    switch(_present){
        case CHOICE_mTN_SN_StopMessageLogging : off=0; break;
        case CHOICE_mTN_SN_StartMessageLogging : off=1; break;
        case CHOICE_mTN_SN_CloseMessageLogfile : off=2; break;
        case CHOICE_mTN_SN_ConfigureSetKeyValue : off=3; break;
        case CHOICE_mSN_TN_HaveGroupId : off=4; break;
        case CHOICE_mTN_SN_AskGroupId : off=5; break;
        case CHOICE_mTN_SN_UseMSDP : off=6; break;
        case CHOICE_mLN_SN_SecondaryLN : off=7; break;
        case CHOICE_mLN_SN_PrimaryLN : off=8; break;
        case CHOICE_mTN_LN_AssignGNsInNetwork : off=9; break;
        case CHOICE_mTN_LN_AssignLNsInNetwork : off=10; break;
        case CHOICE_mTN_SN_AssignLeadershipForGroup : off=11; break;
    }
    SITE_SDL_UINT mask = 0x8LL;
    for(int i=0; i<4; mask>>=1,i++)
      b.putBit(off & mask);
    switch(_present){
        case CHOICE_mTN_SN_StopMessageLogging : elmtLen = VAR_mTN_SN_StopMessageLogging().pEnc(b); break;
        case CHOICE_mTN_SN_StartMessageLogging : elmtLen = VAR_mTN_SN_StartMessageLogging().pEnc(b); break;
        case CHOICE_mTN_SN_CloseMessageLogfile : elmtLen = VAR_mTN_SN_CloseMessageLogfile().pEnc(b); break;
        case CHOICE_mTN_SN_ConfigureSetKeyValue : elmtLen = VAR_mTN_SN_ConfigureSetKeyValue().pEnc(b); break;
        case CHOICE_mSN_TN_HaveGroupId : elmtLen = VAR_mSN_TN_HaveGroupId().pEnc(b); break;
        case CHOICE_mTN_SN_AskGroupId : elmtLen = VAR_mTN_SN_AskGroupId().pEnc(b); break;
        case CHOICE_mTN_SN_UseMSDP : elmtLen = VAR_mTN_SN_UseMSDP().pEnc(b); break;
        case CHOICE_mLN_SN_SecondaryLN : elmtLen = VAR_mLN_SN_SecondaryLN().pEnc(b); break;
        case CHOICE_mLN_SN_PrimaryLN : elmtLen = VAR_mLN_SN_PrimaryLN().pEnc(b); break;
        case CHOICE_mTN_LN_AssignGNsInNetwork : elmtLen = VAR_mTN_LN_AssignGNsInNetwork().pEnc(b); break;
        case CHOICE_mTN_LN_AssignLNsInNetwork : elmtLen = VAR_mTN_LN_AssignLNsInNetwork().pEnc(b); break;
        case CHOICE_mTN_SN_AssignLeadershipForGroup : elmtLen = VAR_mTN_SN_AssignLeadershipForGroup().pEnc(b); break;
    }
    return elmtLen + 4;
}

void TYPE_APManagingProtocol::pDec(BUF_TYPE2 b) {
    SITE_SDL_UINT off = 0;
    for(int i=0; i<4; i++)
      off = (off << 1) | (b.getBit()?1:0);
    switch(off){
        case 0 : _present = CHOICE_mTN_SN_StopMessageLogging; VAR_mTN_SN_StopMessageLogging().pDec(b); break;
        case 1 : _present = CHOICE_mTN_SN_StartMessageLogging; VAR_mTN_SN_StartMessageLogging().pDec(b); break;
        case 2 : _present = CHOICE_mTN_SN_CloseMessageLogfile; VAR_mTN_SN_CloseMessageLogfile().pDec(b); break;
        case 3 : _present = CHOICE_mTN_SN_ConfigureSetKeyValue; VAR_mTN_SN_ConfigureSetKeyValue().pDec(b); break;
        case 4 : _present = CHOICE_mSN_TN_HaveGroupId; VAR_mSN_TN_HaveGroupId().pDec(b); break;
        case 5 : _present = CHOICE_mTN_SN_AskGroupId; VAR_mTN_SN_AskGroupId().pDec(b); break;
        case 6 : _present = CHOICE_mTN_SN_UseMSDP; VAR_mTN_SN_UseMSDP().pDec(b); break;
        case 7 : _present = CHOICE_mLN_SN_SecondaryLN; VAR_mLN_SN_SecondaryLN().pDec(b); break;
        case 8 : _present = CHOICE_mLN_SN_PrimaryLN; VAR_mLN_SN_PrimaryLN().pDec(b); break;
        case 9 : _present = CHOICE_mTN_LN_AssignGNsInNetwork; VAR_mTN_LN_AssignGNsInNetwork().pDec(b); break;
        case 10 : _present = CHOICE_mTN_LN_AssignLNsInNetwork; VAR_mTN_LN_AssignLNsInNetwork().pDec(b); break;
        case 11 : _present = CHOICE_mTN_SN_AssignLeadershipForGroup; VAR_mTN_SN_AssignLeadershipForGroup().pDec(b); break;
    }
    set_state(validValue);
}

bool TYPE_APManagingProtocol::datainfo(long index,SDLIA5String& var_name,
    SDLIA5String& var_type,SDLType*& var,SDLType::infotype it)
{
    switch(index) {
    case 1:
        var_name="mTN-SN-AssignLeadershipForGroup";
        var_type="TN-SN-AssignLeadershipForGroup";
        if (_present!=CHOICE_mTN_SN_AssignLeadershipForGroup && it==SDLType::info_get)
          var = 0;
        else
          var = &VAR_mTN_SN_AssignLeadershipForGroup();
        break;
    case 2:
        var_name="mTN-LN-AssignLNsInNetwork";
        var_type="TN-LN-AssignLNsInNetwork";
        if (_present!=CHOICE_mTN_LN_AssignLNsInNetwork && it==SDLType::info_get)
          var = 0;
        else
          var = &VAR_mTN_LN_AssignLNsInNetwork();
        break;
    case 3:
        var_name="mTN-LN-AssignGNsInNetwork";
        var_type="TN-LN-AssignGNsInNetwork";
        if (_present!=CHOICE_mTN_LN_AssignGNsInNetwork && it==SDLType::info_get)
          var = 0;
        else
          var = &VAR_mTN_LN_AssignGNsInNetwork();
        break;
    case 4:
        var_name="mLN-SN-PrimaryLN";
        var_type="LN-SN-PrimaryLN";
        if (_present!=CHOICE_mLN_SN_PrimaryLN && it==SDLType::info_get)
          var = 0;
        else
          var = &VAR_mLN_SN_PrimaryLN();
        break;
    case 5:
        var_name="mLN-SN-SecondaryLN";
        var_type="LN-SN-SecondaryLN";
        if (_present!=CHOICE_mLN_SN_SecondaryLN && it==SDLType::info_get)
          var = 0;
        else
          var = &VAR_mLN_SN_SecondaryLN();
        break;
    case 6:
        var_name="mTN-SN-UseMSDP";
        var_type="TN-SN-UseMSDP";
        if (_present!=CHOICE_mTN_SN_UseMSDP && it==SDLType::info_get)
          var = 0;
        else
          var = &VAR_mTN_SN_UseMSDP();
        break;
    case 7:
        var_name="mTN-SN-AskGroupId";
        var_type="TN-SN-AskGroupId";
        if (_present!=CHOICE_mTN_SN_AskGroupId && it==SDLType::info_get)
          var = 0;
        else
          var = &VAR_mTN_SN_AskGroupId();
        break;
    case 8:
        var_name="mSN-TN-HaveGroupId";
        var_type="SN-TN-HaveGroupId";
        if (_present!=CHOICE_mSN_TN_HaveGroupId && it==SDLType::info_get)
          var = 0;
        else
          var = &VAR_mSN_TN_HaveGroupId();
        break;
    case 9:
        var_name="mTN-SN-ConfigureSetKeyValue";
        var_type="TN-SN-ConfigureSetKeyValue";
        if (_present!=CHOICE_mTN_SN_ConfigureSetKeyValue && it==SDLType::info_get)
          var = 0;
        else
          var = &VAR_mTN_SN_ConfigureSetKeyValue();
        break;
    case 10:
        var_name="mTN-SN-CloseMessageLogfile";
        var_type="TN-SN-CloseMessageLogfile";
        if (_present!=CHOICE_mTN_SN_CloseMessageLogfile && it==SDLType::info_get)
          var = 0;
        else
          var = &VAR_mTN_SN_CloseMessageLogfile();
        break;
    case 11:
        var_name="mTN-SN-StartMessageLogging";
        var_type="TN-SN-StartMessageLogging";
        if (_present!=CHOICE_mTN_SN_StartMessageLogging && it==SDLType::info_get)
          var = 0;
        else
          var = &VAR_mTN_SN_StartMessageLogging();
        break;
    case 12:
        var_name="mTN-SN-StopMessageLogging";
        var_type="TN-SN-StopMessageLogging";
        if (_present!=CHOICE_mTN_SN_StopMessageLogging && it==SDLType::info_get)
          var = 0;
        else
          var = &VAR_mTN_SN_StopMessageLogging();
        break;
    default: return false;
    }
    return true;
} /* TYPE_APManagingProtocol::datainfo */

SDLSeqSetDescription TYPE_TN_SN_AssignLeadershipForGroup::_fdesc(3);

SDLType* TYPE_TN_SN_AssignLeadershipForGroup::copy()const { return new TYPE_TN_SN_AssignLeadershipForGroup(*this); }

void TYPE_TN_SN_AssignLeadershipForGroup::assign(const SDLType* t)
{
  const TYPE_TN_SN_AssignLeadershipForGroup *arg = SITE_DYNAMIC_CAST(const TYPE_TN_SN_AssignLeadershipForGroup*,t);
  if (!arg) SDLSequence::assign(t);
  else *this = *arg;
}

SDLType* TYPE_TN_SN_AssignLeadershipForGroup::create()
{
  static TYPE_TN_SN_AssignLeadershipForGroup* tmpl = new TYPE_TN_SN_AssignLeadershipForGroup;
  return tmpl;
}

const SDLType* TYPE_TN_SN_AssignLeadershipForGroup::create_new() const { return create(); }

TYPE_TN_SN_AssignLeadershipForGroup::TYPE_TN_SN_AssignLeadershipForGroup():SDLSequence(_fields,3){}
TYPE_TN_SN_AssignLeadershipForGroup::TYPE_TN_SN_AssignLeadershipForGroup(SDLType** f,unsigned long c):SDLSequence(f,c){}
TYPE_TN_SN_AssignLeadershipForGroup::TYPE_TN_SN_AssignLeadershipForGroup(const SDLNull&):SDLSequence(_fields,3)
{ set_state(invalidValue); }
TYPE_TN_SN_AssignLeadershipForGroup::TYPE_TN_SN_AssignLeadershipForGroup(const SDLAny& a, AsnCodingSet rule_set):SDLSequence(_fields,3){a.decode(this,rule_set);}
TYPE_TN_SN_AssignLeadershipForGroup::TYPE_TN_SN_AssignLeadershipForGroup(const TYPE_TN_SN_AssignLeadershipForGroup&o):SDLSequence(o){
  if (o.state(SITEtemporaryValue)) {
#ifdef SITE_LOG
    if (SDLType::_type_debug & SITE_COPY_LOG)
      CERR << "(SDLRTE) struct reference copy of " << o << ENDL;
#endif
    for(int i=0; i<3;++i) {
       _fields[i] = o._fields[i]; o._fields[i] = 0;
    }
  } else sequence_copyinit(_fields,o._fields,3);
}
TYPE_TN_SN_AssignLeadershipForGroup::~TYPE_TN_SN_AssignLeadershipForGroup(){clear_fields(_fields,3);}

TYPE_TN_SN_AssignLeadershipForGroup& TYPE_TN_SN_AssignLeadershipForGroup::operator=(const TYPE_TN_SN_AssignLeadershipForGroup& val){
  val.check_valid();
  if (this!=&val) sequence_assign(val);
  return *this;
}

unsigned int TYPE_TN_SN_AssignLeadershipForGroup::hash(unsigned int max_hash)const{
  return sequence_hash(_fields, 3, max_hash);
}

void TYPE_TN_SN_AssignLeadershipForGroup::get_fields(
  SDLSeqSetDescription*& d,SDLType **&field_list){
  d=&_fdesc; field_list=_fields;
}

void TYPE_TN_SN_AssignLeadershipForGroup::get_fields(
  SDLSeqSetDescription*& d,SDLType *const*&field_list) const{
  d=&_fdesc; field_list=_fields;
}


TYPE_DateTime& TYPE_TN_SN_AssignLeadershipForGroup::VAR_gpsTimeStamp() const
{ return *SITE_STATIC_CAST(TYPE_DateTime*,field_access(_fdesc,_fields,0)); }
static SDLSeqSetDescription::Field *_TYPE_TN_SN_AssignLeadershipForGroupgpsTimeStamp=TYPE_TN_SN_AssignLeadershipForGroup::_fdesc.add(0,"gpsTimeStamp",&TYPE_DateTime::create,true);

TYPE_APManagingProtocol_GEN_1& TYPE_TN_SN_AssignLeadershipForGroup::VAR_groupMembers() const
{ return *SITE_STATIC_CAST(TYPE_APManagingProtocol_GEN_1*,field_access(_fdesc,_fields,1)); }
static SDLSeqSetDescription::Field *_TYPE_TN_SN_AssignLeadershipForGroupgroupMembers=TYPE_TN_SN_AssignLeadershipForGroup::_fdesc.add(1,"groupMembers",&TYPE_APManagingProtocol_GEN_1::create,true);

TYPE_GroupID& TYPE_TN_SN_AssignLeadershipForGroup::VAR_groupID() const
{ return *SITE_STATIC_CAST(TYPE_GroupID*,field_access(_fdesc,_fields,2)); }
static SDLSeqSetDescription::Field *_TYPE_TN_SN_AssignLeadershipForGroupgroupID=TYPE_TN_SN_AssignLeadershipForGroup::_fdesc.add(2,"groupID",&TYPE_GroupID::create,true);



TYPE_TN_SN_AssignLeadershipForGroup::TYPE_TN_SN_AssignLeadershipForGroup(const class TYPE_DateTime& PAR_0, const class TYPE_APManagingProtocol_GEN_1& PAR_1, const class TYPE_GroupID& PAR_2) {
    set_field(0,PAR_0.copy());
    set_field(1,PAR_1.copy());
    set_field(2,PAR_2.copy());
}

AsnLen TYPE_TN_SN_AssignLeadershipForGroup::bEnc(BUF_TYPE b) const{
    AsnLen elmtLen = bEncContent(b);
    elmtLen += BEncDefLen(b,elmtLen);
    elmtLen += BEncTag1(b,UNIV,CONS,16);
    return elmtLen;
} // TYPE_TN_SN_AssignLeadershipForGroup::bEnc

AsnLen TYPE_TN_SN_AssignLeadershipForGroup::bEncContent(BUF_TYPE b) const {
    AsnLen elmtLen, structBytesEncoded = BEncExtraFields(b);
    elmtLen = VAR_groupID().bEncContent(b);
    elmtLen += BEncDefLen(b,elmtLen);
    elmtLen += BEncTag1(b,UNIV,PRIM,2);
    structBytesEncoded += elmtLen;
    elmtLen = VAR_groupMembers().bEncContent(b);
    elmtLen += BEncDefLen(b,elmtLen);
    elmtLen += BEncTag1(b,UNIV,CONS,17);
    structBytesEncoded += elmtLen;
    elmtLen = VAR_gpsTimeStamp().bEncContent(b);
    elmtLen += BEncDefLen(b,elmtLen);
    elmtLen += BEncTag1(b,UNIV,CONS,16);
    structBytesEncoded += elmtLen;
    return structBytesEncoded;
} // TYPE_TN_SN_AssignLeadershipForGroup::bEncContent

void TYPE_TN_SN_AssignLeadershipForGroup::bDec(BUF_TYPE b,AsnLen& bytesDecoded) {
    AsnTag tagId = BDecTag1(b,bytesDecoded);
    AsnLen elmtLen;
    if (tagId != MAKE_TAG_ID(UNIV,CONS,16)) { TagError(MAKE_TAG_ID(UNIV,CONS,16),tagId); return; }
    elmtLen = BDecLen(b,bytesDecoded);
    int pending_eoc = 0;
    if (elmtLen == INDEFINITE_LEN) ++pending_eoc;
    AsnLen localBytesDecoded = 0;
    bDecContent(b,tagId,elmtLen,localBytesDecoded);
    for(;pending_eoc>0;--pending_eoc) { BDecEoc(b,localBytesDecoded); }
    bytesDecoded += localBytesDecoded;
} // TYPE_TN_SN_AssignLeadershipForGroup::bDec

void TYPE_TN_SN_AssignLeadershipForGroup::bDecContent(BUF_TYPE b,AsnTag,
        AsnLen len, AsnLen& bytesDecoded) {
    bool structDone = false;
    AsnLen elmtLen, localBytesDecoded = 0;
    AsnTag tagId;
    if (len == 0) { tagId = 0; structDone = true; }
    else tagId = BDecTag(b,localBytesDecoded);
    if (!structDone && (tagId==MAKE_TAG_ID(UNIV,CONS,16))) {
        elmtLen = BDecLen(b,localBytesDecoded);
        int pending_eoc = 0;
        if (elmtLen == INDEFINITE_LEN) ++pending_eoc;
        VAR_gpsTimeStamp().bDecContent(b,tagId,elmtLen,localBytesDecoded);
        for(;pending_eoc>0;--pending_eoc) { BDecEoc(b,localBytesDecoded); }
        if ((len!=INDEFINITE_LEN) && (localBytesDecoded>=len)) structDone = true;
        else tagId = BDecTag(b,localBytesDecoded);
    } else { TagError(MAKE_TAG_ID(UNIV,CONS,16),tagId); return; }
    if (!structDone && (tagId==MAKE_TAG_ID(UNIV,CONS,17))) {
        elmtLen = BDecLen(b,localBytesDecoded);
        int pending_eoc = 0;
        if (elmtLen == INDEFINITE_LEN) ++pending_eoc;
        VAR_groupMembers().bDecContent(b,tagId,elmtLen,localBytesDecoded);
        for(;pending_eoc>0;--pending_eoc) { BDecEoc(b,localBytesDecoded); }
        if ((len!=INDEFINITE_LEN) && (localBytesDecoded>=len)) structDone = true;
        else tagId = BDecTag(b,localBytesDecoded);
    } else { TagError(MAKE_TAG_ID(UNIV,CONS,17),tagId); return; }
    if (!structDone && (tagId==MAKE_TAG_ID(UNIV,PRIM,2))) {
        elmtLen = BDecLen(b,localBytesDecoded);
        VAR_groupID().bDecContent(b,tagId,elmtLen,localBytesDecoded);
        if ((len!=INDEFINITE_LEN) && (localBytesDecoded>=len)) structDone = true;
        else tagId = BDecTag(b,localBytesDecoded);
    } else { TagError(MAKE_TAG_ID(UNIV,PRIM,2),tagId); return; }
    complete_sequence_decoding(b, len, localBytesDecoded, tagId);
    bytesDecoded += localBytesDecoded;
    set_state(validValue);
} // TYPE_TN_SN_AssignLeadershipForGroup::bDecContent

AsnLen TYPE_TN_SN_AssignLeadershipForGroup::pEnc(BUF_TYPE2 b) const {
    int elmtLen=0;
    elmtLen += VAR_gpsTimeStamp().pEnc(b);
    elmtLen += VAR_groupMembers().pEnc(b);
    elmtLen += VAR_groupID().pEnc(b);
    return elmtLen;
}

void TYPE_TN_SN_AssignLeadershipForGroup::pDec(BUF_TYPE2 b) {
    VAR_gpsTimeStamp().pDec(b);
    VAR_groupMembers().pDec(b);
    VAR_groupID().pDec(b);
    set_state(validValue);
}

SDLSeqSetDescription TYPE_TN_LN_AssignLNsInNetwork::_fdesc(2);

SDLType* TYPE_TN_LN_AssignLNsInNetwork::copy()const { return new TYPE_TN_LN_AssignLNsInNetwork(*this); }

void TYPE_TN_LN_AssignLNsInNetwork::assign(const SDLType* t)
{
  const TYPE_TN_LN_AssignLNsInNetwork *arg = SITE_DYNAMIC_CAST(const TYPE_TN_LN_AssignLNsInNetwork*,t);
  if (!arg) SDLSequence::assign(t);
  else *this = *arg;
}

SDLType* TYPE_TN_LN_AssignLNsInNetwork::create()
{
  static TYPE_TN_LN_AssignLNsInNetwork* tmpl = new TYPE_TN_LN_AssignLNsInNetwork;
  return tmpl;
}

const SDLType* TYPE_TN_LN_AssignLNsInNetwork::create_new() const { return create(); }

TYPE_TN_LN_AssignLNsInNetwork::TYPE_TN_LN_AssignLNsInNetwork():SDLSequence(_fields,2){}
TYPE_TN_LN_AssignLNsInNetwork::TYPE_TN_LN_AssignLNsInNetwork(SDLType** f,unsigned long c):SDLSequence(f,c){}
TYPE_TN_LN_AssignLNsInNetwork::TYPE_TN_LN_AssignLNsInNetwork(const SDLNull&):SDLSequence(_fields,2)
{ set_state(invalidValue); }
TYPE_TN_LN_AssignLNsInNetwork::TYPE_TN_LN_AssignLNsInNetwork(const SDLAny& a, AsnCodingSet rule_set):SDLSequence(_fields,2){a.decode(this,rule_set);}
TYPE_TN_LN_AssignLNsInNetwork::TYPE_TN_LN_AssignLNsInNetwork(const TYPE_TN_LN_AssignLNsInNetwork&o):SDLSequence(o){
  if (o.state(SITEtemporaryValue)) {
#ifdef SITE_LOG
    if (SDLType::_type_debug & SITE_COPY_LOG)
      CERR << "(SDLRTE) struct reference copy of " << o << ENDL;
#endif
    for(int i=0; i<2;++i) {
       _fields[i] = o._fields[i]; o._fields[i] = 0;
    }
  } else sequence_copyinit(_fields,o._fields,2);
}
TYPE_TN_LN_AssignLNsInNetwork::~TYPE_TN_LN_AssignLNsInNetwork(){clear_fields(_fields,2);}

TYPE_TN_LN_AssignLNsInNetwork& TYPE_TN_LN_AssignLNsInNetwork::operator=(const TYPE_TN_LN_AssignLNsInNetwork& val){
  val.check_valid();
  if (this!=&val) sequence_assign(val);
  return *this;
}

unsigned int TYPE_TN_LN_AssignLNsInNetwork::hash(unsigned int max_hash)const{
  return sequence_hash(_fields, 2, max_hash);
}

void TYPE_TN_LN_AssignLNsInNetwork::get_fields(
  SDLSeqSetDescription*& d,SDLType **&field_list){
  d=&_fdesc; field_list=_fields;
}

void TYPE_TN_LN_AssignLNsInNetwork::get_fields(
  SDLSeqSetDescription*& d,SDLType *const*&field_list) const{
  d=&_fdesc; field_list=_fields;
}


TYPE_DateTime& TYPE_TN_LN_AssignLNsInNetwork::VAR_gpsTimeStamp() const
{ return *SITE_STATIC_CAST(TYPE_DateTime*,field_access(_fdesc,_fields,0)); }
static SDLSeqSetDescription::Field *_TYPE_TN_LN_AssignLNsInNetworkgpsTimeStamp=TYPE_TN_LN_AssignLNsInNetwork::_fdesc.add(0,"gpsTimeStamp",&TYPE_DateTime::create,true);

TYPE_APManagingProtocol_GEN_2& TYPE_TN_LN_AssignLNsInNetwork::VAR_leadingNodesInNetwork() const
{ return *SITE_STATIC_CAST(TYPE_APManagingProtocol_GEN_2*,field_access(_fdesc,_fields,1)); }
static SDLSeqSetDescription::Field *_TYPE_TN_LN_AssignLNsInNetworkleadingNodesInNetwork=TYPE_TN_LN_AssignLNsInNetwork::_fdesc.add(1,"leadingNodesInNetwork",&TYPE_APManagingProtocol_GEN_2::create,true);



TYPE_TN_LN_AssignLNsInNetwork::TYPE_TN_LN_AssignLNsInNetwork(const class TYPE_DateTime& PAR_0, const class TYPE_APManagingProtocol_GEN_2& PAR_1) {
    set_field(0,PAR_0.copy());
    set_field(1,PAR_1.copy());
}

AsnLen TYPE_TN_LN_AssignLNsInNetwork::bEnc(BUF_TYPE b) const{
    AsnLen elmtLen = bEncContent(b);
    elmtLen += BEncDefLen(b,elmtLen);
    elmtLen += BEncTag1(b,UNIV,CONS,16);
    return elmtLen;
} // TYPE_TN_LN_AssignLNsInNetwork::bEnc

AsnLen TYPE_TN_LN_AssignLNsInNetwork::bEncContent(BUF_TYPE b) const {
    AsnLen elmtLen, structBytesEncoded = BEncExtraFields(b);
    elmtLen = VAR_leadingNodesInNetwork().bEncContent(b);
    elmtLen += BEncDefLen(b,elmtLen);
    elmtLen += BEncTag1(b,UNIV,CONS,17);
    structBytesEncoded += elmtLen;
    elmtLen = VAR_gpsTimeStamp().bEncContent(b);
    elmtLen += BEncDefLen(b,elmtLen);
    elmtLen += BEncTag1(b,UNIV,CONS,16);
    structBytesEncoded += elmtLen;
    return structBytesEncoded;
} // TYPE_TN_LN_AssignLNsInNetwork::bEncContent

void TYPE_TN_LN_AssignLNsInNetwork::bDec(BUF_TYPE b,AsnLen& bytesDecoded) {
    AsnTag tagId = BDecTag1(b,bytesDecoded);
    AsnLen elmtLen;
    if (tagId != MAKE_TAG_ID(UNIV,CONS,16)) { TagError(MAKE_TAG_ID(UNIV,CONS,16),tagId); return; }
    elmtLen = BDecLen(b,bytesDecoded);
    int pending_eoc = 0;
    if (elmtLen == INDEFINITE_LEN) ++pending_eoc;
    AsnLen localBytesDecoded = 0;
    bDecContent(b,tagId,elmtLen,localBytesDecoded);
    for(;pending_eoc>0;--pending_eoc) { BDecEoc(b,localBytesDecoded); }
    bytesDecoded += localBytesDecoded;
} // TYPE_TN_LN_AssignLNsInNetwork::bDec

void TYPE_TN_LN_AssignLNsInNetwork::bDecContent(BUF_TYPE b,AsnTag,
        AsnLen len, AsnLen& bytesDecoded) {
    bool structDone = false;
    AsnLen elmtLen, localBytesDecoded = 0;
    AsnTag tagId;
    if (len == 0) { tagId = 0; structDone = true; }
    else tagId = BDecTag(b,localBytesDecoded);
    if (!structDone && (tagId==MAKE_TAG_ID(UNIV,CONS,16))) {
        elmtLen = BDecLen(b,localBytesDecoded);
        int pending_eoc = 0;
        if (elmtLen == INDEFINITE_LEN) ++pending_eoc;
        VAR_gpsTimeStamp().bDecContent(b,tagId,elmtLen,localBytesDecoded);
        for(;pending_eoc>0;--pending_eoc) { BDecEoc(b,localBytesDecoded); }
        if ((len!=INDEFINITE_LEN) && (localBytesDecoded>=len)) structDone = true;
        else tagId = BDecTag(b,localBytesDecoded);
    } else { TagError(MAKE_TAG_ID(UNIV,CONS,16),tagId); return; }
    if (!structDone && (tagId==MAKE_TAG_ID(UNIV,CONS,17))) {
        elmtLen = BDecLen(b,localBytesDecoded);
        int pending_eoc = 0;
        if (elmtLen == INDEFINITE_LEN) ++pending_eoc;
        VAR_leadingNodesInNetwork().bDecContent(b,tagId,elmtLen,localBytesDecoded);
        for(;pending_eoc>0;--pending_eoc) { BDecEoc(b,localBytesDecoded); }
        if ((len!=INDEFINITE_LEN) && (localBytesDecoded>=len)) structDone = true;
        else tagId = BDecTag(b,localBytesDecoded);
    } else { TagError(MAKE_TAG_ID(UNIV,CONS,17),tagId); return; }
    complete_sequence_decoding(b, len, localBytesDecoded, tagId);
    bytesDecoded += localBytesDecoded;
    set_state(validValue);
} // TYPE_TN_LN_AssignLNsInNetwork::bDecContent

AsnLen TYPE_TN_LN_AssignLNsInNetwork::pEnc(BUF_TYPE2 b) const {
    int elmtLen=0;
    elmtLen += VAR_gpsTimeStamp().pEnc(b);
    elmtLen += VAR_leadingNodesInNetwork().pEnc(b);
    return elmtLen;
}

void TYPE_TN_LN_AssignLNsInNetwork::pDec(BUF_TYPE2 b) {
    VAR_gpsTimeStamp().pDec(b);
    VAR_leadingNodesInNetwork().pDec(b);
    set_state(validValue);
}

SDLSeqSetDescription TYPE_TN_LN_AssignGNsInNetwork::_fdesc(2);

SDLType* TYPE_TN_LN_AssignGNsInNetwork::copy()const { return new TYPE_TN_LN_AssignGNsInNetwork(*this); }

void TYPE_TN_LN_AssignGNsInNetwork::assign(const SDLType* t)
{
  const TYPE_TN_LN_AssignGNsInNetwork *arg = SITE_DYNAMIC_CAST(const TYPE_TN_LN_AssignGNsInNetwork*,t);
  if (!arg) SDLSequence::assign(t);
  else *this = *arg;
}

SDLType* TYPE_TN_LN_AssignGNsInNetwork::create()
{
  static TYPE_TN_LN_AssignGNsInNetwork* tmpl = new TYPE_TN_LN_AssignGNsInNetwork;
  return tmpl;
}

const SDLType* TYPE_TN_LN_AssignGNsInNetwork::create_new() const { return create(); }

TYPE_TN_LN_AssignGNsInNetwork::TYPE_TN_LN_AssignGNsInNetwork():SDLSequence(_fields,2){}
TYPE_TN_LN_AssignGNsInNetwork::TYPE_TN_LN_AssignGNsInNetwork(SDLType** f,unsigned long c):SDLSequence(f,c){}
TYPE_TN_LN_AssignGNsInNetwork::TYPE_TN_LN_AssignGNsInNetwork(const SDLNull&):SDLSequence(_fields,2)
{ set_state(invalidValue); }
TYPE_TN_LN_AssignGNsInNetwork::TYPE_TN_LN_AssignGNsInNetwork(const SDLAny& a, AsnCodingSet rule_set):SDLSequence(_fields,2){a.decode(this,rule_set);}
TYPE_TN_LN_AssignGNsInNetwork::TYPE_TN_LN_AssignGNsInNetwork(const TYPE_TN_LN_AssignGNsInNetwork&o):SDLSequence(o){
  if (o.state(SITEtemporaryValue)) {
#ifdef SITE_LOG
    if (SDLType::_type_debug & SITE_COPY_LOG)
      CERR << "(SDLRTE) struct reference copy of " << o << ENDL;
#endif
    for(int i=0; i<2;++i) {
       _fields[i] = o._fields[i]; o._fields[i] = 0;
    }
  } else sequence_copyinit(_fields,o._fields,2);
}
TYPE_TN_LN_AssignGNsInNetwork::~TYPE_TN_LN_AssignGNsInNetwork(){clear_fields(_fields,2);}

TYPE_TN_LN_AssignGNsInNetwork& TYPE_TN_LN_AssignGNsInNetwork::operator=(const TYPE_TN_LN_AssignGNsInNetwork& val){
  val.check_valid();
  if (this!=&val) sequence_assign(val);
  return *this;
}

unsigned int TYPE_TN_LN_AssignGNsInNetwork::hash(unsigned int max_hash)const{
  return sequence_hash(_fields, 2, max_hash);
}

void TYPE_TN_LN_AssignGNsInNetwork::get_fields(
  SDLSeqSetDescription*& d,SDLType **&field_list){
  d=&_fdesc; field_list=_fields;
}

void TYPE_TN_LN_AssignGNsInNetwork::get_fields(
  SDLSeqSetDescription*& d,SDLType *const*&field_list) const{
  d=&_fdesc; field_list=_fields;
}


TYPE_DateTime& TYPE_TN_LN_AssignGNsInNetwork::VAR_gpsTimeStamp() const
{ return *SITE_STATIC_CAST(TYPE_DateTime*,field_access(_fdesc,_fields,0)); }
static SDLSeqSetDescription::Field *_TYPE_TN_LN_AssignGNsInNetworkgpsTimeStamp=TYPE_TN_LN_AssignGNsInNetwork::_fdesc.add(0,"gpsTimeStamp",&TYPE_DateTime::create,true);

TYPE_APManagingProtocol_GEN_3& TYPE_TN_LN_AssignGNsInNetwork::VAR_gatewayNodesInNetwork() const
{ return *SITE_STATIC_CAST(TYPE_APManagingProtocol_GEN_3*,field_access(_fdesc,_fields,1)); }
static SDLSeqSetDescription::Field *_TYPE_TN_LN_AssignGNsInNetworkgatewayNodesInNetwork=TYPE_TN_LN_AssignGNsInNetwork::_fdesc.add(1,"gatewayNodesInNetwork",&TYPE_APManagingProtocol_GEN_3::create,true);



TYPE_TN_LN_AssignGNsInNetwork::TYPE_TN_LN_AssignGNsInNetwork(const class TYPE_DateTime& PAR_0, const class TYPE_APManagingProtocol_GEN_3& PAR_1) {
    set_field(0,PAR_0.copy());
    set_field(1,PAR_1.copy());
}

AsnLen TYPE_TN_LN_AssignGNsInNetwork::bEnc(BUF_TYPE b) const{
    AsnLen elmtLen = bEncContent(b);
    elmtLen += BEncDefLen(b,elmtLen);
    elmtLen += BEncTag1(b,UNIV,CONS,16);
    return elmtLen;
} // TYPE_TN_LN_AssignGNsInNetwork::bEnc

AsnLen TYPE_TN_LN_AssignGNsInNetwork::bEncContent(BUF_TYPE b) const {
    AsnLen elmtLen, structBytesEncoded = BEncExtraFields(b);
    elmtLen = VAR_gatewayNodesInNetwork().bEncContent(b);
    elmtLen += BEncDefLen(b,elmtLen);
    elmtLen += BEncTag1(b,UNIV,CONS,17);
    structBytesEncoded += elmtLen;
    elmtLen = VAR_gpsTimeStamp().bEncContent(b);
    elmtLen += BEncDefLen(b,elmtLen);
    elmtLen += BEncTag1(b,UNIV,CONS,16);
    structBytesEncoded += elmtLen;
    return structBytesEncoded;
} // TYPE_TN_LN_AssignGNsInNetwork::bEncContent

void TYPE_TN_LN_AssignGNsInNetwork::bDec(BUF_TYPE b,AsnLen& bytesDecoded) {
    AsnTag tagId = BDecTag1(b,bytesDecoded);
    AsnLen elmtLen;
    if (tagId != MAKE_TAG_ID(UNIV,CONS,16)) { TagError(MAKE_TAG_ID(UNIV,CONS,16),tagId); return; }
    elmtLen = BDecLen(b,bytesDecoded);
    int pending_eoc = 0;
    if (elmtLen == INDEFINITE_LEN) ++pending_eoc;
    AsnLen localBytesDecoded = 0;
    bDecContent(b,tagId,elmtLen,localBytesDecoded);
    for(;pending_eoc>0;--pending_eoc) { BDecEoc(b,localBytesDecoded); }
    bytesDecoded += localBytesDecoded;
} // TYPE_TN_LN_AssignGNsInNetwork::bDec

void TYPE_TN_LN_AssignGNsInNetwork::bDecContent(BUF_TYPE b,AsnTag,
        AsnLen len, AsnLen& bytesDecoded) {
    bool structDone = false;
    AsnLen elmtLen, localBytesDecoded = 0;
    AsnTag tagId;
    if (len == 0) { tagId = 0; structDone = true; }
    else tagId = BDecTag(b,localBytesDecoded);
    if (!structDone && (tagId==MAKE_TAG_ID(UNIV,CONS,16))) {
        elmtLen = BDecLen(b,localBytesDecoded);
        int pending_eoc = 0;
        if (elmtLen == INDEFINITE_LEN) ++pending_eoc;
        VAR_gpsTimeStamp().bDecContent(b,tagId,elmtLen,localBytesDecoded);
        for(;pending_eoc>0;--pending_eoc) { BDecEoc(b,localBytesDecoded); }
        if ((len!=INDEFINITE_LEN) && (localBytesDecoded>=len)) structDone = true;
        else tagId = BDecTag(b,localBytesDecoded);
    } else { TagError(MAKE_TAG_ID(UNIV,CONS,16),tagId); return; }
    if (!structDone && (tagId==MAKE_TAG_ID(UNIV,CONS,17))) {
        elmtLen = BDecLen(b,localBytesDecoded);
        int pending_eoc = 0;
        if (elmtLen == INDEFINITE_LEN) ++pending_eoc;
        VAR_gatewayNodesInNetwork().bDecContent(b,tagId,elmtLen,localBytesDecoded);
        for(;pending_eoc>0;--pending_eoc) { BDecEoc(b,localBytesDecoded); }
        if ((len!=INDEFINITE_LEN) && (localBytesDecoded>=len)) structDone = true;
        else tagId = BDecTag(b,localBytesDecoded);
    } else { TagError(MAKE_TAG_ID(UNIV,CONS,17),tagId); return; }
    complete_sequence_decoding(b, len, localBytesDecoded, tagId);
    bytesDecoded += localBytesDecoded;
    set_state(validValue);
} // TYPE_TN_LN_AssignGNsInNetwork::bDecContent

AsnLen TYPE_TN_LN_AssignGNsInNetwork::pEnc(BUF_TYPE2 b) const {
    int elmtLen=0;
    elmtLen += VAR_gpsTimeStamp().pEnc(b);
    elmtLen += VAR_gatewayNodesInNetwork().pEnc(b);
    return elmtLen;
}

void TYPE_TN_LN_AssignGNsInNetwork::pDec(BUF_TYPE2 b) {
    VAR_gpsTimeStamp().pDec(b);
    VAR_gatewayNodesInNetwork().pDec(b);
    set_state(validValue);
}

SDLSeqSetDescription TYPE_LN_SN_PrimaryLN::_fdesc(3);

SDLType* TYPE_LN_SN_PrimaryLN::copy()const { return new TYPE_LN_SN_PrimaryLN(*this); }

void TYPE_LN_SN_PrimaryLN::assign(const SDLType* t)
{
  const TYPE_LN_SN_PrimaryLN *arg = SITE_DYNAMIC_CAST(const TYPE_LN_SN_PrimaryLN*,t);
  if (!arg) SDLSequence::assign(t);
  else *this = *arg;
}

SDLType* TYPE_LN_SN_PrimaryLN::create()
{
  static TYPE_LN_SN_PrimaryLN* tmpl = new TYPE_LN_SN_PrimaryLN;
  return tmpl;
}

const SDLType* TYPE_LN_SN_PrimaryLN::create_new() const { return create(); }

TYPE_LN_SN_PrimaryLN::TYPE_LN_SN_PrimaryLN():SDLSequence(_fields,3){}
TYPE_LN_SN_PrimaryLN::TYPE_LN_SN_PrimaryLN(SDLType** f,unsigned long c):SDLSequence(f,c){}
TYPE_LN_SN_PrimaryLN::TYPE_LN_SN_PrimaryLN(const SDLNull&):SDLSequence(_fields,3)
{ set_state(invalidValue); }
TYPE_LN_SN_PrimaryLN::TYPE_LN_SN_PrimaryLN(const SDLAny& a, AsnCodingSet rule_set):SDLSequence(_fields,3){a.decode(this,rule_set);}
TYPE_LN_SN_PrimaryLN::TYPE_LN_SN_PrimaryLN(const TYPE_LN_SN_PrimaryLN&o):SDLSequence(o){
  if (o.state(SITEtemporaryValue)) {
#ifdef SITE_LOG
    if (SDLType::_type_debug & SITE_COPY_LOG)
      CERR << "(SDLRTE) struct reference copy of " << o << ENDL;
#endif
    for(int i=0; i<3;++i) {
       _fields[i] = o._fields[i]; o._fields[i] = 0;
    }
  } else sequence_copyinit(_fields,o._fields,3);
}
TYPE_LN_SN_PrimaryLN::~TYPE_LN_SN_PrimaryLN(){clear_fields(_fields,3);}

TYPE_LN_SN_PrimaryLN& TYPE_LN_SN_PrimaryLN::operator=(const TYPE_LN_SN_PrimaryLN& val){
  val.check_valid();
  if (this!=&val) sequence_assign(val);
  return *this;
}

unsigned int TYPE_LN_SN_PrimaryLN::hash(unsigned int max_hash)const{
  return sequence_hash(_fields, 3, max_hash);
}

void TYPE_LN_SN_PrimaryLN::get_fields(
  SDLSeqSetDescription*& d,SDLType **&field_list){
  d=&_fdesc; field_list=_fields;
}

void TYPE_LN_SN_PrimaryLN::get_fields(
  SDLSeqSetDescription*& d,SDLType *const*&field_list) const{
  d=&_fdesc; field_list=_fields;
}


TYPE_DateTime& TYPE_LN_SN_PrimaryLN::VAR_gpsTimeStamp() const
{ return *SITE_STATIC_CAST(TYPE_DateTime*,field_access(_fdesc,_fields,0)); }
static SDLSeqSetDescription::Field *_TYPE_LN_SN_PrimaryLNgpsTimeStamp=TYPE_LN_SN_PrimaryLN::_fdesc.add(0,"gpsTimeStamp",&TYPE_DateTime::create,true);

TYPE_IPAddress& TYPE_LN_SN_PrimaryLN::VAR_leadingNode() const
{ return *SITE_STATIC_CAST(TYPE_IPAddress*,field_access(_fdesc,_fields,1)); }
static SDLSeqSetDescription::Field *_TYPE_LN_SN_PrimaryLNleadingNode=TYPE_LN_SN_PrimaryLN::_fdesc.add(1,"leadingNode",&TYPE_IPAddress::create,true);

TYPE_GroupID& TYPE_LN_SN_PrimaryLN::VAR_groupID() const
{ return *SITE_STATIC_CAST(TYPE_GroupID*,field_access(_fdesc,_fields,2)); }
static SDLSeqSetDescription::Field *_TYPE_LN_SN_PrimaryLNgroupID=TYPE_LN_SN_PrimaryLN::_fdesc.add(2,"groupID",&TYPE_GroupID::create,true);



TYPE_LN_SN_PrimaryLN::TYPE_LN_SN_PrimaryLN(const class TYPE_DateTime& PAR_0, const class TYPE_IPAddress& PAR_1, const class TYPE_GroupID& PAR_2) {
    set_field(0,PAR_0.copy());
    set_field(1,PAR_1.copy());
    set_field(2,PAR_2.copy());
}

AsnLen TYPE_LN_SN_PrimaryLN::bEnc(BUF_TYPE b) const{
    AsnLen elmtLen = bEncContent(b);
    elmtLen += BEncDefLen(b,elmtLen);
    elmtLen += BEncTag1(b,UNIV,CONS,16);
    return elmtLen;
} // TYPE_LN_SN_PrimaryLN::bEnc

AsnLen TYPE_LN_SN_PrimaryLN::bEncContent(BUF_TYPE b) const {
    AsnLen elmtLen, structBytesEncoded = BEncExtraFields(b);
    elmtLen = VAR_groupID().bEncContent(b);
    elmtLen += BEncDefLen(b,elmtLen);
    elmtLen += BEncTag1(b,UNIV,PRIM,2);
    structBytesEncoded += elmtLen;
    elmtLen = VAR_leadingNode().bEncContent(b);
    elmtLen += BEncDefLen(b,elmtLen);
    elmtLen += BEncTag1(b,UNIV,PRIM,22);
    structBytesEncoded += elmtLen;
    elmtLen = VAR_gpsTimeStamp().bEncContent(b);
    elmtLen += BEncDefLen(b,elmtLen);
    elmtLen += BEncTag1(b,UNIV,CONS,16);
    structBytesEncoded += elmtLen;
    return structBytesEncoded;
} // TYPE_LN_SN_PrimaryLN::bEncContent

void TYPE_LN_SN_PrimaryLN::bDec(BUF_TYPE b,AsnLen& bytesDecoded) {
    AsnTag tagId = BDecTag1(b,bytesDecoded);
    AsnLen elmtLen;
    if (tagId != MAKE_TAG_ID(UNIV,CONS,16)) { TagError(MAKE_TAG_ID(UNIV,CONS,16),tagId); return; }
    elmtLen = BDecLen(b,bytesDecoded);
    int pending_eoc = 0;
    if (elmtLen == INDEFINITE_LEN) ++pending_eoc;
    AsnLen localBytesDecoded = 0;
    bDecContent(b,tagId,elmtLen,localBytesDecoded);
    for(;pending_eoc>0;--pending_eoc) { BDecEoc(b,localBytesDecoded); }
    bytesDecoded += localBytesDecoded;
} // TYPE_LN_SN_PrimaryLN::bDec

void TYPE_LN_SN_PrimaryLN::bDecContent(BUF_TYPE b,AsnTag,
        AsnLen len, AsnLen& bytesDecoded) {
    bool structDone = false;
    AsnLen elmtLen, localBytesDecoded = 0;
    AsnTag tagId;
    if (len == 0) { tagId = 0; structDone = true; }
    else tagId = BDecTag(b,localBytesDecoded);
    if (!structDone && (tagId==MAKE_TAG_ID(UNIV,CONS,16))) {
        elmtLen = BDecLen(b,localBytesDecoded);
        int pending_eoc = 0;
        if (elmtLen == INDEFINITE_LEN) ++pending_eoc;
        VAR_gpsTimeStamp().bDecContent(b,tagId,elmtLen,localBytesDecoded);
        for(;pending_eoc>0;--pending_eoc) { BDecEoc(b,localBytesDecoded); }
        if ((len!=INDEFINITE_LEN) && (localBytesDecoded>=len)) structDone = true;
        else tagId = BDecTag(b,localBytesDecoded);
    } else { TagError(MAKE_TAG_ID(UNIV,CONS,16),tagId); return; }
    if (!structDone && (tagId==MAKE_TAG_ID(UNIV,PRIM,22) ||
                        tagId==MAKE_TAG_ID(UNIV,CONS,22))) {
        elmtLen = BDecLen(b,localBytesDecoded);
        VAR_leadingNode().bDecContent(b,tagId,elmtLen,localBytesDecoded);
        if ((len!=INDEFINITE_LEN) && (localBytesDecoded>=len)) structDone = true;
        else tagId = BDecTag(b,localBytesDecoded);
    } else { TagError(MAKE_TAG_ID(UNIV,PRIM,22),tagId); return; }
    if (!structDone && (tagId==MAKE_TAG_ID(UNIV,PRIM,2))) {
        elmtLen = BDecLen(b,localBytesDecoded);
        VAR_groupID().bDecContent(b,tagId,elmtLen,localBytesDecoded);
        if ((len!=INDEFINITE_LEN) && (localBytesDecoded>=len)) structDone = true;
        else tagId = BDecTag(b,localBytesDecoded);
    } else { TagError(MAKE_TAG_ID(UNIV,PRIM,2),tagId); return; }
    complete_sequence_decoding(b, len, localBytesDecoded, tagId);
    bytesDecoded += localBytesDecoded;
    set_state(validValue);
} // TYPE_LN_SN_PrimaryLN::bDecContent

AsnLen TYPE_LN_SN_PrimaryLN::pEnc(BUF_TYPE2 b) const {
    int elmtLen=0;
    elmtLen += VAR_gpsTimeStamp().pEnc(b);
    elmtLen += VAR_leadingNode().pEnc(b);
    elmtLen += VAR_groupID().pEnc(b);
    return elmtLen;
}

void TYPE_LN_SN_PrimaryLN::pDec(BUF_TYPE2 b) {
    VAR_gpsTimeStamp().pDec(b);
    VAR_leadingNode().pDec(b);
    VAR_groupID().pDec(b);
    set_state(validValue);
}

SDLSeqSetDescription TYPE_LN_SN_SecondaryLN::_fdesc(3);

SDLType* TYPE_LN_SN_SecondaryLN::copy()const { return new TYPE_LN_SN_SecondaryLN(*this); }

void TYPE_LN_SN_SecondaryLN::assign(const SDLType* t)
{
  const TYPE_LN_SN_SecondaryLN *arg = SITE_DYNAMIC_CAST(const TYPE_LN_SN_SecondaryLN*,t);
  if (!arg) SDLSequence::assign(t);
  else *this = *arg;
}

SDLType* TYPE_LN_SN_SecondaryLN::create()
{
  static TYPE_LN_SN_SecondaryLN* tmpl = new TYPE_LN_SN_SecondaryLN;
  return tmpl;
}

const SDLType* TYPE_LN_SN_SecondaryLN::create_new() const { return create(); }

TYPE_LN_SN_SecondaryLN::TYPE_LN_SN_SecondaryLN():SDLSequence(_fields,3){}
TYPE_LN_SN_SecondaryLN::TYPE_LN_SN_SecondaryLN(SDLType** f,unsigned long c):SDLSequence(f,c){}
TYPE_LN_SN_SecondaryLN::TYPE_LN_SN_SecondaryLN(const SDLNull&):SDLSequence(_fields,3)
{ set_state(invalidValue); }
TYPE_LN_SN_SecondaryLN::TYPE_LN_SN_SecondaryLN(const SDLAny& a, AsnCodingSet rule_set):SDLSequence(_fields,3){a.decode(this,rule_set);}
TYPE_LN_SN_SecondaryLN::TYPE_LN_SN_SecondaryLN(const TYPE_LN_SN_SecondaryLN&o):SDLSequence(o){
  if (o.state(SITEtemporaryValue)) {
#ifdef SITE_LOG
    if (SDLType::_type_debug & SITE_COPY_LOG)
      CERR << "(SDLRTE) struct reference copy of " << o << ENDL;
#endif
    for(int i=0; i<3;++i) {
       _fields[i] = o._fields[i]; o._fields[i] = 0;
    }
  } else sequence_copyinit(_fields,o._fields,3);
}
TYPE_LN_SN_SecondaryLN::~TYPE_LN_SN_SecondaryLN(){clear_fields(_fields,3);}

TYPE_LN_SN_SecondaryLN& TYPE_LN_SN_SecondaryLN::operator=(const TYPE_LN_SN_SecondaryLN& val){
  val.check_valid();
  if (this!=&val) sequence_assign(val);
  return *this;
}

unsigned int TYPE_LN_SN_SecondaryLN::hash(unsigned int max_hash)const{
  return sequence_hash(_fields, 3, max_hash);
}

void TYPE_LN_SN_SecondaryLN::get_fields(
  SDLSeqSetDescription*& d,SDLType **&field_list){
  d=&_fdesc; field_list=_fields;
}

void TYPE_LN_SN_SecondaryLN::get_fields(
  SDLSeqSetDescription*& d,SDLType *const*&field_list) const{
  d=&_fdesc; field_list=_fields;
}


TYPE_DateTime& TYPE_LN_SN_SecondaryLN::VAR_gpsTimeStamp() const
{ return *SITE_STATIC_CAST(TYPE_DateTime*,field_access(_fdesc,_fields,0)); }
static SDLSeqSetDescription::Field *_TYPE_LN_SN_SecondaryLNgpsTimeStamp=TYPE_LN_SN_SecondaryLN::_fdesc.add(0,"gpsTimeStamp",&TYPE_DateTime::create,true);

TYPE_IPAddress& TYPE_LN_SN_SecondaryLN::VAR_leadingNode() const
{ return *SITE_STATIC_CAST(TYPE_IPAddress*,field_access(_fdesc,_fields,1)); }
static SDLSeqSetDescription::Field *_TYPE_LN_SN_SecondaryLNleadingNode=TYPE_LN_SN_SecondaryLN::_fdesc.add(1,"leadingNode",&TYPE_IPAddress::create,true);

TYPE_GroupID& TYPE_LN_SN_SecondaryLN::VAR_groupID() const
{ return *SITE_STATIC_CAST(TYPE_GroupID*,field_access(_fdesc,_fields,2)); }
static SDLSeqSetDescription::Field *_TYPE_LN_SN_SecondaryLNgroupID=TYPE_LN_SN_SecondaryLN::_fdesc.add(2,"groupID",&TYPE_GroupID::create,true);



TYPE_LN_SN_SecondaryLN::TYPE_LN_SN_SecondaryLN(const class TYPE_DateTime& PAR_0, const class TYPE_IPAddress& PAR_1, const class TYPE_GroupID& PAR_2) {
    set_field(0,PAR_0.copy());
    set_field(1,PAR_1.copy());
    set_field(2,PAR_2.copy());
}

AsnLen TYPE_LN_SN_SecondaryLN::bEnc(BUF_TYPE b) const{
    AsnLen elmtLen = bEncContent(b);
    elmtLen += BEncDefLen(b,elmtLen);
    elmtLen += BEncTag1(b,UNIV,CONS,16);
    return elmtLen;
} // TYPE_LN_SN_SecondaryLN::bEnc

AsnLen TYPE_LN_SN_SecondaryLN::bEncContent(BUF_TYPE b) const {
    AsnLen elmtLen, structBytesEncoded = BEncExtraFields(b);
    elmtLen = VAR_groupID().bEncContent(b);
    elmtLen += BEncDefLen(b,elmtLen);
    elmtLen += BEncTag1(b,UNIV,PRIM,2);
    structBytesEncoded += elmtLen;
    elmtLen = VAR_leadingNode().bEncContent(b);
    elmtLen += BEncDefLen(b,elmtLen);
    elmtLen += BEncTag1(b,UNIV,PRIM,22);
    structBytesEncoded += elmtLen;
    elmtLen = VAR_gpsTimeStamp().bEncContent(b);
    elmtLen += BEncDefLen(b,elmtLen);
    elmtLen += BEncTag1(b,UNIV,CONS,16);
    structBytesEncoded += elmtLen;
    return structBytesEncoded;
} // TYPE_LN_SN_SecondaryLN::bEncContent

void TYPE_LN_SN_SecondaryLN::bDec(BUF_TYPE b,AsnLen& bytesDecoded) {
    AsnTag tagId = BDecTag1(b,bytesDecoded);
    AsnLen elmtLen;
    if (tagId != MAKE_TAG_ID(UNIV,CONS,16)) { TagError(MAKE_TAG_ID(UNIV,CONS,16),tagId); return; }
    elmtLen = BDecLen(b,bytesDecoded);
    int pending_eoc = 0;
    if (elmtLen == INDEFINITE_LEN) ++pending_eoc;
    AsnLen localBytesDecoded = 0;
    bDecContent(b,tagId,elmtLen,localBytesDecoded);
    for(;pending_eoc>0;--pending_eoc) { BDecEoc(b,localBytesDecoded); }
    bytesDecoded += localBytesDecoded;
} // TYPE_LN_SN_SecondaryLN::bDec

void TYPE_LN_SN_SecondaryLN::bDecContent(BUF_TYPE b,AsnTag,
        AsnLen len, AsnLen& bytesDecoded) {
    bool structDone = false;
    AsnLen elmtLen, localBytesDecoded = 0;
    AsnTag tagId;
    if (len == 0) { tagId = 0; structDone = true; }
    else tagId = BDecTag(b,localBytesDecoded);
    if (!structDone && (tagId==MAKE_TAG_ID(UNIV,CONS,16))) {
        elmtLen = BDecLen(b,localBytesDecoded);
        int pending_eoc = 0;
        if (elmtLen == INDEFINITE_LEN) ++pending_eoc;
        VAR_gpsTimeStamp().bDecContent(b,tagId,elmtLen,localBytesDecoded);
        for(;pending_eoc>0;--pending_eoc) { BDecEoc(b,localBytesDecoded); }
        if ((len!=INDEFINITE_LEN) && (localBytesDecoded>=len)) structDone = true;
        else tagId = BDecTag(b,localBytesDecoded);
    } else { TagError(MAKE_TAG_ID(UNIV,CONS,16),tagId); return; }
    if (!structDone && (tagId==MAKE_TAG_ID(UNIV,PRIM,22) ||
                        tagId==MAKE_TAG_ID(UNIV,CONS,22))) {
        elmtLen = BDecLen(b,localBytesDecoded);
        VAR_leadingNode().bDecContent(b,tagId,elmtLen,localBytesDecoded);
        if ((len!=INDEFINITE_LEN) && (localBytesDecoded>=len)) structDone = true;
        else tagId = BDecTag(b,localBytesDecoded);
    } else { TagError(MAKE_TAG_ID(UNIV,PRIM,22),tagId); return; }
    if (!structDone && (tagId==MAKE_TAG_ID(UNIV,PRIM,2))) {
        elmtLen = BDecLen(b,localBytesDecoded);
        VAR_groupID().bDecContent(b,tagId,elmtLen,localBytesDecoded);
        if ((len!=INDEFINITE_LEN) && (localBytesDecoded>=len)) structDone = true;
        else tagId = BDecTag(b,localBytesDecoded);
    } else { TagError(MAKE_TAG_ID(UNIV,PRIM,2),tagId); return; }
    complete_sequence_decoding(b, len, localBytesDecoded, tagId);
    bytesDecoded += localBytesDecoded;
    set_state(validValue);
} // TYPE_LN_SN_SecondaryLN::bDecContent

AsnLen TYPE_LN_SN_SecondaryLN::pEnc(BUF_TYPE2 b) const {
    int elmtLen=0;
    elmtLen += VAR_gpsTimeStamp().pEnc(b);
    elmtLen += VAR_leadingNode().pEnc(b);
    elmtLen += VAR_groupID().pEnc(b);
    return elmtLen;
}

void TYPE_LN_SN_SecondaryLN::pDec(BUF_TYPE2 b) {
    VAR_gpsTimeStamp().pDec(b);
    VAR_leadingNode().pDec(b);
    VAR_groupID().pDec(b);
    set_state(validValue);
}

SDLSeqSetDescription TYPE_TN_SN_UseMSDP::_fdesc(4);

SDLType* TYPE_TN_SN_UseMSDP::copy()const { return new TYPE_TN_SN_UseMSDP(*this); }

void TYPE_TN_SN_UseMSDP::assign(const SDLType* t)
{
  const TYPE_TN_SN_UseMSDP *arg = SITE_DYNAMIC_CAST(const TYPE_TN_SN_UseMSDP*,t);
  if (!arg) SDLSequence::assign(t);
  else *this = *arg;
}

SDLType* TYPE_TN_SN_UseMSDP::create()
{
  static TYPE_TN_SN_UseMSDP* tmpl = new TYPE_TN_SN_UseMSDP;
  return tmpl;
}

const SDLType* TYPE_TN_SN_UseMSDP::create_new() const { return create(); }

TYPE_TN_SN_UseMSDP::TYPE_TN_SN_UseMSDP():SDLSequence(_fields,4){}
TYPE_TN_SN_UseMSDP::TYPE_TN_SN_UseMSDP(SDLType** f,unsigned long c):SDLSequence(f,c){}
TYPE_TN_SN_UseMSDP::TYPE_TN_SN_UseMSDP(const SDLNull&):SDLSequence(_fields,4)
{ set_state(invalidValue); }
TYPE_TN_SN_UseMSDP::TYPE_TN_SN_UseMSDP(const SDLAny& a, AsnCodingSet rule_set):SDLSequence(_fields,4){a.decode(this,rule_set);}
TYPE_TN_SN_UseMSDP::TYPE_TN_SN_UseMSDP(const TYPE_TN_SN_UseMSDP&o):SDLSequence(o){
  if (o.state(SITEtemporaryValue)) {
#ifdef SITE_LOG
    if (SDLType::_type_debug & SITE_COPY_LOG)
      CERR << "(SDLRTE) struct reference copy of " << o << ENDL;
#endif
    for(int i=0; i<4;++i) {
       _fields[i] = o._fields[i]; o._fields[i] = 0;
    }
  } else sequence_copyinit(_fields,o._fields,4);
}
TYPE_TN_SN_UseMSDP::~TYPE_TN_SN_UseMSDP(){clear_fields(_fields,4);}

TYPE_TN_SN_UseMSDP& TYPE_TN_SN_UseMSDP::operator=(const TYPE_TN_SN_UseMSDP& val){
  val.check_valid();
  if (this!=&val) sequence_assign(val);
  return *this;
}

unsigned int TYPE_TN_SN_UseMSDP::hash(unsigned int max_hash)const{
  return sequence_hash(_fields, 4, max_hash);
}

void TYPE_TN_SN_UseMSDP::get_fields(
  SDLSeqSetDescription*& d,SDLType **&field_list){
  d=&_fdesc; field_list=_fields;
}

void TYPE_TN_SN_UseMSDP::get_fields(
  SDLSeqSetDescription*& d,SDLType *const*&field_list) const{
  d=&_fdesc; field_list=_fields;
}


TYPE_DateTime& TYPE_TN_SN_UseMSDP::VAR_gpsTimeStamp() const
{ return *SITE_STATIC_CAST(TYPE_DateTime*,field_access(_fdesc,_fields,0)); }
static SDLSeqSetDescription::Field *_TYPE_TN_SN_UseMSDPgpsTimeStamp=TYPE_TN_SN_UseMSDP::_fdesc.add(0,"gpsTimeStamp",&TYPE_DateTime::create,true);

TYPE_DateTime& TYPE_TN_SN_UseMSDP::VAR_simulationRunStartTime() const
{ return *SITE_STATIC_CAST(TYPE_DateTime*,field_access(_fdesc,_fields,1)); }
static SDLSeqSetDescription::Field *_TYPE_TN_SN_UseMSDPsimulationRunStartTime=TYPE_TN_SN_UseMSDP::_fdesc.add(1,"simulationRunStartTime",&TYPE_DateTime::create,true);

TYPE_DateTime& TYPE_TN_SN_UseMSDP::VAR_modelTimeStartTime() const
{ return *SITE_STATIC_CAST(TYPE_DateTime*,field_access(_fdesc,_fields,2)); }
static SDLSeqSetDescription::Field *_TYPE_TN_SN_UseMSDPmodelTimeStartTime=TYPE_TN_SN_UseMSDP::_fdesc.add(2,"modelTimeStartTime",&TYPE_DateTime::create,true);

TYPE_APManagingProtocol_GEN_4& TYPE_TN_SN_UseMSDP::VAR_sensorDataFile() const
{ return *SITE_STATIC_CAST(TYPE_APManagingProtocol_GEN_4*,field_access(_fdesc,_fields,3)); }
static SDLSeqSetDescription::Field *_TYPE_TN_SN_UseMSDPsensorDataFile=TYPE_TN_SN_UseMSDP::_fdesc.add(3,"sensorDataFile",&TYPE_APManagingProtocol_GEN_4::create,true);



TYPE_TN_SN_UseMSDP::TYPE_TN_SN_UseMSDP(const class TYPE_DateTime& PAR_0, const class TYPE_DateTime& PAR_1, const class TYPE_DateTime& PAR_2, const class TYPE_APManagingProtocol_GEN_4& PAR_3) {
    set_field(0,PAR_0.copy());
    set_field(1,PAR_1.copy());
    set_field(2,PAR_2.copy());
    set_field(3,PAR_3.copy());
}

AsnLen TYPE_TN_SN_UseMSDP::bEnc(BUF_TYPE b) const{
    AsnLen elmtLen = bEncContent(b);
    elmtLen += BEncDefLen(b,elmtLen);
    elmtLen += BEncTag1(b,UNIV,CONS,16);
    return elmtLen;
} // TYPE_TN_SN_UseMSDP::bEnc

AsnLen TYPE_TN_SN_UseMSDP::bEncContent(BUF_TYPE b) const {
    AsnLen elmtLen, structBytesEncoded = BEncExtraFields(b);
    elmtLen = VAR_sensorDataFile().bEncContent(b);
    elmtLen += BEncDefLen(b,elmtLen);
    elmtLen += BEncTag1(b,UNIV,PRIM,22);
    structBytesEncoded += elmtLen;
    elmtLen = VAR_modelTimeStartTime().bEncContent(b);
    elmtLen += BEncDefLen(b,elmtLen);
    elmtLen += BEncTag1(b,UNIV,CONS,16);
    structBytesEncoded += elmtLen;
    elmtLen = VAR_simulationRunStartTime().bEncContent(b);
    elmtLen += BEncDefLen(b,elmtLen);
    elmtLen += BEncTag1(b,UNIV,CONS,16);
    structBytesEncoded += elmtLen;
    elmtLen = VAR_gpsTimeStamp().bEncContent(b);
    elmtLen += BEncDefLen(b,elmtLen);
    elmtLen += BEncTag1(b,UNIV,CONS,16);
    structBytesEncoded += elmtLen;
    return structBytesEncoded;
} // TYPE_TN_SN_UseMSDP::bEncContent

void TYPE_TN_SN_UseMSDP::bDec(BUF_TYPE b,AsnLen& bytesDecoded) {
    AsnTag tagId = BDecTag1(b,bytesDecoded);
    AsnLen elmtLen;
    if (tagId != MAKE_TAG_ID(UNIV,CONS,16)) { TagError(MAKE_TAG_ID(UNIV,CONS,16),tagId); return; }
    elmtLen = BDecLen(b,bytesDecoded);
    int pending_eoc = 0;
    if (elmtLen == INDEFINITE_LEN) ++pending_eoc;
    AsnLen localBytesDecoded = 0;
    bDecContent(b,tagId,elmtLen,localBytesDecoded);
    for(;pending_eoc>0;--pending_eoc) { BDecEoc(b,localBytesDecoded); }
    bytesDecoded += localBytesDecoded;
} // TYPE_TN_SN_UseMSDP::bDec

void TYPE_TN_SN_UseMSDP::bDecContent(BUF_TYPE b,AsnTag,
        AsnLen len, AsnLen& bytesDecoded) {
    bool structDone = false;
    AsnLen elmtLen, localBytesDecoded = 0;
    AsnTag tagId;
    if (len == 0) { tagId = 0; structDone = true; }
    else tagId = BDecTag(b,localBytesDecoded);
    if (!structDone && (tagId==MAKE_TAG_ID(UNIV,CONS,16))) {
        elmtLen = BDecLen(b,localBytesDecoded);
        int pending_eoc = 0;
        if (elmtLen == INDEFINITE_LEN) ++pending_eoc;
        VAR_gpsTimeStamp().bDecContent(b,tagId,elmtLen,localBytesDecoded);
        for(;pending_eoc>0;--pending_eoc) { BDecEoc(b,localBytesDecoded); }
        if ((len!=INDEFINITE_LEN) && (localBytesDecoded>=len)) structDone = true;
        else tagId = BDecTag(b,localBytesDecoded);
    } else { TagError(MAKE_TAG_ID(UNIV,CONS,16),tagId); return; }
    if (!structDone && (tagId==MAKE_TAG_ID(UNIV,CONS,16))) {
        elmtLen = BDecLen(b,localBytesDecoded);
        int pending_eoc = 0;
        if (elmtLen == INDEFINITE_LEN) ++pending_eoc;
        VAR_simulationRunStartTime().bDecContent(b,tagId,elmtLen,localBytesDecoded);
        for(;pending_eoc>0;--pending_eoc) { BDecEoc(b,localBytesDecoded); }
        if ((len!=INDEFINITE_LEN) && (localBytesDecoded>=len)) structDone = true;
        else tagId = BDecTag(b,localBytesDecoded);
    } else { TagError(MAKE_TAG_ID(UNIV,CONS,16),tagId); return; }
    if (!structDone && (tagId==MAKE_TAG_ID(UNIV,CONS,16))) {
        elmtLen = BDecLen(b,localBytesDecoded);
        int pending_eoc = 0;
        if (elmtLen == INDEFINITE_LEN) ++pending_eoc;
        VAR_modelTimeStartTime().bDecContent(b,tagId,elmtLen,localBytesDecoded);
        for(;pending_eoc>0;--pending_eoc) { BDecEoc(b,localBytesDecoded); }
        if ((len!=INDEFINITE_LEN) && (localBytesDecoded>=len)) structDone = true;
        else tagId = BDecTag(b,localBytesDecoded);
    } else { TagError(MAKE_TAG_ID(UNIV,CONS,16),tagId); return; }
    if (!structDone && (tagId==MAKE_TAG_ID(UNIV,PRIM,22) ||
                        tagId==MAKE_TAG_ID(UNIV,CONS,22))) {
        elmtLen = BDecLen(b,localBytesDecoded);
        VAR_sensorDataFile().bDecContent(b,tagId,elmtLen,localBytesDecoded);
        if ((len!=INDEFINITE_LEN) && (localBytesDecoded>=len)) structDone = true;
        else tagId = BDecTag(b,localBytesDecoded);
    } else { TagError(MAKE_TAG_ID(UNIV,PRIM,22),tagId); return; }
    complete_sequence_decoding(b, len, localBytesDecoded, tagId);
    bytesDecoded += localBytesDecoded;
    set_state(validValue);
} // TYPE_TN_SN_UseMSDP::bDecContent

AsnLen TYPE_TN_SN_UseMSDP::pEnc(BUF_TYPE2 b) const {
    int elmtLen=0;
    elmtLen += VAR_gpsTimeStamp().pEnc(b);
    elmtLen += VAR_simulationRunStartTime().pEnc(b);
    elmtLen += VAR_modelTimeStartTime().pEnc(b);
    elmtLen += VAR_sensorDataFile().pEnc(b);
    return elmtLen;
}

void TYPE_TN_SN_UseMSDP::pDec(BUF_TYPE2 b) {
    VAR_gpsTimeStamp().pDec(b);
    VAR_simulationRunStartTime().pDec(b);
    VAR_modelTimeStartTime().pDec(b);
    VAR_sensorDataFile().pDec(b);
    set_state(validValue);
}

SDLSeqSetDescription TYPE_TN_SN_AskGroupId::_fdesc(1);

SDLType* TYPE_TN_SN_AskGroupId::copy()const { return new TYPE_TN_SN_AskGroupId(*this); }

void TYPE_TN_SN_AskGroupId::assign(const SDLType* t)
{
  const TYPE_TN_SN_AskGroupId *arg = SITE_DYNAMIC_CAST(const TYPE_TN_SN_AskGroupId*,t);
  if (!arg) SDLSequence::assign(t);
  else *this = *arg;
}

SDLType* TYPE_TN_SN_AskGroupId::create()
{
  static TYPE_TN_SN_AskGroupId* tmpl = new TYPE_TN_SN_AskGroupId;
  return tmpl;
}

const SDLType* TYPE_TN_SN_AskGroupId::create_new() const { return create(); }

TYPE_TN_SN_AskGroupId::TYPE_TN_SN_AskGroupId():SDLSequence(_fields,1){}
TYPE_TN_SN_AskGroupId::TYPE_TN_SN_AskGroupId(SDLType** f,unsigned long c):SDLSequence(f,c){}
TYPE_TN_SN_AskGroupId::TYPE_TN_SN_AskGroupId(const SDLNull&):SDLSequence(_fields,1)
{ set_state(invalidValue); }
TYPE_TN_SN_AskGroupId::TYPE_TN_SN_AskGroupId(const SDLAny& a, AsnCodingSet rule_set):SDLSequence(_fields,1){a.decode(this,rule_set);}
TYPE_TN_SN_AskGroupId::TYPE_TN_SN_AskGroupId(const TYPE_TN_SN_AskGroupId&o):SDLSequence(o){
  if (o.state(SITEtemporaryValue)) {
#ifdef SITE_LOG
    if (SDLType::_type_debug & SITE_COPY_LOG)
      CERR << "(SDLRTE) struct reference copy of " << o << ENDL;
#endif
    for(int i=0; i<1;++i) {
       _fields[i] = o._fields[i]; o._fields[i] = 0;
    }
  } else sequence_copyinit(_fields,o._fields,1);
}
TYPE_TN_SN_AskGroupId::~TYPE_TN_SN_AskGroupId(){clear_fields(_fields,1);}

TYPE_TN_SN_AskGroupId& TYPE_TN_SN_AskGroupId::operator=(const TYPE_TN_SN_AskGroupId& val){
  val.check_valid();
  if (this!=&val) sequence_assign(val);
  return *this;
}

unsigned int TYPE_TN_SN_AskGroupId::hash(unsigned int max_hash)const{
  return sequence_hash(_fields, 1, max_hash);
}

void TYPE_TN_SN_AskGroupId::get_fields(
  SDLSeqSetDescription*& d,SDLType **&field_list){
  d=&_fdesc; field_list=_fields;
}

void TYPE_TN_SN_AskGroupId::get_fields(
  SDLSeqSetDescription*& d,SDLType *const*&field_list) const{
  d=&_fdesc; field_list=_fields;
}


TYPE_DateTime& TYPE_TN_SN_AskGroupId::VAR_gpsTimeStamp() const
{ return *SITE_STATIC_CAST(TYPE_DateTime*,field_access(_fdesc,_fields,0)); }
static SDLSeqSetDescription::Field *_TYPE_TN_SN_AskGroupIdgpsTimeStamp=TYPE_TN_SN_AskGroupId::_fdesc.add(0,"gpsTimeStamp",&TYPE_DateTime::create,true);



TYPE_TN_SN_AskGroupId::TYPE_TN_SN_AskGroupId(const class TYPE_DateTime& PAR_0) {
    set_field(0,PAR_0.copy());
}

AsnLen TYPE_TN_SN_AskGroupId::bEnc(BUF_TYPE b) const{
    AsnLen elmtLen = bEncContent(b);
    elmtLen += BEncDefLen(b,elmtLen);
    elmtLen += BEncTag1(b,UNIV,CONS,16);
    return elmtLen;
} // TYPE_TN_SN_AskGroupId::bEnc

AsnLen TYPE_TN_SN_AskGroupId::bEncContent(BUF_TYPE b) const {
    AsnLen elmtLen, structBytesEncoded = BEncExtraFields(b);
    elmtLen = VAR_gpsTimeStamp().bEncContent(b);
    elmtLen += BEncDefLen(b,elmtLen);
    elmtLen += BEncTag1(b,UNIV,CONS,16);
    structBytesEncoded += elmtLen;
    return structBytesEncoded;
} // TYPE_TN_SN_AskGroupId::bEncContent

void TYPE_TN_SN_AskGroupId::bDec(BUF_TYPE b,AsnLen& bytesDecoded) {
    AsnTag tagId = BDecTag1(b,bytesDecoded);
    AsnLen elmtLen;
    if (tagId != MAKE_TAG_ID(UNIV,CONS,16)) { TagError(MAKE_TAG_ID(UNIV,CONS,16),tagId); return; }
    elmtLen = BDecLen(b,bytesDecoded);
    int pending_eoc = 0;
    if (elmtLen == INDEFINITE_LEN) ++pending_eoc;
    AsnLen localBytesDecoded = 0;
    bDecContent(b,tagId,elmtLen,localBytesDecoded);
    for(;pending_eoc>0;--pending_eoc) { BDecEoc(b,localBytesDecoded); }
    bytesDecoded += localBytesDecoded;
} // TYPE_TN_SN_AskGroupId::bDec

void TYPE_TN_SN_AskGroupId::bDecContent(BUF_TYPE b,AsnTag,
        AsnLen len, AsnLen& bytesDecoded) {
    bool structDone = false;
    AsnLen elmtLen, localBytesDecoded = 0;
    AsnTag tagId;
    if (len == 0) { tagId = 0; structDone = true; }
    else tagId = BDecTag(b,localBytesDecoded);
    if (!structDone && (tagId==MAKE_TAG_ID(UNIV,CONS,16))) {
        elmtLen = BDecLen(b,localBytesDecoded);
        int pending_eoc = 0;
        if (elmtLen == INDEFINITE_LEN) ++pending_eoc;
        VAR_gpsTimeStamp().bDecContent(b,tagId,elmtLen,localBytesDecoded);
        for(;pending_eoc>0;--pending_eoc) { BDecEoc(b,localBytesDecoded); }
        if ((len!=INDEFINITE_LEN) && (localBytesDecoded>=len)) structDone = true;
        else tagId = BDecTag(b,localBytesDecoded);
    } else { TagError(MAKE_TAG_ID(UNIV,CONS,16),tagId); return; }
    complete_sequence_decoding(b, len, localBytesDecoded, tagId);
    bytesDecoded += localBytesDecoded;
    set_state(validValue);
} // TYPE_TN_SN_AskGroupId::bDecContent

AsnLen TYPE_TN_SN_AskGroupId::pEnc(BUF_TYPE2 b) const {
    int elmtLen=0;
    elmtLen += VAR_gpsTimeStamp().pEnc(b);
    return elmtLen;
}

void TYPE_TN_SN_AskGroupId::pDec(BUF_TYPE2 b) {
    VAR_gpsTimeStamp().pDec(b);
    set_state(validValue);
}

SDLSeqSetDescription TYPE_SN_TN_HaveGroupId::_fdesc(3);

SDLType* TYPE_SN_TN_HaveGroupId::copy()const { return new TYPE_SN_TN_HaveGroupId(*this); }

void TYPE_SN_TN_HaveGroupId::assign(const SDLType* t)
{
  const TYPE_SN_TN_HaveGroupId *arg = SITE_DYNAMIC_CAST(const TYPE_SN_TN_HaveGroupId*,t);
  if (!arg) SDLSequence::assign(t);
  else *this = *arg;
}

SDLType* TYPE_SN_TN_HaveGroupId::create()
{
  static TYPE_SN_TN_HaveGroupId* tmpl = new TYPE_SN_TN_HaveGroupId;
  return tmpl;
}

const SDLType* TYPE_SN_TN_HaveGroupId::create_new() const { return create(); }

TYPE_SN_TN_HaveGroupId::TYPE_SN_TN_HaveGroupId():SDLSequence(_fields,3){}
TYPE_SN_TN_HaveGroupId::TYPE_SN_TN_HaveGroupId(SDLType** f,unsigned long c):SDLSequence(f,c){}
TYPE_SN_TN_HaveGroupId::TYPE_SN_TN_HaveGroupId(const SDLNull&):SDLSequence(_fields,3)
{ set_state(invalidValue); }
TYPE_SN_TN_HaveGroupId::TYPE_SN_TN_HaveGroupId(const SDLAny& a, AsnCodingSet rule_set):SDLSequence(_fields,3){a.decode(this,rule_set);}
TYPE_SN_TN_HaveGroupId::TYPE_SN_TN_HaveGroupId(const TYPE_SN_TN_HaveGroupId&o):SDLSequence(o){
  if (o.state(SITEtemporaryValue)) {
#ifdef SITE_LOG
    if (SDLType::_type_debug & SITE_COPY_LOG)
      CERR << "(SDLRTE) struct reference copy of " << o << ENDL;
#endif
    for(int i=0; i<3;++i) {
       _fields[i] = o._fields[i]; o._fields[i] = 0;
    }
  } else sequence_copyinit(_fields,o._fields,3);
}
TYPE_SN_TN_HaveGroupId::~TYPE_SN_TN_HaveGroupId(){clear_fields(_fields,3);}

TYPE_SN_TN_HaveGroupId& TYPE_SN_TN_HaveGroupId::operator=(const TYPE_SN_TN_HaveGroupId& val){
  val.check_valid();
  if (this!=&val) sequence_assign(val);
  return *this;
}

unsigned int TYPE_SN_TN_HaveGroupId::hash(unsigned int max_hash)const{
  return sequence_hash(_fields, 3, max_hash);
}

void TYPE_SN_TN_HaveGroupId::get_fields(
  SDLSeqSetDescription*& d,SDLType **&field_list){
  d=&_fdesc; field_list=_fields;
}

void TYPE_SN_TN_HaveGroupId::get_fields(
  SDLSeqSetDescription*& d,SDLType *const*&field_list) const{
  d=&_fdesc; field_list=_fields;
}


TYPE_DateTime& TYPE_SN_TN_HaveGroupId::VAR_gpsTimeStamp() const
{ return *SITE_STATIC_CAST(TYPE_DateTime*,field_access(_fdesc,_fields,0)); }
static SDLSeqSetDescription::Field *_TYPE_SN_TN_HaveGroupIdgpsTimeStamp=TYPE_SN_TN_HaveGroupId::_fdesc.add(0,"gpsTimeStamp",&TYPE_DateTime::create,true);

TYPE_IPAddress& TYPE_SN_TN_HaveGroupId::VAR_leadingNode() const
{ return *SITE_STATIC_CAST(TYPE_IPAddress*,field_access(_fdesc,_fields,1)); }
static SDLSeqSetDescription::Field *_TYPE_SN_TN_HaveGroupIdleadingNode=TYPE_SN_TN_HaveGroupId::_fdesc.add(1,"leadingNode",&TYPE_IPAddress::create,true);

TYPE_GroupID& TYPE_SN_TN_HaveGroupId::VAR_groupID() const
{ return *SITE_STATIC_CAST(TYPE_GroupID*,field_access(_fdesc,_fields,2)); }
static SDLSeqSetDescription::Field *_TYPE_SN_TN_HaveGroupIdgroupID=TYPE_SN_TN_HaveGroupId::_fdesc.add(2,"groupID",&TYPE_GroupID::create,true);



TYPE_SN_TN_HaveGroupId::TYPE_SN_TN_HaveGroupId(const class TYPE_DateTime& PAR_0, const class TYPE_IPAddress& PAR_1, const class TYPE_GroupID& PAR_2) {
    set_field(0,PAR_0.copy());
    set_field(1,PAR_1.copy());
    set_field(2,PAR_2.copy());
}

AsnLen TYPE_SN_TN_HaveGroupId::bEnc(BUF_TYPE b) const{
    AsnLen elmtLen = bEncContent(b);
    elmtLen += BEncDefLen(b,elmtLen);
    elmtLen += BEncTag1(b,UNIV,CONS,16);
    return elmtLen;
} // TYPE_SN_TN_HaveGroupId::bEnc

AsnLen TYPE_SN_TN_HaveGroupId::bEncContent(BUF_TYPE b) const {
    AsnLen elmtLen, structBytesEncoded = BEncExtraFields(b);
    elmtLen = VAR_groupID().bEncContent(b);
    elmtLen += BEncDefLen(b,elmtLen);
    elmtLen += BEncTag1(b,UNIV,PRIM,2);
    structBytesEncoded += elmtLen;
    elmtLen = VAR_leadingNode().bEncContent(b);
    elmtLen += BEncDefLen(b,elmtLen);
    elmtLen += BEncTag1(b,UNIV,PRIM,22);
    structBytesEncoded += elmtLen;
    elmtLen = VAR_gpsTimeStamp().bEncContent(b);
    elmtLen += BEncDefLen(b,elmtLen);
    elmtLen += BEncTag1(b,UNIV,CONS,16);
    structBytesEncoded += elmtLen;
    return structBytesEncoded;
} // TYPE_SN_TN_HaveGroupId::bEncContent

void TYPE_SN_TN_HaveGroupId::bDec(BUF_TYPE b,AsnLen& bytesDecoded) {
    AsnTag tagId = BDecTag1(b,bytesDecoded);
    AsnLen elmtLen;
    if (tagId != MAKE_TAG_ID(UNIV,CONS,16)) { TagError(MAKE_TAG_ID(UNIV,CONS,16),tagId); return; }
    elmtLen = BDecLen(b,bytesDecoded);
    int pending_eoc = 0;
    if (elmtLen == INDEFINITE_LEN) ++pending_eoc;
    AsnLen localBytesDecoded = 0;
    bDecContent(b,tagId,elmtLen,localBytesDecoded);
    for(;pending_eoc>0;--pending_eoc) { BDecEoc(b,localBytesDecoded); }
    bytesDecoded += localBytesDecoded;
} // TYPE_SN_TN_HaveGroupId::bDec

void TYPE_SN_TN_HaveGroupId::bDecContent(BUF_TYPE b,AsnTag,
        AsnLen len, AsnLen& bytesDecoded) {
    bool structDone = false;
    AsnLen elmtLen, localBytesDecoded = 0;
    AsnTag tagId;
    if (len == 0) { tagId = 0; structDone = true; }
    else tagId = BDecTag(b,localBytesDecoded);
    if (!structDone && (tagId==MAKE_TAG_ID(UNIV,CONS,16))) {
        elmtLen = BDecLen(b,localBytesDecoded);
        int pending_eoc = 0;
        if (elmtLen == INDEFINITE_LEN) ++pending_eoc;
        VAR_gpsTimeStamp().bDecContent(b,tagId,elmtLen,localBytesDecoded);
        for(;pending_eoc>0;--pending_eoc) { BDecEoc(b,localBytesDecoded); }
        if ((len!=INDEFINITE_LEN) && (localBytesDecoded>=len)) structDone = true;
        else tagId = BDecTag(b,localBytesDecoded);
    } else { TagError(MAKE_TAG_ID(UNIV,CONS,16),tagId); return; }
    if (!structDone && (tagId==MAKE_TAG_ID(UNIV,PRIM,22) ||
                        tagId==MAKE_TAG_ID(UNIV,CONS,22))) {
        elmtLen = BDecLen(b,localBytesDecoded);
        VAR_leadingNode().bDecContent(b,tagId,elmtLen,localBytesDecoded);
        if ((len!=INDEFINITE_LEN) && (localBytesDecoded>=len)) structDone = true;
        else tagId = BDecTag(b,localBytesDecoded);
    } else { TagError(MAKE_TAG_ID(UNIV,PRIM,22),tagId); return; }
    if (!structDone && (tagId==MAKE_TAG_ID(UNIV,PRIM,2))) {
        elmtLen = BDecLen(b,localBytesDecoded);
        VAR_groupID().bDecContent(b,tagId,elmtLen,localBytesDecoded);
        if ((len!=INDEFINITE_LEN) && (localBytesDecoded>=len)) structDone = true;
        else tagId = BDecTag(b,localBytesDecoded);
    } else { TagError(MAKE_TAG_ID(UNIV,PRIM,2),tagId); return; }
    complete_sequence_decoding(b, len, localBytesDecoded, tagId);
    bytesDecoded += localBytesDecoded;
    set_state(validValue);
} // TYPE_SN_TN_HaveGroupId::bDecContent

AsnLen TYPE_SN_TN_HaveGroupId::pEnc(BUF_TYPE2 b) const {
    int elmtLen=0;
    elmtLen += VAR_gpsTimeStamp().pEnc(b);
    elmtLen += VAR_leadingNode().pEnc(b);
    elmtLen += VAR_groupID().pEnc(b);
    return elmtLen;
}

void TYPE_SN_TN_HaveGroupId::pDec(BUF_TYPE2 b) {
    VAR_gpsTimeStamp().pDec(b);
    VAR_leadingNode().pDec(b);
    VAR_groupID().pDec(b);
    set_state(validValue);
}

SDLSeqSetDescription TYPE_KeyValuePair::_fdesc(3);

SDLType* TYPE_KeyValuePair::copy()const { return new TYPE_KeyValuePair(*this); }

void TYPE_KeyValuePair::assign(const SDLType* t)
{
  const TYPE_KeyValuePair *arg = SITE_DYNAMIC_CAST(const TYPE_KeyValuePair*,t);
  if (!arg) SDLSequence::assign(t);
  else *this = *arg;
}

SDLType* TYPE_KeyValuePair::create()
{
  static TYPE_KeyValuePair* tmpl = new TYPE_KeyValuePair;
  return tmpl;
}

const SDLType* TYPE_KeyValuePair::create_new() const { return create(); }

TYPE_KeyValuePair::TYPE_KeyValuePair():SDLSequence(_fields,3){}
TYPE_KeyValuePair::TYPE_KeyValuePair(SDLType** f,unsigned long c):SDLSequence(f,c){}
TYPE_KeyValuePair::TYPE_KeyValuePair(const SDLNull&):SDLSequence(_fields,3)
{ set_state(invalidValue); }
TYPE_KeyValuePair::TYPE_KeyValuePair(const SDLAny& a, AsnCodingSet rule_set):SDLSequence(_fields,3){a.decode(this,rule_set);}
TYPE_KeyValuePair::TYPE_KeyValuePair(const TYPE_KeyValuePair&o):SDLSequence(o){
  if (o.state(SITEtemporaryValue)) {
#ifdef SITE_LOG
    if (SDLType::_type_debug & SITE_COPY_LOG)
      CERR << "(SDLRTE) struct reference copy of " << o << ENDL;
#endif
    for(int i=0; i<3;++i) {
       _fields[i] = o._fields[i]; o._fields[i] = 0;
    }
  } else sequence_copyinit(_fields,o._fields,3);
}
TYPE_KeyValuePair::~TYPE_KeyValuePair(){clear_fields(_fields,3);}

TYPE_KeyValuePair& TYPE_KeyValuePair::operator=(const TYPE_KeyValuePair& val){
  val.check_valid();
  if (this!=&val) sequence_assign(val);
  return *this;
}

unsigned int TYPE_KeyValuePair::hash(unsigned int max_hash)const{
  return sequence_hash(_fields, 3, max_hash);
}

void TYPE_KeyValuePair::get_fields(
  SDLSeqSetDescription*& d,SDLType **&field_list){
  d=&_fdesc; field_list=_fields;
}

void TYPE_KeyValuePair::get_fields(
  SDLSeqSetDescription*& d,SDLType *const*&field_list) const{
  d=&_fdesc; field_list=_fields;
}


SDLIA5String& TYPE_KeyValuePair::VAR_key() const
{ return *SITE_STATIC_CAST(SDLIA5String*,field_access(_fdesc,_fields,0)); }
static SDLSeqSetDescription::Field *_TYPE_KeyValuePairkey=TYPE_KeyValuePair::_fdesc.add(0,"key",&SDLIA5String::create,true);

SDLIA5String& TYPE_KeyValuePair::VAR_value() const
{ return *SITE_STATIC_CAST(SDLIA5String*,field_access(_fdesc,_fields,1)); }
static SDLSeqSetDescription::Field *_TYPE_KeyValuePairvalue=TYPE_KeyValuePair::_fdesc.add(1,"value",&SDLIA5String::create,true);

TYPE_DateTime& TYPE_KeyValuePair::VAR_notValidBefore() const
{ return *SITE_STATIC_CAST(TYPE_DateTime*,field_access(_fdesc,_fields,2)); }

const SDLBool& TYPE_KeyValuePair::notValidBeforePresent()const{
  return field_present(_fdesc,_fields,2);
}

TYPE_KeyValuePair TYPE_KeyValuePair::notValidBeforeOmit()const{
  TYPE_KeyValuePair c(*this);
  field_omit(_fdesc,c._fields,2);
  return c;
}

void TYPE_KeyValuePair::_notValidBeforeOmit() {
  field_omit(_fdesc,_fields,2);
}

static SDLSeqSetDescription::Field *_TYPE_KeyValuePairnotValidBefore=TYPE_KeyValuePair::_fdesc.add_optional(2,"notValidBefore",&TYPE_DateTime::create,true);



TYPE_KeyValuePair::TYPE_KeyValuePair(const class SDLIA5String& PAR_0, const class SDLIA5String& PAR_1, const class TYPE_DateTime& PAR_2) {
    set_field(0,PAR_0.copy());
    set_field(1,PAR_1.copy());
    if(PAR_2.valid())
        set_field(2,new TYPE_DateTime(PAR_2));
    else
        set_field(2,0);
}

AsnLen TYPE_KeyValuePair::bEnc(BUF_TYPE b) const{
    AsnLen elmtLen = bEncContent(b);
    elmtLen += BEncDefLen(b,elmtLen);
    elmtLen += BEncTag1(b,UNIV,CONS,16);
    return elmtLen;
} // TYPE_KeyValuePair::bEnc

AsnLen TYPE_KeyValuePair::bEncContent(BUF_TYPE b) const {
    AsnLen elmtLen, structBytesEncoded = BEncExtraFields(b);
    if (notValidBeforePresent().val()) {
        elmtLen = VAR_notValidBefore().bEncContent(b);
        elmtLen += BEncDefLen(b,elmtLen);
        elmtLen += BEncTag1(b,UNIV,CONS,16);
        elmtLen += BEncDefLen(b,elmtLen);
        elmtLen += BEncTag1(b,CNTX,CONS,1);
        structBytesEncoded += elmtLen;
    }
    elmtLen = VAR_value().bEncContent(b);
    elmtLen += BEncDefLen(b,elmtLen);
    elmtLen += BEncTag1(b,UNIV,PRIM,22);
    structBytesEncoded += elmtLen;
    elmtLen = VAR_key().bEncContent(b);
    elmtLen += BEncDefLen(b,elmtLen);
    elmtLen += BEncTag1(b,UNIV,PRIM,22);
    structBytesEncoded += elmtLen;
    return structBytesEncoded;
} // TYPE_KeyValuePair::bEncContent

void TYPE_KeyValuePair::bDec(BUF_TYPE b,AsnLen& bytesDecoded) {
    AsnTag tagId = BDecTag1(b,bytesDecoded);
    AsnLen elmtLen;
    if (tagId != MAKE_TAG_ID(UNIV,CONS,16)) { TagError(MAKE_TAG_ID(UNIV,CONS,16),tagId); return; }
    elmtLen = BDecLen(b,bytesDecoded);
    int pending_eoc = 0;
    if (elmtLen == INDEFINITE_LEN) ++pending_eoc;
    AsnLen localBytesDecoded = 0;
    bDecContent(b,tagId,elmtLen,localBytesDecoded);
    for(;pending_eoc>0;--pending_eoc) { BDecEoc(b,localBytesDecoded); }
    bytesDecoded += localBytesDecoded;
} // TYPE_KeyValuePair::bDec

void TYPE_KeyValuePair::bDecContent(BUF_TYPE b,AsnTag,
        AsnLen len, AsnLen& bytesDecoded) {
    bool structDone = false;
    AsnLen elmtLen, localBytesDecoded = 0;
    AsnTag tagId;
    if (len == 0) { tagId = 0; structDone = true; }
    else tagId = BDecTag(b,localBytesDecoded);
    if (!structDone && (tagId==MAKE_TAG_ID(UNIV,PRIM,22) ||
                        tagId==MAKE_TAG_ID(UNIV,CONS,22))) {
        elmtLen = BDecLen(b,localBytesDecoded);
        VAR_key().bDecContent(b,tagId,elmtLen,localBytesDecoded);
        if ((len!=INDEFINITE_LEN) && (localBytesDecoded>=len)) structDone = true;
        else tagId = BDecTag(b,localBytesDecoded);
    } else { TagError(MAKE_TAG_ID(UNIV,PRIM,22),tagId); return; }
    if (!structDone && (tagId==MAKE_TAG_ID(UNIV,PRIM,22) ||
                        tagId==MAKE_TAG_ID(UNIV,CONS,22))) {
        elmtLen = BDecLen(b,localBytesDecoded);
        VAR_value().bDecContent(b,tagId,elmtLen,localBytesDecoded);
        if ((len!=INDEFINITE_LEN) && (localBytesDecoded>=len)) structDone = true;
        else tagId = BDecTag(b,localBytesDecoded);
    } else { TagError(MAKE_TAG_ID(UNIV,PRIM,22),tagId); return; }
    if (!structDone && (tagId==MAKE_TAG_ID(CNTX,CONS,1))) {
        elmtLen = BDecLen(b,localBytesDecoded);
        int pending_eoc = 0;
        if (elmtLen == INDEFINITE_LEN) ++pending_eoc;
        tagId = BDecTag1(b,localBytesDecoded);
        if (tagId == MAKE_TAG_ID(UNIV,CONS,16)) {
          elmtLen = BDecLen(b,localBytesDecoded);
        } else { TagError(MAKE_TAG_ID(UNIV,CONS,16),tagId); return; }
        VAR_notValidBefore().bDecContent(b,tagId,elmtLen,localBytesDecoded);
        for(;pending_eoc>0;--pending_eoc) { BDecEoc(b,localBytesDecoded); }
        if (len!=INDEFINITE_LEN && localBytesDecoded>=len) structDone = true;
        else tagId = BDecTag(b,localBytesDecoded);
    }
    complete_sequence_decoding(b, len, localBytesDecoded, tagId);
    bytesDecoded += localBytesDecoded;
    set_state(validValue);
} // TYPE_KeyValuePair::bDecContent

AsnLen TYPE_KeyValuePair::pEnc(BUF_TYPE2 b) const {
    int elmtLen=0;
    b.putBit(notValidBeforePresent().val()?true:false);
    elmtLen++;
    elmtLen += VAR_key().pEnc(b);
    elmtLen += VAR_value().pEnc(b);
    if (notValidBeforePresent().val())
        elmtLen += VAR_notValidBefore().pEnc(b);
    return elmtLen;
}

void TYPE_KeyValuePair::pDec(BUF_TYPE2 b) {
    bool _field_present0 = b.getBit();
    VAR_key().pDec(b);
    VAR_value().pDec(b);
    if(_field_present0) VAR_notValidBefore().pDec(b);
    set_state(validValue);
}

SDLSeqSetDescription TYPE_TN_SN_ConfigureSetKeyValue::_fdesc(2);

SDLType* TYPE_TN_SN_ConfigureSetKeyValue::copy()const { return new TYPE_TN_SN_ConfigureSetKeyValue(*this); }

void TYPE_TN_SN_ConfigureSetKeyValue::assign(const SDLType* t)
{
  const TYPE_TN_SN_ConfigureSetKeyValue *arg = SITE_DYNAMIC_CAST(const TYPE_TN_SN_ConfigureSetKeyValue*,t);
  if (!arg) SDLSequence::assign(t);
  else *this = *arg;
}

SDLType* TYPE_TN_SN_ConfigureSetKeyValue::create()
{
  static TYPE_TN_SN_ConfigureSetKeyValue* tmpl = new TYPE_TN_SN_ConfigureSetKeyValue;
  return tmpl;
}

const SDLType* TYPE_TN_SN_ConfigureSetKeyValue::create_new() const { return create(); }

TYPE_TN_SN_ConfigureSetKeyValue::TYPE_TN_SN_ConfigureSetKeyValue():SDLSequence(_fields,2){}
TYPE_TN_SN_ConfigureSetKeyValue::TYPE_TN_SN_ConfigureSetKeyValue(SDLType** f,unsigned long c):SDLSequence(f,c){}
TYPE_TN_SN_ConfigureSetKeyValue::TYPE_TN_SN_ConfigureSetKeyValue(const SDLNull&):SDLSequence(_fields,2)
{ set_state(invalidValue); }
TYPE_TN_SN_ConfigureSetKeyValue::TYPE_TN_SN_ConfigureSetKeyValue(const SDLAny& a, AsnCodingSet rule_set):SDLSequence(_fields,2){a.decode(this,rule_set);}
TYPE_TN_SN_ConfigureSetKeyValue::TYPE_TN_SN_ConfigureSetKeyValue(const TYPE_TN_SN_ConfigureSetKeyValue&o):SDLSequence(o){
  if (o.state(SITEtemporaryValue)) {
#ifdef SITE_LOG
    if (SDLType::_type_debug & SITE_COPY_LOG)
      CERR << "(SDLRTE) struct reference copy of " << o << ENDL;
#endif
    for(int i=0; i<2;++i) {
       _fields[i] = o._fields[i]; o._fields[i] = 0;
    }
  } else sequence_copyinit(_fields,o._fields,2);
}
TYPE_TN_SN_ConfigureSetKeyValue::~TYPE_TN_SN_ConfigureSetKeyValue(){clear_fields(_fields,2);}

TYPE_TN_SN_ConfigureSetKeyValue& TYPE_TN_SN_ConfigureSetKeyValue::operator=(const TYPE_TN_SN_ConfigureSetKeyValue& val){
  val.check_valid();
  if (this!=&val) sequence_assign(val);
  return *this;
}

unsigned int TYPE_TN_SN_ConfigureSetKeyValue::hash(unsigned int max_hash)const{
  return sequence_hash(_fields, 2, max_hash);
}

void TYPE_TN_SN_ConfigureSetKeyValue::get_fields(
  SDLSeqSetDescription*& d,SDLType **&field_list){
  d=&_fdesc; field_list=_fields;
}

void TYPE_TN_SN_ConfigureSetKeyValue::get_fields(
  SDLSeqSetDescription*& d,SDLType *const*&field_list) const{
  d=&_fdesc; field_list=_fields;
}


TYPE_DateTime& TYPE_TN_SN_ConfigureSetKeyValue::VAR_gpsTimeStamp() const
{ return *SITE_STATIC_CAST(TYPE_DateTime*,field_access(_fdesc,_fields,0)); }
static SDLSeqSetDescription::Field *_TYPE_TN_SN_ConfigureSetKeyValuegpsTimeStamp=TYPE_TN_SN_ConfigureSetKeyValue::_fdesc.add(0,"gpsTimeStamp",&TYPE_DateTime::create,true);

TYPE_APManagingProtocol_GEN_5& TYPE_TN_SN_ConfigureSetKeyValue::VAR_keyValuesSet() const
{ return *SITE_STATIC_CAST(TYPE_APManagingProtocol_GEN_5*,field_access(_fdesc,_fields,1)); }
static SDLSeqSetDescription::Field *_TYPE_TN_SN_ConfigureSetKeyValuekeyValuesSet=TYPE_TN_SN_ConfigureSetKeyValue::_fdesc.add(1,"keyValuesSet",&TYPE_APManagingProtocol_GEN_5::create,true);



TYPE_TN_SN_ConfigureSetKeyValue::TYPE_TN_SN_ConfigureSetKeyValue(const class TYPE_DateTime& PAR_0, const class TYPE_APManagingProtocol_GEN_5& PAR_1) {
    set_field(0,PAR_0.copy());
    set_field(1,PAR_1.copy());
}

AsnLen TYPE_TN_SN_ConfigureSetKeyValue::bEnc(BUF_TYPE b) const{
    AsnLen elmtLen = bEncContent(b);
    elmtLen += BEncDefLen(b,elmtLen);
    elmtLen += BEncTag1(b,UNIV,CONS,16);
    return elmtLen;
} // TYPE_TN_SN_ConfigureSetKeyValue::bEnc

AsnLen TYPE_TN_SN_ConfigureSetKeyValue::bEncContent(BUF_TYPE b) const {
    AsnLen elmtLen, structBytesEncoded = BEncExtraFields(b);
    elmtLen = VAR_keyValuesSet().bEncContent(b);
    elmtLen += BEncDefLen(b,elmtLen);
    elmtLen += BEncTag1(b,UNIV,CONS,17);
    structBytesEncoded += elmtLen;
    elmtLen = VAR_gpsTimeStamp().bEncContent(b);
    elmtLen += BEncDefLen(b,elmtLen);
    elmtLen += BEncTag1(b,UNIV,CONS,16);
    structBytesEncoded += elmtLen;
    return structBytesEncoded;
} // TYPE_TN_SN_ConfigureSetKeyValue::bEncContent

void TYPE_TN_SN_ConfigureSetKeyValue::bDec(BUF_TYPE b,AsnLen& bytesDecoded) {
    AsnTag tagId = BDecTag1(b,bytesDecoded);
    AsnLen elmtLen;
    if (tagId != MAKE_TAG_ID(UNIV,CONS,16)) { TagError(MAKE_TAG_ID(UNIV,CONS,16),tagId); return; }
    elmtLen = BDecLen(b,bytesDecoded);
    int pending_eoc = 0;
    if (elmtLen == INDEFINITE_LEN) ++pending_eoc;
    AsnLen localBytesDecoded = 0;
    bDecContent(b,tagId,elmtLen,localBytesDecoded);
    for(;pending_eoc>0;--pending_eoc) { BDecEoc(b,localBytesDecoded); }
    bytesDecoded += localBytesDecoded;
} // TYPE_TN_SN_ConfigureSetKeyValue::bDec

void TYPE_TN_SN_ConfigureSetKeyValue::bDecContent(BUF_TYPE b,AsnTag,
        AsnLen len, AsnLen& bytesDecoded) {
    bool structDone = false;
    AsnLen elmtLen, localBytesDecoded = 0;
    AsnTag tagId;
    if (len == 0) { tagId = 0; structDone = true; }
    else tagId = BDecTag(b,localBytesDecoded);
    if (!structDone && (tagId==MAKE_TAG_ID(UNIV,CONS,16))) {
        elmtLen = BDecLen(b,localBytesDecoded);
        int pending_eoc = 0;
        if (elmtLen == INDEFINITE_LEN) ++pending_eoc;
        VAR_gpsTimeStamp().bDecContent(b,tagId,elmtLen,localBytesDecoded);
        for(;pending_eoc>0;--pending_eoc) { BDecEoc(b,localBytesDecoded); }
        if ((len!=INDEFINITE_LEN) && (localBytesDecoded>=len)) structDone = true;
        else tagId = BDecTag(b,localBytesDecoded);
    } else { TagError(MAKE_TAG_ID(UNIV,CONS,16),tagId); return; }
    if (!structDone && (tagId==MAKE_TAG_ID(UNIV,CONS,17))) {
        elmtLen = BDecLen(b,localBytesDecoded);
        int pending_eoc = 0;
        if (elmtLen == INDEFINITE_LEN) ++pending_eoc;
        VAR_keyValuesSet().bDecContent(b,tagId,elmtLen,localBytesDecoded);
        for(;pending_eoc>0;--pending_eoc) { BDecEoc(b,localBytesDecoded); }
        if ((len!=INDEFINITE_LEN) && (localBytesDecoded>=len)) structDone = true;
        else tagId = BDecTag(b,localBytesDecoded);
    } else { TagError(MAKE_TAG_ID(UNIV,CONS,17),tagId); return; }
    complete_sequence_decoding(b, len, localBytesDecoded, tagId);
    bytesDecoded += localBytesDecoded;
    set_state(validValue);
} // TYPE_TN_SN_ConfigureSetKeyValue::bDecContent

AsnLen TYPE_TN_SN_ConfigureSetKeyValue::pEnc(BUF_TYPE2 b) const {
    int elmtLen=0;
    elmtLen += VAR_gpsTimeStamp().pEnc(b);
    elmtLen += VAR_keyValuesSet().pEnc(b);
    return elmtLen;
}

void TYPE_TN_SN_ConfigureSetKeyValue::pDec(BUF_TYPE2 b) {
    VAR_gpsTimeStamp().pDec(b);
    VAR_keyValuesSet().pDec(b);
    set_state(validValue);
}

SDLSeqSetDescription TYPE_TN_SN_CloseMessageLogfile::_fdesc(2);

SDLType* TYPE_TN_SN_CloseMessageLogfile::copy()const { return new TYPE_TN_SN_CloseMessageLogfile(*this); }

void TYPE_TN_SN_CloseMessageLogfile::assign(const SDLType* t)
{
  const TYPE_TN_SN_CloseMessageLogfile *arg = SITE_DYNAMIC_CAST(const TYPE_TN_SN_CloseMessageLogfile*,t);
  if (!arg) SDLSequence::assign(t);
  else *this = *arg;
}

SDLType* TYPE_TN_SN_CloseMessageLogfile::create()
{
  static TYPE_TN_SN_CloseMessageLogfile* tmpl = new TYPE_TN_SN_CloseMessageLogfile;
  return tmpl;
}

const SDLType* TYPE_TN_SN_CloseMessageLogfile::create_new() const { return create(); }

TYPE_TN_SN_CloseMessageLogfile::TYPE_TN_SN_CloseMessageLogfile():SDLSequence(_fields,2){}
TYPE_TN_SN_CloseMessageLogfile::TYPE_TN_SN_CloseMessageLogfile(SDLType** f,unsigned long c):SDLSequence(f,c){}
TYPE_TN_SN_CloseMessageLogfile::TYPE_TN_SN_CloseMessageLogfile(const SDLNull&):SDLSequence(_fields,2)
{ set_state(invalidValue); }
TYPE_TN_SN_CloseMessageLogfile::TYPE_TN_SN_CloseMessageLogfile(const SDLAny& a, AsnCodingSet rule_set):SDLSequence(_fields,2){a.decode(this,rule_set);}
TYPE_TN_SN_CloseMessageLogfile::TYPE_TN_SN_CloseMessageLogfile(const TYPE_TN_SN_CloseMessageLogfile&o):SDLSequence(o){
  if (o.state(SITEtemporaryValue)) {
#ifdef SITE_LOG
    if (SDLType::_type_debug & SITE_COPY_LOG)
      CERR << "(SDLRTE) struct reference copy of " << o << ENDL;
#endif
    for(int i=0; i<2;++i) {
       _fields[i] = o._fields[i]; o._fields[i] = 0;
    }
  } else sequence_copyinit(_fields,o._fields,2);
}
TYPE_TN_SN_CloseMessageLogfile::~TYPE_TN_SN_CloseMessageLogfile(){clear_fields(_fields,2);}

TYPE_TN_SN_CloseMessageLogfile& TYPE_TN_SN_CloseMessageLogfile::operator=(const TYPE_TN_SN_CloseMessageLogfile& val){
  val.check_valid();
  if (this!=&val) sequence_assign(val);
  return *this;
}

unsigned int TYPE_TN_SN_CloseMessageLogfile::hash(unsigned int max_hash)const{
  return sequence_hash(_fields, 2, max_hash);
}

void TYPE_TN_SN_CloseMessageLogfile::get_fields(
  SDLSeqSetDescription*& d,SDLType **&field_list){
  d=&_fdesc; field_list=_fields;
}

void TYPE_TN_SN_CloseMessageLogfile::get_fields(
  SDLSeqSetDescription*& d,SDLType *const*&field_list) const{
  d=&_fdesc; field_list=_fields;
}


TYPE_DateTime& TYPE_TN_SN_CloseMessageLogfile::VAR_gpsTimeStamp() const
{ return *SITE_STATIC_CAST(TYPE_DateTime*,field_access(_fdesc,_fields,0)); }
static SDLSeqSetDescription::Field *_TYPE_TN_SN_CloseMessageLogfilegpsTimeStamp=TYPE_TN_SN_CloseMessageLogfile::_fdesc.add(0,"gpsTimeStamp",&TYPE_DateTime::create,true);

TYPE_DateTime& TYPE_TN_SN_CloseMessageLogfile::VAR_executeTime() const
{ return *SITE_STATIC_CAST(TYPE_DateTime*,field_access(_fdesc,_fields,1)); }

const SDLBool& TYPE_TN_SN_CloseMessageLogfile::executeTimePresent()const{
  return field_present(_fdesc,_fields,1);
}

TYPE_TN_SN_CloseMessageLogfile TYPE_TN_SN_CloseMessageLogfile::executeTimeOmit()const{
  TYPE_TN_SN_CloseMessageLogfile c(*this);
  field_omit(_fdesc,c._fields,1);
  return c;
}

void TYPE_TN_SN_CloseMessageLogfile::_executeTimeOmit() {
  field_omit(_fdesc,_fields,1);
}

static SDLSeqSetDescription::Field *_TYPE_TN_SN_CloseMessageLogfileexecuteTime=TYPE_TN_SN_CloseMessageLogfile::_fdesc.add_optional(1,"executeTime",&TYPE_DateTime::create,true);



TYPE_TN_SN_CloseMessageLogfile::TYPE_TN_SN_CloseMessageLogfile(const class TYPE_DateTime& PAR_0, const class TYPE_DateTime& PAR_1) {
    set_field(0,PAR_0.copy());
    if(PAR_1.valid())
        set_field(1,new TYPE_DateTime(PAR_1));
    else
        set_field(1,0);
}

AsnLen TYPE_TN_SN_CloseMessageLogfile::bEnc(BUF_TYPE b) const{
    AsnLen elmtLen = bEncContent(b);
    elmtLen += BEncDefLen(b,elmtLen);
    elmtLen += BEncTag1(b,UNIV,CONS,16);
    return elmtLen;
} // TYPE_TN_SN_CloseMessageLogfile::bEnc

AsnLen TYPE_TN_SN_CloseMessageLogfile::bEncContent(BUF_TYPE b) const {
    AsnLen elmtLen, structBytesEncoded = BEncExtraFields(b);
    if (executeTimePresent().val()) {
        elmtLen = VAR_executeTime().bEncContent(b);
        elmtLen += BEncDefLen(b,elmtLen);
        elmtLen += BEncTag1(b,UNIV,CONS,16);
        elmtLen += BEncDefLen(b,elmtLen);
        elmtLen += BEncTag1(b,CNTX,CONS,1);
        structBytesEncoded += elmtLen;
    }
    elmtLen = VAR_gpsTimeStamp().bEncContent(b);
    elmtLen += BEncDefLen(b,elmtLen);
    elmtLen += BEncTag1(b,UNIV,CONS,16);
    structBytesEncoded += elmtLen;
    return structBytesEncoded;
} // TYPE_TN_SN_CloseMessageLogfile::bEncContent

void TYPE_TN_SN_CloseMessageLogfile::bDec(BUF_TYPE b,AsnLen& bytesDecoded) {
    AsnTag tagId = BDecTag1(b,bytesDecoded);
    AsnLen elmtLen;
    if (tagId != MAKE_TAG_ID(UNIV,CONS,16)) { TagError(MAKE_TAG_ID(UNIV,CONS,16),tagId); return; }
    elmtLen = BDecLen(b,bytesDecoded);
    int pending_eoc = 0;
    if (elmtLen == INDEFINITE_LEN) ++pending_eoc;
    AsnLen localBytesDecoded = 0;
    bDecContent(b,tagId,elmtLen,localBytesDecoded);
    for(;pending_eoc>0;--pending_eoc) { BDecEoc(b,localBytesDecoded); }
    bytesDecoded += localBytesDecoded;
} // TYPE_TN_SN_CloseMessageLogfile::bDec

void TYPE_TN_SN_CloseMessageLogfile::bDecContent(BUF_TYPE b,AsnTag,
        AsnLen len, AsnLen& bytesDecoded) {
    bool structDone = false;
    AsnLen elmtLen, localBytesDecoded = 0;
    AsnTag tagId;
    if (len == 0) { tagId = 0; structDone = true; }
    else tagId = BDecTag(b,localBytesDecoded);
    if (!structDone && (tagId==MAKE_TAG_ID(UNIV,CONS,16))) {
        elmtLen = BDecLen(b,localBytesDecoded);
        int pending_eoc = 0;
        if (elmtLen == INDEFINITE_LEN) ++pending_eoc;
        VAR_gpsTimeStamp().bDecContent(b,tagId,elmtLen,localBytesDecoded);
        for(;pending_eoc>0;--pending_eoc) { BDecEoc(b,localBytesDecoded); }
        if ((len!=INDEFINITE_LEN) && (localBytesDecoded>=len)) structDone = true;
        else tagId = BDecTag(b,localBytesDecoded);
    } else { TagError(MAKE_TAG_ID(UNIV,CONS,16),tagId); return; }
    if (!structDone && (tagId==MAKE_TAG_ID(CNTX,CONS,1))) {
        elmtLen = BDecLen(b,localBytesDecoded);
        int pending_eoc = 0;
        if (elmtLen == INDEFINITE_LEN) ++pending_eoc;
        tagId = BDecTag1(b,localBytesDecoded);
        if (tagId == MAKE_TAG_ID(UNIV,CONS,16)) {
          elmtLen = BDecLen(b,localBytesDecoded);
        } else { TagError(MAKE_TAG_ID(UNIV,CONS,16),tagId); return; }
        VAR_executeTime().bDecContent(b,tagId,elmtLen,localBytesDecoded);
        for(;pending_eoc>0;--pending_eoc) { BDecEoc(b,localBytesDecoded); }
        if (len!=INDEFINITE_LEN && localBytesDecoded>=len) structDone = true;
        else tagId = BDecTag(b,localBytesDecoded);
    }
    complete_sequence_decoding(b, len, localBytesDecoded, tagId);
    bytesDecoded += localBytesDecoded;
    set_state(validValue);
} // TYPE_TN_SN_CloseMessageLogfile::bDecContent

AsnLen TYPE_TN_SN_CloseMessageLogfile::pEnc(BUF_TYPE2 b) const {
    int elmtLen=0;
    b.putBit(executeTimePresent().val()?true:false);
    elmtLen++;
    elmtLen += VAR_gpsTimeStamp().pEnc(b);
    if (executeTimePresent().val())
        elmtLen += VAR_executeTime().pEnc(b);
    return elmtLen;
}

void TYPE_TN_SN_CloseMessageLogfile::pDec(BUF_TYPE2 b) {
    bool _field_present0 = b.getBit();
    VAR_gpsTimeStamp().pDec(b);
    if(_field_present0) VAR_executeTime().pDec(b);
    set_state(validValue);
}

SDLSeqSetDescription TYPE_TN_SN_StartMessageLogging::_fdesc(2);

SDLType* TYPE_TN_SN_StartMessageLogging::copy()const { return new TYPE_TN_SN_StartMessageLogging(*this); }

void TYPE_TN_SN_StartMessageLogging::assign(const SDLType* t)
{
  const TYPE_TN_SN_StartMessageLogging *arg = SITE_DYNAMIC_CAST(const TYPE_TN_SN_StartMessageLogging*,t);
  if (!arg) SDLSequence::assign(t);
  else *this = *arg;
}

SDLType* TYPE_TN_SN_StartMessageLogging::create()
{
  static TYPE_TN_SN_StartMessageLogging* tmpl = new TYPE_TN_SN_StartMessageLogging;
  return tmpl;
}

const SDLType* TYPE_TN_SN_StartMessageLogging::create_new() const { return create(); }

TYPE_TN_SN_StartMessageLogging::TYPE_TN_SN_StartMessageLogging():SDLSequence(_fields,2){}
TYPE_TN_SN_StartMessageLogging::TYPE_TN_SN_StartMessageLogging(SDLType** f,unsigned long c):SDLSequence(f,c){}
TYPE_TN_SN_StartMessageLogging::TYPE_TN_SN_StartMessageLogging(const SDLNull&):SDLSequence(_fields,2)
{ set_state(invalidValue); }
TYPE_TN_SN_StartMessageLogging::TYPE_TN_SN_StartMessageLogging(const SDLAny& a, AsnCodingSet rule_set):SDLSequence(_fields,2){a.decode(this,rule_set);}
TYPE_TN_SN_StartMessageLogging::TYPE_TN_SN_StartMessageLogging(const TYPE_TN_SN_StartMessageLogging&o):SDLSequence(o){
  if (o.state(SITEtemporaryValue)) {
#ifdef SITE_LOG
    if (SDLType::_type_debug & SITE_COPY_LOG)
      CERR << "(SDLRTE) struct reference copy of " << o << ENDL;
#endif
    for(int i=0; i<2;++i) {
       _fields[i] = o._fields[i]; o._fields[i] = 0;
    }
  } else sequence_copyinit(_fields,o._fields,2);
}
TYPE_TN_SN_StartMessageLogging::~TYPE_TN_SN_StartMessageLogging(){clear_fields(_fields,2);}

TYPE_TN_SN_StartMessageLogging& TYPE_TN_SN_StartMessageLogging::operator=(const TYPE_TN_SN_StartMessageLogging& val){
  val.check_valid();
  if (this!=&val) sequence_assign(val);
  return *this;
}

unsigned int TYPE_TN_SN_StartMessageLogging::hash(unsigned int max_hash)const{
  return sequence_hash(_fields, 2, max_hash);
}

void TYPE_TN_SN_StartMessageLogging::get_fields(
  SDLSeqSetDescription*& d,SDLType **&field_list){
  d=&_fdesc; field_list=_fields;
}

void TYPE_TN_SN_StartMessageLogging::get_fields(
  SDLSeqSetDescription*& d,SDLType *const*&field_list) const{
  d=&_fdesc; field_list=_fields;
}


TYPE_DateTime& TYPE_TN_SN_StartMessageLogging::VAR_gpsTimeStamp() const
{ return *SITE_STATIC_CAST(TYPE_DateTime*,field_access(_fdesc,_fields,0)); }
static SDLSeqSetDescription::Field *_TYPE_TN_SN_StartMessageLogginggpsTimeStamp=TYPE_TN_SN_StartMessageLogging::_fdesc.add(0,"gpsTimeStamp",&TYPE_DateTime::create,true);

TYPE_DateTime& TYPE_TN_SN_StartMessageLogging::VAR_executeTime() const
{ return *SITE_STATIC_CAST(TYPE_DateTime*,field_access(_fdesc,_fields,1)); }

const SDLBool& TYPE_TN_SN_StartMessageLogging::executeTimePresent()const{
  return field_present(_fdesc,_fields,1);
}

TYPE_TN_SN_StartMessageLogging TYPE_TN_SN_StartMessageLogging::executeTimeOmit()const{
  TYPE_TN_SN_StartMessageLogging c(*this);
  field_omit(_fdesc,c._fields,1);
  return c;
}

void TYPE_TN_SN_StartMessageLogging::_executeTimeOmit() {
  field_omit(_fdesc,_fields,1);
}

static SDLSeqSetDescription::Field *_TYPE_TN_SN_StartMessageLoggingexecuteTime=TYPE_TN_SN_StartMessageLogging::_fdesc.add_optional(1,"executeTime",&TYPE_DateTime::create,true);



TYPE_TN_SN_StartMessageLogging::TYPE_TN_SN_StartMessageLogging(const class TYPE_DateTime& PAR_0, const class TYPE_DateTime& PAR_1) {
    set_field(0,PAR_0.copy());
    if(PAR_1.valid())
        set_field(1,new TYPE_DateTime(PAR_1));
    else
        set_field(1,0);
}

AsnLen TYPE_TN_SN_StartMessageLogging::bEnc(BUF_TYPE b) const{
    AsnLen elmtLen = bEncContent(b);
    elmtLen += BEncDefLen(b,elmtLen);
    elmtLen += BEncTag1(b,UNIV,CONS,16);
    return elmtLen;
} // TYPE_TN_SN_StartMessageLogging::bEnc

AsnLen TYPE_TN_SN_StartMessageLogging::bEncContent(BUF_TYPE b) const {
    AsnLen elmtLen, structBytesEncoded = BEncExtraFields(b);
    if (executeTimePresent().val()) {
        elmtLen = VAR_executeTime().bEncContent(b);
        elmtLen += BEncDefLen(b,elmtLen);
        elmtLen += BEncTag1(b,UNIV,CONS,16);
        elmtLen += BEncDefLen(b,elmtLen);
        elmtLen += BEncTag1(b,CNTX,CONS,1);
        structBytesEncoded += elmtLen;
    }
    elmtLen = VAR_gpsTimeStamp().bEncContent(b);
    elmtLen += BEncDefLen(b,elmtLen);
    elmtLen += BEncTag1(b,UNIV,CONS,16);
    structBytesEncoded += elmtLen;
    return structBytesEncoded;
} // TYPE_TN_SN_StartMessageLogging::bEncContent

void TYPE_TN_SN_StartMessageLogging::bDec(BUF_TYPE b,AsnLen& bytesDecoded) {
    AsnTag tagId = BDecTag1(b,bytesDecoded);
    AsnLen elmtLen;
    if (tagId != MAKE_TAG_ID(UNIV,CONS,16)) { TagError(MAKE_TAG_ID(UNIV,CONS,16),tagId); return; }
    elmtLen = BDecLen(b,bytesDecoded);
    int pending_eoc = 0;
    if (elmtLen == INDEFINITE_LEN) ++pending_eoc;
    AsnLen localBytesDecoded = 0;
    bDecContent(b,tagId,elmtLen,localBytesDecoded);
    for(;pending_eoc>0;--pending_eoc) { BDecEoc(b,localBytesDecoded); }
    bytesDecoded += localBytesDecoded;
} // TYPE_TN_SN_StartMessageLogging::bDec

void TYPE_TN_SN_StartMessageLogging::bDecContent(BUF_TYPE b,AsnTag,
        AsnLen len, AsnLen& bytesDecoded) {
    bool structDone = false;
    AsnLen elmtLen, localBytesDecoded = 0;
    AsnTag tagId;
    if (len == 0) { tagId = 0; structDone = true; }
    else tagId = BDecTag(b,localBytesDecoded);
    if (!structDone && (tagId==MAKE_TAG_ID(UNIV,CONS,16))) {
        elmtLen = BDecLen(b,localBytesDecoded);
        int pending_eoc = 0;
        if (elmtLen == INDEFINITE_LEN) ++pending_eoc;
        VAR_gpsTimeStamp().bDecContent(b,tagId,elmtLen,localBytesDecoded);
        for(;pending_eoc>0;--pending_eoc) { BDecEoc(b,localBytesDecoded); }
        if ((len!=INDEFINITE_LEN) && (localBytesDecoded>=len)) structDone = true;
        else tagId = BDecTag(b,localBytesDecoded);
    } else { TagError(MAKE_TAG_ID(UNIV,CONS,16),tagId); return; }
    if (!structDone && (tagId==MAKE_TAG_ID(CNTX,CONS,1))) {
        elmtLen = BDecLen(b,localBytesDecoded);
        int pending_eoc = 0;
        if (elmtLen == INDEFINITE_LEN) ++pending_eoc;
        tagId = BDecTag1(b,localBytesDecoded);
        if (tagId == MAKE_TAG_ID(UNIV,CONS,16)) {
          elmtLen = BDecLen(b,localBytesDecoded);
        } else { TagError(MAKE_TAG_ID(UNIV,CONS,16),tagId); return; }
        VAR_executeTime().bDecContent(b,tagId,elmtLen,localBytesDecoded);
        for(;pending_eoc>0;--pending_eoc) { BDecEoc(b,localBytesDecoded); }
        if (len!=INDEFINITE_LEN && localBytesDecoded>=len) structDone = true;
        else tagId = BDecTag(b,localBytesDecoded);
    }
    complete_sequence_decoding(b, len, localBytesDecoded, tagId);
    bytesDecoded += localBytesDecoded;
    set_state(validValue);
} // TYPE_TN_SN_StartMessageLogging::bDecContent

AsnLen TYPE_TN_SN_StartMessageLogging::pEnc(BUF_TYPE2 b) const {
    int elmtLen=0;
    b.putBit(executeTimePresent().val()?true:false);
    elmtLen++;
    elmtLen += VAR_gpsTimeStamp().pEnc(b);
    if (executeTimePresent().val())
        elmtLen += VAR_executeTime().pEnc(b);
    return elmtLen;
}

void TYPE_TN_SN_StartMessageLogging::pDec(BUF_TYPE2 b) {
    bool _field_present0 = b.getBit();
    VAR_gpsTimeStamp().pDec(b);
    if(_field_present0) VAR_executeTime().pDec(b);
    set_state(validValue);
}

SDLSeqSetDescription TYPE_TN_SN_StopMessageLogging::_fdesc(2);

SDLType* TYPE_TN_SN_StopMessageLogging::copy()const { return new TYPE_TN_SN_StopMessageLogging(*this); }

void TYPE_TN_SN_StopMessageLogging::assign(const SDLType* t)
{
  const TYPE_TN_SN_StopMessageLogging *arg = SITE_DYNAMIC_CAST(const TYPE_TN_SN_StopMessageLogging*,t);
  if (!arg) SDLSequence::assign(t);
  else *this = *arg;
}

SDLType* TYPE_TN_SN_StopMessageLogging::create()
{
  static TYPE_TN_SN_StopMessageLogging* tmpl = new TYPE_TN_SN_StopMessageLogging;
  return tmpl;
}

const SDLType* TYPE_TN_SN_StopMessageLogging::create_new() const { return create(); }

TYPE_TN_SN_StopMessageLogging::TYPE_TN_SN_StopMessageLogging():SDLSequence(_fields,2){}
TYPE_TN_SN_StopMessageLogging::TYPE_TN_SN_StopMessageLogging(SDLType** f,unsigned long c):SDLSequence(f,c){}
TYPE_TN_SN_StopMessageLogging::TYPE_TN_SN_StopMessageLogging(const SDLNull&):SDLSequence(_fields,2)
{ set_state(invalidValue); }
TYPE_TN_SN_StopMessageLogging::TYPE_TN_SN_StopMessageLogging(const SDLAny& a, AsnCodingSet rule_set):SDLSequence(_fields,2){a.decode(this,rule_set);}
TYPE_TN_SN_StopMessageLogging::TYPE_TN_SN_StopMessageLogging(const TYPE_TN_SN_StopMessageLogging&o):SDLSequence(o){
  if (o.state(SITEtemporaryValue)) {
#ifdef SITE_LOG
    if (SDLType::_type_debug & SITE_COPY_LOG)
      CERR << "(SDLRTE) struct reference copy of " << o << ENDL;
#endif
    for(int i=0; i<2;++i) {
       _fields[i] = o._fields[i]; o._fields[i] = 0;
    }
  } else sequence_copyinit(_fields,o._fields,2);
}
TYPE_TN_SN_StopMessageLogging::~TYPE_TN_SN_StopMessageLogging(){clear_fields(_fields,2);}

TYPE_TN_SN_StopMessageLogging& TYPE_TN_SN_StopMessageLogging::operator=(const TYPE_TN_SN_StopMessageLogging& val){
  val.check_valid();
  if (this!=&val) sequence_assign(val);
  return *this;
}

unsigned int TYPE_TN_SN_StopMessageLogging::hash(unsigned int max_hash)const{
  return sequence_hash(_fields, 2, max_hash);
}

void TYPE_TN_SN_StopMessageLogging::get_fields(
  SDLSeqSetDescription*& d,SDLType **&field_list){
  d=&_fdesc; field_list=_fields;
}

void TYPE_TN_SN_StopMessageLogging::get_fields(
  SDLSeqSetDescription*& d,SDLType *const*&field_list) const{
  d=&_fdesc; field_list=_fields;
}


TYPE_DateTime& TYPE_TN_SN_StopMessageLogging::VAR_gpsTimeStamp() const
{ return *SITE_STATIC_CAST(TYPE_DateTime*,field_access(_fdesc,_fields,0)); }
static SDLSeqSetDescription::Field *_TYPE_TN_SN_StopMessageLogginggpsTimeStamp=TYPE_TN_SN_StopMessageLogging::_fdesc.add(0,"gpsTimeStamp",&TYPE_DateTime::create,true);

TYPE_DateTime& TYPE_TN_SN_StopMessageLogging::VAR_executeTime() const
{ return *SITE_STATIC_CAST(TYPE_DateTime*,field_access(_fdesc,_fields,1)); }

const SDLBool& TYPE_TN_SN_StopMessageLogging::executeTimePresent()const{
  return field_present(_fdesc,_fields,1);
}

TYPE_TN_SN_StopMessageLogging TYPE_TN_SN_StopMessageLogging::executeTimeOmit()const{
  TYPE_TN_SN_StopMessageLogging c(*this);
  field_omit(_fdesc,c._fields,1);
  return c;
}

void TYPE_TN_SN_StopMessageLogging::_executeTimeOmit() {
  field_omit(_fdesc,_fields,1);
}

static SDLSeqSetDescription::Field *_TYPE_TN_SN_StopMessageLoggingexecuteTime=TYPE_TN_SN_StopMessageLogging::_fdesc.add_optional(1,"executeTime",&TYPE_DateTime::create,true);



TYPE_TN_SN_StopMessageLogging::TYPE_TN_SN_StopMessageLogging(const class TYPE_DateTime& PAR_0, const class TYPE_DateTime& PAR_1) {
    set_field(0,PAR_0.copy());
    if(PAR_1.valid())
        set_field(1,new TYPE_DateTime(PAR_1));
    else
        set_field(1,0);
}

AsnLen TYPE_TN_SN_StopMessageLogging::bEnc(BUF_TYPE b) const{
    AsnLen elmtLen = bEncContent(b);
    elmtLen += BEncDefLen(b,elmtLen);
    elmtLen += BEncTag1(b,UNIV,CONS,16);
    return elmtLen;
} // TYPE_TN_SN_StopMessageLogging::bEnc

AsnLen TYPE_TN_SN_StopMessageLogging::bEncContent(BUF_TYPE b) const {
    AsnLen elmtLen, structBytesEncoded = BEncExtraFields(b);
    if (executeTimePresent().val()) {
        elmtLen = VAR_executeTime().bEncContent(b);
        elmtLen += BEncDefLen(b,elmtLen);
        elmtLen += BEncTag1(b,UNIV,CONS,16);
        elmtLen += BEncDefLen(b,elmtLen);
        elmtLen += BEncTag1(b,CNTX,CONS,1);
        structBytesEncoded += elmtLen;
    }
    elmtLen = VAR_gpsTimeStamp().bEncContent(b);
    elmtLen += BEncDefLen(b,elmtLen);
    elmtLen += BEncTag1(b,UNIV,CONS,16);
    structBytesEncoded += elmtLen;
    return structBytesEncoded;
} // TYPE_TN_SN_StopMessageLogging::bEncContent

void TYPE_TN_SN_StopMessageLogging::bDec(BUF_TYPE b,AsnLen& bytesDecoded) {
    AsnTag tagId = BDecTag1(b,bytesDecoded);
    AsnLen elmtLen;
    if (tagId != MAKE_TAG_ID(UNIV,CONS,16)) { TagError(MAKE_TAG_ID(UNIV,CONS,16),tagId); return; }
    elmtLen = BDecLen(b,bytesDecoded);
    int pending_eoc = 0;
    if (elmtLen == INDEFINITE_LEN) ++pending_eoc;
    AsnLen localBytesDecoded = 0;
    bDecContent(b,tagId,elmtLen,localBytesDecoded);
    for(;pending_eoc>0;--pending_eoc) { BDecEoc(b,localBytesDecoded); }
    bytesDecoded += localBytesDecoded;
} // TYPE_TN_SN_StopMessageLogging::bDec

void TYPE_TN_SN_StopMessageLogging::bDecContent(BUF_TYPE b,AsnTag,
        AsnLen len, AsnLen& bytesDecoded) {
    bool structDone = false;
    AsnLen elmtLen, localBytesDecoded = 0;
    AsnTag tagId;
    if (len == 0) { tagId = 0; structDone = true; }
    else tagId = BDecTag(b,localBytesDecoded);
    if (!structDone && (tagId==MAKE_TAG_ID(UNIV,CONS,16))) {
        elmtLen = BDecLen(b,localBytesDecoded);
        int pending_eoc = 0;
        if (elmtLen == INDEFINITE_LEN) ++pending_eoc;
        VAR_gpsTimeStamp().bDecContent(b,tagId,elmtLen,localBytesDecoded);
        for(;pending_eoc>0;--pending_eoc) { BDecEoc(b,localBytesDecoded); }
        if ((len!=INDEFINITE_LEN) && (localBytesDecoded>=len)) structDone = true;
        else tagId = BDecTag(b,localBytesDecoded);
    } else { TagError(MAKE_TAG_ID(UNIV,CONS,16),tagId); return; }
    if (!structDone && (tagId==MAKE_TAG_ID(CNTX,CONS,1))) {
        elmtLen = BDecLen(b,localBytesDecoded);
        int pending_eoc = 0;
        if (elmtLen == INDEFINITE_LEN) ++pending_eoc;
        tagId = BDecTag1(b,localBytesDecoded);
        if (tagId == MAKE_TAG_ID(UNIV,CONS,16)) {
          elmtLen = BDecLen(b,localBytesDecoded);
        } else { TagError(MAKE_TAG_ID(UNIV,CONS,16),tagId); return; }
        VAR_executeTime().bDecContent(b,tagId,elmtLen,localBytesDecoded);
        for(;pending_eoc>0;--pending_eoc) { BDecEoc(b,localBytesDecoded); }
        if (len!=INDEFINITE_LEN && localBytesDecoded>=len) structDone = true;
        else tagId = BDecTag(b,localBytesDecoded);
    }
    complete_sequence_decoding(b, len, localBytesDecoded, tagId);
    bytesDecoded += localBytesDecoded;
    set_state(validValue);
} // TYPE_TN_SN_StopMessageLogging::bDecContent

AsnLen TYPE_TN_SN_StopMessageLogging::pEnc(BUF_TYPE2 b) const {
    int elmtLen=0;
    b.putBit(executeTimePresent().val()?true:false);
    elmtLen++;
    elmtLen += VAR_gpsTimeStamp().pEnc(b);
    if (executeTimePresent().val())
        elmtLen += VAR_executeTime().pEnc(b);
    return elmtLen;
}

void TYPE_TN_SN_StopMessageLogging::pDec(BUF_TYPE2 b) {
    bool _field_present0 = b.getBit();
    VAR_gpsTimeStamp().pDec(b);
    if(_field_present0) VAR_executeTime().pDec(b);
    set_state(validValue);
}

TYPE_APManagingProtocol_GEN_1::TYPE_APManagingProtocol_GEN_1(const SDLAny& a, AsnCodingSet rule_set){                                      a.decode(this,rule_set); }

SDLType* TYPE_APManagingProtocol_GEN_1::copy()const { return new TYPE_APManagingProtocol_GEN_1(*this); }

void TYPE_APManagingProtocol_GEN_1::assign(const SDLType* t)
{
  const TYPE_APManagingProtocol_GEN_1 *arg = SITE_DYNAMIC_CAST(const TYPE_APManagingProtocol_GEN_1*,t);
  if (!arg) super::assign(t);
  else *this = *arg;
}

SDLType* TYPE_APManagingProtocol_GEN_1::create()
{
  static TYPE_APManagingProtocol_GEN_1* tmpl = new TYPE_APManagingProtocol_GEN_1;
  return tmpl;
}

const SDLType* TYPE_APManagingProtocol_GEN_1::create_new() const { return create(); }


AsnLen TYPE_APManagingProtocol_GEN_1::bEnc(BUF_TYPE b) const {
    AsnLen elmtLen = bEncContent(b);
    elmtLen += BEncDefLen(b,elmtLen);
    elmtLen += BEncTag1(b,UNIV,CONS,17);
    return elmtLen;
} // TYPE_APManagingProtocol_GEN_1::bEnc

AsnLen TYPE_APManagingProtocol_GEN_1::bEncContent(BUF_TYPE b) const {
    AsnLen elmtLen, localBytesEncoded = 0;
    for(SITE_SDL_INT i=lengthAsLong(); i>0; i--) {
        elmtLen = elem(i)->bEncContent(b);
        elmtLen += BEncDefLen(b,elmtLen);
        elmtLen += BEncTag1(b,UNIV,PRIM,22);
        localBytesEncoded += elmtLen;
    }
    return localBytesEncoded;
} // TYPE_APManagingProtocol_GEN_1::bEncContent

void TYPE_APManagingProtocol_GEN_1::bDec(BUF_TYPE b,AsnLen& bytesDecoded) {
    AsnTag tagId = BDecTag1(b,bytesDecoded);
    AsnLen elmtLen;
    if (tagId != MAKE_TAG_ID(UNIV,CONS,17)) { TagError(MAKE_TAG_ID(UNIV,CONS,17),tagId); return; }
    elmtLen = BDecLen(b,bytesDecoded);
    int pending_eoc = 0;
    if (elmtLen == INDEFINITE_LEN) ++pending_eoc;
    AsnLen localBytesDecoded = 0;
    bDecContent(b,tagId,elmtLen,localBytesDecoded);
    for(;pending_eoc>0;--pending_eoc) { BDecEoc(b,localBytesDecoded); }
    bytesDecoded += localBytesDecoded;
} // TYPE_APManagingProtocol_GEN_1::bDec

void TYPE_APManagingProtocol_GEN_1::bDecContent(BUF_TYPE b,AsnTag,
        AsnLen len, AsnLen& bytesDecoded) {
    AsnLen elmtLen, localBytesDecoded = 0;
    for(int i=1; (localBytesDecoded<len) || (len==INDEFINITE_LEN); i++) {
        AsnTag tagId = BDecTag1(b,localBytesDecoded);
        if (tagId == MAKE_TAG_ID(UNIV,PRIM,22)) {
            elmtLen = BDecLen(b,localBytesDecoded);
            elem(i)->bDecContent(b,tagId,elmtLen,localBytesDecoded);
        } else if ((tagId==EOC_TAG_ID) && (len==INDEFINITE_LEN)) {
            BDEC_2ND_EOC_OCTET(b,localBytesDecoded);
            break;
        } else { TagError(MAKE_TAG_ID(UNIV,PRIM,22),tagId); return; }
    }
    bytesDecoded += localBytesDecoded;
} /* TYPE_APManagingProtocol_GEN_1::bDecContent */

TYPE_APManagingProtocol_GEN_2::TYPE_APManagingProtocol_GEN_2(const SDLAny& a, AsnCodingSet rule_set){                                      a.decode(this,rule_set); }

SDLType* TYPE_APManagingProtocol_GEN_2::copy()const { return new TYPE_APManagingProtocol_GEN_2(*this); }

void TYPE_APManagingProtocol_GEN_2::assign(const SDLType* t)
{
  const TYPE_APManagingProtocol_GEN_2 *arg = SITE_DYNAMIC_CAST(const TYPE_APManagingProtocol_GEN_2*,t);
  if (!arg) super::assign(t);
  else *this = *arg;
}

SDLType* TYPE_APManagingProtocol_GEN_2::create()
{
  static TYPE_APManagingProtocol_GEN_2* tmpl = new TYPE_APManagingProtocol_GEN_2;
  return tmpl;
}

const SDLType* TYPE_APManagingProtocol_GEN_2::create_new() const { return create(); }


AsnLen TYPE_APManagingProtocol_GEN_2::bEnc(BUF_TYPE b) const {
    AsnLen elmtLen = bEncContent(b);
    elmtLen += BEncDefLen(b,elmtLen);
    elmtLen += BEncTag1(b,UNIV,CONS,17);
    return elmtLen;
} // TYPE_APManagingProtocol_GEN_2::bEnc

AsnLen TYPE_APManagingProtocol_GEN_2::bEncContent(BUF_TYPE b) const {
    AsnLen elmtLen, localBytesEncoded = 0;
    for(SITE_SDL_INT i=lengthAsLong(); i>0; i--) {
        elmtLen = elem(i)->bEncContent(b);
        elmtLen += BEncDefLen(b,elmtLen);
        elmtLen += BEncTag1(b,UNIV,PRIM,22);
        localBytesEncoded += elmtLen;
    }
    return localBytesEncoded;
} // TYPE_APManagingProtocol_GEN_2::bEncContent

void TYPE_APManagingProtocol_GEN_2::bDec(BUF_TYPE b,AsnLen& bytesDecoded) {
    AsnTag tagId = BDecTag1(b,bytesDecoded);
    AsnLen elmtLen;
    if (tagId != MAKE_TAG_ID(UNIV,CONS,17)) { TagError(MAKE_TAG_ID(UNIV,CONS,17),tagId); return; }
    elmtLen = BDecLen(b,bytesDecoded);
    int pending_eoc = 0;
    if (elmtLen == INDEFINITE_LEN) ++pending_eoc;
    AsnLen localBytesDecoded = 0;
    bDecContent(b,tagId,elmtLen,localBytesDecoded);
    for(;pending_eoc>0;--pending_eoc) { BDecEoc(b,localBytesDecoded); }
    bytesDecoded += localBytesDecoded;
} // TYPE_APManagingProtocol_GEN_2::bDec

void TYPE_APManagingProtocol_GEN_2::bDecContent(BUF_TYPE b,AsnTag,
        AsnLen len, AsnLen& bytesDecoded) {
    AsnLen elmtLen, localBytesDecoded = 0;
    for(int i=1; (localBytesDecoded<len) || (len==INDEFINITE_LEN); i++) {
        AsnTag tagId = BDecTag1(b,localBytesDecoded);
        if (tagId == MAKE_TAG_ID(UNIV,PRIM,22)) {
            elmtLen = BDecLen(b,localBytesDecoded);
            elem(i)->bDecContent(b,tagId,elmtLen,localBytesDecoded);
        } else if ((tagId==EOC_TAG_ID) && (len==INDEFINITE_LEN)) {
            BDEC_2ND_EOC_OCTET(b,localBytesDecoded);
            break;
        } else { TagError(MAKE_TAG_ID(UNIV,PRIM,22),tagId); return; }
    }
    bytesDecoded += localBytesDecoded;
} /* TYPE_APManagingProtocol_GEN_2::bDecContent */

TYPE_APManagingProtocol_GEN_3::TYPE_APManagingProtocol_GEN_3(const SDLAny& a, AsnCodingSet rule_set){                                      a.decode(this,rule_set); }

SDLType* TYPE_APManagingProtocol_GEN_3::copy()const { return new TYPE_APManagingProtocol_GEN_3(*this); }

void TYPE_APManagingProtocol_GEN_3::assign(const SDLType* t)
{
  const TYPE_APManagingProtocol_GEN_3 *arg = SITE_DYNAMIC_CAST(const TYPE_APManagingProtocol_GEN_3*,t);
  if (!arg) super::assign(t);
  else *this = *arg;
}

SDLType* TYPE_APManagingProtocol_GEN_3::create()
{
  static TYPE_APManagingProtocol_GEN_3* tmpl = new TYPE_APManagingProtocol_GEN_3;
  return tmpl;
}

const SDLType* TYPE_APManagingProtocol_GEN_3::create_new() const { return create(); }


AsnLen TYPE_APManagingProtocol_GEN_3::bEnc(BUF_TYPE b) const {
    AsnLen elmtLen = bEncContent(b);
    elmtLen += BEncDefLen(b,elmtLen);
    elmtLen += BEncTag1(b,UNIV,CONS,17);
    return elmtLen;
} // TYPE_APManagingProtocol_GEN_3::bEnc

AsnLen TYPE_APManagingProtocol_GEN_3::bEncContent(BUF_TYPE b) const {
    AsnLen elmtLen, localBytesEncoded = 0;
    for(SITE_SDL_INT i=lengthAsLong(); i>0; i--) {
        elmtLen = elem(i)->bEncContent(b);
        elmtLen += BEncDefLen(b,elmtLen);
        elmtLen += BEncTag1(b,UNIV,PRIM,22);
        localBytesEncoded += elmtLen;
    }
    return localBytesEncoded;
} // TYPE_APManagingProtocol_GEN_3::bEncContent

void TYPE_APManagingProtocol_GEN_3::bDec(BUF_TYPE b,AsnLen& bytesDecoded) {
    AsnTag tagId = BDecTag1(b,bytesDecoded);
    AsnLen elmtLen;
    if (tagId != MAKE_TAG_ID(UNIV,CONS,17)) { TagError(MAKE_TAG_ID(UNIV,CONS,17),tagId); return; }
    elmtLen = BDecLen(b,bytesDecoded);
    int pending_eoc = 0;
    if (elmtLen == INDEFINITE_LEN) ++pending_eoc;
    AsnLen localBytesDecoded = 0;
    bDecContent(b,tagId,elmtLen,localBytesDecoded);
    for(;pending_eoc>0;--pending_eoc) { BDecEoc(b,localBytesDecoded); }
    bytesDecoded += localBytesDecoded;
} // TYPE_APManagingProtocol_GEN_3::bDec

void TYPE_APManagingProtocol_GEN_3::bDecContent(BUF_TYPE b,AsnTag,
        AsnLen len, AsnLen& bytesDecoded) {
    AsnLen elmtLen, localBytesDecoded = 0;
    for(int i=1; (localBytesDecoded<len) || (len==INDEFINITE_LEN); i++) {
        AsnTag tagId = BDecTag1(b,localBytesDecoded);
        if (tagId == MAKE_TAG_ID(UNIV,PRIM,22)) {
            elmtLen = BDecLen(b,localBytesDecoded);
            elem(i)->bDecContent(b,tagId,elmtLen,localBytesDecoded);
        } else if ((tagId==EOC_TAG_ID) && (len==INDEFINITE_LEN)) {
            BDEC_2ND_EOC_OCTET(b,localBytesDecoded);
            break;
        } else { TagError(MAKE_TAG_ID(UNIV,PRIM,22),tagId); return; }
    }
    bytesDecoded += localBytesDecoded;
} /* TYPE_APManagingProtocol_GEN_3::bDecContent */

TYPE_APManagingProtocol_GEN_4::TYPE_APManagingProtocol_GEN_4(const SDLAny& a, AsnCodingSet rule_set){                                      a.decode(this,rule_set); }

SDLType* TYPE_APManagingProtocol_GEN_4::copy()const { return new TYPE_APManagingProtocol_GEN_4(*this); }

void TYPE_APManagingProtocol_GEN_4::assign(const SDLType* t)
{
  const TYPE_APManagingProtocol_GEN_4 *arg = SITE_DYNAMIC_CAST(const TYPE_APManagingProtocol_GEN_4*,t);
  if (!arg) SDLIA5String::assign(t);
  else *this = *arg;
}

SDLType* TYPE_APManagingProtocol_GEN_4::create()
{
  static TYPE_APManagingProtocol_GEN_4* tmpl = new TYPE_APManagingProtocol_GEN_4;
  return tmpl;
}

const SDLType* TYPE_APManagingProtocol_GEN_4::create_new() const { return create(); }

AsnLen TYPE_APManagingProtocol_GEN_4::pEnc(BUF_TYPE2 b) const {
    /* PER UNALIGNED VARIANT */
    SITE_SDL_UINT off = _length - 1LL;
    SITE_SDL_UINT mask = 0xffLL;
    for(int i=0; i>=0; mask>>=8,i--)
      b.putByte(static_cast<Byte>((off & mask)>>(i*8)));
    // _length<64k
    for(int i=0;i<_length;i++)
        b.putByte(_string[i]);
    return _length*8 + 8;
}

void TYPE_APManagingProtocol_GEN_4::pDec(BUF_TYPE2 b) {
    /* PER UNALIGNED VARIANT */
    SITE_SDL_UINT off = 0;
    for(int i=0; i<1; i++)
      off = (off << 8) | b.getByte();
    _length = off + 1LL;
    _string_size = _length;
    delete[] _string;
    _string = new char[_length+1];
    for(int i=0; i<_length; i++)
        _string[i]=b.getByte();
    _string[_length]='\0';
    set_state(validValue);
}

const SDLBool& TYPE_APManagingProtocol_GEN_4::check() const{
    if(((length().ge(1))&&(length().le(255)))) return SDLBool::SDLTrue();
    return SDLBool::SDLFalse();
}

TYPE_APManagingProtocol_GEN_5::TYPE_APManagingProtocol_GEN_5(const SDLAny& a, AsnCodingSet rule_set){                                      a.decode(this,rule_set); }

SDLType* TYPE_APManagingProtocol_GEN_5::copy()const { return new TYPE_APManagingProtocol_GEN_5(*this); }

void TYPE_APManagingProtocol_GEN_5::assign(const SDLType* t)
{
  const TYPE_APManagingProtocol_GEN_5 *arg = SITE_DYNAMIC_CAST(const TYPE_APManagingProtocol_GEN_5*,t);
  if (!arg) super::assign(t);
  else *this = *arg;
}

SDLType* TYPE_APManagingProtocol_GEN_5::create()
{
  static TYPE_APManagingProtocol_GEN_5* tmpl = new TYPE_APManagingProtocol_GEN_5;
  return tmpl;
}

const SDLType* TYPE_APManagingProtocol_GEN_5::create_new() const { return create(); }


AsnLen TYPE_APManagingProtocol_GEN_5::bEnc(BUF_TYPE b) const {
    AsnLen elmtLen = bEncContent(b);
    elmtLen += BEncDefLen(b,elmtLen);
    elmtLen += BEncTag1(b,UNIV,CONS,17);
    return elmtLen;
} // TYPE_APManagingProtocol_GEN_5::bEnc

AsnLen TYPE_APManagingProtocol_GEN_5::bEncContent(BUF_TYPE b) const {
    AsnLen elmtLen, localBytesEncoded = 0;
    for(SITE_SDL_INT i=lengthAsLong(); i>0; i--) {
        elmtLen = elem(i)->bEncContent(b);
        elmtLen += BEncDefLen(b,elmtLen);
        elmtLen += BEncTag1(b,UNIV,CONS,16);
        localBytesEncoded += elmtLen;
    }
    return localBytesEncoded;
} // TYPE_APManagingProtocol_GEN_5::bEncContent

void TYPE_APManagingProtocol_GEN_5::bDec(BUF_TYPE b,AsnLen& bytesDecoded) {
    AsnTag tagId = BDecTag1(b,bytesDecoded);
    AsnLen elmtLen;
    if (tagId != MAKE_TAG_ID(UNIV,CONS,17)) { TagError(MAKE_TAG_ID(UNIV,CONS,17),tagId); return; }
    elmtLen = BDecLen(b,bytesDecoded);
    int pending_eoc = 0;
    if (elmtLen == INDEFINITE_LEN) ++pending_eoc;
    AsnLen localBytesDecoded = 0;
    bDecContent(b,tagId,elmtLen,localBytesDecoded);
    for(;pending_eoc>0;--pending_eoc) { BDecEoc(b,localBytesDecoded); }
    bytesDecoded += localBytesDecoded;
} // TYPE_APManagingProtocol_GEN_5::bDec

void TYPE_APManagingProtocol_GEN_5::bDecContent(BUF_TYPE b,AsnTag,
        AsnLen len, AsnLen& bytesDecoded) {
    AsnLen elmtLen, localBytesDecoded = 0;
    for(int i=1; (localBytesDecoded<len) || (len==INDEFINITE_LEN); i++) {
        AsnTag tagId = BDecTag1(b,localBytesDecoded);
        if (tagId == MAKE_TAG_ID(UNIV,CONS,16)) {
            elmtLen = BDecLen(b,localBytesDecoded);
            int pending_eoc = 0;
            if (elmtLen == INDEFINITE_LEN) ++pending_eoc;
            elem(i)->bDecContent(b,tagId,elmtLen,localBytesDecoded);
            for(;pending_eoc>0;--pending_eoc) { BDecEoc(b,localBytesDecoded); }
        } else if ((tagId==EOC_TAG_ID) && (len==INDEFINITE_LEN)) {
            BDEC_2ND_EOC_OCTET(b,localBytesDecoded);
            break;
        } else { TagError(MAKE_TAG_ID(UNIV,CONS,16),tagId); return; }
    }
    bytesDecoded += localBytesDecoded;
} /* TYPE_APManagingProtocol_GEN_5::bDecContent */

END_SITE_NAMESPACE
