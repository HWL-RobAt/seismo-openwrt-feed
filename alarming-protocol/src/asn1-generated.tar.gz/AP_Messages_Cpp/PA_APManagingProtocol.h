/* ===== PA_APManagingProtocol.h ===== */

#ifndef PA_APManagingProtocol_H
#define PA_APManagingProtocol_H
#include <sdlconfig.h>
#include "PA_APEWProtocol.h"
/* Note: DLL_SUPPORT depends on the sequence of includes,
         PA_APManagingProtocol not! */
#ifdef PA_APManagingProtocol_LIB
#define PA_APManagingProtocol_API DllExport
#else
#define PA_APManagingProtocol_API DllImport
#endif
#undef DLL_SUPPORT
#undef SDLARRAY_EXPORT
#ifdef PA_APManagingProtocol_LIB
#define DLL_SUPPORT DllExport
#define SDLARRAY_EXPORT DllExport
#else
#define DLL_SUPPORT DllImport
#define SDLARRAY_EXPORT DllImport
#endif
#include <sdltimer.h>

BEGIN_SITE_NAMESPACE(AP_GeneralProtocol)

class PA_APManagingProtocol_API TYPE_APManagingProtocol;
class PA_APManagingProtocol_API TYPE_TN_SN_AssignLeadershipForGroup;
class PA_APManagingProtocol_API TYPE_TN_LN_AssignLNsInNetwork;
class PA_APManagingProtocol_API TYPE_TN_LN_AssignGNsInNetwork;
class PA_APManagingProtocol_API TYPE_LN_SN_PrimaryLN;
class PA_APManagingProtocol_API TYPE_LN_SN_SecondaryLN;
class PA_APManagingProtocol_API TYPE_TN_SN_UseMSDP;
class PA_APManagingProtocol_API TYPE_TN_SN_AskGroupId;
class PA_APManagingProtocol_API TYPE_SN_TN_HaveGroupId;
class PA_APManagingProtocol_API TYPE_KeyValuePair;
class PA_APManagingProtocol_API TYPE_TN_SN_ConfigureSetKeyValue;
class PA_APManagingProtocol_API TYPE_TN_SN_CloseMessageLogfile;
class PA_APManagingProtocol_API TYPE_TN_SN_StartMessageLogging;
class PA_APManagingProtocol_API TYPE_TN_SN_StopMessageLogging;
class PA_APManagingProtocol_API TYPE_APManagingProtocol_GEN_1;
class PA_APManagingProtocol_API TYPE_APManagingProtocol_GEN_2;
class PA_APManagingProtocol_API TYPE_APManagingProtocol_GEN_3;
class PA_APManagingProtocol_API TYPE_APManagingProtocol_GEN_4;
class PA_APManagingProtocol_API TYPE_APManagingProtocol_GEN_5;

class PA_APManagingProtocol_API TYPE_APManagingProtocol: public SDLChoice {
public:
    TYPE_APManagingProtocol(const SDLAny&, AsnCodingSet rule_set=asn_ber);
    virtual const char* name() const { return "TYPE_APManagingProtocol"; }
    virtual SDLType* copy()const;
    virtual void assign(const SDLType* t);
    static SDLType* create();
    virtual const SDLType* create_new() const;
    static const TYPE_APManagingProtocol& convert(const TYPE_APManagingProtocol&t) { return t; };
    
public:
    TYPE_APManagingProtocol(unsigned int i,const SDLType& elem) { assign_field(i,elem); }
    TYPE_APManagingProtocol(){}
    TYPE_APManagingProtocol(const SDLNull& n):SDLChoice(n){}
    TYPE_APManagingProtocol(const TYPE_APManagingProtocol& base):SDLChoice(base){}
    enum {
        CHOICE_NoAssign,
        CHOICE_mTN_SN_AssignLeadershipForGroup,
        CHOICE_mTN_LN_AssignLNsInNetwork,
        CHOICE_mTN_LN_AssignGNsInNetwork,
        CHOICE_mLN_SN_PrimaryLN,
        CHOICE_mLN_SN_SecondaryLN,
        CHOICE_mTN_SN_UseMSDP,
        CHOICE_mTN_SN_AskGroupId,
        CHOICE_mSN_TN_HaveGroupId,
        CHOICE_mTN_SN_ConfigureSetKeyValue,
        CHOICE_mTN_SN_CloseMessageLogfile,
        CHOICE_mTN_SN_StartMessageLogging,
        CHOICE_mTN_SN_StopMessageLogging
    };
    const SDLBool& mTN_SN_AssignLeadershipForGroupPresent()const
    { return (_present == CHOICE_mTN_SN_AssignLeadershipForGroup)?SDLBool::SDLTrue():SDLBool::SDLFalse(); }
    TYPE_TN_SN_AssignLeadershipForGroup& VAR_mTN_SN_AssignLeadershipForGroup() const;
    const SDLBool& mTN_LN_AssignLNsInNetworkPresent()const
    { return (_present == CHOICE_mTN_LN_AssignLNsInNetwork)?SDLBool::SDLTrue():SDLBool::SDLFalse(); }
    TYPE_TN_LN_AssignLNsInNetwork& VAR_mTN_LN_AssignLNsInNetwork() const;
    const SDLBool& mTN_LN_AssignGNsInNetworkPresent()const
    { return (_present == CHOICE_mTN_LN_AssignGNsInNetwork)?SDLBool::SDLTrue():SDLBool::SDLFalse(); }
    TYPE_TN_LN_AssignGNsInNetwork& VAR_mTN_LN_AssignGNsInNetwork() const;
    const SDLBool& mLN_SN_PrimaryLNPresent()const
    { return (_present == CHOICE_mLN_SN_PrimaryLN)?SDLBool::SDLTrue():SDLBool::SDLFalse(); }
    TYPE_LN_SN_PrimaryLN& VAR_mLN_SN_PrimaryLN() const;
    const SDLBool& mLN_SN_SecondaryLNPresent()const
    { return (_present == CHOICE_mLN_SN_SecondaryLN)?SDLBool::SDLTrue():SDLBool::SDLFalse(); }
    TYPE_LN_SN_SecondaryLN& VAR_mLN_SN_SecondaryLN() const;
    const SDLBool& mTN_SN_UseMSDPPresent()const
    { return (_present == CHOICE_mTN_SN_UseMSDP)?SDLBool::SDLTrue():SDLBool::SDLFalse(); }
    TYPE_TN_SN_UseMSDP& VAR_mTN_SN_UseMSDP() const;
    const SDLBool& mTN_SN_AskGroupIdPresent()const
    { return (_present == CHOICE_mTN_SN_AskGroupId)?SDLBool::SDLTrue():SDLBool::SDLFalse(); }
    TYPE_TN_SN_AskGroupId& VAR_mTN_SN_AskGroupId() const;
    const SDLBool& mSN_TN_HaveGroupIdPresent()const
    { return (_present == CHOICE_mSN_TN_HaveGroupId)?SDLBool::SDLTrue():SDLBool::SDLFalse(); }
    TYPE_SN_TN_HaveGroupId& VAR_mSN_TN_HaveGroupId() const;
    const SDLBool& mTN_SN_ConfigureSetKeyValuePresent()const
    { return (_present == CHOICE_mTN_SN_ConfigureSetKeyValue)?SDLBool::SDLTrue():SDLBool::SDLFalse(); }
    TYPE_TN_SN_ConfigureSetKeyValue& VAR_mTN_SN_ConfigureSetKeyValue() const;
    const SDLBool& mTN_SN_CloseMessageLogfilePresent()const
    { return (_present == CHOICE_mTN_SN_CloseMessageLogfile)?SDLBool::SDLTrue():SDLBool::SDLFalse(); }
    TYPE_TN_SN_CloseMessageLogfile& VAR_mTN_SN_CloseMessageLogfile() const;
    const SDLBool& mTN_SN_StartMessageLoggingPresent()const
    { return (_present == CHOICE_mTN_SN_StartMessageLogging)?SDLBool::SDLTrue():SDLBool::SDLFalse(); }
    TYPE_TN_SN_StartMessageLogging& VAR_mTN_SN_StartMessageLogging() const;
    const SDLBool& mTN_SN_StopMessageLoggingPresent()const
    { return (_present == CHOICE_mTN_SN_StopMessageLogging)?SDLBool::SDLTrue():SDLBool::SDLFalse(); }
    TYPE_TN_SN_StopMessageLogging& VAR_mTN_SN_StopMessageLogging() const;
    void assign_field(unsigned int variant,const SDLType& elem);
    AsnLen bEnc(BUF_TYPE) const;
    AsnLen bEncContent(BUF_TYPE) const;
    void bDec(BUF_TYPE,AsnLen&);
    void bDecContent(BUF_TYPE,AsnTag,AsnLen,AsnLen&);
    AsnLen pEnc(BUF_TYPE2 b) const;
    void pDec(BUF_TYPE2 b);
    bool datainfo(long,SDLIA5String&,SDLIA5String&,SDLType*&,SDLType::infotype);
};

class PA_APManagingProtocol_API TYPE_TN_SN_AssignLeadershipForGroup: public SDLSequence {
    typedef TYPE_TN_SN_AssignLeadershipForGroup _TYPE_thistype;
public:
    static SDLSeqSetDescription _fdesc;
public:
    TYPE_TN_SN_AssignLeadershipForGroup(const SDLAny&, AsnCodingSet rule_set=asn_ber);
    virtual const char* name() const { return "TYPE_TN_SN_AssignLeadershipForGroup"; }
    virtual SDLType* copy()const;
    virtual void assign(const SDLType* t);
    static SDLType* create();
    virtual const SDLType* create_new() const;
    static const TYPE_TN_SN_AssignLeadershipForGroup& convert(const TYPE_TN_SN_AssignLeadershipForGroup&t) { return t; };
    
    TYPE_TN_SN_AssignLeadershipForGroup();
    TYPE_TN_SN_AssignLeadershipForGroup(SDLType**,unsigned long);
    TYPE_TN_SN_AssignLeadershipForGroup(const SDLNull&);
    TYPE_TN_SN_AssignLeadershipForGroup(const TYPE_TN_SN_AssignLeadershipForGroup&);
    virtual ~TYPE_TN_SN_AssignLeadershipForGroup();
    
    TYPE_TN_SN_AssignLeadershipForGroup& operator=(const TYPE_TN_SN_AssignLeadershipForGroup&);
    unsigned int hash(unsigned int max_hash)const;
    
    mutable SDLType* _fields[3?3:1];
    virtual void get_fields(SDLSeqSetDescription*&,SDLType**&);
    virtual void get_fields(SDLSeqSetDescription*&,SDLType *const*&)const;
    void set_field(int index,SDLType* value){
      _fields[index]=value;
    }
    
public:
    TYPE_TN_SN_AssignLeadershipForGroup(const class TYPE_DateTime&, const class TYPE_APManagingProtocol_GEN_1&, const class TYPE_GroupID&);
    TYPE_DateTime& VAR_gpsTimeStamp() const;
    TYPE_APManagingProtocol_GEN_1& VAR_groupMembers() const;
    TYPE_GroupID& VAR_groupID() const;
    AsnLen bEnc(BUF_TYPE) const;
    AsnLen bEncContent(BUF_TYPE) const;
    void bDec(BUF_TYPE,AsnLen&);
    void bDecContent(BUF_TYPE,AsnTag,AsnLen,AsnLen&);
    AsnLen pEnc(BUF_TYPE2 b) const;
    void pDec(BUF_TYPE2 b);
};

class PA_APManagingProtocol_API TYPE_TN_LN_AssignLNsInNetwork: public SDLSequence {
    typedef TYPE_TN_LN_AssignLNsInNetwork _TYPE_thistype;
public:
    static SDLSeqSetDescription _fdesc;
public:
    TYPE_TN_LN_AssignLNsInNetwork(const SDLAny&, AsnCodingSet rule_set=asn_ber);
    virtual const char* name() const { return "TYPE_TN_LN_AssignLNsInNetwork"; }
    virtual SDLType* copy()const;
    virtual void assign(const SDLType* t);
    static SDLType* create();
    virtual const SDLType* create_new() const;
    static const TYPE_TN_LN_AssignLNsInNetwork& convert(const TYPE_TN_LN_AssignLNsInNetwork&t) { return t; };
    
    TYPE_TN_LN_AssignLNsInNetwork();
    TYPE_TN_LN_AssignLNsInNetwork(SDLType**,unsigned long);
    TYPE_TN_LN_AssignLNsInNetwork(const SDLNull&);
    TYPE_TN_LN_AssignLNsInNetwork(const TYPE_TN_LN_AssignLNsInNetwork&);
    virtual ~TYPE_TN_LN_AssignLNsInNetwork();
    
    TYPE_TN_LN_AssignLNsInNetwork& operator=(const TYPE_TN_LN_AssignLNsInNetwork&);
    unsigned int hash(unsigned int max_hash)const;
    
    mutable SDLType* _fields[2?2:1];
    virtual void get_fields(SDLSeqSetDescription*&,SDLType**&);
    virtual void get_fields(SDLSeqSetDescription*&,SDLType *const*&)const;
    void set_field(int index,SDLType* value){
      _fields[index]=value;
    }
    
public:
    TYPE_TN_LN_AssignLNsInNetwork(const class TYPE_DateTime&, const class TYPE_APManagingProtocol_GEN_2&);
    TYPE_DateTime& VAR_gpsTimeStamp() const;
    TYPE_APManagingProtocol_GEN_2& VAR_leadingNodesInNetwork() const;
    AsnLen bEnc(BUF_TYPE) const;
    AsnLen bEncContent(BUF_TYPE) const;
    void bDec(BUF_TYPE,AsnLen&);
    void bDecContent(BUF_TYPE,AsnTag,AsnLen,AsnLen&);
    AsnLen pEnc(BUF_TYPE2 b) const;
    void pDec(BUF_TYPE2 b);
};

class PA_APManagingProtocol_API TYPE_TN_LN_AssignGNsInNetwork: public SDLSequence {
    typedef TYPE_TN_LN_AssignGNsInNetwork _TYPE_thistype;
public:
    static SDLSeqSetDescription _fdesc;
public:
    TYPE_TN_LN_AssignGNsInNetwork(const SDLAny&, AsnCodingSet rule_set=asn_ber);
    virtual const char* name() const { return "TYPE_TN_LN_AssignGNsInNetwork"; }
    virtual SDLType* copy()const;
    virtual void assign(const SDLType* t);
    static SDLType* create();
    virtual const SDLType* create_new() const;
    static const TYPE_TN_LN_AssignGNsInNetwork& convert(const TYPE_TN_LN_AssignGNsInNetwork&t) { return t; };
    
    TYPE_TN_LN_AssignGNsInNetwork();
    TYPE_TN_LN_AssignGNsInNetwork(SDLType**,unsigned long);
    TYPE_TN_LN_AssignGNsInNetwork(const SDLNull&);
    TYPE_TN_LN_AssignGNsInNetwork(const TYPE_TN_LN_AssignGNsInNetwork&);
    virtual ~TYPE_TN_LN_AssignGNsInNetwork();
    
    TYPE_TN_LN_AssignGNsInNetwork& operator=(const TYPE_TN_LN_AssignGNsInNetwork&);
    unsigned int hash(unsigned int max_hash)const;
    
    mutable SDLType* _fields[2?2:1];
    virtual void get_fields(SDLSeqSetDescription*&,SDLType**&);
    virtual void get_fields(SDLSeqSetDescription*&,SDLType *const*&)const;
    void set_field(int index,SDLType* value){
      _fields[index]=value;
    }
    
public:
    TYPE_TN_LN_AssignGNsInNetwork(const class TYPE_DateTime&, const class TYPE_APManagingProtocol_GEN_3&);
    TYPE_DateTime& VAR_gpsTimeStamp() const;
    TYPE_APManagingProtocol_GEN_3& VAR_gatewayNodesInNetwork() const;
    AsnLen bEnc(BUF_TYPE) const;
    AsnLen bEncContent(BUF_TYPE) const;
    void bDec(BUF_TYPE,AsnLen&);
    void bDecContent(BUF_TYPE,AsnTag,AsnLen,AsnLen&);
    AsnLen pEnc(BUF_TYPE2 b) const;
    void pDec(BUF_TYPE2 b);
};

class PA_APManagingProtocol_API TYPE_LN_SN_PrimaryLN: public SDLSequence {
    typedef TYPE_LN_SN_PrimaryLN _TYPE_thistype;
public:
    static SDLSeqSetDescription _fdesc;
public:
    TYPE_LN_SN_PrimaryLN(const SDLAny&, AsnCodingSet rule_set=asn_ber);
    virtual const char* name() const { return "TYPE_LN_SN_PrimaryLN"; }
    virtual SDLType* copy()const;
    virtual void assign(const SDLType* t);
    static SDLType* create();
    virtual const SDLType* create_new() const;
    static const TYPE_LN_SN_PrimaryLN& convert(const TYPE_LN_SN_PrimaryLN&t) { return t; };
    
    TYPE_LN_SN_PrimaryLN();
    TYPE_LN_SN_PrimaryLN(SDLType**,unsigned long);
    TYPE_LN_SN_PrimaryLN(const SDLNull&);
    TYPE_LN_SN_PrimaryLN(const TYPE_LN_SN_PrimaryLN&);
    virtual ~TYPE_LN_SN_PrimaryLN();
    
    TYPE_LN_SN_PrimaryLN& operator=(const TYPE_LN_SN_PrimaryLN&);
    unsigned int hash(unsigned int max_hash)const;
    
    mutable SDLType* _fields[3?3:1];
    virtual void get_fields(SDLSeqSetDescription*&,SDLType**&);
    virtual void get_fields(SDLSeqSetDescription*&,SDLType *const*&)const;
    void set_field(int index,SDLType* value){
      _fields[index]=value;
    }
    
public:
    TYPE_LN_SN_PrimaryLN(const class TYPE_DateTime&, const class TYPE_IPAddress&, const class TYPE_GroupID&);
    TYPE_DateTime& VAR_gpsTimeStamp() const;
    TYPE_IPAddress& VAR_leadingNode() const;
    TYPE_GroupID& VAR_groupID() const;
    AsnLen bEnc(BUF_TYPE) const;
    AsnLen bEncContent(BUF_TYPE) const;
    void bDec(BUF_TYPE,AsnLen&);
    void bDecContent(BUF_TYPE,AsnTag,AsnLen,AsnLen&);
    AsnLen pEnc(BUF_TYPE2 b) const;
    void pDec(BUF_TYPE2 b);
};

class PA_APManagingProtocol_API TYPE_LN_SN_SecondaryLN: public SDLSequence {
    typedef TYPE_LN_SN_SecondaryLN _TYPE_thistype;
public:
    static SDLSeqSetDescription _fdesc;
public:
    TYPE_LN_SN_SecondaryLN(const SDLAny&, AsnCodingSet rule_set=asn_ber);
    virtual const char* name() const { return "TYPE_LN_SN_SecondaryLN"; }
    virtual SDLType* copy()const;
    virtual void assign(const SDLType* t);
    static SDLType* create();
    virtual const SDLType* create_new() const;
    static const TYPE_LN_SN_SecondaryLN& convert(const TYPE_LN_SN_SecondaryLN&t) { return t; };
    
    TYPE_LN_SN_SecondaryLN();
    TYPE_LN_SN_SecondaryLN(SDLType**,unsigned long);
    TYPE_LN_SN_SecondaryLN(const SDLNull&);
    TYPE_LN_SN_SecondaryLN(const TYPE_LN_SN_SecondaryLN&);
    virtual ~TYPE_LN_SN_SecondaryLN();
    
    TYPE_LN_SN_SecondaryLN& operator=(const TYPE_LN_SN_SecondaryLN&);
    unsigned int hash(unsigned int max_hash)const;
    
    mutable SDLType* _fields[3?3:1];
    virtual void get_fields(SDLSeqSetDescription*&,SDLType**&);
    virtual void get_fields(SDLSeqSetDescription*&,SDLType *const*&)const;
    void set_field(int index,SDLType* value){
      _fields[index]=value;
    }
    
public:
    TYPE_LN_SN_SecondaryLN(const class TYPE_DateTime&, const class TYPE_IPAddress&, const class TYPE_GroupID&);
    TYPE_DateTime& VAR_gpsTimeStamp() const;
    TYPE_IPAddress& VAR_leadingNode() const;
    TYPE_GroupID& VAR_groupID() const;
    AsnLen bEnc(BUF_TYPE) const;
    AsnLen bEncContent(BUF_TYPE) const;
    void bDec(BUF_TYPE,AsnLen&);
    void bDecContent(BUF_TYPE,AsnTag,AsnLen,AsnLen&);
    AsnLen pEnc(BUF_TYPE2 b) const;
    void pDec(BUF_TYPE2 b);
};

class PA_APManagingProtocol_API TYPE_TN_SN_UseMSDP: public SDLSequence {
    typedef TYPE_TN_SN_UseMSDP _TYPE_thistype;
public:
    static SDLSeqSetDescription _fdesc;
public:
    TYPE_TN_SN_UseMSDP(const SDLAny&, AsnCodingSet rule_set=asn_ber);
    virtual const char* name() const { return "TYPE_TN_SN_UseMSDP"; }
    virtual SDLType* copy()const;
    virtual void assign(const SDLType* t);
    static SDLType* create();
    virtual const SDLType* create_new() const;
    static const TYPE_TN_SN_UseMSDP& convert(const TYPE_TN_SN_UseMSDP&t) { return t; };
    
    TYPE_TN_SN_UseMSDP();
    TYPE_TN_SN_UseMSDP(SDLType**,unsigned long);
    TYPE_TN_SN_UseMSDP(const SDLNull&);
    TYPE_TN_SN_UseMSDP(const TYPE_TN_SN_UseMSDP&);
    virtual ~TYPE_TN_SN_UseMSDP();
    
    TYPE_TN_SN_UseMSDP& operator=(const TYPE_TN_SN_UseMSDP&);
    unsigned int hash(unsigned int max_hash)const;
    
    mutable SDLType* _fields[4?4:1];
    virtual void get_fields(SDLSeqSetDescription*&,SDLType**&);
    virtual void get_fields(SDLSeqSetDescription*&,SDLType *const*&)const;
    void set_field(int index,SDLType* value){
      _fields[index]=value;
    }
    
public:
    TYPE_TN_SN_UseMSDP(const class TYPE_DateTime&, const class TYPE_DateTime&, const class TYPE_DateTime&, const class TYPE_APManagingProtocol_GEN_4&);
    TYPE_DateTime& VAR_gpsTimeStamp() const;
    TYPE_DateTime& VAR_simulationRunStartTime() const;
    TYPE_DateTime& VAR_modelTimeStartTime() const;
    TYPE_APManagingProtocol_GEN_4& VAR_sensorDataFile() const;
    AsnLen bEnc(BUF_TYPE) const;
    AsnLen bEncContent(BUF_TYPE) const;
    void bDec(BUF_TYPE,AsnLen&);
    void bDecContent(BUF_TYPE,AsnTag,AsnLen,AsnLen&);
    AsnLen pEnc(BUF_TYPE2 b) const;
    void pDec(BUF_TYPE2 b);
};

class PA_APManagingProtocol_API TYPE_TN_SN_AskGroupId: public SDLSequence {
    typedef TYPE_TN_SN_AskGroupId _TYPE_thistype;
public:
    static SDLSeqSetDescription _fdesc;
public:
    TYPE_TN_SN_AskGroupId(const SDLAny&, AsnCodingSet rule_set=asn_ber);
    virtual const char* name() const { return "TYPE_TN_SN_AskGroupId"; }
    virtual SDLType* copy()const;
    virtual void assign(const SDLType* t);
    static SDLType* create();
    virtual const SDLType* create_new() const;
    static const TYPE_TN_SN_AskGroupId& convert(const TYPE_TN_SN_AskGroupId&t) { return t; };
    
    TYPE_TN_SN_AskGroupId();
    TYPE_TN_SN_AskGroupId(SDLType**,unsigned long);
    TYPE_TN_SN_AskGroupId(const SDLNull&);
    TYPE_TN_SN_AskGroupId(const TYPE_TN_SN_AskGroupId&);
    virtual ~TYPE_TN_SN_AskGroupId();
    
    TYPE_TN_SN_AskGroupId& operator=(const TYPE_TN_SN_AskGroupId&);
    unsigned int hash(unsigned int max_hash)const;
    
    mutable SDLType* _fields[1?1:1];
    virtual void get_fields(SDLSeqSetDescription*&,SDLType**&);
    virtual void get_fields(SDLSeqSetDescription*&,SDLType *const*&)const;
    void set_field(int index,SDLType* value){
      _fields[index]=value;
    }
    
public:
    TYPE_TN_SN_AskGroupId(const class TYPE_DateTime&);
    TYPE_DateTime& VAR_gpsTimeStamp() const;
    AsnLen bEnc(BUF_TYPE) const;
    AsnLen bEncContent(BUF_TYPE) const;
    void bDec(BUF_TYPE,AsnLen&);
    void bDecContent(BUF_TYPE,AsnTag,AsnLen,AsnLen&);
    AsnLen pEnc(BUF_TYPE2 b) const;
    void pDec(BUF_TYPE2 b);
};

class PA_APManagingProtocol_API TYPE_SN_TN_HaveGroupId: public SDLSequence {
    typedef TYPE_SN_TN_HaveGroupId _TYPE_thistype;
public:
    static SDLSeqSetDescription _fdesc;
public:
    TYPE_SN_TN_HaveGroupId(const SDLAny&, AsnCodingSet rule_set=asn_ber);
    virtual const char* name() const { return "TYPE_SN_TN_HaveGroupId"; }
    virtual SDLType* copy()const;
    virtual void assign(const SDLType* t);
    static SDLType* create();
    virtual const SDLType* create_new() const;
    static const TYPE_SN_TN_HaveGroupId& convert(const TYPE_SN_TN_HaveGroupId&t) { return t; };
    
    TYPE_SN_TN_HaveGroupId();
    TYPE_SN_TN_HaveGroupId(SDLType**,unsigned long);
    TYPE_SN_TN_HaveGroupId(const SDLNull&);
    TYPE_SN_TN_HaveGroupId(const TYPE_SN_TN_HaveGroupId&);
    virtual ~TYPE_SN_TN_HaveGroupId();
    
    TYPE_SN_TN_HaveGroupId& operator=(const TYPE_SN_TN_HaveGroupId&);
    unsigned int hash(unsigned int max_hash)const;
    
    mutable SDLType* _fields[3?3:1];
    virtual void get_fields(SDLSeqSetDescription*&,SDLType**&);
    virtual void get_fields(SDLSeqSetDescription*&,SDLType *const*&)const;
    void set_field(int index,SDLType* value){
      _fields[index]=value;
    }
    
public:
    TYPE_SN_TN_HaveGroupId(const class TYPE_DateTime&, const class TYPE_IPAddress&, const class TYPE_GroupID&);
    TYPE_DateTime& VAR_gpsTimeStamp() const;
    TYPE_IPAddress& VAR_leadingNode() const;
    TYPE_GroupID& VAR_groupID() const;
    AsnLen bEnc(BUF_TYPE) const;
    AsnLen bEncContent(BUF_TYPE) const;
    void bDec(BUF_TYPE,AsnLen&);
    void bDecContent(BUF_TYPE,AsnTag,AsnLen,AsnLen&);
    AsnLen pEnc(BUF_TYPE2 b) const;
    void pDec(BUF_TYPE2 b);
};

class PA_APManagingProtocol_API TYPE_KeyValuePair: public SDLSequence {
    typedef TYPE_KeyValuePair _TYPE_thistype;
public:
    static SDLSeqSetDescription _fdesc;
public:
    TYPE_KeyValuePair(const SDLAny&, AsnCodingSet rule_set=asn_ber);
    virtual const char* name() const { return "TYPE_KeyValuePair"; }
    virtual SDLType* copy()const;
    virtual void assign(const SDLType* t);
    static SDLType* create();
    virtual const SDLType* create_new() const;
    static const TYPE_KeyValuePair& convert(const TYPE_KeyValuePair&t) { return t; };
    
    TYPE_KeyValuePair();
    TYPE_KeyValuePair(SDLType**,unsigned long);
    TYPE_KeyValuePair(const SDLNull&);
    TYPE_KeyValuePair(const TYPE_KeyValuePair&);
    virtual ~TYPE_KeyValuePair();
    
    TYPE_KeyValuePair& operator=(const TYPE_KeyValuePair&);
    unsigned int hash(unsigned int max_hash)const;
    
    mutable SDLType* _fields[3?3:1];
    virtual void get_fields(SDLSeqSetDescription*&,SDLType**&);
    virtual void get_fields(SDLSeqSetDescription*&,SDLType *const*&)const;
    void set_field(int index,SDLType* value){
      _fields[index]=value;
    }
    
public:
    TYPE_KeyValuePair(const class SDLIA5String&, const class SDLIA5String&, const class TYPE_DateTime&);
    SDLIA5String& VAR_key() const;
    SDLIA5String& VAR_value() const;
    TYPE_DateTime& VAR_notValidBefore() const;
    const SDLBool& notValidBeforePresent()const;
    _TYPE_thistype notValidBeforeOmit()const;
    void _notValidBeforeOmit();
    
    AsnLen bEnc(BUF_TYPE) const;
    AsnLen bEncContent(BUF_TYPE) const;
    void bDec(BUF_TYPE,AsnLen&);
    void bDecContent(BUF_TYPE,AsnTag,AsnLen,AsnLen&);
    AsnLen pEnc(BUF_TYPE2 b) const;
    void pDec(BUF_TYPE2 b);
};

class PA_APManagingProtocol_API TYPE_TN_SN_ConfigureSetKeyValue: public SDLSequence {
    typedef TYPE_TN_SN_ConfigureSetKeyValue _TYPE_thistype;
public:
    static SDLSeqSetDescription _fdesc;
public:
    TYPE_TN_SN_ConfigureSetKeyValue(const SDLAny&, AsnCodingSet rule_set=asn_ber);
    virtual const char* name() const { return "TYPE_TN_SN_ConfigureSetKeyValue"; }
    virtual SDLType* copy()const;
    virtual void assign(const SDLType* t);
    static SDLType* create();
    virtual const SDLType* create_new() const;
    static const TYPE_TN_SN_ConfigureSetKeyValue& convert(const TYPE_TN_SN_ConfigureSetKeyValue&t) { return t; };
    
    TYPE_TN_SN_ConfigureSetKeyValue();
    TYPE_TN_SN_ConfigureSetKeyValue(SDLType**,unsigned long);
    TYPE_TN_SN_ConfigureSetKeyValue(const SDLNull&);
    TYPE_TN_SN_ConfigureSetKeyValue(const TYPE_TN_SN_ConfigureSetKeyValue&);
    virtual ~TYPE_TN_SN_ConfigureSetKeyValue();
    
    TYPE_TN_SN_ConfigureSetKeyValue& operator=(const TYPE_TN_SN_ConfigureSetKeyValue&);
    unsigned int hash(unsigned int max_hash)const;
    
    mutable SDLType* _fields[2?2:1];
    virtual void get_fields(SDLSeqSetDescription*&,SDLType**&);
    virtual void get_fields(SDLSeqSetDescription*&,SDLType *const*&)const;
    void set_field(int index,SDLType* value){
      _fields[index]=value;
    }
    
public:
    TYPE_TN_SN_ConfigureSetKeyValue(const class TYPE_DateTime&, const class TYPE_APManagingProtocol_GEN_5&);
    TYPE_DateTime& VAR_gpsTimeStamp() const;
    TYPE_APManagingProtocol_GEN_5& VAR_keyValuesSet() const;
    AsnLen bEnc(BUF_TYPE) const;
    AsnLen bEncContent(BUF_TYPE) const;
    void bDec(BUF_TYPE,AsnLen&);
    void bDecContent(BUF_TYPE,AsnTag,AsnLen,AsnLen&);
    AsnLen pEnc(BUF_TYPE2 b) const;
    void pDec(BUF_TYPE2 b);
};

class PA_APManagingProtocol_API TYPE_TN_SN_CloseMessageLogfile: public SDLSequence {
    typedef TYPE_TN_SN_CloseMessageLogfile _TYPE_thistype;
public:
    static SDLSeqSetDescription _fdesc;
public:
    TYPE_TN_SN_CloseMessageLogfile(const SDLAny&, AsnCodingSet rule_set=asn_ber);
    virtual const char* name() const { return "TYPE_TN_SN_CloseMessageLogfile"; }
    virtual SDLType* copy()const;
    virtual void assign(const SDLType* t);
    static SDLType* create();
    virtual const SDLType* create_new() const;
    static const TYPE_TN_SN_CloseMessageLogfile& convert(const TYPE_TN_SN_CloseMessageLogfile&t) { return t; };
    
    TYPE_TN_SN_CloseMessageLogfile();
    TYPE_TN_SN_CloseMessageLogfile(SDLType**,unsigned long);
    TYPE_TN_SN_CloseMessageLogfile(const SDLNull&);
    TYPE_TN_SN_CloseMessageLogfile(const TYPE_TN_SN_CloseMessageLogfile&);
    virtual ~TYPE_TN_SN_CloseMessageLogfile();
    
    TYPE_TN_SN_CloseMessageLogfile& operator=(const TYPE_TN_SN_CloseMessageLogfile&);
    unsigned int hash(unsigned int max_hash)const;
    
    mutable SDLType* _fields[2?2:1];
    virtual void get_fields(SDLSeqSetDescription*&,SDLType**&);
    virtual void get_fields(SDLSeqSetDescription*&,SDLType *const*&)const;
    void set_field(int index,SDLType* value){
      _fields[index]=value;
    }
    
public:
    TYPE_TN_SN_CloseMessageLogfile(const class TYPE_DateTime&, const class TYPE_DateTime&);
    TYPE_DateTime& VAR_gpsTimeStamp() const;
    TYPE_DateTime& VAR_executeTime() const;
    const SDLBool& executeTimePresent()const;
    _TYPE_thistype executeTimeOmit()const;
    void _executeTimeOmit();
    
    AsnLen bEnc(BUF_TYPE) const;
    AsnLen bEncContent(BUF_TYPE) const;
    void bDec(BUF_TYPE,AsnLen&);
    void bDecContent(BUF_TYPE,AsnTag,AsnLen,AsnLen&);
    AsnLen pEnc(BUF_TYPE2 b) const;
    void pDec(BUF_TYPE2 b);
};

class PA_APManagingProtocol_API TYPE_TN_SN_StartMessageLogging: public SDLSequence {
    typedef TYPE_TN_SN_StartMessageLogging _TYPE_thistype;
public:
    static SDLSeqSetDescription _fdesc;
public:
    TYPE_TN_SN_StartMessageLogging(const SDLAny&, AsnCodingSet rule_set=asn_ber);
    virtual const char* name() const { return "TYPE_TN_SN_StartMessageLogging"; }
    virtual SDLType* copy()const;
    virtual void assign(const SDLType* t);
    static SDLType* create();
    virtual const SDLType* create_new() const;
    static const TYPE_TN_SN_StartMessageLogging& convert(const TYPE_TN_SN_StartMessageLogging&t) { return t; };
    
    TYPE_TN_SN_StartMessageLogging();
    TYPE_TN_SN_StartMessageLogging(SDLType**,unsigned long);
    TYPE_TN_SN_StartMessageLogging(const SDLNull&);
    TYPE_TN_SN_StartMessageLogging(const TYPE_TN_SN_StartMessageLogging&);
    virtual ~TYPE_TN_SN_StartMessageLogging();
    
    TYPE_TN_SN_StartMessageLogging& operator=(const TYPE_TN_SN_StartMessageLogging&);
    unsigned int hash(unsigned int max_hash)const;
    
    mutable SDLType* _fields[2?2:1];
    virtual void get_fields(SDLSeqSetDescription*&,SDLType**&);
    virtual void get_fields(SDLSeqSetDescription*&,SDLType *const*&)const;
    void set_field(int index,SDLType* value){
      _fields[index]=value;
    }
    
public:
    TYPE_TN_SN_StartMessageLogging(const class TYPE_DateTime&, const class TYPE_DateTime&);
    TYPE_DateTime& VAR_gpsTimeStamp() const;
    TYPE_DateTime& VAR_executeTime() const;
    const SDLBool& executeTimePresent()const;
    _TYPE_thistype executeTimeOmit()const;
    void _executeTimeOmit();
    
    AsnLen bEnc(BUF_TYPE) const;
    AsnLen bEncContent(BUF_TYPE) const;
    void bDec(BUF_TYPE,AsnLen&);
    void bDecContent(BUF_TYPE,AsnTag,AsnLen,AsnLen&);
    AsnLen pEnc(BUF_TYPE2 b) const;
    void pDec(BUF_TYPE2 b);
};

class PA_APManagingProtocol_API TYPE_TN_SN_StopMessageLogging: public SDLSequence {
    typedef TYPE_TN_SN_StopMessageLogging _TYPE_thistype;
public:
    static SDLSeqSetDescription _fdesc;
public:
    TYPE_TN_SN_StopMessageLogging(const SDLAny&, AsnCodingSet rule_set=asn_ber);
    virtual const char* name() const { return "TYPE_TN_SN_StopMessageLogging"; }
    virtual SDLType* copy()const;
    virtual void assign(const SDLType* t);
    static SDLType* create();
    virtual const SDLType* create_new() const;
    static const TYPE_TN_SN_StopMessageLogging& convert(const TYPE_TN_SN_StopMessageLogging&t) { return t; };
    
    TYPE_TN_SN_StopMessageLogging();
    TYPE_TN_SN_StopMessageLogging(SDLType**,unsigned long);
    TYPE_TN_SN_StopMessageLogging(const SDLNull&);
    TYPE_TN_SN_StopMessageLogging(const TYPE_TN_SN_StopMessageLogging&);
    virtual ~TYPE_TN_SN_StopMessageLogging();
    
    TYPE_TN_SN_StopMessageLogging& operator=(const TYPE_TN_SN_StopMessageLogging&);
    unsigned int hash(unsigned int max_hash)const;
    
    mutable SDLType* _fields[2?2:1];
    virtual void get_fields(SDLSeqSetDescription*&,SDLType**&);
    virtual void get_fields(SDLSeqSetDescription*&,SDLType *const*&)const;
    void set_field(int index,SDLType* value){
      _fields[index]=value;
    }
    
public:
    TYPE_TN_SN_StopMessageLogging(const class TYPE_DateTime&, const class TYPE_DateTime&);
    TYPE_DateTime& VAR_gpsTimeStamp() const;
    TYPE_DateTime& VAR_executeTime() const;
    const SDLBool& executeTimePresent()const;
    _TYPE_thistype executeTimeOmit()const;
    void _executeTimeOmit();
    
    AsnLen bEnc(BUF_TYPE) const;
    AsnLen bEncContent(BUF_TYPE) const;
    void bDec(BUF_TYPE,AsnLen&);
    void bDecContent(BUF_TYPE,AsnTag,AsnLen,AsnLen&);
    AsnLen pEnc(BUF_TYPE2 b) const;
    void pDec(BUF_TYPE2 b);
};

class PA_APManagingProtocol_API TYPE_APManagingProtocol_GEN_1: public SDLSetof<TYPE_APManagingProtocol_GEN_1,TYPE_IPAddress> {
    // typedef for use in macros
    typedef SDLSetof<TYPE_APManagingProtocol_GEN_1,TYPE_IPAddress> super;
public:
    TYPE_APManagingProtocol_GEN_1(const SDLAny&, AsnCodingSet rule_set=asn_ber);
    virtual const char* name() const { return "TYPE_APManagingProtocol_GEN_1"; }
    virtual SDLType* copy()const;
    virtual void assign(const SDLType* t);
    static SDLType* create();
    virtual const SDLType* create_new() const;
    static const TYPE_APManagingProtocol_GEN_1& convert(const TYPE_APManagingProtocol_GEN_1&t) { return t; };
    
    TYPE_APManagingProtocol_GEN_1(){ set_state(validValue); }
    TYPE_APManagingProtocol_GEN_1(const TYPE_IPAddress& elem):super(elem){}
    TYPE_APManagingProtocol_GEN_1(const super& base):super(base){}
    TYPE_APManagingProtocol_GEN_1(const SDLNull& n):super(n){}
    TYPE_APManagingProtocol_GEN_1(const TYPE_APManagingProtocol_GEN_1& base,SITE_SDL_INT reserve):super(base,reserve){}
    
public:
    static const TYPE_APManagingProtocol_GEN_1& LIT_Empty() { static TYPE_APManagingProtocol_GEN_1 v; return v; }
    AsnLen bEnc(BUF_TYPE) const;
    AsnLen bEncContent(BUF_TYPE) const;
    void bDec(BUF_TYPE,AsnLen&);
    void bDecContent(BUF_TYPE,AsnTag,AsnLen,AsnLen&);
};

class PA_APManagingProtocol_API TYPE_APManagingProtocol_GEN_2: public SDLSetof<TYPE_APManagingProtocol_GEN_2,TYPE_IPAddress> {
    // typedef for use in macros
    typedef SDLSetof<TYPE_APManagingProtocol_GEN_2,TYPE_IPAddress> super;
public:
    TYPE_APManagingProtocol_GEN_2(const SDLAny&, AsnCodingSet rule_set=asn_ber);
    virtual const char* name() const { return "TYPE_APManagingProtocol_GEN_2"; }
    virtual SDLType* copy()const;
    virtual void assign(const SDLType* t);
    static SDLType* create();
    virtual const SDLType* create_new() const;
    static const TYPE_APManagingProtocol_GEN_2& convert(const TYPE_APManagingProtocol_GEN_2&t) { return t; };
    
    TYPE_APManagingProtocol_GEN_2(){ set_state(validValue); }
    TYPE_APManagingProtocol_GEN_2(const TYPE_IPAddress& elem):super(elem){}
    TYPE_APManagingProtocol_GEN_2(const super& base):super(base){}
    TYPE_APManagingProtocol_GEN_2(const SDLNull& n):super(n){}
    TYPE_APManagingProtocol_GEN_2(const TYPE_APManagingProtocol_GEN_2& base,SITE_SDL_INT reserve):super(base,reserve){}
    
public:
    static const TYPE_APManagingProtocol_GEN_2& LIT_Empty() { static TYPE_APManagingProtocol_GEN_2 v; return v; }
    AsnLen bEnc(BUF_TYPE) const;
    AsnLen bEncContent(BUF_TYPE) const;
    void bDec(BUF_TYPE,AsnLen&);
    void bDecContent(BUF_TYPE,AsnTag,AsnLen,AsnLen&);
};

class PA_APManagingProtocol_API TYPE_APManagingProtocol_GEN_3: public SDLSetof<TYPE_APManagingProtocol_GEN_3,TYPE_IPAddress> {
    // typedef for use in macros
    typedef SDLSetof<TYPE_APManagingProtocol_GEN_3,TYPE_IPAddress> super;
public:
    TYPE_APManagingProtocol_GEN_3(const SDLAny&, AsnCodingSet rule_set=asn_ber);
    virtual const char* name() const { return "TYPE_APManagingProtocol_GEN_3"; }
    virtual SDLType* copy()const;
    virtual void assign(const SDLType* t);
    static SDLType* create();
    virtual const SDLType* create_new() const;
    static const TYPE_APManagingProtocol_GEN_3& convert(const TYPE_APManagingProtocol_GEN_3&t) { return t; };
    
    TYPE_APManagingProtocol_GEN_3(){ set_state(validValue); }
    TYPE_APManagingProtocol_GEN_3(const TYPE_IPAddress& elem):super(elem){}
    TYPE_APManagingProtocol_GEN_3(const super& base):super(base){}
    TYPE_APManagingProtocol_GEN_3(const SDLNull& n):super(n){}
    TYPE_APManagingProtocol_GEN_3(const TYPE_APManagingProtocol_GEN_3& base,SITE_SDL_INT reserve):super(base,reserve){}
    
public:
    static const TYPE_APManagingProtocol_GEN_3& LIT_Empty() { static TYPE_APManagingProtocol_GEN_3 v; return v; }
    AsnLen bEnc(BUF_TYPE) const;
    AsnLen bEncContent(BUF_TYPE) const;
    void bDec(BUF_TYPE,AsnLen&);
    void bDecContent(BUF_TYPE,AsnTag,AsnLen,AsnLen&);
};

class PA_APManagingProtocol_API TYPE_APManagingProtocol_GEN_4: public SDLIA5String {
public:
    TYPE_APManagingProtocol_GEN_4(const SDLAny&, AsnCodingSet rule_set=asn_ber);
    virtual const char* name() const { return "TYPE_APManagingProtocol_GEN_4"; }
    virtual SDLType* copy()const;
    virtual void assign(const SDLType* t);
    static SDLType* create();
    virtual const SDLType* create_new() const;
    static const TYPE_APManagingProtocol_GEN_4& convert(const TYPE_APManagingProtocol_GEN_4&t) { return t; };
    
public:
    TYPE_APManagingProtocol_GEN_4(const char *str,SITE_SDL_INT size = -1,bool no_copy=false):SDLIA5String(str,size,no_copy){}
    TYPE_APManagingProtocol_GEN_4(){}
    TYPE_APManagingProtocol_GEN_4(const SDLNull& n):SDLIA5String(n){}
    TYPE_APManagingProtocol_GEN_4(const SDLCharstring& base):SDLIA5String(base){}
    AsnLen pEnc(BUF_TYPE2) const;
    void pDec(BUF_TYPE2);
    const SDLBool& check() const;
};

class PA_APManagingProtocol_API TYPE_APManagingProtocol_GEN_5: public SDLSetof<TYPE_APManagingProtocol_GEN_5,TYPE_KeyValuePair> {
    // typedef for use in macros
    typedef SDLSetof<TYPE_APManagingProtocol_GEN_5,TYPE_KeyValuePair> super;
public:
    TYPE_APManagingProtocol_GEN_5(const SDLAny&, AsnCodingSet rule_set=asn_ber);
    virtual const char* name() const { return "TYPE_APManagingProtocol_GEN_5"; }
    virtual SDLType* copy()const;
    virtual void assign(const SDLType* t);
    static SDLType* create();
    virtual const SDLType* create_new() const;
    static const TYPE_APManagingProtocol_GEN_5& convert(const TYPE_APManagingProtocol_GEN_5&t) { return t; };
    
    TYPE_APManagingProtocol_GEN_5(){ set_state(validValue); }
    TYPE_APManagingProtocol_GEN_5(const TYPE_KeyValuePair& elem):super(elem){}
    TYPE_APManagingProtocol_GEN_5(const super& base):super(base){}
    TYPE_APManagingProtocol_GEN_5(const SDLNull& n):super(n){}
    TYPE_APManagingProtocol_GEN_5(const TYPE_APManagingProtocol_GEN_5& base,SITE_SDL_INT reserve):super(base,reserve){}
    
public:
    static const TYPE_APManagingProtocol_GEN_5& LIT_Empty() { static TYPE_APManagingProtocol_GEN_5 v; return v; }
    AsnLen bEnc(BUF_TYPE) const;
    AsnLen bEncContent(BUF_TYPE) const;
    void bDec(BUF_TYPE,AsnLen&);
    void bDecContent(BUF_TYPE,AsnTag,AsnLen,AsnLen&);
};

END_SITE_NAMESPACE
#include <sdlpackage.h>
#include <sdlblock.h>
#include <sdlchannel.h>
#include <sdlshell.h>

BEGIN_SITE_NAMESPACE(AP_GeneralProtocol)
extern int PA_APManagingProtocol507664_has_been_changed;

class PA_APManagingProtocol_API PA_APManagingProtocol : public SDLPackage 
{
    declareSDLPackage(PA_APManagingProtocol)
    PA_APManagingProtocol(const char *);
public:
    void init();
    ~PA_APManagingProtocol();
    static PA_APManagingProtocol* Instance();
    bool datainfo(long,class SDLIA5String&,SDLIA5String&,SDLType*&);
    const char * get_namespace() const { return "AP_GeneralProtocol"; }
}; /* PA_APManagingProtocol */

#define MY_PA_APManagingProtocol (PA_APManagingProtocol::Instance())

END_SITE_NAMESPACE
#endif
