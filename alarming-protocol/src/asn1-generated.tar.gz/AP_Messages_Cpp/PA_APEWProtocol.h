/* ===== PA_APEWProtocol.h ===== */

#ifndef PA_APEWProtocol_H
#define PA_APEWProtocol_H
#include <sdlconfig.h>
/* Note: DLL_SUPPORT depends on the sequence of includes,
         PA_APEWProtocol not! */
#ifdef PA_APEWProtocol_LIB
#define PA_APEWProtocol_API DllExport
#else
#define PA_APEWProtocol_API DllImport
#endif
#undef DLL_SUPPORT
#undef SDLARRAY_EXPORT
#ifdef PA_APEWProtocol_LIB
#define DLL_SUPPORT DllExport
#define SDLARRAY_EXPORT DllExport
#else
#define DLL_SUPPORT DllImport
#define SDLARRAY_EXPORT DllImport
#endif
#include <sdltimer.h>

BEGIN_SITE_NAMESPACE(AP_GeneralProtocol)

class PA_APEWProtocol_API TYPE_APEWProtocol;
class PA_APEWProtocol_API TYPE_Acceleration;
#define TYPE_Velocity SDLReal
#define TYPE_Displacement SDLReal
#define TYPE_Frequency SDLReal
#define TYPE_IPAddress SDLIA5String
#define TYPE_EventID SDLInt
class PA_APEWProtocol_API TYPE_GroupID;
class PA_APEWProtocol_API TYPE_DateTime;
class PA_APEWProtocol_API TYPE_GeographicCoordinate;
class PA_APEWProtocol_API TYPE_SensorAccelerationAverage;
class PA_APEWProtocol_API TYPE_SensorAcceleration;
class PA_APEWProtocol_API TYPE_SensorVelocity;
class PA_APEWProtocol_API TYPE_SensorDisplacement;
class PA_APEWProtocol_API TYPE_SN_LN_Idle;
class PA_APEWProtocol_API TYPE_SN_LN_Detection;
class PA_APEWProtocol_API TYPE_SN_LN_Description;
class PA_APEWProtocol_API TYPE_SN_LN_Summary;
class PA_APEWProtocol_API TYPE_ResponseSpectra;
class PA_APEWProtocol_API TYPE_SN_LN_PositionChange;
class PA_APEWProtocol_API TYPE_StatusSNInfo;
class PA_APEWProtocol_API TYPE_LN_SN_Alarm;
class PA_APEWProtocol_API TYPE_LN_SN_FalseAlarm;
class PA_APEWProtocol_API TYPE_LN_SN_Describe;
class PA_APEWProtocol_API TYPE_LN_SN_Summarise;
class PA_APEWProtocol_API TYPE_BreakdownReason;
class PA_APEWProtocol_API TYPE_InoperativeSNInfo;
class PA_APEWProtocol_API TYPE_TriggeredSNInfo;
class PA_APEWProtocol_API TYPE_LN_LN_Idle;
class PA_APEWProtocol_API TYPE_LN_LN_Detection;
class PA_APEWProtocol_API TYPE_LN_LN_Alarm;
class PA_APEWProtocol_API TYPE_LN_LN_Description;
class PA_APEWProtocol_API TYPE_LN_EN_Alarm;
class PA_APEWProtocol_API TYPE_LN_EN_Summary;
class PA_APEWProtocol_API TYPE_APEWProtocol_GEN_1;
class PA_APEWProtocol_API TYPE_APEWProtocol_GEN_2;
class PA_APEWProtocol_API TYPE_APEWProtocol_GEN_3;
class PA_APEWProtocol_API TYPE_APEWProtocol_GEN_4;
class PA_APEWProtocol_API TYPE_APEWProtocol_GEN_5;
#define TYPE_APEWProtocol_GEN_6 SDLReal
class PA_APEWProtocol_API TYPE_APEWProtocol_GEN_7;
class PA_APEWProtocol_API TYPE_APEWProtocol_GEN_8;
class PA_APEWProtocol_API TYPE_APEWProtocol_GEN_9;
class PA_APEWProtocol_API TYPE_APEWProtocol_GEN_10;
class PA_APEWProtocol_API TYPE_APEWProtocol_GEN_11;
class PA_APEWProtocol_API TYPE_APEWProtocol_GEN_12;
class PA_APEWProtocol_API TYPE_APEWProtocol_GEN_13;
class PA_APEWProtocol_API TYPE_APEWProtocol_GEN_14;
class PA_APEWProtocol_API TYPE_APEWProtocol_GEN_15;
class PA_APEWProtocol_API TYPE_APEWProtocol_GEN_16;
class PA_APEWProtocol_API TYPE_APEWProtocol_GEN_17;
class PA_APEWProtocol_API TYPE_APEWProtocol_GEN_18;

class PA_APEWProtocol_API TYPE_APEWProtocol: public SDLChoice {
public:
    TYPE_APEWProtocol(const SDLAny&, AsnCodingSet rule_set=asn_ber);
    virtual const char* name() const { return "TYPE_APEWProtocol"; }
    virtual SDLType* copy()const;
    virtual void assign(const SDLType* t);
    static SDLType* create();
    virtual const SDLType* create_new() const;
    static const TYPE_APEWProtocol& convert(const TYPE_APEWProtocol&t) { return t; };
    
public:
    TYPE_APEWProtocol(unsigned int i,const SDLType& elem) { assign_field(i,elem); }
    TYPE_APEWProtocol(){}
    TYPE_APEWProtocol(const SDLNull& n):SDLChoice(n){}
    TYPE_APEWProtocol(const TYPE_APEWProtocol& base):SDLChoice(base){}
    enum {
        CHOICE_NoAssign,
        CHOICE_mSN_LN_Idle,
        CHOICE_mSN_LN_Detection,
        CHOICE_mSN_LN_Description,
        CHOICE_mSN_LN_Summary,
        CHOICE_mSN_LN_PositionChange,
        CHOICE_mLN_SN_Alarm,
        CHOICE_mLN_SN_FalseAlarm,
        CHOICE_mLN_SN_Describe,
        CHOICE_mLN_SN_Summarise,
        CHOICE_mLN_LN_Idle,
        CHOICE_mLN_LN_Detection,
        CHOICE_mLN_LN_Alarm,
        CHOICE_mLN_LN_Description,
        CHOICE_mLN_EN_Alarm,
        CHOICE_mLN_EN_Summary
    };
    const SDLBool& mSN_LN_IdlePresent()const
    { return (_present == CHOICE_mSN_LN_Idle)?SDLBool::SDLTrue():SDLBool::SDLFalse(); }
    TYPE_SN_LN_Idle& VAR_mSN_LN_Idle() const;
    const SDLBool& mSN_LN_DetectionPresent()const
    { return (_present == CHOICE_mSN_LN_Detection)?SDLBool::SDLTrue():SDLBool::SDLFalse(); }
    TYPE_SN_LN_Detection& VAR_mSN_LN_Detection() const;
    const SDLBool& mSN_LN_DescriptionPresent()const
    { return (_present == CHOICE_mSN_LN_Description)?SDLBool::SDLTrue():SDLBool::SDLFalse(); }
    TYPE_SN_LN_Description& VAR_mSN_LN_Description() const;
    const SDLBool& mSN_LN_SummaryPresent()const
    { return (_present == CHOICE_mSN_LN_Summary)?SDLBool::SDLTrue():SDLBool::SDLFalse(); }
    TYPE_SN_LN_Summary& VAR_mSN_LN_Summary() const;
    const SDLBool& mSN_LN_PositionChangePresent()const
    { return (_present == CHOICE_mSN_LN_PositionChange)?SDLBool::SDLTrue():SDLBool::SDLFalse(); }
    TYPE_SN_LN_PositionChange& VAR_mSN_LN_PositionChange() const;
    const SDLBool& mLN_SN_AlarmPresent()const
    { return (_present == CHOICE_mLN_SN_Alarm)?SDLBool::SDLTrue():SDLBool::SDLFalse(); }
    TYPE_LN_SN_Alarm& VAR_mLN_SN_Alarm() const;
    const SDLBool& mLN_SN_FalseAlarmPresent()const
    { return (_present == CHOICE_mLN_SN_FalseAlarm)?SDLBool::SDLTrue():SDLBool::SDLFalse(); }
    TYPE_LN_SN_FalseAlarm& VAR_mLN_SN_FalseAlarm() const;
    const SDLBool& mLN_SN_DescribePresent()const
    { return (_present == CHOICE_mLN_SN_Describe)?SDLBool::SDLTrue():SDLBool::SDLFalse(); }
    TYPE_LN_SN_Describe& VAR_mLN_SN_Describe() const;
    const SDLBool& mLN_SN_SummarisePresent()const
    { return (_present == CHOICE_mLN_SN_Summarise)?SDLBool::SDLTrue():SDLBool::SDLFalse(); }
    TYPE_LN_SN_Summarise& VAR_mLN_SN_Summarise() const;
    const SDLBool& mLN_LN_IdlePresent()const
    { return (_present == CHOICE_mLN_LN_Idle)?SDLBool::SDLTrue():SDLBool::SDLFalse(); }
    TYPE_LN_LN_Idle& VAR_mLN_LN_Idle() const;
    const SDLBool& mLN_LN_DetectionPresent()const
    { return (_present == CHOICE_mLN_LN_Detection)?SDLBool::SDLTrue():SDLBool::SDLFalse(); }
    TYPE_LN_LN_Detection& VAR_mLN_LN_Detection() const;
    const SDLBool& mLN_LN_AlarmPresent()const
    { return (_present == CHOICE_mLN_LN_Alarm)?SDLBool::SDLTrue():SDLBool::SDLFalse(); }
    TYPE_LN_LN_Alarm& VAR_mLN_LN_Alarm() const;
    const SDLBool& mLN_LN_DescriptionPresent()const
    { return (_present == CHOICE_mLN_LN_Description)?SDLBool::SDLTrue():SDLBool::SDLFalse(); }
    TYPE_LN_LN_Description& VAR_mLN_LN_Description() const;
    const SDLBool& mLN_EN_AlarmPresent()const
    { return (_present == CHOICE_mLN_EN_Alarm)?SDLBool::SDLTrue():SDLBool::SDLFalse(); }
    TYPE_LN_EN_Alarm& VAR_mLN_EN_Alarm() const;
    const SDLBool& mLN_EN_SummaryPresent()const
    { return (_present == CHOICE_mLN_EN_Summary)?SDLBool::SDLTrue():SDLBool::SDLFalse(); }
    TYPE_LN_EN_Summary& VAR_mLN_EN_Summary() const;
    void assign_field(unsigned int variant,const SDLType& elem);
    AsnLen bEnc(BUF_TYPE) const;
    AsnLen bEncContent(BUF_TYPE) const;
    void bDec(BUF_TYPE,AsnLen&);
    void bDecContent(BUF_TYPE,AsnTag,AsnLen,AsnLen&);
    AsnLen pEnc(BUF_TYPE2 b) const;
    void pDec(BUF_TYPE2 b);
    bool datainfo(long,SDLIA5String&,SDLIA5String&,SDLType*&,SDLType::infotype);
};

class PA_APEWProtocol_API TYPE_Acceleration: public SDLReal {
public:
    TYPE_Acceleration(const SDLAny&, AsnCodingSet rule_set=asn_ber);
    virtual const char* name() const { return "TYPE_Acceleration"; }
    virtual SDLType* copy()const;
    virtual void assign(const SDLType* t);
    static SDLType* create();
    virtual const SDLType* create_new() const;
    static const TYPE_Acceleration& convert(const TYPE_Acceleration&t) { return t; };
    
public:
    TYPE_Acceleration(double d):SDLReal(d){}
    TYPE_Acceleration(SITE_SDL_INT mantissa,SITE_SDL_INT base,SITE_SDL_INT exp):SDLReal(mantissa,base,exp){}
    TYPE_Acceleration(){}
    TYPE_Acceleration(const SDLNull& n):SDLReal(n){}
    TYPE_Acceleration(const SDLReal& base):SDLReal(base){}
    const SDLBool& check() const;
};

class PA_APEWProtocol_API TYPE_GroupID: public SDLInt {
public:
    TYPE_GroupID(const SDLAny&, AsnCodingSet rule_set=asn_ber);
    virtual const char* name() const { return "TYPE_GroupID"; }
    virtual SDLType* copy()const;
    virtual void assign(const SDLType* t);
    static SDLType* create();
    virtual const SDLType* create_new() const;
    static const TYPE_GroupID& convert(const TYPE_GroupID&t) { return t; };
    
public:
    TYPE_GroupID(SITE_SDL_INT l):SDLInt(l){}
    TYPE_GroupID(){}
    TYPE_GroupID(const SDLNull& n):SDLInt(n){}
    TYPE_GroupID(const SDLInt& base):SDLInt(base){}
    AsnLen pEnc(BUF_TYPE2) const;
    void pDec(BUF_TYPE2);
    const SDLBool& check() const;
};

class PA_APEWProtocol_API TYPE_DateTime: public SDLSequence {
    typedef TYPE_DateTime _TYPE_thistype;
public:
    static SDLSeqSetDescription _fdesc;
public:
    TYPE_DateTime(const SDLAny&, AsnCodingSet rule_set=asn_ber);
    virtual const char* name() const { return "TYPE_DateTime"; }
    virtual SDLType* copy()const;
    virtual void assign(const SDLType* t);
    static SDLType* create();
    virtual const SDLType* create_new() const;
    static const TYPE_DateTime& convert(const TYPE_DateTime&t) { return t; };
    
    TYPE_DateTime();
    TYPE_DateTime(SDLType**,unsigned long);
    TYPE_DateTime(const SDLNull&);
    TYPE_DateTime(const TYPE_DateTime&);
    virtual ~TYPE_DateTime();
    
    TYPE_DateTime& operator=(const TYPE_DateTime&);
    unsigned int hash(unsigned int max_hash)const;
    
    mutable SDLType* _fields[2?2:1];
    virtual void get_fields(SDLSeqSetDescription*&,SDLType**&);
    virtual void get_fields(SDLSeqSetDescription*&,SDLType *const*&)const;
    void set_field(int index,SDLType* value){
      _fields[index]=value;
    }
    
public:
    TYPE_DateTime(const class TYPE_APEWProtocol_GEN_1&, const class TYPE_APEWProtocol_GEN_2&);
    TYPE_APEWProtocol_GEN_1& VAR_unixTime() const;
    TYPE_APEWProtocol_GEN_2& VAR_msFraction() const;
    AsnLen bEnc(BUF_TYPE) const;
    AsnLen bEncContent(BUF_TYPE) const;
    void bDec(BUF_TYPE,AsnLen&);
    void bDecContent(BUF_TYPE,AsnTag,AsnLen,AsnLen&);
    AsnLen pEnc(BUF_TYPE2 b) const;
    void pDec(BUF_TYPE2 b);
};

class PA_APEWProtocol_API TYPE_GeographicCoordinate: public SDLSequence {
    typedef TYPE_GeographicCoordinate _TYPE_thistype;
public:
    static SDLSeqSetDescription _fdesc;
public:
    TYPE_GeographicCoordinate(const SDLAny&, AsnCodingSet rule_set=asn_ber);
    virtual const char* name() const { return "TYPE_GeographicCoordinate"; }
    virtual SDLType* copy()const;
    virtual void assign(const SDLType* t);
    static SDLType* create();
    virtual const SDLType* create_new() const;
    static const TYPE_GeographicCoordinate& convert(const TYPE_GeographicCoordinate&t) { return t; };
    
    TYPE_GeographicCoordinate();
    TYPE_GeographicCoordinate(SDLType**,unsigned long);
    TYPE_GeographicCoordinate(const SDLNull&);
    TYPE_GeographicCoordinate(const TYPE_GeographicCoordinate&);
    virtual ~TYPE_GeographicCoordinate();
    
    TYPE_GeographicCoordinate& operator=(const TYPE_GeographicCoordinate&);
    unsigned int hash(unsigned int max_hash)const;
    
    mutable SDLType* _fields[3?3:1];
    virtual void get_fields(SDLSeqSetDescription*&,SDLType**&);
    virtual void get_fields(SDLSeqSetDescription*&,SDLType *const*&)const;
    void set_field(int index,SDLType* value){
      _fields[index]=value;
    }
    
public:
    TYPE_GeographicCoordinate(const class TYPE_APEWProtocol_GEN_3&, const class TYPE_APEWProtocol_GEN_4&, const class TYPE_APEWProtocol_GEN_5&);
    TYPE_APEWProtocol_GEN_3& VAR_latitude() const;
    TYPE_APEWProtocol_GEN_4& VAR_longitude() const;
    TYPE_APEWProtocol_GEN_5& VAR_height() const;
    const SDLBool& heightPresent()const;
    _TYPE_thistype heightOmit()const;
    void _heightOmit();
    
    AsnLen bEnc(BUF_TYPE) const;
    AsnLen bEncContent(BUF_TYPE) const;
    void bDec(BUF_TYPE,AsnLen&);
    void bDecContent(BUF_TYPE,AsnTag,AsnLen,AsnLen&);
    AsnLen pEnc(BUF_TYPE2 b) const;
    void pDec(BUF_TYPE2 b);
};

class PA_APEWProtocol_API TYPE_SensorAccelerationAverage: public SDLSequence {
    typedef TYPE_SensorAccelerationAverage _TYPE_thistype;
public:
    static SDLSeqSetDescription _fdesc;
public:
    TYPE_SensorAccelerationAverage(const SDLAny&, AsnCodingSet rule_set=asn_ber);
    virtual const char* name() const { return "TYPE_SensorAccelerationAverage"; }
    virtual SDLType* copy()const;
    virtual void assign(const SDLType* t);
    static SDLType* create();
    virtual const SDLType* create_new() const;
    static const TYPE_SensorAccelerationAverage& convert(const TYPE_SensorAccelerationAverage&t) { return t; };
    
    TYPE_SensorAccelerationAverage();
    TYPE_SensorAccelerationAverage(SDLType**,unsigned long);
    TYPE_SensorAccelerationAverage(const SDLNull&);
    TYPE_SensorAccelerationAverage(const TYPE_SensorAccelerationAverage&);
    virtual ~TYPE_SensorAccelerationAverage();
    
    TYPE_SensorAccelerationAverage& operator=(const TYPE_SensorAccelerationAverage&);
    unsigned int hash(unsigned int max_hash)const;
    
    mutable SDLType* _fields[2?2:1];
    virtual void get_fields(SDLSeqSetDescription*&,SDLType**&);
    virtual void get_fields(SDLSeqSetDescription*&,SDLType *const*&)const;
    void set_field(int index,SDLType* value){
      _fields[index]=value;
    }
    
public:
    TYPE_SensorAccelerationAverage(const class TYPE_SensorAcceleration&, const class TYPE_APEWProtocol_GEN_7&);
    TYPE_SensorAcceleration& VAR_acceleration() const;
    TYPE_APEWProtocol_GEN_7& VAR_timeWindowLength() const;
    AsnLen bEnc(BUF_TYPE) const;
    AsnLen bEncContent(BUF_TYPE) const;
    void bDec(BUF_TYPE,AsnLen&);
    void bDecContent(BUF_TYPE,AsnTag,AsnLen,AsnLen&);
    AsnLen pEnc(BUF_TYPE2 b) const;
    void pDec(BUF_TYPE2 b);
};

class PA_APEWProtocol_API TYPE_SensorAcceleration: public SDLSequence {
    typedef TYPE_SensorAcceleration _TYPE_thistype;
public:
    static SDLSeqSetDescription _fdesc;
public:
    TYPE_SensorAcceleration(const SDLAny&, AsnCodingSet rule_set=asn_ber);
    virtual const char* name() const { return "TYPE_SensorAcceleration"; }
    virtual SDLType* copy()const;
    virtual void assign(const SDLType* t);
    static SDLType* create();
    virtual const SDLType* create_new() const;
    static const TYPE_SensorAcceleration& convert(const TYPE_SensorAcceleration&t) { return t; };
    
    TYPE_SensorAcceleration();
    TYPE_SensorAcceleration(SDLType**,unsigned long);
    TYPE_SensorAcceleration(const SDLNull&);
    TYPE_SensorAcceleration(const TYPE_SensorAcceleration&);
    virtual ~TYPE_SensorAcceleration();
    
    TYPE_SensorAcceleration& operator=(const TYPE_SensorAcceleration&);
    unsigned int hash(unsigned int max_hash)const;
    
    mutable SDLType* _fields[3?3:1];
    virtual void get_fields(SDLSeqSetDescription*&,SDLType**&);
    virtual void get_fields(SDLSeqSetDescription*&,SDLType *const*&)const;
    void set_field(int index,SDLType* value){
      _fields[index]=value;
    }
    
public:
    TYPE_SensorAcceleration(const class TYPE_Acceleration&, const class TYPE_Acceleration&, const class TYPE_Acceleration&);
    TYPE_Acceleration& VAR_e() const;
    TYPE_Acceleration& VAR_n() const;
    TYPE_Acceleration& VAR_z() const;
    AsnLen bEnc(BUF_TYPE) const;
    AsnLen bEncContent(BUF_TYPE) const;
    void bDec(BUF_TYPE,AsnLen&);
    void bDecContent(BUF_TYPE,AsnTag,AsnLen,AsnLen&);
    AsnLen pEnc(BUF_TYPE2 b) const;
    void pDec(BUF_TYPE2 b);
};

class PA_APEWProtocol_API TYPE_SensorVelocity: public SDLSequence {
    typedef TYPE_SensorVelocity _TYPE_thistype;
public:
    static SDLSeqSetDescription _fdesc;
public:
    TYPE_SensorVelocity(const SDLAny&, AsnCodingSet rule_set=asn_ber);
    virtual const char* name() const { return "TYPE_SensorVelocity"; }
    virtual SDLType* copy()const;
    virtual void assign(const SDLType* t);
    static SDLType* create();
    virtual const SDLType* create_new() const;
    static const TYPE_SensorVelocity& convert(const TYPE_SensorVelocity&t) { return t; };
    
    TYPE_SensorVelocity();
    TYPE_SensorVelocity(SDLType**,unsigned long);
    TYPE_SensorVelocity(const SDLNull&);
    TYPE_SensorVelocity(const TYPE_SensorVelocity&);
    virtual ~TYPE_SensorVelocity();
    
    TYPE_SensorVelocity& operator=(const TYPE_SensorVelocity&);
    unsigned int hash(unsigned int max_hash)const;
    
    mutable SDLType* _fields[3?3:1];
    virtual void get_fields(SDLSeqSetDescription*&,SDLType**&);
    virtual void get_fields(SDLSeqSetDescription*&,SDLType *const*&)const;
    void set_field(int index,SDLType* value){
      _fields[index]=value;
    }
    
public:
    TYPE_SensorVelocity(const class TYPE_Velocity&, const class TYPE_Velocity&, const class TYPE_Velocity&);
    TYPE_Velocity& VAR_e() const;
    TYPE_Velocity& VAR_n() const;
    TYPE_Velocity& VAR_z() const;
    AsnLen bEnc(BUF_TYPE) const;
    AsnLen bEncContent(BUF_TYPE) const;
    void bDec(BUF_TYPE,AsnLen&);
    void bDecContent(BUF_TYPE,AsnTag,AsnLen,AsnLen&);
    AsnLen pEnc(BUF_TYPE2 b) const;
    void pDec(BUF_TYPE2 b);
};

class PA_APEWProtocol_API TYPE_SensorDisplacement: public SDLSequence {
    typedef TYPE_SensorDisplacement _TYPE_thistype;
public:
    static SDLSeqSetDescription _fdesc;
public:
    TYPE_SensorDisplacement(const SDLAny&, AsnCodingSet rule_set=asn_ber);
    virtual const char* name() const { return "TYPE_SensorDisplacement"; }
    virtual SDLType* copy()const;
    virtual void assign(const SDLType* t);
    static SDLType* create();
    virtual const SDLType* create_new() const;
    static const TYPE_SensorDisplacement& convert(const TYPE_SensorDisplacement&t) { return t; };
    
    TYPE_SensorDisplacement();
    TYPE_SensorDisplacement(SDLType**,unsigned long);
    TYPE_SensorDisplacement(const SDLNull&);
    TYPE_SensorDisplacement(const TYPE_SensorDisplacement&);
    virtual ~TYPE_SensorDisplacement();
    
    TYPE_SensorDisplacement& operator=(const TYPE_SensorDisplacement&);
    unsigned int hash(unsigned int max_hash)const;
    
    mutable SDLType* _fields[3?3:1];
    virtual void get_fields(SDLSeqSetDescription*&,SDLType**&);
    virtual void get_fields(SDLSeqSetDescription*&,SDLType *const*&)const;
    void set_field(int index,SDLType* value){
      _fields[index]=value;
    }
    
public:
    TYPE_SensorDisplacement(const class TYPE_Displacement&, const class TYPE_Displacement&, const class TYPE_Displacement&);
    TYPE_Displacement& VAR_e() const;
    TYPE_Displacement& VAR_n() const;
    TYPE_Displacement& VAR_z() const;
    AsnLen bEnc(BUF_TYPE) const;
    AsnLen bEncContent(BUF_TYPE) const;
    void bDec(BUF_TYPE,AsnLen&);
    void bDecContent(BUF_TYPE,AsnTag,AsnLen,AsnLen&);
    AsnLen pEnc(BUF_TYPE2 b) const;
    void pDec(BUF_TYPE2 b);
};

class PA_APEWProtocol_API TYPE_SN_LN_Idle: public SDLSequence {
    typedef TYPE_SN_LN_Idle _TYPE_thistype;
public:
    static SDLSeqSetDescription _fdesc;
public:
    TYPE_SN_LN_Idle(const SDLAny&, AsnCodingSet rule_set=asn_ber);
    virtual const char* name() const { return "TYPE_SN_LN_Idle"; }
    virtual SDLType* copy()const;
    virtual void assign(const SDLType* t);
    static SDLType* create();
    virtual const SDLType* create_new() const;
    static const TYPE_SN_LN_Idle& convert(const TYPE_SN_LN_Idle&t) { return t; };
    
    TYPE_SN_LN_Idle();
    TYPE_SN_LN_Idle(SDLType**,unsigned long);
    TYPE_SN_LN_Idle(const SDLNull&);
    TYPE_SN_LN_Idle(const TYPE_SN_LN_Idle&);
    virtual ~TYPE_SN_LN_Idle();
    
    TYPE_SN_LN_Idle& operator=(const TYPE_SN_LN_Idle&);
    unsigned int hash(unsigned int max_hash)const;
    
    mutable SDLType* _fields[4?4:1];
    virtual void get_fields(SDLSeqSetDescription*&,SDLType**&);
    virtual void get_fields(SDLSeqSetDescription*&,SDLType *const*&)const;
    void set_field(int index,SDLType* value){
      _fields[index]=value;
    }
    
public:
    TYPE_SN_LN_Idle(const class TYPE_DateTime&, const class TYPE_SensorAccelerationAverage&, const class SDLReal&, const class SDLReal&);
    TYPE_DateTime& VAR_gpsTimeStamp() const;
    TYPE_SensorAccelerationAverage& VAR_noiseAverage() const;
    SDLReal& VAR_batteryVoltage() const;
    const SDLBool& batteryVoltagePresent()const;
    _TYPE_thistype batteryVoltageOmit()const;
    void _batteryVoltageOmit();
    
    SDLReal& VAR_valueFourthChannel() const;
    const SDLBool& valueFourthChannelPresent()const;
    _TYPE_thistype valueFourthChannelOmit()const;
    void _valueFourthChannelOmit();
    
    AsnLen bEnc(BUF_TYPE) const;
    AsnLen bEncContent(BUF_TYPE) const;
    void bDec(BUF_TYPE,AsnLen&);
    void bDecContent(BUF_TYPE,AsnTag,AsnLen,AsnLen&);
    AsnLen pEnc(BUF_TYPE2 b) const;
    void pDec(BUF_TYPE2 b);
};

class PA_APEWProtocol_API TYPE_SN_LN_Detection: public SDLSequence {
    typedef TYPE_SN_LN_Detection _TYPE_thistype;
public:
    static SDLSeqSetDescription _fdesc;
public:
    TYPE_SN_LN_Detection(const SDLAny&, AsnCodingSet rule_set=asn_ber);
    virtual const char* name() const { return "TYPE_SN_LN_Detection"; }
    virtual SDLType* copy()const;
    virtual void assign(const SDLType* t);
    static SDLType* create();
    virtual const SDLType* create_new() const;
    static const TYPE_SN_LN_Detection& convert(const TYPE_SN_LN_Detection&t) { return t; };
    
    TYPE_SN_LN_Detection();
    TYPE_SN_LN_Detection(SDLType**,unsigned long);
    TYPE_SN_LN_Detection(const SDLNull&);
    TYPE_SN_LN_Detection(const TYPE_SN_LN_Detection&);
    virtual ~TYPE_SN_LN_Detection();
    
    TYPE_SN_LN_Detection& operator=(const TYPE_SN_LN_Detection&);
    unsigned int hash(unsigned int max_hash)const;
    
    mutable SDLType* _fields[8?8:1];
    virtual void get_fields(SDLSeqSetDescription*&,SDLType**&);
    virtual void get_fields(SDLSeqSetDescription*&,SDLType *const*&)const;
    void set_field(int index,SDLType* value){
      _fields[index]=value;
    }
    
public:
    TYPE_SN_LN_Detection(const class TYPE_DateTime&, const class TYPE_DateTime&, const class TYPE_SensorAcceleration&, const class TYPE_SensorVelocity&, const class TYPE_SensorDisplacement&, const class TYPE_SensorAccelerationAverage&, const class SDLReal&, const class SDLReal&);
    TYPE_DateTime& VAR_gpsTimeStamp() const;
    TYPE_DateTime& VAR_tp() const;
    TYPE_SensorAcceleration& VAR_a_max() const;
    TYPE_SensorVelocity& VAR_v_max() const;
    TYPE_SensorDisplacement& VAR_d_max() const;
    TYPE_SensorAccelerationAverage& VAR_noiseAverage() const;
    SDLReal& VAR_valueFourthChannel() const;
    const SDLBool& valueFourthChannelPresent()const;
    _TYPE_thistype valueFourthChannelOmit()const;
    void _valueFourthChannelOmit();
    
    SDLReal& VAR_sta_lta_TriggerValue() const;
    AsnLen bEnc(BUF_TYPE) const;
    AsnLen bEncContent(BUF_TYPE) const;
    void bDec(BUF_TYPE,AsnLen&);
    void bDecContent(BUF_TYPE,AsnTag,AsnLen,AsnLen&);
    AsnLen pEnc(BUF_TYPE2 b) const;
    void pDec(BUF_TYPE2 b);
};

class PA_APEWProtocol_API TYPE_SN_LN_Description: public SDLSequence {
    typedef TYPE_SN_LN_Description _TYPE_thistype;
public:
    static SDLSeqSetDescription _fdesc;
public:
    TYPE_SN_LN_Description(const SDLAny&, AsnCodingSet rule_set=asn_ber);
    virtual const char* name() const { return "TYPE_SN_LN_Description"; }
    virtual SDLType* copy()const;
    virtual void assign(const SDLType* t);
    static SDLType* create();
    virtual const SDLType* create_new() const;
    static const TYPE_SN_LN_Description& convert(const TYPE_SN_LN_Description&t) { return t; };
    
    TYPE_SN_LN_Description();
    TYPE_SN_LN_Description(SDLType**,unsigned long);
    TYPE_SN_LN_Description(const SDLNull&);
    TYPE_SN_LN_Description(const TYPE_SN_LN_Description&);
    virtual ~TYPE_SN_LN_Description();
    
    TYPE_SN_LN_Description& operator=(const TYPE_SN_LN_Description&);
    unsigned int hash(unsigned int max_hash)const;
    
    mutable SDLType* _fields[11?11:1];
    virtual void get_fields(SDLSeqSetDescription*&,SDLType**&);
    virtual void get_fields(SDLSeqSetDescription*&,SDLType *const*&)const;
    void set_field(int index,SDLType* value){
      _fields[index]=value;
    }
    
public:
    TYPE_SN_LN_Description(const class TYPE_DateTime&, const class TYPE_DateTime&, const class TYPE_APEWProtocol_GEN_8&, const class TYPE_SensorAcceleration&, const class TYPE_SensorVelocity&, const class TYPE_SensorDisplacement&, const class TYPE_SensorAccelerationAverage&, const class SDLReal&, const class SDLReal&, const class SDLReal&, const class SDLReal&);
    TYPE_DateTime& VAR_gpsTimeStamp() const;
    TYPE_DateTime& VAR_tp() const;
    TYPE_APEWProtocol_GEN_8& VAR_waveType() const;
    TYPE_SensorAcceleration& VAR_pga() const;
    TYPE_SensorVelocity& VAR_pgv() const;
    TYPE_SensorDisplacement& VAR_pgd() const;
    TYPE_SensorAccelerationAverage& VAR_noiseAverage() const;
    SDLReal& VAR_predominantPeriod() const;
    const SDLBool& predominantPeriodPresent()const;
    _TYPE_thistype predominantPeriodOmit()const;
    void _predominantPeriodOmit();
    
    SDLReal& VAR_cav() const;
    SDLReal& VAR_ariasIntensity() const;
    SDLReal& VAR_valueFourthChannel() const;
    const SDLBool& valueFourthChannelPresent()const;
    _TYPE_thistype valueFourthChannelOmit()const;
    void _valueFourthChannelOmit();
    
    AsnLen bEnc(BUF_TYPE) const;
    AsnLen bEncContent(BUF_TYPE) const;
    void bDec(BUF_TYPE,AsnLen&);
    void bDecContent(BUF_TYPE,AsnTag,AsnLen,AsnLen&);
    AsnLen pEnc(BUF_TYPE2 b) const;
    void pDec(BUF_TYPE2 b);
};

class PA_APEWProtocol_API TYPE_SN_LN_Summary: public SDLSequence {
    typedef TYPE_SN_LN_Summary _TYPE_thistype;
public:
    static SDLSeqSetDescription _fdesc;
public:
    TYPE_SN_LN_Summary(const SDLAny&, AsnCodingSet rule_set=asn_ber);
    virtual const char* name() const { return "TYPE_SN_LN_Summary"; }
    virtual SDLType* copy()const;
    virtual void assign(const SDLType* t);
    static SDLType* create();
    virtual const SDLType* create_new() const;
    static const TYPE_SN_LN_Summary& convert(const TYPE_SN_LN_Summary&t) { return t; };
    
    TYPE_SN_LN_Summary();
    TYPE_SN_LN_Summary(SDLType**,unsigned long);
    TYPE_SN_LN_Summary(const SDLNull&);
    TYPE_SN_LN_Summary(const TYPE_SN_LN_Summary&);
    virtual ~TYPE_SN_LN_Summary();
    
    TYPE_SN_LN_Summary& operator=(const TYPE_SN_LN_Summary&);
    unsigned int hash(unsigned int max_hash)const;
    
    mutable SDLType* _fields[12?12:1];
    virtual void get_fields(SDLSeqSetDescription*&,SDLType**&);
    virtual void get_fields(SDLSeqSetDescription*&,SDLType *const*&)const;
    void set_field(int index,SDLType* value){
      _fields[index]=value;
    }
    
public:
    TYPE_SN_LN_Summary(const class TYPE_DateTime&, const class TYPE_DateTime&, const class TYPE_DateTime&, const class TYPE_DateTime&, const class TYPE_SensorAcceleration&, const class TYPE_SensorVelocity&, const class TYPE_SensorDisplacement&, const class TYPE_SensorAccelerationAverage&, const class SDLReal&, const class SDLReal&, const class SDLReal&, const class SDLReal&);
    TYPE_DateTime& VAR_gpsTimeStamp() const;
    TYPE_DateTime& VAR_t_p() const;
    TYPE_DateTime& VAR_t_s() const;
    TYPE_DateTime& VAR_t_end() const;
    TYPE_SensorAcceleration& VAR_pga() const;
    TYPE_SensorVelocity& VAR_pgv() const;
    TYPE_SensorDisplacement& VAR_pgd() const;
    TYPE_SensorAccelerationAverage& VAR_noiseAverage() const;
    SDLReal& VAR_cav() const;
    SDLReal& VAR_ariasIntensity() const;
    SDLReal& VAR_valueFourthChannel() const;
    const SDLBool& valueFourthChannelPresent()const;
    _TYPE_thistype valueFourthChannelOmit()const;
    void _valueFourthChannelOmit();
    
    SDLReal& VAR_batteryVoltage() const;
    const SDLBool& batteryVoltagePresent()const;
    _TYPE_thistype batteryVoltageOmit()const;
    void _batteryVoltageOmit();
    
    AsnLen bEnc(BUF_TYPE) const;
    AsnLen bEncContent(BUF_TYPE) const;
    void bDec(BUF_TYPE,AsnLen&);
    void bDecContent(BUF_TYPE,AsnTag,AsnLen,AsnLen&);
    AsnLen pEnc(BUF_TYPE2 b) const;
    void pDec(BUF_TYPE2 b);
};

class PA_APEWProtocol_API TYPE_ResponseSpectra: public SDLSequence {
    typedef TYPE_ResponseSpectra _TYPE_thistype;
public:
    static SDLSeqSetDescription _fdesc;
public:
    TYPE_ResponseSpectra(const SDLAny&, AsnCodingSet rule_set=asn_ber);
    virtual const char* name() const { return "TYPE_ResponseSpectra"; }
    virtual SDLType* copy()const;
    virtual void assign(const SDLType* t);
    static SDLType* create();
    virtual const SDLType* create_new() const;
    static const TYPE_ResponseSpectra& convert(const TYPE_ResponseSpectra&t) { return t; };
    
    TYPE_ResponseSpectra();
    TYPE_ResponseSpectra(SDLType**,unsigned long);
    TYPE_ResponseSpectra(const SDLNull&);
    TYPE_ResponseSpectra(const TYPE_ResponseSpectra&);
    virtual ~TYPE_ResponseSpectra();
    
    TYPE_ResponseSpectra& operator=(const TYPE_ResponseSpectra&);
    unsigned int hash(unsigned int max_hash)const;
    
    mutable SDLType* _fields[3?3:1];
    virtual void get_fields(SDLSeqSetDescription*&,SDLType**&);
    virtual void get_fields(SDLSeqSetDescription*&,SDLType *const*&)const;
    void set_field(int index,SDLType* value){
      _fields[index]=value;
    }
    
public:
    TYPE_ResponseSpectra(const class TYPE_SensorAcceleration&, const class TYPE_SensorAcceleration&, const class TYPE_SensorAcceleration&);
    TYPE_SensorAcceleration& VAR_a_0_3sec() const;
    TYPE_SensorAcceleration& VAR_a_1sec() const;
    TYPE_SensorAcceleration& VAR_a_3sec() const;
    AsnLen bEnc(BUF_TYPE) const;
    AsnLen bEncContent(BUF_TYPE) const;
    void bDec(BUF_TYPE,AsnLen&);
    void bDecContent(BUF_TYPE,AsnTag,AsnLen,AsnLen&);
    AsnLen pEnc(BUF_TYPE2 b) const;
    void pDec(BUF_TYPE2 b);
};

class PA_APEWProtocol_API TYPE_SN_LN_PositionChange: public SDLSequence {
    typedef TYPE_SN_LN_PositionChange _TYPE_thistype;
public:
    static SDLSeqSetDescription _fdesc;
public:
    TYPE_SN_LN_PositionChange(const SDLAny&, AsnCodingSet rule_set=asn_ber);
    virtual const char* name() const { return "TYPE_SN_LN_PositionChange"; }
    virtual SDLType* copy()const;
    virtual void assign(const SDLType* t);
    static SDLType* create();
    virtual const SDLType* create_new() const;
    static const TYPE_SN_LN_PositionChange& convert(const TYPE_SN_LN_PositionChange&t) { return t; };
    
    TYPE_SN_LN_PositionChange();
    TYPE_SN_LN_PositionChange(SDLType**,unsigned long);
    TYPE_SN_LN_PositionChange(const SDLNull&);
    TYPE_SN_LN_PositionChange(const TYPE_SN_LN_PositionChange&);
    virtual ~TYPE_SN_LN_PositionChange();
    
    TYPE_SN_LN_PositionChange& operator=(const TYPE_SN_LN_PositionChange&);
    unsigned int hash(unsigned int max_hash)const;
    
    mutable SDLType* _fields[3?3:1];
    virtual void get_fields(SDLSeqSetDescription*&,SDLType**&);
    virtual void get_fields(SDLSeqSetDescription*&,SDLType *const*&)const;
    void set_field(int index,SDLType* value){
      _fields[index]=value;
    }
    
public:
    TYPE_SN_LN_PositionChange(const class TYPE_DateTime&, const class TYPE_GeographicCoordinate&, const class TYPE_GeographicCoordinate&);
    TYPE_DateTime& VAR_gpsTimeStamp() const;
    TYPE_GeographicCoordinate& VAR_oldCoordinate() const;
    TYPE_GeographicCoordinate& VAR_newCoordinate() const;
    AsnLen bEnc(BUF_TYPE) const;
    AsnLen bEncContent(BUF_TYPE) const;
    void bDec(BUF_TYPE,AsnLen&);
    void bDecContent(BUF_TYPE,AsnTag,AsnLen,AsnLen&);
    AsnLen pEnc(BUF_TYPE2 b) const;
    void pDec(BUF_TYPE2 b);
};

class PA_APEWProtocol_API TYPE_StatusSNInfo: public SDLSequence {
    typedef TYPE_StatusSNInfo _TYPE_thistype;
public:
    static SDLSeqSetDescription _fdesc;
public:
    TYPE_StatusSNInfo(const SDLAny&, AsnCodingSet rule_set=asn_ber);
    virtual const char* name() const { return "TYPE_StatusSNInfo"; }
    virtual SDLType* copy()const;
    virtual void assign(const SDLType* t);
    static SDLType* create();
    virtual const SDLType* create_new() const;
    static const TYPE_StatusSNInfo& convert(const TYPE_StatusSNInfo&t) { return t; };
    
    TYPE_StatusSNInfo();
    TYPE_StatusSNInfo(SDLType**,unsigned long);
    TYPE_StatusSNInfo(const SDLNull&);
    TYPE_StatusSNInfo(const TYPE_StatusSNInfo&);
    virtual ~TYPE_StatusSNInfo();
    
    TYPE_StatusSNInfo& operator=(const TYPE_StatusSNInfo&);
    unsigned int hash(unsigned int max_hash)const;
    
    mutable SDLType* _fields[11?11:1];
    virtual void get_fields(SDLSeqSetDescription*&,SDLType**&);
    virtual void get_fields(SDLSeqSetDescription*&,SDLType *const*&)const;
    void set_field(int index,SDLType* value){
      _fields[index]=value;
    }
    
public:
    TYPE_StatusSNInfo(const class TYPE_DateTime&, const class TYPE_IPAddress&, const class TYPE_SensorAcceleration&, const class TYPE_SensorVelocity&, const class TYPE_SensorDisplacement&, const class SDLReal&, const class SDLReal&, const class SDLReal&, const class SDLReal&, const class SDLReal&, const class TYPE_ResponseSpectra&);
    TYPE_DateTime& VAR_gpsTimeStamp() const;
    TYPE_IPAddress& VAR_sourceSN() const;
    TYPE_SensorAcceleration& VAR_pga() const;
    TYPE_SensorVelocity& VAR_pgv() const;
    TYPE_SensorDisplacement& VAR_pgd() const;
    SDLReal& VAR_predominantPeriod() const;
    SDLReal& VAR_cav() const;
    SDLReal& VAR_instrumentalIntensity() const;
    const SDLBool& instrumentalIntensityPresent()const;
    _TYPE_thistype instrumentalIntensityOmit()const;
    void _instrumentalIntensityOmit();
    
    SDLReal& VAR_ariasIntensity() const;
    const SDLBool& ariasIntensityPresent()const;
    _TYPE_thistype ariasIntensityOmit()const;
    void _ariasIntensityOmit();
    
    SDLReal& VAR_valueFourthChannel() const;
    const SDLBool& valueFourthChannelPresent()const;
    _TYPE_thistype valueFourthChannelOmit()const;
    void _valueFourthChannelOmit();
    
    TYPE_ResponseSpectra& VAR_responseSpectra() const;
    const SDLBool& responseSpectraPresent()const;
    _TYPE_thistype responseSpectraOmit()const;
    void _responseSpectraOmit();
    
    AsnLen bEnc(BUF_TYPE) const;
    AsnLen bEncContent(BUF_TYPE) const;
    void bDec(BUF_TYPE,AsnLen&);
    void bDecContent(BUF_TYPE,AsnTag,AsnLen,AsnLen&);
    AsnLen pEnc(BUF_TYPE2 b) const;
    void pDec(BUF_TYPE2 b);
};

class PA_APEWProtocol_API TYPE_LN_SN_Alarm: public SDLSequence {
    typedef TYPE_LN_SN_Alarm _TYPE_thistype;
public:
    static SDLSeqSetDescription _fdesc;
public:
    TYPE_LN_SN_Alarm(const SDLAny&, AsnCodingSet rule_set=asn_ber);
    virtual const char* name() const { return "TYPE_LN_SN_Alarm"; }
    virtual SDLType* copy()const;
    virtual void assign(const SDLType* t);
    static SDLType* create();
    virtual const SDLType* create_new() const;
    static const TYPE_LN_SN_Alarm& convert(const TYPE_LN_SN_Alarm&t) { return t; };
    
    TYPE_LN_SN_Alarm();
    TYPE_LN_SN_Alarm(SDLType**,unsigned long);
    TYPE_LN_SN_Alarm(const SDLNull&);
    TYPE_LN_SN_Alarm(const TYPE_LN_SN_Alarm&);
    virtual ~TYPE_LN_SN_Alarm();
    
    TYPE_LN_SN_Alarm& operator=(const TYPE_LN_SN_Alarm&);
    unsigned int hash(unsigned int max_hash)const;
    
    mutable SDLType* _fields[3?3:1];
    virtual void get_fields(SDLSeqSetDescription*&,SDLType**&);
    virtual void get_fields(SDLSeqSetDescription*&,SDLType *const*&)const;
    void set_field(int index,SDLType* value){
      _fields[index]=value;
    }
    
public:
    TYPE_LN_SN_Alarm(const class TYPE_DateTime&, const class TYPE_EventID&, const class TYPE_APEWProtocol_GEN_9&);
    TYPE_DateTime& VAR_gpsTimeStamp() const;
    TYPE_EventID& VAR_event() const;
    TYPE_APEWProtocol_GEN_9& VAR_decisionMakingSNs() const;
    AsnLen bEnc(BUF_TYPE) const;
    AsnLen bEncContent(BUF_TYPE) const;
    void bDec(BUF_TYPE,AsnLen&);
    void bDecContent(BUF_TYPE,AsnTag,AsnLen,AsnLen&);
    AsnLen pEnc(BUF_TYPE2 b) const;
    void pDec(BUF_TYPE2 b);
};

class PA_APEWProtocol_API TYPE_LN_SN_FalseAlarm: public SDLSequence {
    typedef TYPE_LN_SN_FalseAlarm _TYPE_thistype;
public:
    static SDLSeqSetDescription _fdesc;
public:
    TYPE_LN_SN_FalseAlarm(const SDLAny&, AsnCodingSet rule_set=asn_ber);
    virtual const char* name() const { return "TYPE_LN_SN_FalseAlarm"; }
    virtual SDLType* copy()const;
    virtual void assign(const SDLType* t);
    static SDLType* create();
    virtual const SDLType* create_new() const;
    static const TYPE_LN_SN_FalseAlarm& convert(const TYPE_LN_SN_FalseAlarm&t) { return t; };
    
    TYPE_LN_SN_FalseAlarm();
    TYPE_LN_SN_FalseAlarm(SDLType**,unsigned long);
    TYPE_LN_SN_FalseAlarm(const SDLNull&);
    TYPE_LN_SN_FalseAlarm(const TYPE_LN_SN_FalseAlarm&);
    virtual ~TYPE_LN_SN_FalseAlarm();
    
    TYPE_LN_SN_FalseAlarm& operator=(const TYPE_LN_SN_FalseAlarm&);
    unsigned int hash(unsigned int max_hash)const;
    
    mutable SDLType* _fields[2?2:1];
    virtual void get_fields(SDLSeqSetDescription*&,SDLType**&);
    virtual void get_fields(SDLSeqSetDescription*&,SDLType *const*&)const;
    void set_field(int index,SDLType* value){
      _fields[index]=value;
    }
    
public:
    TYPE_LN_SN_FalseAlarm(const class TYPE_DateTime&, const class TYPE_DateTime&);
    TYPE_DateTime& VAR_gpsTimeStamp() const;
    TYPE_DateTime& VAR_timeOfFalseAlarm() const;
    AsnLen bEnc(BUF_TYPE) const;
    AsnLen bEncContent(BUF_TYPE) const;
    void bDec(BUF_TYPE,AsnLen&);
    void bDecContent(BUF_TYPE,AsnTag,AsnLen,AsnLen&);
    AsnLen pEnc(BUF_TYPE2 b) const;
    void pDec(BUF_TYPE2 b);
};

class PA_APEWProtocol_API TYPE_LN_SN_Describe: public SDLSequence {
    typedef TYPE_LN_SN_Describe _TYPE_thistype;
public:
    static SDLSeqSetDescription _fdesc;
public:
    TYPE_LN_SN_Describe(const SDLAny&, AsnCodingSet rule_set=asn_ber);
    virtual const char* name() const { return "TYPE_LN_SN_Describe"; }
    virtual SDLType* copy()const;
    virtual void assign(const SDLType* t);
    static SDLType* create();
    virtual const SDLType* create_new() const;
    static const TYPE_LN_SN_Describe& convert(const TYPE_LN_SN_Describe&t) { return t; };
    
    TYPE_LN_SN_Describe();
    TYPE_LN_SN_Describe(SDLType**,unsigned long);
    TYPE_LN_SN_Describe(const SDLNull&);
    TYPE_LN_SN_Describe(const TYPE_LN_SN_Describe&);
    virtual ~TYPE_LN_SN_Describe();
    
    TYPE_LN_SN_Describe& operator=(const TYPE_LN_SN_Describe&);
    unsigned int hash(unsigned int max_hash)const;
    
    mutable SDLType* _fields[2?2:1];
    virtual void get_fields(SDLSeqSetDescription*&,SDLType**&);
    virtual void get_fields(SDLSeqSetDescription*&,SDLType *const*&)const;
    void set_field(int index,SDLType* value){
      _fields[index]=value;
    }
    
public:
    TYPE_LN_SN_Describe(const class TYPE_DateTime&, const class TYPE_EventID&);
    TYPE_DateTime& VAR_gpsTimeStamp() const;
    TYPE_EventID& VAR_event() const;
    const SDLBool& eventPresent()const;
    _TYPE_thistype eventOmit()const;
    void _eventOmit();
    
    AsnLen bEnc(BUF_TYPE) const;
    AsnLen bEncContent(BUF_TYPE) const;
    void bDec(BUF_TYPE,AsnLen&);
    void bDecContent(BUF_TYPE,AsnTag,AsnLen,AsnLen&);
    AsnLen pEnc(BUF_TYPE2 b) const;
    void pDec(BUF_TYPE2 b);
};

class PA_APEWProtocol_API TYPE_LN_SN_Summarise: public SDLSequence {
    typedef TYPE_LN_SN_Summarise _TYPE_thistype;
public:
    static SDLSeqSetDescription _fdesc;
public:
    TYPE_LN_SN_Summarise(const SDLAny&, AsnCodingSet rule_set=asn_ber);
    virtual const char* name() const { return "TYPE_LN_SN_Summarise"; }
    virtual SDLType* copy()const;
    virtual void assign(const SDLType* t);
    static SDLType* create();
    virtual const SDLType* create_new() const;
    static const TYPE_LN_SN_Summarise& convert(const TYPE_LN_SN_Summarise&t) { return t; };
    
    TYPE_LN_SN_Summarise();
    TYPE_LN_SN_Summarise(SDLType**,unsigned long);
    TYPE_LN_SN_Summarise(const SDLNull&);
    TYPE_LN_SN_Summarise(const TYPE_LN_SN_Summarise&);
    virtual ~TYPE_LN_SN_Summarise();
    
    TYPE_LN_SN_Summarise& operator=(const TYPE_LN_SN_Summarise&);
    unsigned int hash(unsigned int max_hash)const;
    
    mutable SDLType* _fields[2?2:1];
    virtual void get_fields(SDLSeqSetDescription*&,SDLType**&);
    virtual void get_fields(SDLSeqSetDescription*&,SDLType *const*&)const;
    void set_field(int index,SDLType* value){
      _fields[index]=value;
    }
    
public:
    TYPE_LN_SN_Summarise(const class TYPE_DateTime&, const class TYPE_EventID&);
    TYPE_DateTime& VAR_gpsTimeStamp() const;
    TYPE_EventID& VAR_event() const;
    const SDLBool& eventPresent()const;
    _TYPE_thistype eventOmit()const;
    void _eventOmit();
    
    AsnLen bEnc(BUF_TYPE) const;
    AsnLen bEncContent(BUF_TYPE) const;
    void bDec(BUF_TYPE,AsnLen&);
    void bDecContent(BUF_TYPE,AsnTag,AsnLen,AsnLen&);
    AsnLen pEnc(BUF_TYPE2 b) const;
    void pDec(BUF_TYPE2 b);
};

class PA_APEWProtocol_API TYPE_BreakdownReason: public SDLEnum {
public:
    TYPE_BreakdownReason(const SDLAny&, AsnCodingSet rule_set=asn_ber);
    virtual const char* name() const { return "TYPE_BreakdownReason"; }
    virtual SDLType* copy()const;
    virtual void assign(const SDLType* t);
    static SDLType* create();
    virtual const SDLType* create_new() const;
    static const TYPE_BreakdownReason& convert(const TYPE_BreakdownReason&t) { return t; };
    
public:
    TYPE_BreakdownReason(long l):SDLEnum(l){}
    TYPE_BreakdownReason(){}
    TYPE_BreakdownReason(const SDLNull& n):SDLEnum(n){}
    TYPE_BreakdownReason(const SDLEnum& base):SDLEnum(base){}
    static const TYPE_BreakdownReason& LIT_linkDown();
    static const TYPE_BreakdownReason& LIT_batteryLow();
    AsnLen pEnc(BUF_TYPE2) const;
    void pDec(BUF_TYPE2);
    bool datainfo(long,SDLIA5String&,const SDLType*&)const;
    bool get_literal(int,const SDLEnum**,long*)const;
    int nr_literals() const;
    static TYPE_BreakdownReason Any() { return SDLEnum::Any(TYPE_BreakdownReason()); }
};

class PA_APEWProtocol_API TYPE_InoperativeSNInfo: public SDLSequence {
    typedef TYPE_InoperativeSNInfo _TYPE_thistype;
public:
    static SDLSeqSetDescription _fdesc;
public:
    TYPE_InoperativeSNInfo(const SDLAny&, AsnCodingSet rule_set=asn_ber);
    virtual const char* name() const { return "TYPE_InoperativeSNInfo"; }
    virtual SDLType* copy()const;
    virtual void assign(const SDLType* t);
    static SDLType* create();
    virtual const SDLType* create_new() const;
    static const TYPE_InoperativeSNInfo& convert(const TYPE_InoperativeSNInfo&t) { return t; };
    
    TYPE_InoperativeSNInfo();
    TYPE_InoperativeSNInfo(SDLType**,unsigned long);
    TYPE_InoperativeSNInfo(const SDLNull&);
    TYPE_InoperativeSNInfo(const TYPE_InoperativeSNInfo&);
    virtual ~TYPE_InoperativeSNInfo();
    
    TYPE_InoperativeSNInfo& operator=(const TYPE_InoperativeSNInfo&);
    unsigned int hash(unsigned int max_hash)const;
    
    mutable SDLType* _fields[3?3:1];
    virtual void get_fields(SDLSeqSetDescription*&,SDLType**&);
    virtual void get_fields(SDLSeqSetDescription*&,SDLType *const*&)const;
    void set_field(int index,SDLType* value){
      _fields[index]=value;
    }
    
public:
    TYPE_InoperativeSNInfo(const class TYPE_DateTime&, const class TYPE_IPAddress&, const class TYPE_BreakdownReason&);
    TYPE_DateTime& VAR_lastOperativeAt() const;
    TYPE_IPAddress& VAR_sourceSN() const;
    TYPE_BreakdownReason& VAR_reason() const;
    const SDLBool& reasonPresent()const;
    _TYPE_thistype reasonOmit()const;
    void _reasonOmit();
    
    AsnLen bEnc(BUF_TYPE) const;
    AsnLen bEncContent(BUF_TYPE) const;
    void bDec(BUF_TYPE,AsnLen&);
    void bDecContent(BUF_TYPE,AsnTag,AsnLen,AsnLen&);
    AsnLen pEnc(BUF_TYPE2 b) const;
    void pDec(BUF_TYPE2 b);
};

class PA_APEWProtocol_API TYPE_TriggeredSNInfo: public SDLSequence {
    typedef TYPE_TriggeredSNInfo _TYPE_thistype;
public:
    static SDLSeqSetDescription _fdesc;
public:
    TYPE_TriggeredSNInfo(const SDLAny&, AsnCodingSet rule_set=asn_ber);
    virtual const char* name() const { return "TYPE_TriggeredSNInfo"; }
    virtual SDLType* copy()const;
    virtual void assign(const SDLType* t);
    static SDLType* create();
    virtual const SDLType* create_new() const;
    static const TYPE_TriggeredSNInfo& convert(const TYPE_TriggeredSNInfo&t) { return t; };
    
    TYPE_TriggeredSNInfo();
    TYPE_TriggeredSNInfo(SDLType**,unsigned long);
    TYPE_TriggeredSNInfo(const SDLNull&);
    TYPE_TriggeredSNInfo(const TYPE_TriggeredSNInfo&);
    virtual ~TYPE_TriggeredSNInfo();
    
    TYPE_TriggeredSNInfo& operator=(const TYPE_TriggeredSNInfo&);
    unsigned int hash(unsigned int max_hash)const;
    
    mutable SDLType* _fields[9?9:1];
    virtual void get_fields(SDLSeqSetDescription*&,SDLType**&);
    virtual void get_fields(SDLSeqSetDescription*&,SDLType *const*&)const;
    void set_field(int index,SDLType* value){
      _fields[index]=value;
    }
    
public:
    TYPE_TriggeredSNInfo(const class TYPE_DateTime&, const class TYPE_IPAddress&, const class TYPE_SensorAcceleration&, const class TYPE_DateTime&, const class TYPE_Acceleration&, const class TYPE_DateTime&, const class SDLReal&, const class SDLReal&, const class SDLReal&);
    TYPE_DateTime& VAR_gpsTimeStamp() const;
    TYPE_IPAddress& VAR_sourceSN() const;
    TYPE_SensorAcceleration& VAR_currentSensorValues() const;
    TYPE_DateTime& VAR_tp() const;
    TYPE_Acceleration& VAR_az_max() const;
    TYPE_DateTime& VAR_t_max() const;
    SDLReal& VAR_max_noise() const;
    SDLReal& VAR_valueFourthChannel() const;
    const SDLBool& valueFourthChannelPresent()const;
    _TYPE_thistype valueFourthChannelOmit()const;
    void _valueFourthChannelOmit();
    
    SDLReal& VAR_sta_lta_TriggerValue() const;
    AsnLen bEnc(BUF_TYPE) const;
    AsnLen bEncContent(BUF_TYPE) const;
    void bDec(BUF_TYPE,AsnLen&);
    void bDecContent(BUF_TYPE,AsnTag,AsnLen,AsnLen&);
    AsnLen pEnc(BUF_TYPE2 b) const;
    void pDec(BUF_TYPE2 b);
};

class PA_APEWProtocol_API TYPE_LN_LN_Idle: public SDLSequence {
    typedef TYPE_LN_LN_Idle _TYPE_thistype;
public:
    static SDLSeqSetDescription _fdesc;
public:
    TYPE_LN_LN_Idle(const SDLAny&, AsnCodingSet rule_set=asn_ber);
    virtual const char* name() const { return "TYPE_LN_LN_Idle"; }
    virtual SDLType* copy()const;
    virtual void assign(const SDLType* t);
    static SDLType* create();
    virtual const SDLType* create_new() const;
    static const TYPE_LN_LN_Idle& convert(const TYPE_LN_LN_Idle&t) { return t; };
    
    TYPE_LN_LN_Idle();
    TYPE_LN_LN_Idle(SDLType**,unsigned long);
    TYPE_LN_LN_Idle(const SDLNull&);
    TYPE_LN_LN_Idle(const TYPE_LN_LN_Idle&);
    virtual ~TYPE_LN_LN_Idle();
    
    TYPE_LN_LN_Idle& operator=(const TYPE_LN_LN_Idle&);
    unsigned int hash(unsigned int max_hash)const;
    
    mutable SDLType* _fields[4?4:1];
    virtual void get_fields(SDLSeqSetDescription*&,SDLType**&);
    virtual void get_fields(SDLSeqSetDescription*&,SDLType *const*&)const;
    void set_field(int index,SDLType* value){
      _fields[index]=value;
    }
    
public:
    TYPE_LN_LN_Idle(const class TYPE_DateTime&, const class TYPE_APEWProtocol_GEN_10&, const class TYPE_APEWProtocol_GEN_11&, const class TYPE_SensorAccelerationAverage&);
    TYPE_DateTime& VAR_gpsTimeStamp() const;
    TYPE_APEWProtocol_GEN_10& VAR_operativeSNs() const;
    TYPE_APEWProtocol_GEN_11& VAR_inoperativeSNs() const;
    TYPE_SensorAccelerationAverage& VAR_noiseAverage() const;
    AsnLen bEnc(BUF_TYPE) const;
    AsnLen bEncContent(BUF_TYPE) const;
    void bDec(BUF_TYPE,AsnLen&);
    void bDecContent(BUF_TYPE,AsnTag,AsnLen,AsnLen&);
    AsnLen pEnc(BUF_TYPE2 b) const;
    void pDec(BUF_TYPE2 b);
};

class PA_APEWProtocol_API TYPE_LN_LN_Detection: public SDLSequence {
    typedef TYPE_LN_LN_Detection _TYPE_thistype;
public:
    static SDLSeqSetDescription _fdesc;
public:
    TYPE_LN_LN_Detection(const SDLAny&, AsnCodingSet rule_set=asn_ber);
    virtual const char* name() const { return "TYPE_LN_LN_Detection"; }
    virtual SDLType* copy()const;
    virtual void assign(const SDLType* t);
    static SDLType* create();
    virtual const SDLType* create_new() const;
    static const TYPE_LN_LN_Detection& convert(const TYPE_LN_LN_Detection&t) { return t; };
    
    TYPE_LN_LN_Detection();
    TYPE_LN_LN_Detection(SDLType**,unsigned long);
    TYPE_LN_LN_Detection(const SDLNull&);
    TYPE_LN_LN_Detection(const TYPE_LN_LN_Detection&);
    virtual ~TYPE_LN_LN_Detection();
    
    TYPE_LN_LN_Detection& operator=(const TYPE_LN_LN_Detection&);
    unsigned int hash(unsigned int max_hash)const;
    
    mutable SDLType* _fields[5?5:1];
    virtual void get_fields(SDLSeqSetDescription*&,SDLType**&);
    virtual void get_fields(SDLSeqSetDescription*&,SDLType *const*&)const;
    void set_field(int index,SDLType* value){
      _fields[index]=value;
    }
    
public:
    TYPE_LN_LN_Detection(const class TYPE_DateTime&, const class TYPE_EventID&, const class TYPE_APEWProtocol_GEN_12&, const class TYPE_APEWProtocol_GEN_13&, const class TYPE_SensorAccelerationAverage&);
    TYPE_DateTime& VAR_gpsTimeStamp() const;
    TYPE_EventID& VAR_event() const;
    TYPE_APEWProtocol_GEN_12& VAR_triggeredSNs() const;
    TYPE_APEWProtocol_GEN_13& VAR_inoperativeSNs() const;
    TYPE_SensorAccelerationAverage& VAR_noiseAveragePreEvent() const;
    AsnLen bEnc(BUF_TYPE) const;
    AsnLen bEncContent(BUF_TYPE) const;
    void bDec(BUF_TYPE,AsnLen&);
    void bDecContent(BUF_TYPE,AsnTag,AsnLen,AsnLen&);
    AsnLen pEnc(BUF_TYPE2 b) const;
    void pDec(BUF_TYPE2 b);
};

class PA_APEWProtocol_API TYPE_LN_LN_Alarm: public SDLSequence {
    typedef TYPE_LN_LN_Alarm _TYPE_thistype;
public:
    static SDLSeqSetDescription _fdesc;
public:
    TYPE_LN_LN_Alarm(const SDLAny&, AsnCodingSet rule_set=asn_ber);
    virtual const char* name() const { return "TYPE_LN_LN_Alarm"; }
    virtual SDLType* copy()const;
    virtual void assign(const SDLType* t);
    static SDLType* create();
    virtual const SDLType* create_new() const;
    static const TYPE_LN_LN_Alarm& convert(const TYPE_LN_LN_Alarm&t) { return t; };
    
    TYPE_LN_LN_Alarm();
    TYPE_LN_LN_Alarm(SDLType**,unsigned long);
    TYPE_LN_LN_Alarm(const SDLNull&);
    TYPE_LN_LN_Alarm(const TYPE_LN_LN_Alarm&);
    virtual ~TYPE_LN_LN_Alarm();
    
    TYPE_LN_LN_Alarm& operator=(const TYPE_LN_LN_Alarm&);
    unsigned int hash(unsigned int max_hash)const;
    
    mutable SDLType* _fields[3?3:1];
    virtual void get_fields(SDLSeqSetDescription*&,SDLType**&);
    virtual void get_fields(SDLSeqSetDescription*&,SDLType *const*&)const;
    void set_field(int index,SDLType* value){
      _fields[index]=value;
    }
    
public:
    TYPE_LN_LN_Alarm(const class TYPE_DateTime&, const class TYPE_EventID&, const class TYPE_APEWProtocol_GEN_14&);
    TYPE_DateTime& VAR_gpsTimeStamp() const;
    TYPE_EventID& VAR_event() const;
    TYPE_APEWProtocol_GEN_14& VAR_decisionMakingSNs() const;
    AsnLen bEnc(BUF_TYPE) const;
    AsnLen bEncContent(BUF_TYPE) const;
    void bDec(BUF_TYPE,AsnLen&);
    void bDecContent(BUF_TYPE,AsnTag,AsnLen,AsnLen&);
    AsnLen pEnc(BUF_TYPE2 b) const;
    void pDec(BUF_TYPE2 b);
};

class PA_APEWProtocol_API TYPE_LN_LN_Description: public SDLSequence {
    typedef TYPE_LN_LN_Description _TYPE_thistype;
public:
    static SDLSeqSetDescription _fdesc;
public:
    TYPE_LN_LN_Description(const SDLAny&, AsnCodingSet rule_set=asn_ber);
    virtual const char* name() const { return "TYPE_LN_LN_Description"; }
    virtual SDLType* copy()const;
    virtual void assign(const SDLType* t);
    static SDLType* create();
    virtual const SDLType* create_new() const;
    static const TYPE_LN_LN_Description& convert(const TYPE_LN_LN_Description&t) { return t; };
    
    TYPE_LN_LN_Description();
    TYPE_LN_LN_Description(SDLType**,unsigned long);
    TYPE_LN_LN_Description(const SDLNull&);
    TYPE_LN_LN_Description(const TYPE_LN_LN_Description&);
    virtual ~TYPE_LN_LN_Description();
    
    TYPE_LN_LN_Description& operator=(const TYPE_LN_LN_Description&);
    unsigned int hash(unsigned int max_hash)const;
    
    mutable SDLType* _fields[2?2:1];
    virtual void get_fields(SDLSeqSetDescription*&,SDLType**&);
    virtual void get_fields(SDLSeqSetDescription*&,SDLType *const*&)const;
    void set_field(int index,SDLType* value){
      _fields[index]=value;
    }
    
public:
    TYPE_LN_LN_Description(const class TYPE_DateTime&, const class TYPE_EventID&);
    TYPE_DateTime& VAR_gpsTimeStamp() const;
    TYPE_EventID& VAR_event() const;
    const SDLBool& eventPresent()const;
    _TYPE_thistype eventOmit()const;
    void _eventOmit();
    
    AsnLen bEnc(BUF_TYPE) const;
    AsnLen bEncContent(BUF_TYPE) const;
    void bDec(BUF_TYPE,AsnLen&);
    void bDecContent(BUF_TYPE,AsnTag,AsnLen,AsnLen&);
    AsnLen pEnc(BUF_TYPE2 b) const;
    void pDec(BUF_TYPE2 b);
};

class PA_APEWProtocol_API TYPE_LN_EN_Alarm: public SDLSequence {
    typedef TYPE_LN_EN_Alarm _TYPE_thistype;
public:
    static SDLSeqSetDescription _fdesc;
public:
    TYPE_LN_EN_Alarm(const SDLAny&, AsnCodingSet rule_set=asn_ber);
    virtual const char* name() const { return "TYPE_LN_EN_Alarm"; }
    virtual SDLType* copy()const;
    virtual void assign(const SDLType* t);
    static SDLType* create();
    virtual const SDLType* create_new() const;
    static const TYPE_LN_EN_Alarm& convert(const TYPE_LN_EN_Alarm&t) { return t; };
    
    TYPE_LN_EN_Alarm();
    TYPE_LN_EN_Alarm(SDLType**,unsigned long);
    TYPE_LN_EN_Alarm(const SDLNull&);
    TYPE_LN_EN_Alarm(const TYPE_LN_EN_Alarm&);
    virtual ~TYPE_LN_EN_Alarm();
    
    TYPE_LN_EN_Alarm& operator=(const TYPE_LN_EN_Alarm&);
    unsigned int hash(unsigned int max_hash)const;
    
    mutable SDLType* _fields[3?3:1];
    virtual void get_fields(SDLSeqSetDescription*&,SDLType**&);
    virtual void get_fields(SDLSeqSetDescription*&,SDLType *const*&)const;
    void set_field(int index,SDLType* value){
      _fields[index]=value;
    }
    
public:
    TYPE_LN_EN_Alarm(const class TYPE_DateTime&, const class TYPE_EventID&, const class TYPE_APEWProtocol_GEN_15&);
    TYPE_DateTime& VAR_gpsTimeStamp() const;
    TYPE_EventID& VAR_event() const;
    TYPE_APEWProtocol_GEN_15& VAR_decisionMakingSNs() const;
    AsnLen bEnc(BUF_TYPE) const;
    AsnLen bEncContent(BUF_TYPE) const;
    void bDec(BUF_TYPE,AsnLen&);
    void bDecContent(BUF_TYPE,AsnTag,AsnLen,AsnLen&);
    AsnLen pEnc(BUF_TYPE2 b) const;
    void pDec(BUF_TYPE2 b);
};

class PA_APEWProtocol_API TYPE_LN_EN_Summary: public SDLSequence {
    typedef TYPE_LN_EN_Summary _TYPE_thistype;
public:
    static SDLSeqSetDescription _fdesc;
public:
    TYPE_LN_EN_Summary(const SDLAny&, AsnCodingSet rule_set=asn_ber);
    virtual const char* name() const { return "TYPE_LN_EN_Summary"; }
    virtual SDLType* copy()const;
    virtual void assign(const SDLType* t);
    static SDLType* create();
    virtual const SDLType* create_new() const;
    static const TYPE_LN_EN_Summary& convert(const TYPE_LN_EN_Summary&t) { return t; };
    
    TYPE_LN_EN_Summary();
    TYPE_LN_EN_Summary(SDLType**,unsigned long);
    TYPE_LN_EN_Summary(const SDLNull&);
    TYPE_LN_EN_Summary(const TYPE_LN_EN_Summary&);
    virtual ~TYPE_LN_EN_Summary();
    
    TYPE_LN_EN_Summary& operator=(const TYPE_LN_EN_Summary&);
    unsigned int hash(unsigned int max_hash)const;
    
    mutable SDLType* _fields[6?6:1];
    virtual void get_fields(SDLSeqSetDescription*&,SDLType**&);
    virtual void get_fields(SDLSeqSetDescription*&,SDLType *const*&)const;
    void set_field(int index,SDLType* value){
      _fields[index]=value;
    }
    
public:
    TYPE_LN_EN_Summary(const class TYPE_DateTime&, const class TYPE_EventID&, const class TYPE_APEWProtocol_GEN_16&, const class TYPE_APEWProtocol_GEN_17&, const class TYPE_APEWProtocol_GEN_18&, const class SDLReal&);
    TYPE_DateTime& VAR_gpsTimeStamp() const;
    TYPE_EventID& VAR_event() const;
    TYPE_APEWProtocol_GEN_16& VAR_operativeSNs() const;
    TYPE_APEWProtocol_GEN_17& VAR_inoperativeSNs() const;
    TYPE_APEWProtocol_GEN_18& VAR_decisionMakingSNs() const;
    SDLReal& VAR_ariasIntensity() const;
    AsnLen bEnc(BUF_TYPE) const;
    AsnLen bEncContent(BUF_TYPE) const;
    void bDec(BUF_TYPE,AsnLen&);
    void bDecContent(BUF_TYPE,AsnTag,AsnLen,AsnLen&);
    AsnLen pEnc(BUF_TYPE2 b) const;
    void pDec(BUF_TYPE2 b);
};

class PA_APEWProtocol_API TYPE_APEWProtocol_GEN_1: public SDLInt {
public:
    TYPE_APEWProtocol_GEN_1(const SDLAny&, AsnCodingSet rule_set=asn_ber);
    virtual const char* name() const { return "TYPE_APEWProtocol_GEN_1"; }
    virtual SDLType* copy()const;
    virtual void assign(const SDLType* t);
    static SDLType* create();
    virtual const SDLType* create_new() const;
    static const TYPE_APEWProtocol_GEN_1& convert(const TYPE_APEWProtocol_GEN_1&t) { return t; };
    
public:
    TYPE_APEWProtocol_GEN_1(SITE_SDL_INT l):SDLInt(l){}
    TYPE_APEWProtocol_GEN_1(){}
    TYPE_APEWProtocol_GEN_1(const SDLNull& n):SDLInt(n){}
    TYPE_APEWProtocol_GEN_1(const SDLInt& base):SDLInt(base){}
    AsnLen pEnc(BUF_TYPE2) const;
    void pDec(BUF_TYPE2);
    const SDLBool& check() const;
};

class PA_APEWProtocol_API TYPE_APEWProtocol_GEN_2: public SDLInt {
public:
    TYPE_APEWProtocol_GEN_2(const SDLAny&, AsnCodingSet rule_set=asn_ber);
    virtual const char* name() const { return "TYPE_APEWProtocol_GEN_2"; }
    virtual SDLType* copy()const;
    virtual void assign(const SDLType* t);
    static SDLType* create();
    virtual const SDLType* create_new() const;
    static const TYPE_APEWProtocol_GEN_2& convert(const TYPE_APEWProtocol_GEN_2&t) { return t; };
    
public:
    TYPE_APEWProtocol_GEN_2(SITE_SDL_INT l):SDLInt(l){}
    TYPE_APEWProtocol_GEN_2(){}
    TYPE_APEWProtocol_GEN_2(const SDLNull& n):SDLInt(n){}
    TYPE_APEWProtocol_GEN_2(const SDLInt& base):SDLInt(base){}
    AsnLen pEnc(BUF_TYPE2) const;
    void pDec(BUF_TYPE2);
    const SDLBool& check() const;
};

class PA_APEWProtocol_API TYPE_APEWProtocol_GEN_3: public SDLReal {
public:
    TYPE_APEWProtocol_GEN_3(const SDLAny&, AsnCodingSet rule_set=asn_ber);
    virtual const char* name() const { return "TYPE_APEWProtocol_GEN_3"; }
    virtual SDLType* copy()const;
    virtual void assign(const SDLType* t);
    static SDLType* create();
    virtual const SDLType* create_new() const;
    static const TYPE_APEWProtocol_GEN_3& convert(const TYPE_APEWProtocol_GEN_3&t) { return t; };
    
public:
    TYPE_APEWProtocol_GEN_3(double d):SDLReal(d){}
    TYPE_APEWProtocol_GEN_3(SITE_SDL_INT mantissa,SITE_SDL_INT base,SITE_SDL_INT exp):SDLReal(mantissa,base,exp){}
    TYPE_APEWProtocol_GEN_3(){}
    TYPE_APEWProtocol_GEN_3(const SDLNull& n):SDLReal(n){}
    TYPE_APEWProtocol_GEN_3(const SDLReal& base):SDLReal(base){}
    const SDLBool& check() const;
};

class PA_APEWProtocol_API TYPE_APEWProtocol_GEN_4: public SDLReal {
public:
    TYPE_APEWProtocol_GEN_4(const SDLAny&, AsnCodingSet rule_set=asn_ber);
    virtual const char* name() const { return "TYPE_APEWProtocol_GEN_4"; }
    virtual SDLType* copy()const;
    virtual void assign(const SDLType* t);
    static SDLType* create();
    virtual const SDLType* create_new() const;
    static const TYPE_APEWProtocol_GEN_4& convert(const TYPE_APEWProtocol_GEN_4&t) { return t; };
    
public:
    TYPE_APEWProtocol_GEN_4(double d):SDLReal(d){}
    TYPE_APEWProtocol_GEN_4(SITE_SDL_INT mantissa,SITE_SDL_INT base,SITE_SDL_INT exp):SDLReal(mantissa,base,exp){}
    TYPE_APEWProtocol_GEN_4(){}
    TYPE_APEWProtocol_GEN_4(const SDLNull& n):SDLReal(n){}
    TYPE_APEWProtocol_GEN_4(const SDLReal& base):SDLReal(base){}
    const SDLBool& check() const;
};

class PA_APEWProtocol_API TYPE_APEWProtocol_GEN_5: public TYPE_APEWProtocol_GEN_6 {
public:
    TYPE_APEWProtocol_GEN_5(const SDLAny&, AsnCodingSet rule_set=asn_ber);
    virtual const char* name() const { return "TYPE_APEWProtocol_GEN_5"; }
    virtual SDLType* copy()const;
    virtual void assign(const SDLType* t);
    static SDLType* create();
    virtual const SDLType* create_new() const;
    static const TYPE_APEWProtocol_GEN_5& convert(const TYPE_APEWProtocol_GEN_5&t) { return t; };
    
public:
    TYPE_APEWProtocol_GEN_5(double d):TYPE_APEWProtocol_GEN_6(d){}
    TYPE_APEWProtocol_GEN_5(SITE_SDL_INT mantissa,SITE_SDL_INT base,SITE_SDL_INT exp):TYPE_APEWProtocol_GEN_6(mantissa,base,exp){}
    TYPE_APEWProtocol_GEN_5(){}
    TYPE_APEWProtocol_GEN_5(const SDLNull& n):TYPE_APEWProtocol_GEN_6(n){}
    TYPE_APEWProtocol_GEN_5(const SDLReal& base):TYPE_APEWProtocol_GEN_6(base){}
    AsnLen bEnc(BUF_TYPE) const;
    void bDec(BUF_TYPE,AsnLen&);
    const SDLBool& check() const;
};

class PA_APEWProtocol_API TYPE_APEWProtocol_GEN_7: public SDLInt {
public:
    TYPE_APEWProtocol_GEN_7(const SDLAny&, AsnCodingSet rule_set=asn_ber);
    virtual const char* name() const { return "TYPE_APEWProtocol_GEN_7"; }
    virtual SDLType* copy()const;
    virtual void assign(const SDLType* t);
    static SDLType* create();
    virtual const SDLType* create_new() const;
    static const TYPE_APEWProtocol_GEN_7& convert(const TYPE_APEWProtocol_GEN_7&t) { return t; };
    
public:
    TYPE_APEWProtocol_GEN_7(SITE_SDL_INT l):SDLInt(l){}
    TYPE_APEWProtocol_GEN_7(){}
    TYPE_APEWProtocol_GEN_7(const SDLNull& n):SDLInt(n){}
    TYPE_APEWProtocol_GEN_7(const SDLInt& base):SDLInt(base){}
    AsnLen pEnc(BUF_TYPE2) const;
    void pDec(BUF_TYPE2);
    const SDLBool& check() const;
};

class PA_APEWProtocol_API TYPE_APEWProtocol_GEN_8: public SDLEnum {
public:
    TYPE_APEWProtocol_GEN_8(const SDLAny&, AsnCodingSet rule_set=asn_ber);
    virtual const char* name() const { return "TYPE_APEWProtocol_GEN_8"; }
    virtual SDLType* copy()const;
    virtual void assign(const SDLType* t);
    static SDLType* create();
    virtual const SDLType* create_new() const;
    static const TYPE_APEWProtocol_GEN_8& convert(const TYPE_APEWProtocol_GEN_8&t) { return t; };
    
public:
    TYPE_APEWProtocol_GEN_8(long l):SDLEnum(l){}
    TYPE_APEWProtocol_GEN_8(){}
    TYPE_APEWProtocol_GEN_8(const SDLNull& n):SDLEnum(n){}
    TYPE_APEWProtocol_GEN_8(const SDLEnum& base):SDLEnum(base){}
    static const TYPE_APEWProtocol_GEN_8& LIT_pWave();
    static const TYPE_APEWProtocol_GEN_8& LIT_sWave();
    AsnLen pEnc(BUF_TYPE2) const;
    void pDec(BUF_TYPE2);
    bool datainfo(long,SDLIA5String&,const SDLType*&)const;
    bool get_literal(int,const SDLEnum**,long*)const;
    int nr_literals() const;
    static TYPE_APEWProtocol_GEN_8 Any() { return SDLEnum::Any(TYPE_APEWProtocol_GEN_8()); }
};

class PA_APEWProtocol_API TYPE_APEWProtocol_GEN_9: public SDLSetof<TYPE_APEWProtocol_GEN_9,TYPE_TriggeredSNInfo> {
    // typedef for use in macros
    typedef SDLSetof<TYPE_APEWProtocol_GEN_9,TYPE_TriggeredSNInfo> super;
public:
    TYPE_APEWProtocol_GEN_9(const SDLAny&, AsnCodingSet rule_set=asn_ber);
    virtual const char* name() const { return "TYPE_APEWProtocol_GEN_9"; }
    virtual SDLType* copy()const;
    virtual void assign(const SDLType* t);
    static SDLType* create();
    virtual const SDLType* create_new() const;
    static const TYPE_APEWProtocol_GEN_9& convert(const TYPE_APEWProtocol_GEN_9&t) { return t; };
    
    TYPE_APEWProtocol_GEN_9(){ set_state(validValue); }
    TYPE_APEWProtocol_GEN_9(const TYPE_TriggeredSNInfo& elem):super(elem){}
    TYPE_APEWProtocol_GEN_9(const super& base):super(base){}
    TYPE_APEWProtocol_GEN_9(const SDLNull& n):super(n){}
    TYPE_APEWProtocol_GEN_9(const TYPE_APEWProtocol_GEN_9& base,SITE_SDL_INT reserve):super(base,reserve){}
    
public:
    static const TYPE_APEWProtocol_GEN_9& LIT_Empty() { static TYPE_APEWProtocol_GEN_9 v; return v; }
    AsnLen bEnc(BUF_TYPE) const;
    AsnLen bEncContent(BUF_TYPE) const;
    void bDec(BUF_TYPE,AsnLen&);
    void bDecContent(BUF_TYPE,AsnTag,AsnLen,AsnLen&);
};

class PA_APEWProtocol_API TYPE_APEWProtocol_GEN_10: public SDLSetof<TYPE_APEWProtocol_GEN_10,TYPE_IPAddress> {
    // typedef for use in macros
    typedef SDLSetof<TYPE_APEWProtocol_GEN_10,TYPE_IPAddress> super;
public:
    TYPE_APEWProtocol_GEN_10(const SDLAny&, AsnCodingSet rule_set=asn_ber);
    virtual const char* name() const { return "TYPE_APEWProtocol_GEN_10"; }
    virtual SDLType* copy()const;
    virtual void assign(const SDLType* t);
    static SDLType* create();
    virtual const SDLType* create_new() const;
    static const TYPE_APEWProtocol_GEN_10& convert(const TYPE_APEWProtocol_GEN_10&t) { return t; };
    
    TYPE_APEWProtocol_GEN_10(){ set_state(validValue); }
    TYPE_APEWProtocol_GEN_10(const TYPE_IPAddress& elem):super(elem){}
    TYPE_APEWProtocol_GEN_10(const super& base):super(base){}
    TYPE_APEWProtocol_GEN_10(const SDLNull& n):super(n){}
    TYPE_APEWProtocol_GEN_10(const TYPE_APEWProtocol_GEN_10& base,SITE_SDL_INT reserve):super(base,reserve){}
    
public:
    static const TYPE_APEWProtocol_GEN_10& LIT_Empty() { static TYPE_APEWProtocol_GEN_10 v; return v; }
    AsnLen bEnc(BUF_TYPE) const;
    AsnLen bEncContent(BUF_TYPE) const;
    void bDec(BUF_TYPE,AsnLen&);
    void bDecContent(BUF_TYPE,AsnTag,AsnLen,AsnLen&);
};

class PA_APEWProtocol_API TYPE_APEWProtocol_GEN_11: public SDLSetof<TYPE_APEWProtocol_GEN_11,TYPE_InoperativeSNInfo> {
    // typedef for use in macros
    typedef SDLSetof<TYPE_APEWProtocol_GEN_11,TYPE_InoperativeSNInfo> super;
public:
    TYPE_APEWProtocol_GEN_11(const SDLAny&, AsnCodingSet rule_set=asn_ber);
    virtual const char* name() const { return "TYPE_APEWProtocol_GEN_11"; }
    virtual SDLType* copy()const;
    virtual void assign(const SDLType* t);
    static SDLType* create();
    virtual const SDLType* create_new() const;
    static const TYPE_APEWProtocol_GEN_11& convert(const TYPE_APEWProtocol_GEN_11&t) { return t; };
    
    TYPE_APEWProtocol_GEN_11(){ set_state(validValue); }
    TYPE_APEWProtocol_GEN_11(const TYPE_InoperativeSNInfo& elem):super(elem){}
    TYPE_APEWProtocol_GEN_11(const super& base):super(base){}
    TYPE_APEWProtocol_GEN_11(const SDLNull& n):super(n){}
    TYPE_APEWProtocol_GEN_11(const TYPE_APEWProtocol_GEN_11& base,SITE_SDL_INT reserve):super(base,reserve){}
    
public:
    static const TYPE_APEWProtocol_GEN_11& LIT_Empty() { static TYPE_APEWProtocol_GEN_11 v; return v; }
    AsnLen bEnc(BUF_TYPE) const;
    AsnLen bEncContent(BUF_TYPE) const;
    void bDec(BUF_TYPE,AsnLen&);
    void bDecContent(BUF_TYPE,AsnTag,AsnLen,AsnLen&);
};

class PA_APEWProtocol_API TYPE_APEWProtocol_GEN_12: public SDLSetof<TYPE_APEWProtocol_GEN_12,TYPE_TriggeredSNInfo> {
    // typedef for use in macros
    typedef SDLSetof<TYPE_APEWProtocol_GEN_12,TYPE_TriggeredSNInfo> super;
public:
    TYPE_APEWProtocol_GEN_12(const SDLAny&, AsnCodingSet rule_set=asn_ber);
    virtual const char* name() const { return "TYPE_APEWProtocol_GEN_12"; }
    virtual SDLType* copy()const;
    virtual void assign(const SDLType* t);
    static SDLType* create();
    virtual const SDLType* create_new() const;
    static const TYPE_APEWProtocol_GEN_12& convert(const TYPE_APEWProtocol_GEN_12&t) { return t; };
    
    TYPE_APEWProtocol_GEN_12(){ set_state(validValue); }
    TYPE_APEWProtocol_GEN_12(const TYPE_TriggeredSNInfo& elem):super(elem){}
    TYPE_APEWProtocol_GEN_12(const super& base):super(base){}
    TYPE_APEWProtocol_GEN_12(const SDLNull& n):super(n){}
    TYPE_APEWProtocol_GEN_12(const TYPE_APEWProtocol_GEN_12& base,SITE_SDL_INT reserve):super(base,reserve){}
    
public:
    static const TYPE_APEWProtocol_GEN_12& LIT_Empty() { static TYPE_APEWProtocol_GEN_12 v; return v; }
    AsnLen bEnc(BUF_TYPE) const;
    AsnLen bEncContent(BUF_TYPE) const;
    void bDec(BUF_TYPE,AsnLen&);
    void bDecContent(BUF_TYPE,AsnTag,AsnLen,AsnLen&);
};

class PA_APEWProtocol_API TYPE_APEWProtocol_GEN_13: public SDLSetof<TYPE_APEWProtocol_GEN_13,TYPE_InoperativeSNInfo> {
    // typedef for use in macros
    typedef SDLSetof<TYPE_APEWProtocol_GEN_13,TYPE_InoperativeSNInfo> super;
public:
    TYPE_APEWProtocol_GEN_13(const SDLAny&, AsnCodingSet rule_set=asn_ber);
    virtual const char* name() const { return "TYPE_APEWProtocol_GEN_13"; }
    virtual SDLType* copy()const;
    virtual void assign(const SDLType* t);
    static SDLType* create();
    virtual const SDLType* create_new() const;
    static const TYPE_APEWProtocol_GEN_13& convert(const TYPE_APEWProtocol_GEN_13&t) { return t; };
    
    TYPE_APEWProtocol_GEN_13(){ set_state(validValue); }
    TYPE_APEWProtocol_GEN_13(const TYPE_InoperativeSNInfo& elem):super(elem){}
    TYPE_APEWProtocol_GEN_13(const super& base):super(base){}
    TYPE_APEWProtocol_GEN_13(const SDLNull& n):super(n){}
    TYPE_APEWProtocol_GEN_13(const TYPE_APEWProtocol_GEN_13& base,SITE_SDL_INT reserve):super(base,reserve){}
    
public:
    static const TYPE_APEWProtocol_GEN_13& LIT_Empty() { static TYPE_APEWProtocol_GEN_13 v; return v; }
    AsnLen bEnc(BUF_TYPE) const;
    AsnLen bEncContent(BUF_TYPE) const;
    void bDec(BUF_TYPE,AsnLen&);
    void bDecContent(BUF_TYPE,AsnTag,AsnLen,AsnLen&);
};

class PA_APEWProtocol_API TYPE_APEWProtocol_GEN_14: public SDLSetof<TYPE_APEWProtocol_GEN_14,TYPE_TriggeredSNInfo> {
    // typedef for use in macros
    typedef SDLSetof<TYPE_APEWProtocol_GEN_14,TYPE_TriggeredSNInfo> super;
public:
    TYPE_APEWProtocol_GEN_14(const SDLAny&, AsnCodingSet rule_set=asn_ber);
    virtual const char* name() const { return "TYPE_APEWProtocol_GEN_14"; }
    virtual SDLType* copy()const;
    virtual void assign(const SDLType* t);
    static SDLType* create();
    virtual const SDLType* create_new() const;
    static const TYPE_APEWProtocol_GEN_14& convert(const TYPE_APEWProtocol_GEN_14&t) { return t; };
    
    TYPE_APEWProtocol_GEN_14(){ set_state(validValue); }
    TYPE_APEWProtocol_GEN_14(const TYPE_TriggeredSNInfo& elem):super(elem){}
    TYPE_APEWProtocol_GEN_14(const super& base):super(base){}
    TYPE_APEWProtocol_GEN_14(const SDLNull& n):super(n){}
    TYPE_APEWProtocol_GEN_14(const TYPE_APEWProtocol_GEN_14& base,SITE_SDL_INT reserve):super(base,reserve){}
    
public:
    static const TYPE_APEWProtocol_GEN_14& LIT_Empty() { static TYPE_APEWProtocol_GEN_14 v; return v; }
    AsnLen bEnc(BUF_TYPE) const;
    AsnLen bEncContent(BUF_TYPE) const;
    void bDec(BUF_TYPE,AsnLen&);
    void bDecContent(BUF_TYPE,AsnTag,AsnLen,AsnLen&);
};

class PA_APEWProtocol_API TYPE_APEWProtocol_GEN_15: public SDLSetof<TYPE_APEWProtocol_GEN_15,TYPE_TriggeredSNInfo> {
    // typedef for use in macros
    typedef SDLSetof<TYPE_APEWProtocol_GEN_15,TYPE_TriggeredSNInfo> super;
public:
    TYPE_APEWProtocol_GEN_15(const SDLAny&, AsnCodingSet rule_set=asn_ber);
    virtual const char* name() const { return "TYPE_APEWProtocol_GEN_15"; }
    virtual SDLType* copy()const;
    virtual void assign(const SDLType* t);
    static SDLType* create();
    virtual const SDLType* create_new() const;
    static const TYPE_APEWProtocol_GEN_15& convert(const TYPE_APEWProtocol_GEN_15&t) { return t; };
    
    TYPE_APEWProtocol_GEN_15(){ set_state(validValue); }
    TYPE_APEWProtocol_GEN_15(const TYPE_TriggeredSNInfo& elem):super(elem){}
    TYPE_APEWProtocol_GEN_15(const super& base):super(base){}
    TYPE_APEWProtocol_GEN_15(const SDLNull& n):super(n){}
    TYPE_APEWProtocol_GEN_15(const TYPE_APEWProtocol_GEN_15& base,SITE_SDL_INT reserve):super(base,reserve){}
    
public:
    static const TYPE_APEWProtocol_GEN_15& LIT_Empty() { static TYPE_APEWProtocol_GEN_15 v; return v; }
    AsnLen bEnc(BUF_TYPE) const;
    AsnLen bEncContent(BUF_TYPE) const;
    void bDec(BUF_TYPE,AsnLen&);
    void bDecContent(BUF_TYPE,AsnTag,AsnLen,AsnLen&);
};

class PA_APEWProtocol_API TYPE_APEWProtocol_GEN_16: public SDLSetof<TYPE_APEWProtocol_GEN_16,TYPE_IPAddress> {
    // typedef for use in macros
    typedef SDLSetof<TYPE_APEWProtocol_GEN_16,TYPE_IPAddress> super;
public:
    TYPE_APEWProtocol_GEN_16(const SDLAny&, AsnCodingSet rule_set=asn_ber);
    virtual const char* name() const { return "TYPE_APEWProtocol_GEN_16"; }
    virtual SDLType* copy()const;
    virtual void assign(const SDLType* t);
    static SDLType* create();
    virtual const SDLType* create_new() const;
    static const TYPE_APEWProtocol_GEN_16& convert(const TYPE_APEWProtocol_GEN_16&t) { return t; };
    
    TYPE_APEWProtocol_GEN_16(){ set_state(validValue); }
    TYPE_APEWProtocol_GEN_16(const TYPE_IPAddress& elem):super(elem){}
    TYPE_APEWProtocol_GEN_16(const super& base):super(base){}
    TYPE_APEWProtocol_GEN_16(const SDLNull& n):super(n){}
    TYPE_APEWProtocol_GEN_16(const TYPE_APEWProtocol_GEN_16& base,SITE_SDL_INT reserve):super(base,reserve){}
    
public:
    static const TYPE_APEWProtocol_GEN_16& LIT_Empty() { static TYPE_APEWProtocol_GEN_16 v; return v; }
    AsnLen bEnc(BUF_TYPE) const;
    AsnLen bEncContent(BUF_TYPE) const;
    void bDec(BUF_TYPE,AsnLen&);
    void bDecContent(BUF_TYPE,AsnTag,AsnLen,AsnLen&);
};

class PA_APEWProtocol_API TYPE_APEWProtocol_GEN_17: public SDLSetof<TYPE_APEWProtocol_GEN_17,TYPE_InoperativeSNInfo> {
    // typedef for use in macros
    typedef SDLSetof<TYPE_APEWProtocol_GEN_17,TYPE_InoperativeSNInfo> super;
public:
    TYPE_APEWProtocol_GEN_17(const SDLAny&, AsnCodingSet rule_set=asn_ber);
    virtual const char* name() const { return "TYPE_APEWProtocol_GEN_17"; }
    virtual SDLType* copy()const;
    virtual void assign(const SDLType* t);
    static SDLType* create();
    virtual const SDLType* create_new() const;
    static const TYPE_APEWProtocol_GEN_17& convert(const TYPE_APEWProtocol_GEN_17&t) { return t; };
    
    TYPE_APEWProtocol_GEN_17(){ set_state(validValue); }
    TYPE_APEWProtocol_GEN_17(const TYPE_InoperativeSNInfo& elem):super(elem){}
    TYPE_APEWProtocol_GEN_17(const super& base):super(base){}
    TYPE_APEWProtocol_GEN_17(const SDLNull& n):super(n){}
    TYPE_APEWProtocol_GEN_17(const TYPE_APEWProtocol_GEN_17& base,SITE_SDL_INT reserve):super(base,reserve){}
    
public:
    static const TYPE_APEWProtocol_GEN_17& LIT_Empty() { static TYPE_APEWProtocol_GEN_17 v; return v; }
    AsnLen bEnc(BUF_TYPE) const;
    AsnLen bEncContent(BUF_TYPE) const;
    void bDec(BUF_TYPE,AsnLen&);
    void bDecContent(BUF_TYPE,AsnTag,AsnLen,AsnLen&);
};

class PA_APEWProtocol_API TYPE_APEWProtocol_GEN_18: public SDLSetof<TYPE_APEWProtocol_GEN_18,TYPE_StatusSNInfo> {
    // typedef for use in macros
    typedef SDLSetof<TYPE_APEWProtocol_GEN_18,TYPE_StatusSNInfo> super;
public:
    TYPE_APEWProtocol_GEN_18(const SDLAny&, AsnCodingSet rule_set=asn_ber);
    virtual const char* name() const { return "TYPE_APEWProtocol_GEN_18"; }
    virtual SDLType* copy()const;
    virtual void assign(const SDLType* t);
    static SDLType* create();
    virtual const SDLType* create_new() const;
    static const TYPE_APEWProtocol_GEN_18& convert(const TYPE_APEWProtocol_GEN_18&t) { return t; };
    
    TYPE_APEWProtocol_GEN_18(){ set_state(validValue); }
    TYPE_APEWProtocol_GEN_18(const TYPE_StatusSNInfo& elem):super(elem){}
    TYPE_APEWProtocol_GEN_18(const super& base):super(base){}
    TYPE_APEWProtocol_GEN_18(const SDLNull& n):super(n){}
    TYPE_APEWProtocol_GEN_18(const TYPE_APEWProtocol_GEN_18& base,SITE_SDL_INT reserve):super(base,reserve){}
    
public:
    static const TYPE_APEWProtocol_GEN_18& LIT_Empty() { static TYPE_APEWProtocol_GEN_18 v; return v; }
    AsnLen bEnc(BUF_TYPE) const;
    AsnLen bEncContent(BUF_TYPE) const;
    void bDec(BUF_TYPE,AsnLen&);
    void bDecContent(BUF_TYPE,AsnTag,AsnLen,AsnLen&);
};

END_SITE_NAMESPACE
#include <sdlpackage.h>
#include <sdlblock.h>
#include <sdlchannel.h>
#include <sdlshell.h>

BEGIN_SITE_NAMESPACE(AP_GeneralProtocol)
extern int PA_APEWProtocol1241092_has_been_changed;

class PA_APEWProtocol_API PA_APEWProtocol : public SDLPackage 
{
    declareSDLPackage(PA_APEWProtocol)
    PA_APEWProtocol(const char *);
public:
    void init();
    ~PA_APEWProtocol();
    static PA_APEWProtocol* Instance();
    bool datainfo(long,class SDLIA5String&,SDLIA5String&,SDLType*&);
    const char * get_namespace() const { return "AP_GeneralProtocol"; }
}; /* PA_APEWProtocol */

#define MY_PA_APEWProtocol (PA_APEWProtocol::Instance())

END_SITE_NAMESPACE
#endif
