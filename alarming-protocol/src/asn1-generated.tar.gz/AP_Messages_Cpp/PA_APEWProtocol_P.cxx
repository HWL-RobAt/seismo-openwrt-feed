/* ===== PA_APEWProtocol_P.cxx ===== */

#include "PA_APEWProtocol.h"
#include "version.h"

BEGIN_SITE_NAMESPACE(AP_GeneralProtocol)
TYPE_APEWProtocol::TYPE_APEWProtocol(const SDLAny& a, AsnCodingSet rule_set){                                      a.decode(this,rule_set); }

SDLType* TYPE_APEWProtocol::copy()const { return new TYPE_APEWProtocol(*this); }

void TYPE_APEWProtocol::assign(const SDLType* t)
{
  const TYPE_APEWProtocol *arg = SITE_DYNAMIC_CAST(const TYPE_APEWProtocol*,t);
  if (!arg) SDLChoice::assign(t);
  else *this = *arg;
}

SDLType* TYPE_APEWProtocol::create()
{
  static TYPE_APEWProtocol* tmpl = new TYPE_APEWProtocol;
  return tmpl;
}

const SDLType* TYPE_APEWProtocol::create_new() const { return create(); }

TYPE_SN_LN_Idle& TYPE_APEWProtocol::VAR_mSN_LN_Idle() const {
    if (_u && _present!=CHOICE_mSN_LN_Idle) {
        delete _u; _u=0;
    }
    if(!_u) {
        _u = new TYPE_SN_LN_Idle;
        _present = CHOICE_mSN_LN_Idle;
    } else {
        SITEASSERT(SITE_DYNAMIC_CAST(TYPE_SN_LN_Idle*,_u),
                   "dynamic cast failure for CHOICE element");
    }
    return *SITE_STATIC_CAST(TYPE_SN_LN_Idle*,_u);
}

TYPE_SN_LN_Detection& TYPE_APEWProtocol::VAR_mSN_LN_Detection() const {
    if (_u && _present!=CHOICE_mSN_LN_Detection) {
        delete _u; _u=0;
    }
    if(!_u) {
        _u = new TYPE_SN_LN_Detection;
        _present = CHOICE_mSN_LN_Detection;
    } else {
        SITEASSERT(SITE_DYNAMIC_CAST(TYPE_SN_LN_Detection*,_u),
                   "dynamic cast failure for CHOICE element");
    }
    return *SITE_STATIC_CAST(TYPE_SN_LN_Detection*,_u);
}

TYPE_SN_LN_Description& TYPE_APEWProtocol::VAR_mSN_LN_Description() const {
    if (_u && _present!=CHOICE_mSN_LN_Description) {
        delete _u; _u=0;
    }
    if(!_u) {
        _u = new TYPE_SN_LN_Description;
        _present = CHOICE_mSN_LN_Description;
    } else {
        SITEASSERT(SITE_DYNAMIC_CAST(TYPE_SN_LN_Description*,_u),
                   "dynamic cast failure for CHOICE element");
    }
    return *SITE_STATIC_CAST(TYPE_SN_LN_Description*,_u);
}

TYPE_SN_LN_Summary& TYPE_APEWProtocol::VAR_mSN_LN_Summary() const {
    if (_u && _present!=CHOICE_mSN_LN_Summary) {
        delete _u; _u=0;
    }
    if(!_u) {
        _u = new TYPE_SN_LN_Summary;
        _present = CHOICE_mSN_LN_Summary;
    } else {
        SITEASSERT(SITE_DYNAMIC_CAST(TYPE_SN_LN_Summary*,_u),
                   "dynamic cast failure for CHOICE element");
    }
    return *SITE_STATIC_CAST(TYPE_SN_LN_Summary*,_u);
}

TYPE_SN_LN_PositionChange& TYPE_APEWProtocol::VAR_mSN_LN_PositionChange() const {
    if (_u && _present!=CHOICE_mSN_LN_PositionChange) {
        delete _u; _u=0;
    }
    if(!_u) {
        _u = new TYPE_SN_LN_PositionChange;
        _present = CHOICE_mSN_LN_PositionChange;
    } else {
        SITEASSERT(SITE_DYNAMIC_CAST(TYPE_SN_LN_PositionChange*,_u),
                   "dynamic cast failure for CHOICE element");
    }
    return *SITE_STATIC_CAST(TYPE_SN_LN_PositionChange*,_u);
}

TYPE_LN_SN_Alarm& TYPE_APEWProtocol::VAR_mLN_SN_Alarm() const {
    if (_u && _present!=CHOICE_mLN_SN_Alarm) {
        delete _u; _u=0;
    }
    if(!_u) {
        _u = new TYPE_LN_SN_Alarm;
        _present = CHOICE_mLN_SN_Alarm;
    } else {
        SITEASSERT(SITE_DYNAMIC_CAST(TYPE_LN_SN_Alarm*,_u),
                   "dynamic cast failure for CHOICE element");
    }
    return *SITE_STATIC_CAST(TYPE_LN_SN_Alarm*,_u);
}

TYPE_LN_SN_FalseAlarm& TYPE_APEWProtocol::VAR_mLN_SN_FalseAlarm() const {
    if (_u && _present!=CHOICE_mLN_SN_FalseAlarm) {
        delete _u; _u=0;
    }
    if(!_u) {
        _u = new TYPE_LN_SN_FalseAlarm;
        _present = CHOICE_mLN_SN_FalseAlarm;
    } else {
        SITEASSERT(SITE_DYNAMIC_CAST(TYPE_LN_SN_FalseAlarm*,_u),
                   "dynamic cast failure for CHOICE element");
    }
    return *SITE_STATIC_CAST(TYPE_LN_SN_FalseAlarm*,_u);
}

TYPE_LN_SN_Describe& TYPE_APEWProtocol::VAR_mLN_SN_Describe() const {
    if (_u && _present!=CHOICE_mLN_SN_Describe) {
        delete _u; _u=0;
    }
    if(!_u) {
        _u = new TYPE_LN_SN_Describe;
        _present = CHOICE_mLN_SN_Describe;
    } else {
        SITEASSERT(SITE_DYNAMIC_CAST(TYPE_LN_SN_Describe*,_u),
                   "dynamic cast failure for CHOICE element");
    }
    return *SITE_STATIC_CAST(TYPE_LN_SN_Describe*,_u);
}

TYPE_LN_SN_Summarise& TYPE_APEWProtocol::VAR_mLN_SN_Summarise() const {
    if (_u && _present!=CHOICE_mLN_SN_Summarise) {
        delete _u; _u=0;
    }
    if(!_u) {
        _u = new TYPE_LN_SN_Summarise;
        _present = CHOICE_mLN_SN_Summarise;
    } else {
        SITEASSERT(SITE_DYNAMIC_CAST(TYPE_LN_SN_Summarise*,_u),
                   "dynamic cast failure for CHOICE element");
    }
    return *SITE_STATIC_CAST(TYPE_LN_SN_Summarise*,_u);
}

TYPE_LN_LN_Idle& TYPE_APEWProtocol::VAR_mLN_LN_Idle() const {
    if (_u && _present!=CHOICE_mLN_LN_Idle) {
        delete _u; _u=0;
    }
    if(!_u) {
        _u = new TYPE_LN_LN_Idle;
        _present = CHOICE_mLN_LN_Idle;
    } else {
        SITEASSERT(SITE_DYNAMIC_CAST(TYPE_LN_LN_Idle*,_u),
                   "dynamic cast failure for CHOICE element");
    }
    return *SITE_STATIC_CAST(TYPE_LN_LN_Idle*,_u);
}

TYPE_LN_LN_Detection& TYPE_APEWProtocol::VAR_mLN_LN_Detection() const {
    if (_u && _present!=CHOICE_mLN_LN_Detection) {
        delete _u; _u=0;
    }
    if(!_u) {
        _u = new TYPE_LN_LN_Detection;
        _present = CHOICE_mLN_LN_Detection;
    } else {
        SITEASSERT(SITE_DYNAMIC_CAST(TYPE_LN_LN_Detection*,_u),
                   "dynamic cast failure for CHOICE element");
    }
    return *SITE_STATIC_CAST(TYPE_LN_LN_Detection*,_u);
}

TYPE_LN_LN_Alarm& TYPE_APEWProtocol::VAR_mLN_LN_Alarm() const {
    if (_u && _present!=CHOICE_mLN_LN_Alarm) {
        delete _u; _u=0;
    }
    if(!_u) {
        _u = new TYPE_LN_LN_Alarm;
        _present = CHOICE_mLN_LN_Alarm;
    } else {
        SITEASSERT(SITE_DYNAMIC_CAST(TYPE_LN_LN_Alarm*,_u),
                   "dynamic cast failure for CHOICE element");
    }
    return *SITE_STATIC_CAST(TYPE_LN_LN_Alarm*,_u);
}

TYPE_LN_LN_Description& TYPE_APEWProtocol::VAR_mLN_LN_Description() const {
    if (_u && _present!=CHOICE_mLN_LN_Description) {
        delete _u; _u=0;
    }
    if(!_u) {
        _u = new TYPE_LN_LN_Description;
        _present = CHOICE_mLN_LN_Description;
    } else {
        SITEASSERT(SITE_DYNAMIC_CAST(TYPE_LN_LN_Description*,_u),
                   "dynamic cast failure for CHOICE element");
    }
    return *SITE_STATIC_CAST(TYPE_LN_LN_Description*,_u);
}

TYPE_LN_EN_Alarm& TYPE_APEWProtocol::VAR_mLN_EN_Alarm() const {
    if (_u && _present!=CHOICE_mLN_EN_Alarm) {
        delete _u; _u=0;
    }
    if(!_u) {
        _u = new TYPE_LN_EN_Alarm;
        _present = CHOICE_mLN_EN_Alarm;
    } else {
        SITEASSERT(SITE_DYNAMIC_CAST(TYPE_LN_EN_Alarm*,_u),
                   "dynamic cast failure for CHOICE element");
    }
    return *SITE_STATIC_CAST(TYPE_LN_EN_Alarm*,_u);
}

TYPE_LN_EN_Summary& TYPE_APEWProtocol::VAR_mLN_EN_Summary() const {
    if (_u && _present!=CHOICE_mLN_EN_Summary) {
        delete _u; _u=0;
    }
    if(!_u) {
        _u = new TYPE_LN_EN_Summary;
        _present = CHOICE_mLN_EN_Summary;
    } else {
        SITEASSERT(SITE_DYNAMIC_CAST(TYPE_LN_EN_Summary*,_u),
                   "dynamic cast failure for CHOICE element");
    }
    return *SITE_STATIC_CAST(TYPE_LN_EN_Summary*,_u);
}

void TYPE_APEWProtocol::assign_field(unsigned int variant,const SDLType& elem)
{
    switch(variant) {
        case CHOICE_mSN_LN_Idle: VAR_mSN_LN_Idle().assign(&elem); break;
        case CHOICE_mSN_LN_Detection: VAR_mSN_LN_Detection().assign(&elem); break;
        case CHOICE_mSN_LN_Description: VAR_mSN_LN_Description().assign(&elem); break;
        case CHOICE_mSN_LN_Summary: VAR_mSN_LN_Summary().assign(&elem); break;
        case CHOICE_mSN_LN_PositionChange: VAR_mSN_LN_PositionChange().assign(&elem); break;
        case CHOICE_mLN_SN_Alarm: VAR_mLN_SN_Alarm().assign(&elem); break;
        case CHOICE_mLN_SN_FalseAlarm: VAR_mLN_SN_FalseAlarm().assign(&elem); break;
        case CHOICE_mLN_SN_Describe: VAR_mLN_SN_Describe().assign(&elem); break;
        case CHOICE_mLN_SN_Summarise: VAR_mLN_SN_Summarise().assign(&elem); break;
        case CHOICE_mLN_LN_Idle: VAR_mLN_LN_Idle().assign(&elem); break;
        case CHOICE_mLN_LN_Detection: VAR_mLN_LN_Detection().assign(&elem); break;
        case CHOICE_mLN_LN_Alarm: VAR_mLN_LN_Alarm().assign(&elem); break;
        case CHOICE_mLN_LN_Description: VAR_mLN_LN_Description().assign(&elem); break;
        case CHOICE_mLN_EN_Alarm: VAR_mLN_EN_Alarm().assign(&elem); break;
        case CHOICE_mLN_EN_Summary: VAR_mLN_EN_Summary().assign(&elem); break;
        default : SDLASSERT(0,"wrong choice variant");
    }
    SDLASSERT(_u,"type error for choice variant");
} // TYPE_APEWProtocol::assign_field

AsnLen TYPE_APEWProtocol::bEnc(BUF_TYPE b) const {
    AsnLen elmtLen = bEncContent(b);
    return elmtLen;
} // TYPE_APEWProtocol::bEnc

AsnLen TYPE_APEWProtocol::bEncContent(BUF_TYPE b) const {
    AsnLen elmtLen;
    switch(_present) {
        case CHOICE_mSN_LN_Idle :
            elmtLen = VAR_mSN_LN_Idle().bEncContent(b);
            elmtLen += BEncDefLen(b,elmtLen);
            elmtLen += BEncTag1(b,UNIV,CONS,16);
            elmtLen += BEncDefLen(b,elmtLen);
            elmtLen += BEncTag1(b,CNTX,CONS,1);
            return elmtLen;
        case CHOICE_mSN_LN_Detection :
            elmtLen = VAR_mSN_LN_Detection().bEncContent(b);
            elmtLen += BEncDefLen(b,elmtLen);
            elmtLen += BEncTag1(b,UNIV,CONS,16);
            elmtLen += BEncDefLen(b,elmtLen);
            elmtLen += BEncTag1(b,CNTX,CONS,2);
            return elmtLen;
        case CHOICE_mSN_LN_Description :
            elmtLen = VAR_mSN_LN_Description().bEncContent(b);
            elmtLen += BEncDefLen(b,elmtLen);
            elmtLen += BEncTag1(b,UNIV,CONS,16);
            elmtLen += BEncDefLen(b,elmtLen);
            elmtLen += BEncTag1(b,CNTX,CONS,3);
            return elmtLen;
        case CHOICE_mSN_LN_Summary :
            elmtLen = VAR_mSN_LN_Summary().bEncContent(b);
            elmtLen += BEncDefLen(b,elmtLen);
            elmtLen += BEncTag1(b,UNIV,CONS,16);
            elmtLen += BEncDefLen(b,elmtLen);
            elmtLen += BEncTag1(b,CNTX,CONS,4);
            return elmtLen;
        case CHOICE_mSN_LN_PositionChange :
            elmtLen = VAR_mSN_LN_PositionChange().bEncContent(b);
            elmtLen += BEncDefLen(b,elmtLen);
            elmtLen += BEncTag1(b,UNIV,CONS,16);
            elmtLen += BEncDefLen(b,elmtLen);
            elmtLen += BEncTag1(b,CNTX,CONS,5);
            return elmtLen;
        case CHOICE_mLN_SN_Alarm :
            elmtLen = VAR_mLN_SN_Alarm().bEncContent(b);
            elmtLen += BEncDefLen(b,elmtLen);
            elmtLen += BEncTag1(b,UNIV,CONS,16);
            elmtLen += BEncDefLen(b,elmtLen);
            elmtLen += BEncTag1(b,CNTX,CONS,6);
            return elmtLen;
        case CHOICE_mLN_SN_FalseAlarm :
            elmtLen = VAR_mLN_SN_FalseAlarm().bEncContent(b);
            elmtLen += BEncDefLen(b,elmtLen);
            elmtLen += BEncTag1(b,UNIV,CONS,16);
            elmtLen += BEncDefLen(b,elmtLen);
            elmtLen += BEncTag1(b,CNTX,CONS,7);
            return elmtLen;
        case CHOICE_mLN_SN_Describe :
            elmtLen = VAR_mLN_SN_Describe().bEncContent(b);
            elmtLen += BEncDefLen(b,elmtLen);
            elmtLen += BEncTag1(b,UNIV,CONS,16);
            elmtLen += BEncDefLen(b,elmtLen);
            elmtLen += BEncTag1(b,CNTX,CONS,8);
            return elmtLen;
        case CHOICE_mLN_SN_Summarise :
            elmtLen = VAR_mLN_SN_Summarise().bEncContent(b);
            elmtLen += BEncDefLen(b,elmtLen);
            elmtLen += BEncTag1(b,UNIV,CONS,16);
            elmtLen += BEncDefLen(b,elmtLen);
            elmtLen += BEncTag1(b,CNTX,CONS,9);
            return elmtLen;
        case CHOICE_mLN_LN_Idle :
            elmtLen = VAR_mLN_LN_Idle().bEncContent(b);
            elmtLen += BEncDefLen(b,elmtLen);
            elmtLen += BEncTag1(b,UNIV,CONS,16);
            elmtLen += BEncDefLen(b,elmtLen);
            elmtLen += BEncTag1(b,CNTX,CONS,10);
            return elmtLen;
        case CHOICE_mLN_LN_Detection :
            elmtLen = VAR_mLN_LN_Detection().bEncContent(b);
            elmtLen += BEncDefLen(b,elmtLen);
            elmtLen += BEncTag1(b,UNIV,CONS,16);
            elmtLen += BEncDefLen(b,elmtLen);
            elmtLen += BEncTag1(b,CNTX,CONS,11);
            return elmtLen;
        case CHOICE_mLN_LN_Alarm :
            elmtLen = VAR_mLN_LN_Alarm().bEncContent(b);
            elmtLen += BEncDefLen(b,elmtLen);
            elmtLen += BEncTag1(b,UNIV,CONS,16);
            elmtLen += BEncDefLen(b,elmtLen);
            elmtLen += BEncTag1(b,CNTX,CONS,12);
            return elmtLen;
        case CHOICE_mLN_LN_Description :
            elmtLen = VAR_mLN_LN_Description().bEncContent(b);
            elmtLen += BEncDefLen(b,elmtLen);
            elmtLen += BEncTag1(b,UNIV,CONS,16);
            elmtLen += BEncDefLen(b,elmtLen);
            elmtLen += BEncTag1(b,CNTX,CONS,13);
            return elmtLen;
        case CHOICE_mLN_EN_Alarm :
            elmtLen = VAR_mLN_EN_Alarm().bEncContent(b);
            elmtLen += BEncDefLen(b,elmtLen);
            elmtLen += BEncTag1(b,UNIV,CONS,16);
            elmtLen += BEncDefLen(b,elmtLen);
            elmtLen += BEncTag1(b,CNTX,CONS,14);
            return elmtLen;
        case CHOICE_mLN_EN_Summary :
            elmtLen = VAR_mLN_EN_Summary().bEncContent(b);
            elmtLen += BEncDefLen(b,elmtLen);
            elmtLen += BEncTag1(b,UNIV,CONS,16);
            elmtLen += BEncDefLen(b,elmtLen);
            elmtLen += BEncTag1(b,CNTX,CONS,15);
            return elmtLen;
        default:;
    }
    ChoiceError("ERROR no valid field");
    return 0;
} // TYPE_APEWProtocol::bEncContent

void TYPE_APEWProtocol::bDec(BUF_TYPE b,AsnLen& bytesDecoded) {
    AsnTag tagId = BDecTag(b,bytesDecoded);
    AsnLen elmtLen = BDecLen(b,bytesDecoded);
    bDecContent(b,tagId,elmtLen,bytesDecoded);
} // TYPE_APEWProtocol::bDec

void TYPE_APEWProtocol::bDecContent(BUF_TYPE b,AsnTag tagId,
        AsnLen len, AsnLen& bytesDecoded) {
    AsnLen elmtLen = len, localBytesDecoded = 0;
    int pending_eoc = 0; // can be unused if implicit tagged 
    switch(tagId) {
        case MAKE_TAG_ID(CNTX,CONS,1):
            if (elmtLen == INDEFINITE_LEN) ++pending_eoc;
            tagId = BDecTag1(b,localBytesDecoded);
            if (tagId == MAKE_TAG_ID(UNIV,CONS,16)) {
              elmtLen = BDecLen(b,localBytesDecoded);
            } else { TagError(MAKE_TAG_ID(UNIV,CONS,16),tagId); return; }
            VAR_mSN_LN_Idle().bDecContent(b,tagId,elmtLen,localBytesDecoded);
            break;
        case MAKE_TAG_ID(CNTX,CONS,2):
            if (elmtLen == INDEFINITE_LEN) ++pending_eoc;
            tagId = BDecTag1(b,localBytesDecoded);
            if (tagId == MAKE_TAG_ID(UNIV,CONS,16)) {
              elmtLen = BDecLen(b,localBytesDecoded);
            } else { TagError(MAKE_TAG_ID(UNIV,CONS,16),tagId); return; }
            VAR_mSN_LN_Detection().bDecContent(b,tagId,elmtLen,localBytesDecoded);
            break;
        case MAKE_TAG_ID(CNTX,CONS,3):
            if (elmtLen == INDEFINITE_LEN) ++pending_eoc;
            tagId = BDecTag1(b,localBytesDecoded);
            if (tagId == MAKE_TAG_ID(UNIV,CONS,16)) {
              elmtLen = BDecLen(b,localBytesDecoded);
            } else { TagError(MAKE_TAG_ID(UNIV,CONS,16),tagId); return; }
            VAR_mSN_LN_Description().bDecContent(b,tagId,elmtLen,localBytesDecoded);
            break;
        case MAKE_TAG_ID(CNTX,CONS,4):
            if (elmtLen == INDEFINITE_LEN) ++pending_eoc;
            tagId = BDecTag1(b,localBytesDecoded);
            if (tagId == MAKE_TAG_ID(UNIV,CONS,16)) {
              elmtLen = BDecLen(b,localBytesDecoded);
            } else { TagError(MAKE_TAG_ID(UNIV,CONS,16),tagId); return; }
            VAR_mSN_LN_Summary().bDecContent(b,tagId,elmtLen,localBytesDecoded);
            break;
        case MAKE_TAG_ID(CNTX,CONS,5):
            if (elmtLen == INDEFINITE_LEN) ++pending_eoc;
            tagId = BDecTag1(b,localBytesDecoded);
            if (tagId == MAKE_TAG_ID(UNIV,CONS,16)) {
              elmtLen = BDecLen(b,localBytesDecoded);
            } else { TagError(MAKE_TAG_ID(UNIV,CONS,16),tagId); return; }
            VAR_mSN_LN_PositionChange().bDecContent(b,tagId,elmtLen,localBytesDecoded);
            break;
        case MAKE_TAG_ID(CNTX,CONS,6):
            if (elmtLen == INDEFINITE_LEN) ++pending_eoc;
            tagId = BDecTag1(b,localBytesDecoded);
            if (tagId == MAKE_TAG_ID(UNIV,CONS,16)) {
              elmtLen = BDecLen(b,localBytesDecoded);
            } else { TagError(MAKE_TAG_ID(UNIV,CONS,16),tagId); return; }
            VAR_mLN_SN_Alarm().bDecContent(b,tagId,elmtLen,localBytesDecoded);
            break;
        case MAKE_TAG_ID(CNTX,CONS,7):
            if (elmtLen == INDEFINITE_LEN) ++pending_eoc;
            tagId = BDecTag1(b,localBytesDecoded);
            if (tagId == MAKE_TAG_ID(UNIV,CONS,16)) {
              elmtLen = BDecLen(b,localBytesDecoded);
            } else { TagError(MAKE_TAG_ID(UNIV,CONS,16),tagId); return; }
            VAR_mLN_SN_FalseAlarm().bDecContent(b,tagId,elmtLen,localBytesDecoded);
            break;
        case MAKE_TAG_ID(CNTX,CONS,8):
            if (elmtLen == INDEFINITE_LEN) ++pending_eoc;
            tagId = BDecTag1(b,localBytesDecoded);
            if (tagId == MAKE_TAG_ID(UNIV,CONS,16)) {
              elmtLen = BDecLen(b,localBytesDecoded);
            } else { TagError(MAKE_TAG_ID(UNIV,CONS,16),tagId); return; }
            VAR_mLN_SN_Describe().bDecContent(b,tagId,elmtLen,localBytesDecoded);
            break;
        case MAKE_TAG_ID(CNTX,CONS,9):
            if (elmtLen == INDEFINITE_LEN) ++pending_eoc;
            tagId = BDecTag1(b,localBytesDecoded);
            if (tagId == MAKE_TAG_ID(UNIV,CONS,16)) {
              elmtLen = BDecLen(b,localBytesDecoded);
            } else { TagError(MAKE_TAG_ID(UNIV,CONS,16),tagId); return; }
            VAR_mLN_SN_Summarise().bDecContent(b,tagId,elmtLen,localBytesDecoded);
            break;
        case MAKE_TAG_ID(CNTX,CONS,10):
            if (elmtLen == INDEFINITE_LEN) ++pending_eoc;
            tagId = BDecTag1(b,localBytesDecoded);
            if (tagId == MAKE_TAG_ID(UNIV,CONS,16)) {
              elmtLen = BDecLen(b,localBytesDecoded);
            } else { TagError(MAKE_TAG_ID(UNIV,CONS,16),tagId); return; }
            VAR_mLN_LN_Idle().bDecContent(b,tagId,elmtLen,localBytesDecoded);
            break;
        case MAKE_TAG_ID(CNTX,CONS,11):
            if (elmtLen == INDEFINITE_LEN) ++pending_eoc;
            tagId = BDecTag1(b,localBytesDecoded);
            if (tagId == MAKE_TAG_ID(UNIV,CONS,16)) {
              elmtLen = BDecLen(b,localBytesDecoded);
            } else { TagError(MAKE_TAG_ID(UNIV,CONS,16),tagId); return; }
            VAR_mLN_LN_Detection().bDecContent(b,tagId,elmtLen,localBytesDecoded);
            break;
        case MAKE_TAG_ID(CNTX,CONS,12):
            if (elmtLen == INDEFINITE_LEN) ++pending_eoc;
            tagId = BDecTag1(b,localBytesDecoded);
            if (tagId == MAKE_TAG_ID(UNIV,CONS,16)) {
              elmtLen = BDecLen(b,localBytesDecoded);
            } else { TagError(MAKE_TAG_ID(UNIV,CONS,16),tagId); return; }
            VAR_mLN_LN_Alarm().bDecContent(b,tagId,elmtLen,localBytesDecoded);
            break;
        case MAKE_TAG_ID(CNTX,CONS,13):
            if (elmtLen == INDEFINITE_LEN) ++pending_eoc;
            tagId = BDecTag1(b,localBytesDecoded);
            if (tagId == MAKE_TAG_ID(UNIV,CONS,16)) {
              elmtLen = BDecLen(b,localBytesDecoded);
            } else { TagError(MAKE_TAG_ID(UNIV,CONS,16),tagId); return; }
            VAR_mLN_LN_Description().bDecContent(b,tagId,elmtLen,localBytesDecoded);
            break;
        case MAKE_TAG_ID(CNTX,CONS,14):
            if (elmtLen == INDEFINITE_LEN) ++pending_eoc;
            tagId = BDecTag1(b,localBytesDecoded);
            if (tagId == MAKE_TAG_ID(UNIV,CONS,16)) {
              elmtLen = BDecLen(b,localBytesDecoded);
            } else { TagError(MAKE_TAG_ID(UNIV,CONS,16),tagId); return; }
            VAR_mLN_EN_Alarm().bDecContent(b,tagId,elmtLen,localBytesDecoded);
            break;
        case MAKE_TAG_ID(CNTX,CONS,15):
            if (elmtLen == INDEFINITE_LEN) ++pending_eoc;
            tagId = BDecTag1(b,localBytesDecoded);
            if (tagId == MAKE_TAG_ID(UNIV,CONS,16)) {
              elmtLen = BDecLen(b,localBytesDecoded);
            } else { TagError(MAKE_TAG_ID(UNIV,CONS,16),tagId); return; }
            VAR_mLN_EN_Summary().bDecContent(b,tagId,elmtLen,localBytesDecoded);
            break;
        default: TagError(0,tagId); return;
    } /* tag switch */
    bytesDecoded += localBytesDecoded;
    for(;pending_eoc>0;--pending_eoc) { BDecEoc(b,localBytesDecoded); }
    if ((len!=INDEFINITE_LEN) && (localBytesDecoded!=len)) { LengthError();return; }
    set_state(validValue);
} // TYPE_APEWProtocol::bDecContent

AsnLen TYPE_APEWProtocol::pEnc(BUF_TYPE2 b) const {
    int off, elmtLen;
    switch(_present){
        case CHOICE_mLN_EN_Summary : off=0; break;
        case CHOICE_mLN_EN_Alarm : off=1; break;
        case CHOICE_mLN_LN_Description : off=2; break;
        case CHOICE_mLN_LN_Alarm : off=3; break;
        case CHOICE_mLN_LN_Detection : off=4; break;
        case CHOICE_mLN_LN_Idle : off=5; break;
        case CHOICE_mLN_SN_Summarise : off=6; break;
        case CHOICE_mLN_SN_Describe : off=7; break;
        case CHOICE_mLN_SN_FalseAlarm : off=8; break;
        case CHOICE_mLN_SN_Alarm : off=9; break;
        case CHOICE_mSN_LN_PositionChange : off=10; break;
        case CHOICE_mSN_LN_Summary : off=11; break;
        case CHOICE_mSN_LN_Description : off=12; break;
        case CHOICE_mSN_LN_Detection : off=13; break;
        case CHOICE_mSN_LN_Idle : off=14; break;
    }
    SITE_SDL_UINT mask = 0x8LL;
    for(int i=0; i<4; mask>>=1,i++)
      b.putBit(off & mask);
    switch(_present){
        case CHOICE_mLN_EN_Summary : elmtLen = VAR_mLN_EN_Summary().pEnc(b); break;
        case CHOICE_mLN_EN_Alarm : elmtLen = VAR_mLN_EN_Alarm().pEnc(b); break;
        case CHOICE_mLN_LN_Description : elmtLen = VAR_mLN_LN_Description().pEnc(b); break;
        case CHOICE_mLN_LN_Alarm : elmtLen = VAR_mLN_LN_Alarm().pEnc(b); break;
        case CHOICE_mLN_LN_Detection : elmtLen = VAR_mLN_LN_Detection().pEnc(b); break;
        case CHOICE_mLN_LN_Idle : elmtLen = VAR_mLN_LN_Idle().pEnc(b); break;
        case CHOICE_mLN_SN_Summarise : elmtLen = VAR_mLN_SN_Summarise().pEnc(b); break;
        case CHOICE_mLN_SN_Describe : elmtLen = VAR_mLN_SN_Describe().pEnc(b); break;
        case CHOICE_mLN_SN_FalseAlarm : elmtLen = VAR_mLN_SN_FalseAlarm().pEnc(b); break;
        case CHOICE_mLN_SN_Alarm : elmtLen = VAR_mLN_SN_Alarm().pEnc(b); break;
        case CHOICE_mSN_LN_PositionChange : elmtLen = VAR_mSN_LN_PositionChange().pEnc(b); break;
        case CHOICE_mSN_LN_Summary : elmtLen = VAR_mSN_LN_Summary().pEnc(b); break;
        case CHOICE_mSN_LN_Description : elmtLen = VAR_mSN_LN_Description().pEnc(b); break;
        case CHOICE_mSN_LN_Detection : elmtLen = VAR_mSN_LN_Detection().pEnc(b); break;
        case CHOICE_mSN_LN_Idle : elmtLen = VAR_mSN_LN_Idle().pEnc(b); break;
    }
    return elmtLen + 4;
}

void TYPE_APEWProtocol::pDec(BUF_TYPE2 b) {
    SITE_SDL_UINT off = 0;
    for(int i=0; i<4; i++)
      off = (off << 1) | (b.getBit()?1:0);
    switch(off){
        case 0 : _present = CHOICE_mLN_EN_Summary; VAR_mLN_EN_Summary().pDec(b); break;
        case 1 : _present = CHOICE_mLN_EN_Alarm; VAR_mLN_EN_Alarm().pDec(b); break;
        case 2 : _present = CHOICE_mLN_LN_Description; VAR_mLN_LN_Description().pDec(b); break;
        case 3 : _present = CHOICE_mLN_LN_Alarm; VAR_mLN_LN_Alarm().pDec(b); break;
        case 4 : _present = CHOICE_mLN_LN_Detection; VAR_mLN_LN_Detection().pDec(b); break;
        case 5 : _present = CHOICE_mLN_LN_Idle; VAR_mLN_LN_Idle().pDec(b); break;
        case 6 : _present = CHOICE_mLN_SN_Summarise; VAR_mLN_SN_Summarise().pDec(b); break;
        case 7 : _present = CHOICE_mLN_SN_Describe; VAR_mLN_SN_Describe().pDec(b); break;
        case 8 : _present = CHOICE_mLN_SN_FalseAlarm; VAR_mLN_SN_FalseAlarm().pDec(b); break;
        case 9 : _present = CHOICE_mLN_SN_Alarm; VAR_mLN_SN_Alarm().pDec(b); break;
        case 10 : _present = CHOICE_mSN_LN_PositionChange; VAR_mSN_LN_PositionChange().pDec(b); break;
        case 11 : _present = CHOICE_mSN_LN_Summary; VAR_mSN_LN_Summary().pDec(b); break;
        case 12 : _present = CHOICE_mSN_LN_Description; VAR_mSN_LN_Description().pDec(b); break;
        case 13 : _present = CHOICE_mSN_LN_Detection; VAR_mSN_LN_Detection().pDec(b); break;
        case 14 : _present = CHOICE_mSN_LN_Idle; VAR_mSN_LN_Idle().pDec(b); break;
    }
    set_state(validValue);
}

bool TYPE_APEWProtocol::datainfo(long index,SDLIA5String& var_name,
    SDLIA5String& var_type,SDLType*& var,SDLType::infotype it)
{
    switch(index) {
    case 1:
        var_name="mSN-LN-Idle";
        var_type="SN-LN-Idle";
        if (_present!=CHOICE_mSN_LN_Idle && it==SDLType::info_get)
          var = 0;
        else
          var = &VAR_mSN_LN_Idle();
        break;
    case 2:
        var_name="mSN-LN-Detection";
        var_type="SN-LN-Detection";
        if (_present!=CHOICE_mSN_LN_Detection && it==SDLType::info_get)
          var = 0;
        else
          var = &VAR_mSN_LN_Detection();
        break;
    case 3:
        var_name="mSN-LN-Description";
        var_type="SN-LN-Description";
        if (_present!=CHOICE_mSN_LN_Description && it==SDLType::info_get)
          var = 0;
        else
          var = &VAR_mSN_LN_Description();
        break;
    case 4:
        var_name="mSN-LN-Summary";
        var_type="SN-LN-Summary";
        if (_present!=CHOICE_mSN_LN_Summary && it==SDLType::info_get)
          var = 0;
        else
          var = &VAR_mSN_LN_Summary();
        break;
    case 5:
        var_name="mSN-LN-PositionChange";
        var_type="SN-LN-PositionChange";
        if (_present!=CHOICE_mSN_LN_PositionChange && it==SDLType::info_get)
          var = 0;
        else
          var = &VAR_mSN_LN_PositionChange();
        break;
    case 6:
        var_name="mLN-SN-Alarm";
        var_type="LN-SN-Alarm";
        if (_present!=CHOICE_mLN_SN_Alarm && it==SDLType::info_get)
          var = 0;
        else
          var = &VAR_mLN_SN_Alarm();
        break;
    case 7:
        var_name="mLN-SN-FalseAlarm";
        var_type="LN-SN-FalseAlarm";
        if (_present!=CHOICE_mLN_SN_FalseAlarm && it==SDLType::info_get)
          var = 0;
        else
          var = &VAR_mLN_SN_FalseAlarm();
        break;
    case 8:
        var_name="mLN-SN-Describe";
        var_type="LN-SN-Describe";
        if (_present!=CHOICE_mLN_SN_Describe && it==SDLType::info_get)
          var = 0;
        else
          var = &VAR_mLN_SN_Describe();
        break;
    case 9:
        var_name="mLN-SN-Summarise";
        var_type="LN-SN-Summarise";
        if (_present!=CHOICE_mLN_SN_Summarise && it==SDLType::info_get)
          var = 0;
        else
          var = &VAR_mLN_SN_Summarise();
        break;
    case 10:
        var_name="mLN-LN-Idle";
        var_type="LN-LN-Idle";
        if (_present!=CHOICE_mLN_LN_Idle && it==SDLType::info_get)
          var = 0;
        else
          var = &VAR_mLN_LN_Idle();
        break;
    case 11:
        var_name="mLN-LN-Detection";
        var_type="LN-LN-Detection";
        if (_present!=CHOICE_mLN_LN_Detection && it==SDLType::info_get)
          var = 0;
        else
          var = &VAR_mLN_LN_Detection();
        break;
    case 12:
        var_name="mLN-LN-Alarm";
        var_type="LN-LN-Alarm";
        if (_present!=CHOICE_mLN_LN_Alarm && it==SDLType::info_get)
          var = 0;
        else
          var = &VAR_mLN_LN_Alarm();
        break;
    case 13:
        var_name="mLN-LN-Description";
        var_type="LN-LN-Description";
        if (_present!=CHOICE_mLN_LN_Description && it==SDLType::info_get)
          var = 0;
        else
          var = &VAR_mLN_LN_Description();
        break;
    case 14:
        var_name="mLN-EN-Alarm";
        var_type="LN-EN-Alarm";
        if (_present!=CHOICE_mLN_EN_Alarm && it==SDLType::info_get)
          var = 0;
        else
          var = &VAR_mLN_EN_Alarm();
        break;
    case 15:
        var_name="mLN-EN-Summary";
        var_type="LN-EN-Summary";
        if (_present!=CHOICE_mLN_EN_Summary && it==SDLType::info_get)
          var = 0;
        else
          var = &VAR_mLN_EN_Summary();
        break;
    default: return false;
    }
    return true;
} /* TYPE_APEWProtocol::datainfo */

TYPE_Acceleration::TYPE_Acceleration(const SDLAny& a, AsnCodingSet rule_set){                                      a.decode(this,rule_set); }

SDLType* TYPE_Acceleration::copy()const { return new TYPE_Acceleration(*this); }

void TYPE_Acceleration::assign(const SDLType* t)
{
  const TYPE_Acceleration *arg = SITE_DYNAMIC_CAST(const TYPE_Acceleration*,t);
  if (!arg) SDLReal::assign(t);
  else *this = *arg;
}

SDLType* TYPE_Acceleration::create()
{
  static TYPE_Acceleration* tmpl = new TYPE_Acceleration;
  return tmpl;
}

const SDLType* TYPE_Acceleration::create_new() const { return create(); }

const SDLBool& TYPE_Acceleration::check() const{
    if(((ge(SDLReal(2).neg()))&&(le(2)))) return SDLBool::SDLTrue();
    return SDLBool::SDLFalse();
}

// data type "TYPE_Velocity" is just a #define

// data type "TYPE_Displacement" is just a #define

// data type "TYPE_Frequency" is just a #define

// data type "TYPE_IPAddress" is just a #define

// data type "TYPE_EventID" is just a #define

TYPE_GroupID::TYPE_GroupID(const SDLAny& a, AsnCodingSet rule_set){                                      a.decode(this,rule_set); }

SDLType* TYPE_GroupID::copy()const { return new TYPE_GroupID(*this); }

void TYPE_GroupID::assign(const SDLType* t)
{
  const TYPE_GroupID *arg = SITE_DYNAMIC_CAST(const TYPE_GroupID*,t);
  if (!arg) SDLInt::assign(t);
  else *this = *arg;
}

SDLType* TYPE_GroupID::create()
{
  static TYPE_GroupID* tmpl = new TYPE_GroupID;
  return tmpl;
}

const SDLType* TYPE_GroupID::create_new() const { return create(); }

AsnLen TYPE_GroupID::pEnc(BUF_TYPE2 b) const {
    SITE_SDL_UINT off = _value - 0LL;
    SITE_SDL_UINT mask = 0xff00000000000000LL;
    int len;
    for(len=8; len>1; mask>>8,len--)
        if(off & mask) break;
    pEncLen(b, len);
    for(int i=len-1; i>=0; mask>>=8,i--)
        b.putByte(static_cast<char>((off & mask)>>(i*8)));
    return 8*(len+1);
}

void TYPE_GroupID::pDec(BUF_TYPE2 b) {
    /* PER UNALIGNED VARIANT */
    SITE_SDL_UINT off = 0;
    int len = pDecLen(b);
    for(int i=0; i<len; i++)
        off = (off << 8) | b.getByte();
    _value = off + 0LL;
    set_state(validValue);
}

const SDLBool& TYPE_GroupID::check() const{
    if(((ge(0))&&true /* half open intervall */)) return SDLBool::SDLTrue();
    return SDLBool::SDLFalse();
}

SDLSeqSetDescription TYPE_DateTime::_fdesc(2);

SDLType* TYPE_DateTime::copy()const { return new TYPE_DateTime(*this); }

void TYPE_DateTime::assign(const SDLType* t)
{
  const TYPE_DateTime *arg = SITE_DYNAMIC_CAST(const TYPE_DateTime*,t);
  if (!arg) SDLSequence::assign(t);
  else *this = *arg;
}

SDLType* TYPE_DateTime::create()
{
  static TYPE_DateTime* tmpl = new TYPE_DateTime;
  return tmpl;
}

const SDLType* TYPE_DateTime::create_new() const { return create(); }

TYPE_DateTime::TYPE_DateTime():SDLSequence(_fields,2){}
TYPE_DateTime::TYPE_DateTime(SDLType** f,unsigned long c):SDLSequence(f,c){}
TYPE_DateTime::TYPE_DateTime(const SDLNull&):SDLSequence(_fields,2)
{ set_state(invalidValue); }
TYPE_DateTime::TYPE_DateTime(const SDLAny& a, AsnCodingSet rule_set):SDLSequence(_fields,2){a.decode(this,rule_set);}
TYPE_DateTime::TYPE_DateTime(const TYPE_DateTime&o):SDLSequence(o){
  if (o.state(SITEtemporaryValue)) {
#ifdef SITE_LOG
    if (SDLType::_type_debug & SITE_COPY_LOG)
      CERR << "(SDLRTE) struct reference copy of " << o << ENDL;
#endif
    for(int i=0; i<2;++i) {
       _fields[i] = o._fields[i]; o._fields[i] = 0;
    }
  } else sequence_copyinit(_fields,o._fields,2);
}
TYPE_DateTime::~TYPE_DateTime(){clear_fields(_fields,2);}

TYPE_DateTime& TYPE_DateTime::operator=(const TYPE_DateTime& val){
  val.check_valid();
  if (this!=&val) sequence_assign(val);
  return *this;
}

unsigned int TYPE_DateTime::hash(unsigned int max_hash)const{
  return sequence_hash(_fields, 2, max_hash);
}

void TYPE_DateTime::get_fields(
  SDLSeqSetDescription*& d,SDLType **&field_list){
  d=&_fdesc; field_list=_fields;
}

void TYPE_DateTime::get_fields(
  SDLSeqSetDescription*& d,SDLType *const*&field_list) const{
  d=&_fdesc; field_list=_fields;
}


TYPE_APEWProtocol_GEN_1& TYPE_DateTime::VAR_unixTime() const
{ return *SITE_STATIC_CAST(TYPE_APEWProtocol_GEN_1*,field_access(_fdesc,_fields,0)); }
static SDLSeqSetDescription::Field *_TYPE_DateTimeunixTime=TYPE_DateTime::_fdesc.add(0,"unixTime",&TYPE_APEWProtocol_GEN_1::create,true);

TYPE_APEWProtocol_GEN_2& TYPE_DateTime::VAR_msFraction() const
{ return *SITE_STATIC_CAST(TYPE_APEWProtocol_GEN_2*,field_access(_fdesc,_fields,1)); }
static SDLSeqSetDescription::Field *_TYPE_DateTimemsFraction=TYPE_DateTime::_fdesc.add(1,"msFraction",&TYPE_APEWProtocol_GEN_2::create,true);



TYPE_DateTime::TYPE_DateTime(const class TYPE_APEWProtocol_GEN_1& PAR_0, const class TYPE_APEWProtocol_GEN_2& PAR_1) {
    set_field(0,PAR_0.copy());
    set_field(1,PAR_1.copy());
}

AsnLen TYPE_DateTime::bEnc(BUF_TYPE b) const{
    AsnLen elmtLen = bEncContent(b);
    elmtLen += BEncDefLen(b,elmtLen);
    elmtLen += BEncTag1(b,UNIV,CONS,16);
    return elmtLen;
} // TYPE_DateTime::bEnc

AsnLen TYPE_DateTime::bEncContent(BUF_TYPE b) const {
    AsnLen elmtLen, structBytesEncoded = BEncExtraFields(b);
    elmtLen = VAR_msFraction().bEncContent(b);
    elmtLen += BEncDefLen(b,elmtLen);
    elmtLen += BEncTag1(b,UNIV,PRIM,2);
    structBytesEncoded += elmtLen;
    elmtLen = VAR_unixTime().bEncContent(b);
    elmtLen += BEncDefLen(b,elmtLen);
    elmtLen += BEncTag1(b,UNIV,PRIM,2);
    structBytesEncoded += elmtLen;
    return structBytesEncoded;
} // TYPE_DateTime::bEncContent

void TYPE_DateTime::bDec(BUF_TYPE b,AsnLen& bytesDecoded) {
    AsnTag tagId = BDecTag1(b,bytesDecoded);
    AsnLen elmtLen;
    if (tagId != MAKE_TAG_ID(UNIV,CONS,16)) { TagError(MAKE_TAG_ID(UNIV,CONS,16),tagId); return; }
    elmtLen = BDecLen(b,bytesDecoded);
    int pending_eoc = 0;
    if (elmtLen == INDEFINITE_LEN) ++pending_eoc;
    AsnLen localBytesDecoded = 0;
    bDecContent(b,tagId,elmtLen,localBytesDecoded);
    for(;pending_eoc>0;--pending_eoc) { BDecEoc(b,localBytesDecoded); }
    bytesDecoded += localBytesDecoded;
} // TYPE_DateTime::bDec

void TYPE_DateTime::bDecContent(BUF_TYPE b,AsnTag,
        AsnLen len, AsnLen& bytesDecoded) {
    bool structDone = false;
    AsnLen elmtLen, localBytesDecoded = 0;
    AsnTag tagId;
    if (len == 0) { tagId = 0; structDone = true; }
    else tagId = BDecTag(b,localBytesDecoded);
    if (!structDone && (tagId==MAKE_TAG_ID(UNIV,PRIM,2))) {
        elmtLen = BDecLen(b,localBytesDecoded);
        VAR_unixTime().bDecContent(b,tagId,elmtLen,localBytesDecoded);
        if ((len!=INDEFINITE_LEN) && (localBytesDecoded>=len)) structDone = true;
        else tagId = BDecTag(b,localBytesDecoded);
    } else { TagError(MAKE_TAG_ID(UNIV,PRIM,2),tagId); return; }
    if (!structDone && (tagId==MAKE_TAG_ID(UNIV,PRIM,2))) {
        elmtLen = BDecLen(b,localBytesDecoded);
        VAR_msFraction().bDecContent(b,tagId,elmtLen,localBytesDecoded);
        if ((len!=INDEFINITE_LEN) && (localBytesDecoded>=len)) structDone = true;
        else tagId = BDecTag(b,localBytesDecoded);
    } else { TagError(MAKE_TAG_ID(UNIV,PRIM,2),tagId); return; }
    complete_sequence_decoding(b, len, localBytesDecoded, tagId);
    bytesDecoded += localBytesDecoded;
    set_state(validValue);
} // TYPE_DateTime::bDecContent

AsnLen TYPE_DateTime::pEnc(BUF_TYPE2 b) const {
    int elmtLen=0;
    elmtLen += VAR_unixTime().pEnc(b);
    elmtLen += VAR_msFraction().pEnc(b);
    return elmtLen;
}

void TYPE_DateTime::pDec(BUF_TYPE2 b) {
    VAR_unixTime().pDec(b);
    VAR_msFraction().pDec(b);
    set_state(validValue);
}

SDLSeqSetDescription TYPE_GeographicCoordinate::_fdesc(3);

SDLType* TYPE_GeographicCoordinate::copy()const { return new TYPE_GeographicCoordinate(*this); }

void TYPE_GeographicCoordinate::assign(const SDLType* t)
{
  const TYPE_GeographicCoordinate *arg = SITE_DYNAMIC_CAST(const TYPE_GeographicCoordinate*,t);
  if (!arg) SDLSequence::assign(t);
  else *this = *arg;
}

SDLType* TYPE_GeographicCoordinate::create()
{
  static TYPE_GeographicCoordinate* tmpl = new TYPE_GeographicCoordinate;
  return tmpl;
}

const SDLType* TYPE_GeographicCoordinate::create_new() const { return create(); }

TYPE_GeographicCoordinate::TYPE_GeographicCoordinate():SDLSequence(_fields,3){}
TYPE_GeographicCoordinate::TYPE_GeographicCoordinate(SDLType** f,unsigned long c):SDLSequence(f,c){}
TYPE_GeographicCoordinate::TYPE_GeographicCoordinate(const SDLNull&):SDLSequence(_fields,3)
{ set_state(invalidValue); }
TYPE_GeographicCoordinate::TYPE_GeographicCoordinate(const SDLAny& a, AsnCodingSet rule_set):SDLSequence(_fields,3){a.decode(this,rule_set);}
TYPE_GeographicCoordinate::TYPE_GeographicCoordinate(const TYPE_GeographicCoordinate&o):SDLSequence(o){
  if (o.state(SITEtemporaryValue)) {
#ifdef SITE_LOG
    if (SDLType::_type_debug & SITE_COPY_LOG)
      CERR << "(SDLRTE) struct reference copy of " << o << ENDL;
#endif
    for(int i=0; i<3;++i) {
       _fields[i] = o._fields[i]; o._fields[i] = 0;
    }
  } else sequence_copyinit(_fields,o._fields,3);
}
TYPE_GeographicCoordinate::~TYPE_GeographicCoordinate(){clear_fields(_fields,3);}

TYPE_GeographicCoordinate& TYPE_GeographicCoordinate::operator=(const TYPE_GeographicCoordinate& val){
  val.check_valid();
  if (this!=&val) sequence_assign(val);
  return *this;
}

unsigned int TYPE_GeographicCoordinate::hash(unsigned int max_hash)const{
  return sequence_hash(_fields, 3, max_hash);
}

void TYPE_GeographicCoordinate::get_fields(
  SDLSeqSetDescription*& d,SDLType **&field_list){
  d=&_fdesc; field_list=_fields;
}

void TYPE_GeographicCoordinate::get_fields(
  SDLSeqSetDescription*& d,SDLType *const*&field_list) const{
  d=&_fdesc; field_list=_fields;
}


TYPE_APEWProtocol_GEN_3& TYPE_GeographicCoordinate::VAR_latitude() const
{ return *SITE_STATIC_CAST(TYPE_APEWProtocol_GEN_3*,field_access(_fdesc,_fields,0)); }
static SDLSeqSetDescription::Field *_TYPE_GeographicCoordinatelatitude=TYPE_GeographicCoordinate::_fdesc.add(0,"latitude",&TYPE_APEWProtocol_GEN_3::create,true);

TYPE_APEWProtocol_GEN_4& TYPE_GeographicCoordinate::VAR_longitude() const
{ return *SITE_STATIC_CAST(TYPE_APEWProtocol_GEN_4*,field_access(_fdesc,_fields,1)); }
static SDLSeqSetDescription::Field *_TYPE_GeographicCoordinatelongitude=TYPE_GeographicCoordinate::_fdesc.add(1,"longitude",&TYPE_APEWProtocol_GEN_4::create,true);

TYPE_APEWProtocol_GEN_5& TYPE_GeographicCoordinate::VAR_height() const
{ return *SITE_STATIC_CAST(TYPE_APEWProtocol_GEN_5*,field_access(_fdesc,_fields,2)); }

const SDLBool& TYPE_GeographicCoordinate::heightPresent()const{
  return field_present(_fdesc,_fields,2);
}

TYPE_GeographicCoordinate TYPE_GeographicCoordinate::heightOmit()const{
  TYPE_GeographicCoordinate c(*this);
  field_omit(_fdesc,c._fields,2);
  return c;
}

void TYPE_GeographicCoordinate::_heightOmit() {
  field_omit(_fdesc,_fields,2);
}

static SDLSeqSetDescription::Field *_TYPE_GeographicCoordinateheight=TYPE_GeographicCoordinate::_fdesc.add_optional(2,"height",&TYPE_APEWProtocol_GEN_5::create,true);



TYPE_GeographicCoordinate::TYPE_GeographicCoordinate(const class TYPE_APEWProtocol_GEN_3& PAR_0, const class TYPE_APEWProtocol_GEN_4& PAR_1, const class TYPE_APEWProtocol_GEN_5& PAR_2) {
    set_field(0,PAR_0.copy());
    set_field(1,PAR_1.copy());
    if(PAR_2.valid())
        set_field(2,new TYPE_APEWProtocol_GEN_5(PAR_2));
    else
        set_field(2,0);
}

AsnLen TYPE_GeographicCoordinate::bEnc(BUF_TYPE b) const{
    AsnLen elmtLen = bEncContent(b);
    elmtLen += BEncDefLen(b,elmtLen);
    elmtLen += BEncTag1(b,UNIV,CONS,16);
    return elmtLen;
} // TYPE_GeographicCoordinate::bEnc

AsnLen TYPE_GeographicCoordinate::bEncContent(BUF_TYPE b) const {
    AsnLen elmtLen, structBytesEncoded = BEncExtraFields(b);
    if (heightPresent().val()) {
        elmtLen = VAR_height().bEncContent(b);
        elmtLen += BEncDefLen(b,elmtLen);
        elmtLen += BEncTag1(b,UNIV,PRIM,9);
        elmtLen += BEncDefLen(b,elmtLen);
        elmtLen += BEncTag1(b,CNTX,CONS,1);
        structBytesEncoded += elmtLen;
    }
    elmtLen = VAR_longitude().bEncContent(b);
    elmtLen += BEncDefLen(b,elmtLen);
    elmtLen += BEncTag1(b,UNIV,PRIM,9);
    structBytesEncoded += elmtLen;
    elmtLen = VAR_latitude().bEncContent(b);
    elmtLen += BEncDefLen(b,elmtLen);
    elmtLen += BEncTag1(b,UNIV,PRIM,9);
    structBytesEncoded += elmtLen;
    return structBytesEncoded;
} // TYPE_GeographicCoordinate::bEncContent

void TYPE_GeographicCoordinate::bDec(BUF_TYPE b,AsnLen& bytesDecoded) {
    AsnTag tagId = BDecTag1(b,bytesDecoded);
    AsnLen elmtLen;
    if (tagId != MAKE_TAG_ID(UNIV,CONS,16)) { TagError(MAKE_TAG_ID(UNIV,CONS,16),tagId); return; }
    elmtLen = BDecLen(b,bytesDecoded);
    int pending_eoc = 0;
    if (elmtLen == INDEFINITE_LEN) ++pending_eoc;
    AsnLen localBytesDecoded = 0;
    bDecContent(b,tagId,elmtLen,localBytesDecoded);
    for(;pending_eoc>0;--pending_eoc) { BDecEoc(b,localBytesDecoded); }
    bytesDecoded += localBytesDecoded;
} // TYPE_GeographicCoordinate::bDec

void TYPE_GeographicCoordinate::bDecContent(BUF_TYPE b,AsnTag,
        AsnLen len, AsnLen& bytesDecoded) {
    bool structDone = false;
    AsnLen elmtLen, localBytesDecoded = 0;
    AsnTag tagId;
    if (len == 0) { tagId = 0; structDone = true; }
    else tagId = BDecTag(b,localBytesDecoded);
    if (!structDone && (tagId==MAKE_TAG_ID(UNIV,PRIM,9))) {
        elmtLen = BDecLen(b,localBytesDecoded);
        VAR_latitude().bDecContent(b,tagId,elmtLen,localBytesDecoded);
        if ((len!=INDEFINITE_LEN) && (localBytesDecoded>=len)) structDone = true;
        else tagId = BDecTag(b,localBytesDecoded);
    } else { TagError(MAKE_TAG_ID(UNIV,PRIM,9),tagId); return; }
    if (!structDone && (tagId==MAKE_TAG_ID(UNIV,PRIM,9))) {
        elmtLen = BDecLen(b,localBytesDecoded);
        VAR_longitude().bDecContent(b,tagId,elmtLen,localBytesDecoded);
        if ((len!=INDEFINITE_LEN) && (localBytesDecoded>=len)) structDone = true;
        else tagId = BDecTag(b,localBytesDecoded);
    } else { TagError(MAKE_TAG_ID(UNIV,PRIM,9),tagId); return; }
    if (!structDone && (tagId==MAKE_TAG_ID(CNTX,CONS,1))) {
        elmtLen = BDecLen(b,localBytesDecoded);
        int pending_eoc = 0;
        if (elmtLen == INDEFINITE_LEN) ++pending_eoc;
        tagId = BDecTag1(b,localBytesDecoded);
        if (tagId == MAKE_TAG_ID(UNIV,PRIM,9)) {
          elmtLen = BDecLen(b,localBytesDecoded);
        } else { TagError(MAKE_TAG_ID(UNIV,PRIM,9),tagId); return; }
        VAR_height().bDecContent(b,tagId,elmtLen,localBytesDecoded);
        for(;pending_eoc>0;--pending_eoc) { BDecEoc(b,localBytesDecoded); }
        if (len!=INDEFINITE_LEN && localBytesDecoded>=len) structDone = true;
        else tagId = BDecTag(b,localBytesDecoded);
    }
    complete_sequence_decoding(b, len, localBytesDecoded, tagId);
    bytesDecoded += localBytesDecoded;
    set_state(validValue);
} // TYPE_GeographicCoordinate::bDecContent

AsnLen TYPE_GeographicCoordinate::pEnc(BUF_TYPE2 b) const {
    int elmtLen=0;
    b.putBit(heightPresent().val()?true:false);
    elmtLen++;
    elmtLen += VAR_latitude().pEnc(b);
    elmtLen += VAR_longitude().pEnc(b);
    if (heightPresent().val())
        elmtLen += VAR_height().pEnc(b);
    return elmtLen;
}

void TYPE_GeographicCoordinate::pDec(BUF_TYPE2 b) {
    bool _field_present0 = b.getBit();
    VAR_latitude().pDec(b);
    VAR_longitude().pDec(b);
    if(_field_present0) VAR_height().pDec(b);
    set_state(validValue);
}

SDLSeqSetDescription TYPE_SensorAccelerationAverage::_fdesc(2);

SDLType* TYPE_SensorAccelerationAverage::copy()const { return new TYPE_SensorAccelerationAverage(*this); }

void TYPE_SensorAccelerationAverage::assign(const SDLType* t)
{
  const TYPE_SensorAccelerationAverage *arg = SITE_DYNAMIC_CAST(const TYPE_SensorAccelerationAverage*,t);
  if (!arg) SDLSequence::assign(t);
  else *this = *arg;
}

SDLType* TYPE_SensorAccelerationAverage::create()
{
  static TYPE_SensorAccelerationAverage* tmpl = new TYPE_SensorAccelerationAverage;
  return tmpl;
}

const SDLType* TYPE_SensorAccelerationAverage::create_new() const { return create(); }

TYPE_SensorAccelerationAverage::TYPE_SensorAccelerationAverage():SDLSequence(_fields,2){}
TYPE_SensorAccelerationAverage::TYPE_SensorAccelerationAverage(SDLType** f,unsigned long c):SDLSequence(f,c){}
TYPE_SensorAccelerationAverage::TYPE_SensorAccelerationAverage(const SDLNull&):SDLSequence(_fields,2)
{ set_state(invalidValue); }
TYPE_SensorAccelerationAverage::TYPE_SensorAccelerationAverage(const SDLAny& a, AsnCodingSet rule_set):SDLSequence(_fields,2){a.decode(this,rule_set);}
TYPE_SensorAccelerationAverage::TYPE_SensorAccelerationAverage(const TYPE_SensorAccelerationAverage&o):SDLSequence(o){
  if (o.state(SITEtemporaryValue)) {
#ifdef SITE_LOG
    if (SDLType::_type_debug & SITE_COPY_LOG)
      CERR << "(SDLRTE) struct reference copy of " << o << ENDL;
#endif
    for(int i=0; i<2;++i) {
       _fields[i] = o._fields[i]; o._fields[i] = 0;
    }
  } else sequence_copyinit(_fields,o._fields,2);
}
TYPE_SensorAccelerationAverage::~TYPE_SensorAccelerationAverage(){clear_fields(_fields,2);}

TYPE_SensorAccelerationAverage& TYPE_SensorAccelerationAverage::operator=(const TYPE_SensorAccelerationAverage& val){
  val.check_valid();
  if (this!=&val) sequence_assign(val);
  return *this;
}

unsigned int TYPE_SensorAccelerationAverage::hash(unsigned int max_hash)const{
  return sequence_hash(_fields, 2, max_hash);
}

void TYPE_SensorAccelerationAverage::get_fields(
  SDLSeqSetDescription*& d,SDLType **&field_list){
  d=&_fdesc; field_list=_fields;
}

void TYPE_SensorAccelerationAverage::get_fields(
  SDLSeqSetDescription*& d,SDLType *const*&field_list) const{
  d=&_fdesc; field_list=_fields;
}


TYPE_SensorAcceleration& TYPE_SensorAccelerationAverage::VAR_acceleration() const
{ return *SITE_STATIC_CAST(TYPE_SensorAcceleration*,field_access(_fdesc,_fields,0)); }
static SDLSeqSetDescription::Field *_TYPE_SensorAccelerationAverageacceleration=TYPE_SensorAccelerationAverage::_fdesc.add(0,"acceleration",&TYPE_SensorAcceleration::create,true);

TYPE_APEWProtocol_GEN_7& TYPE_SensorAccelerationAverage::VAR_timeWindowLength() const
{ return *SITE_STATIC_CAST(TYPE_APEWProtocol_GEN_7*,field_access(_fdesc,_fields,1)); }
static SDLSeqSetDescription::Field *_TYPE_SensorAccelerationAveragetimeWindowLength=TYPE_SensorAccelerationAverage::_fdesc.add(1,"timeWindowLength",&TYPE_APEWProtocol_GEN_7::create,true);



TYPE_SensorAccelerationAverage::TYPE_SensorAccelerationAverage(const class TYPE_SensorAcceleration& PAR_0, const class TYPE_APEWProtocol_GEN_7& PAR_1) {
    set_field(0,PAR_0.copy());
    set_field(1,PAR_1.copy());
}

AsnLen TYPE_SensorAccelerationAverage::bEnc(BUF_TYPE b) const{
    AsnLen elmtLen = bEncContent(b);
    elmtLen += BEncDefLen(b,elmtLen);
    elmtLen += BEncTag1(b,UNIV,CONS,16);
    return elmtLen;
} // TYPE_SensorAccelerationAverage::bEnc

AsnLen TYPE_SensorAccelerationAverage::bEncContent(BUF_TYPE b) const {
    AsnLen elmtLen, structBytesEncoded = BEncExtraFields(b);
    elmtLen = VAR_timeWindowLength().bEncContent(b);
    elmtLen += BEncDefLen(b,elmtLen);
    elmtLen += BEncTag1(b,UNIV,PRIM,2);
    structBytesEncoded += elmtLen;
    elmtLen = VAR_acceleration().bEncContent(b);
    elmtLen += BEncDefLen(b,elmtLen);
    elmtLen += BEncTag1(b,UNIV,CONS,16);
    structBytesEncoded += elmtLen;
    return structBytesEncoded;
} // TYPE_SensorAccelerationAverage::bEncContent

void TYPE_SensorAccelerationAverage::bDec(BUF_TYPE b,AsnLen& bytesDecoded) {
    AsnTag tagId = BDecTag1(b,bytesDecoded);
    AsnLen elmtLen;
    if (tagId != MAKE_TAG_ID(UNIV,CONS,16)) { TagError(MAKE_TAG_ID(UNIV,CONS,16),tagId); return; }
    elmtLen = BDecLen(b,bytesDecoded);
    int pending_eoc = 0;
    if (elmtLen == INDEFINITE_LEN) ++pending_eoc;
    AsnLen localBytesDecoded = 0;
    bDecContent(b,tagId,elmtLen,localBytesDecoded);
    for(;pending_eoc>0;--pending_eoc) { BDecEoc(b,localBytesDecoded); }
    bytesDecoded += localBytesDecoded;
} // TYPE_SensorAccelerationAverage::bDec

void TYPE_SensorAccelerationAverage::bDecContent(BUF_TYPE b,AsnTag,
        AsnLen len, AsnLen& bytesDecoded) {
    bool structDone = false;
    AsnLen elmtLen, localBytesDecoded = 0;
    AsnTag tagId;
    if (len == 0) { tagId = 0; structDone = true; }
    else tagId = BDecTag(b,localBytesDecoded);
    if (!structDone && (tagId==MAKE_TAG_ID(UNIV,CONS,16))) {
        elmtLen = BDecLen(b,localBytesDecoded);
        int pending_eoc = 0;
        if (elmtLen == INDEFINITE_LEN) ++pending_eoc;
        VAR_acceleration().bDecContent(b,tagId,elmtLen,localBytesDecoded);
        for(;pending_eoc>0;--pending_eoc) { BDecEoc(b,localBytesDecoded); }
        if ((len!=INDEFINITE_LEN) && (localBytesDecoded>=len)) structDone = true;
        else tagId = BDecTag(b,localBytesDecoded);
    } else { TagError(MAKE_TAG_ID(UNIV,CONS,16),tagId); return; }
    if (!structDone && (tagId==MAKE_TAG_ID(UNIV,PRIM,2))) {
        elmtLen = BDecLen(b,localBytesDecoded);
        VAR_timeWindowLength().bDecContent(b,tagId,elmtLen,localBytesDecoded);
        if ((len!=INDEFINITE_LEN) && (localBytesDecoded>=len)) structDone = true;
        else tagId = BDecTag(b,localBytesDecoded);
    } else { TagError(MAKE_TAG_ID(UNIV,PRIM,2),tagId); return; }
    complete_sequence_decoding(b, len, localBytesDecoded, tagId);
    bytesDecoded += localBytesDecoded;
    set_state(validValue);
} // TYPE_SensorAccelerationAverage::bDecContent

AsnLen TYPE_SensorAccelerationAverage::pEnc(BUF_TYPE2 b) const {
    int elmtLen=0;
    elmtLen += VAR_acceleration().pEnc(b);
    elmtLen += VAR_timeWindowLength().pEnc(b);
    return elmtLen;
}

void TYPE_SensorAccelerationAverage::pDec(BUF_TYPE2 b) {
    VAR_acceleration().pDec(b);
    VAR_timeWindowLength().pDec(b);
    set_state(validValue);
}

SDLSeqSetDescription TYPE_SensorAcceleration::_fdesc(3);

SDLType* TYPE_SensorAcceleration::copy()const { return new TYPE_SensorAcceleration(*this); }

void TYPE_SensorAcceleration::assign(const SDLType* t)
{
  const TYPE_SensorAcceleration *arg = SITE_DYNAMIC_CAST(const TYPE_SensorAcceleration*,t);
  if (!arg) SDLSequence::assign(t);
  else *this = *arg;
}

SDLType* TYPE_SensorAcceleration::create()
{
  static TYPE_SensorAcceleration* tmpl = new TYPE_SensorAcceleration;
  return tmpl;
}

const SDLType* TYPE_SensorAcceleration::create_new() const { return create(); }

TYPE_SensorAcceleration::TYPE_SensorAcceleration():SDLSequence(_fields,3){}
TYPE_SensorAcceleration::TYPE_SensorAcceleration(SDLType** f,unsigned long c):SDLSequence(f,c){}
TYPE_SensorAcceleration::TYPE_SensorAcceleration(const SDLNull&):SDLSequence(_fields,3)
{ set_state(invalidValue); }
TYPE_SensorAcceleration::TYPE_SensorAcceleration(const SDLAny& a, AsnCodingSet rule_set):SDLSequence(_fields,3){a.decode(this,rule_set);}
TYPE_SensorAcceleration::TYPE_SensorAcceleration(const TYPE_SensorAcceleration&o):SDLSequence(o){
  if (o.state(SITEtemporaryValue)) {
#ifdef SITE_LOG
    if (SDLType::_type_debug & SITE_COPY_LOG)
      CERR << "(SDLRTE) struct reference copy of " << o << ENDL;
#endif
    for(int i=0; i<3;++i) {
       _fields[i] = o._fields[i]; o._fields[i] = 0;
    }
  } else sequence_copyinit(_fields,o._fields,3);
}
TYPE_SensorAcceleration::~TYPE_SensorAcceleration(){clear_fields(_fields,3);}

TYPE_SensorAcceleration& TYPE_SensorAcceleration::operator=(const TYPE_SensorAcceleration& val){
  val.check_valid();
  if (this!=&val) sequence_assign(val);
  return *this;
}

unsigned int TYPE_SensorAcceleration::hash(unsigned int max_hash)const{
  return sequence_hash(_fields, 3, max_hash);
}

void TYPE_SensorAcceleration::get_fields(
  SDLSeqSetDescription*& d,SDLType **&field_list){
  d=&_fdesc; field_list=_fields;
}

void TYPE_SensorAcceleration::get_fields(
  SDLSeqSetDescription*& d,SDLType *const*&field_list) const{
  d=&_fdesc; field_list=_fields;
}


TYPE_Acceleration& TYPE_SensorAcceleration::VAR_e() const
{ return *SITE_STATIC_CAST(TYPE_Acceleration*,field_access(_fdesc,_fields,0)); }
static SDLSeqSetDescription::Field *_TYPE_SensorAcceleratione=TYPE_SensorAcceleration::_fdesc.add(0,"e",&TYPE_Acceleration::create,true);

TYPE_Acceleration& TYPE_SensorAcceleration::VAR_n() const
{ return *SITE_STATIC_CAST(TYPE_Acceleration*,field_access(_fdesc,_fields,1)); }
static SDLSeqSetDescription::Field *_TYPE_SensorAccelerationn=TYPE_SensorAcceleration::_fdesc.add(1,"n",&TYPE_Acceleration::create,true);

TYPE_Acceleration& TYPE_SensorAcceleration::VAR_z() const
{ return *SITE_STATIC_CAST(TYPE_Acceleration*,field_access(_fdesc,_fields,2)); }
static SDLSeqSetDescription::Field *_TYPE_SensorAccelerationz=TYPE_SensorAcceleration::_fdesc.add(2,"z",&TYPE_Acceleration::create,true);



TYPE_SensorAcceleration::TYPE_SensorAcceleration(const class TYPE_Acceleration& PAR_0, const class TYPE_Acceleration& PAR_1, const class TYPE_Acceleration& PAR_2) {
    set_field(0,PAR_0.copy());
    set_field(1,PAR_1.copy());
    set_field(2,PAR_2.copy());
}

AsnLen TYPE_SensorAcceleration::bEnc(BUF_TYPE b) const{
    AsnLen elmtLen = bEncContent(b);
    elmtLen += BEncDefLen(b,elmtLen);
    elmtLen += BEncTag1(b,UNIV,CONS,16);
    return elmtLen;
} // TYPE_SensorAcceleration::bEnc

AsnLen TYPE_SensorAcceleration::bEncContent(BUF_TYPE b) const {
    AsnLen elmtLen, structBytesEncoded = BEncExtraFields(b);
    elmtLen = VAR_z().bEncContent(b);
    elmtLen += BEncDefLen(b,elmtLen);
    elmtLen += BEncTag1(b,UNIV,PRIM,9);
    structBytesEncoded += elmtLen;
    elmtLen = VAR_n().bEncContent(b);
    elmtLen += BEncDefLen(b,elmtLen);
    elmtLen += BEncTag1(b,UNIV,PRIM,9);
    structBytesEncoded += elmtLen;
    elmtLen = VAR_e().bEncContent(b);
    elmtLen += BEncDefLen(b,elmtLen);
    elmtLen += BEncTag1(b,UNIV,PRIM,9);
    structBytesEncoded += elmtLen;
    return structBytesEncoded;
} // TYPE_SensorAcceleration::bEncContent

void TYPE_SensorAcceleration::bDec(BUF_TYPE b,AsnLen& bytesDecoded) {
    AsnTag tagId = BDecTag1(b,bytesDecoded);
    AsnLen elmtLen;
    if (tagId != MAKE_TAG_ID(UNIV,CONS,16)) { TagError(MAKE_TAG_ID(UNIV,CONS,16),tagId); return; }
    elmtLen = BDecLen(b,bytesDecoded);
    int pending_eoc = 0;
    if (elmtLen == INDEFINITE_LEN) ++pending_eoc;
    AsnLen localBytesDecoded = 0;
    bDecContent(b,tagId,elmtLen,localBytesDecoded);
    for(;pending_eoc>0;--pending_eoc) { BDecEoc(b,localBytesDecoded); }
    bytesDecoded += localBytesDecoded;
} // TYPE_SensorAcceleration::bDec

void TYPE_SensorAcceleration::bDecContent(BUF_TYPE b,AsnTag,
        AsnLen len, AsnLen& bytesDecoded) {
    bool structDone = false;
    AsnLen elmtLen, localBytesDecoded = 0;
    AsnTag tagId;
    if (len == 0) { tagId = 0; structDone = true; }
    else tagId = BDecTag(b,localBytesDecoded);
    if (!structDone && (tagId==MAKE_TAG_ID(UNIV,PRIM,9))) {
        elmtLen = BDecLen(b,localBytesDecoded);
        VAR_e().bDecContent(b,tagId,elmtLen,localBytesDecoded);
        if ((len!=INDEFINITE_LEN) && (localBytesDecoded>=len)) structDone = true;
        else tagId = BDecTag(b,localBytesDecoded);
    } else { TagError(MAKE_TAG_ID(UNIV,PRIM,9),tagId); return; }
    if (!structDone && (tagId==MAKE_TAG_ID(UNIV,PRIM,9))) {
        elmtLen = BDecLen(b,localBytesDecoded);
        VAR_n().bDecContent(b,tagId,elmtLen,localBytesDecoded);
        if ((len!=INDEFINITE_LEN) && (localBytesDecoded>=len)) structDone = true;
        else tagId = BDecTag(b,localBytesDecoded);
    } else { TagError(MAKE_TAG_ID(UNIV,PRIM,9),tagId); return; }
    if (!structDone && (tagId==MAKE_TAG_ID(UNIV,PRIM,9))) {
        elmtLen = BDecLen(b,localBytesDecoded);
        VAR_z().bDecContent(b,tagId,elmtLen,localBytesDecoded);
        if ((len!=INDEFINITE_LEN) && (localBytesDecoded>=len)) structDone = true;
        else tagId = BDecTag(b,localBytesDecoded);
    } else { TagError(MAKE_TAG_ID(UNIV,PRIM,9),tagId); return; }
    complete_sequence_decoding(b, len, localBytesDecoded, tagId);
    bytesDecoded += localBytesDecoded;
    set_state(validValue);
} // TYPE_SensorAcceleration::bDecContent

AsnLen TYPE_SensorAcceleration::pEnc(BUF_TYPE2 b) const {
    int elmtLen=0;
    elmtLen += VAR_e().pEnc(b);
    elmtLen += VAR_n().pEnc(b);
    elmtLen += VAR_z().pEnc(b);
    return elmtLen;
}

void TYPE_SensorAcceleration::pDec(BUF_TYPE2 b) {
    VAR_e().pDec(b);
    VAR_n().pDec(b);
    VAR_z().pDec(b);
    set_state(validValue);
}

SDLSeqSetDescription TYPE_SensorVelocity::_fdesc(3);

SDLType* TYPE_SensorVelocity::copy()const { return new TYPE_SensorVelocity(*this); }

void TYPE_SensorVelocity::assign(const SDLType* t)
{
  const TYPE_SensorVelocity *arg = SITE_DYNAMIC_CAST(const TYPE_SensorVelocity*,t);
  if (!arg) SDLSequence::assign(t);
  else *this = *arg;
}

SDLType* TYPE_SensorVelocity::create()
{
  static TYPE_SensorVelocity* tmpl = new TYPE_SensorVelocity;
  return tmpl;
}

const SDLType* TYPE_SensorVelocity::create_new() const { return create(); }

TYPE_SensorVelocity::TYPE_SensorVelocity():SDLSequence(_fields,3){}
TYPE_SensorVelocity::TYPE_SensorVelocity(SDLType** f,unsigned long c):SDLSequence(f,c){}
TYPE_SensorVelocity::TYPE_SensorVelocity(const SDLNull&):SDLSequence(_fields,3)
{ set_state(invalidValue); }
TYPE_SensorVelocity::TYPE_SensorVelocity(const SDLAny& a, AsnCodingSet rule_set):SDLSequence(_fields,3){a.decode(this,rule_set);}
TYPE_SensorVelocity::TYPE_SensorVelocity(const TYPE_SensorVelocity&o):SDLSequence(o){
  if (o.state(SITEtemporaryValue)) {
#ifdef SITE_LOG
    if (SDLType::_type_debug & SITE_COPY_LOG)
      CERR << "(SDLRTE) struct reference copy of " << o << ENDL;
#endif
    for(int i=0; i<3;++i) {
       _fields[i] = o._fields[i]; o._fields[i] = 0;
    }
  } else sequence_copyinit(_fields,o._fields,3);
}
TYPE_SensorVelocity::~TYPE_SensorVelocity(){clear_fields(_fields,3);}

TYPE_SensorVelocity& TYPE_SensorVelocity::operator=(const TYPE_SensorVelocity& val){
  val.check_valid();
  if (this!=&val) sequence_assign(val);
  return *this;
}

unsigned int TYPE_SensorVelocity::hash(unsigned int max_hash)const{
  return sequence_hash(_fields, 3, max_hash);
}

void TYPE_SensorVelocity::get_fields(
  SDLSeqSetDescription*& d,SDLType **&field_list){
  d=&_fdesc; field_list=_fields;
}

void TYPE_SensorVelocity::get_fields(
  SDLSeqSetDescription*& d,SDLType *const*&field_list) const{
  d=&_fdesc; field_list=_fields;
}


TYPE_Velocity& TYPE_SensorVelocity::VAR_e() const
{ return *SITE_STATIC_CAST(TYPE_Velocity*,field_access(_fdesc,_fields,0)); }
static SDLSeqSetDescription::Field *_TYPE_SensorVelocitye=TYPE_SensorVelocity::_fdesc.add(0,"e",&TYPE_Velocity::create,true);

TYPE_Velocity& TYPE_SensorVelocity::VAR_n() const
{ return *SITE_STATIC_CAST(TYPE_Velocity*,field_access(_fdesc,_fields,1)); }
static SDLSeqSetDescription::Field *_TYPE_SensorVelocityn=TYPE_SensorVelocity::_fdesc.add(1,"n",&TYPE_Velocity::create,true);

TYPE_Velocity& TYPE_SensorVelocity::VAR_z() const
{ return *SITE_STATIC_CAST(TYPE_Velocity*,field_access(_fdesc,_fields,2)); }
static SDLSeqSetDescription::Field *_TYPE_SensorVelocityz=TYPE_SensorVelocity::_fdesc.add(2,"z",&TYPE_Velocity::create,true);



TYPE_SensorVelocity::TYPE_SensorVelocity(const class TYPE_Velocity& PAR_0, const class TYPE_Velocity& PAR_1, const class TYPE_Velocity& PAR_2) {
    set_field(0,PAR_0.copy());
    set_field(1,PAR_1.copy());
    set_field(2,PAR_2.copy());
}

AsnLen TYPE_SensorVelocity::bEnc(BUF_TYPE b) const{
    AsnLen elmtLen = bEncContent(b);
    elmtLen += BEncDefLen(b,elmtLen);
    elmtLen += BEncTag1(b,UNIV,CONS,16);
    return elmtLen;
} // TYPE_SensorVelocity::bEnc

AsnLen TYPE_SensorVelocity::bEncContent(BUF_TYPE b) const {
    AsnLen elmtLen, structBytesEncoded = BEncExtraFields(b);
    elmtLen = VAR_z().bEncContent(b);
    elmtLen += BEncDefLen(b,elmtLen);
    elmtLen += BEncTag1(b,UNIV,PRIM,9);
    structBytesEncoded += elmtLen;
    elmtLen = VAR_n().bEncContent(b);
    elmtLen += BEncDefLen(b,elmtLen);
    elmtLen += BEncTag1(b,UNIV,PRIM,9);
    structBytesEncoded += elmtLen;
    elmtLen = VAR_e().bEncContent(b);
    elmtLen += BEncDefLen(b,elmtLen);
    elmtLen += BEncTag1(b,UNIV,PRIM,9);
    structBytesEncoded += elmtLen;
    return structBytesEncoded;
} // TYPE_SensorVelocity::bEncContent

void TYPE_SensorVelocity::bDec(BUF_TYPE b,AsnLen& bytesDecoded) {
    AsnTag tagId = BDecTag1(b,bytesDecoded);
    AsnLen elmtLen;
    if (tagId != MAKE_TAG_ID(UNIV,CONS,16)) { TagError(MAKE_TAG_ID(UNIV,CONS,16),tagId); return; }
    elmtLen = BDecLen(b,bytesDecoded);
    int pending_eoc = 0;
    if (elmtLen == INDEFINITE_LEN) ++pending_eoc;
    AsnLen localBytesDecoded = 0;
    bDecContent(b,tagId,elmtLen,localBytesDecoded);
    for(;pending_eoc>0;--pending_eoc) { BDecEoc(b,localBytesDecoded); }
    bytesDecoded += localBytesDecoded;
} // TYPE_SensorVelocity::bDec

void TYPE_SensorVelocity::bDecContent(BUF_TYPE b,AsnTag,
        AsnLen len, AsnLen& bytesDecoded) {
    bool structDone = false;
    AsnLen elmtLen, localBytesDecoded = 0;
    AsnTag tagId;
    if (len == 0) { tagId = 0; structDone = true; }
    else tagId = BDecTag(b,localBytesDecoded);
    if (!structDone && (tagId==MAKE_TAG_ID(UNIV,PRIM,9))) {
        elmtLen = BDecLen(b,localBytesDecoded);
        VAR_e().bDecContent(b,tagId,elmtLen,localBytesDecoded);
        if ((len!=INDEFINITE_LEN) && (localBytesDecoded>=len)) structDone = true;
        else tagId = BDecTag(b,localBytesDecoded);
    } else { TagError(MAKE_TAG_ID(UNIV,PRIM,9),tagId); return; }
    if (!structDone && (tagId==MAKE_TAG_ID(UNIV,PRIM,9))) {
        elmtLen = BDecLen(b,localBytesDecoded);
        VAR_n().bDecContent(b,tagId,elmtLen,localBytesDecoded);
        if ((len!=INDEFINITE_LEN) && (localBytesDecoded>=len)) structDone = true;
        else tagId = BDecTag(b,localBytesDecoded);
    } else { TagError(MAKE_TAG_ID(UNIV,PRIM,9),tagId); return; }
    if (!structDone && (tagId==MAKE_TAG_ID(UNIV,PRIM,9))) {
        elmtLen = BDecLen(b,localBytesDecoded);
        VAR_z().bDecContent(b,tagId,elmtLen,localBytesDecoded);
        if ((len!=INDEFINITE_LEN) && (localBytesDecoded>=len)) structDone = true;
        else tagId = BDecTag(b,localBytesDecoded);
    } else { TagError(MAKE_TAG_ID(UNIV,PRIM,9),tagId); return; }
    complete_sequence_decoding(b, len, localBytesDecoded, tagId);
    bytesDecoded += localBytesDecoded;
    set_state(validValue);
} // TYPE_SensorVelocity::bDecContent

AsnLen TYPE_SensorVelocity::pEnc(BUF_TYPE2 b) const {
    int elmtLen=0;
    elmtLen += VAR_e().pEnc(b);
    elmtLen += VAR_n().pEnc(b);
    elmtLen += VAR_z().pEnc(b);
    return elmtLen;
}

void TYPE_SensorVelocity::pDec(BUF_TYPE2 b) {
    VAR_e().pDec(b);
    VAR_n().pDec(b);
    VAR_z().pDec(b);
    set_state(validValue);
}

SDLSeqSetDescription TYPE_SensorDisplacement::_fdesc(3);

SDLType* TYPE_SensorDisplacement::copy()const { return new TYPE_SensorDisplacement(*this); }

void TYPE_SensorDisplacement::assign(const SDLType* t)
{
  const TYPE_SensorDisplacement *arg = SITE_DYNAMIC_CAST(const TYPE_SensorDisplacement*,t);
  if (!arg) SDLSequence::assign(t);
  else *this = *arg;
}

SDLType* TYPE_SensorDisplacement::create()
{
  static TYPE_SensorDisplacement* tmpl = new TYPE_SensorDisplacement;
  return tmpl;
}

const SDLType* TYPE_SensorDisplacement::create_new() const { return create(); }

TYPE_SensorDisplacement::TYPE_SensorDisplacement():SDLSequence(_fields,3){}
TYPE_SensorDisplacement::TYPE_SensorDisplacement(SDLType** f,unsigned long c):SDLSequence(f,c){}
TYPE_SensorDisplacement::TYPE_SensorDisplacement(const SDLNull&):SDLSequence(_fields,3)
{ set_state(invalidValue); }
TYPE_SensorDisplacement::TYPE_SensorDisplacement(const SDLAny& a, AsnCodingSet rule_set):SDLSequence(_fields,3){a.decode(this,rule_set);}
TYPE_SensorDisplacement::TYPE_SensorDisplacement(const TYPE_SensorDisplacement&o):SDLSequence(o){
  if (o.state(SITEtemporaryValue)) {
#ifdef SITE_LOG
    if (SDLType::_type_debug & SITE_COPY_LOG)
      CERR << "(SDLRTE) struct reference copy of " << o << ENDL;
#endif
    for(int i=0; i<3;++i) {
       _fields[i] = o._fields[i]; o._fields[i] = 0;
    }
  } else sequence_copyinit(_fields,o._fields,3);
}
TYPE_SensorDisplacement::~TYPE_SensorDisplacement(){clear_fields(_fields,3);}

TYPE_SensorDisplacement& TYPE_SensorDisplacement::operator=(const TYPE_SensorDisplacement& val){
  val.check_valid();
  if (this!=&val) sequence_assign(val);
  return *this;
}

unsigned int TYPE_SensorDisplacement::hash(unsigned int max_hash)const{
  return sequence_hash(_fields, 3, max_hash);
}

void TYPE_SensorDisplacement::get_fields(
  SDLSeqSetDescription*& d,SDLType **&field_list){
  d=&_fdesc; field_list=_fields;
}

void TYPE_SensorDisplacement::get_fields(
  SDLSeqSetDescription*& d,SDLType *const*&field_list) const{
  d=&_fdesc; field_list=_fields;
}


TYPE_Displacement& TYPE_SensorDisplacement::VAR_e() const
{ return *SITE_STATIC_CAST(TYPE_Displacement*,field_access(_fdesc,_fields,0)); }
static SDLSeqSetDescription::Field *_TYPE_SensorDisplacemente=TYPE_SensorDisplacement::_fdesc.add(0,"e",&TYPE_Displacement::create,true);

TYPE_Displacement& TYPE_SensorDisplacement::VAR_n() const
{ return *SITE_STATIC_CAST(TYPE_Displacement*,field_access(_fdesc,_fields,1)); }
static SDLSeqSetDescription::Field *_TYPE_SensorDisplacementn=TYPE_SensorDisplacement::_fdesc.add(1,"n",&TYPE_Displacement::create,true);

TYPE_Displacement& TYPE_SensorDisplacement::VAR_z() const
{ return *SITE_STATIC_CAST(TYPE_Displacement*,field_access(_fdesc,_fields,2)); }
static SDLSeqSetDescription::Field *_TYPE_SensorDisplacementz=TYPE_SensorDisplacement::_fdesc.add(2,"z",&TYPE_Displacement::create,true);



TYPE_SensorDisplacement::TYPE_SensorDisplacement(const class TYPE_Displacement& PAR_0, const class TYPE_Displacement& PAR_1, const class TYPE_Displacement& PAR_2) {
    set_field(0,PAR_0.copy());
    set_field(1,PAR_1.copy());
    set_field(2,PAR_2.copy());
}

AsnLen TYPE_SensorDisplacement::bEnc(BUF_TYPE b) const{
    AsnLen elmtLen = bEncContent(b);
    elmtLen += BEncDefLen(b,elmtLen);
    elmtLen += BEncTag1(b,UNIV,CONS,16);
    return elmtLen;
} // TYPE_SensorDisplacement::bEnc

AsnLen TYPE_SensorDisplacement::bEncContent(BUF_TYPE b) const {
    AsnLen elmtLen, structBytesEncoded = BEncExtraFields(b);
    elmtLen = VAR_z().bEncContent(b);
    elmtLen += BEncDefLen(b,elmtLen);
    elmtLen += BEncTag1(b,UNIV,PRIM,9);
    structBytesEncoded += elmtLen;
    elmtLen = VAR_n().bEncContent(b);
    elmtLen += BEncDefLen(b,elmtLen);
    elmtLen += BEncTag1(b,UNIV,PRIM,9);
    structBytesEncoded += elmtLen;
    elmtLen = VAR_e().bEncContent(b);
    elmtLen += BEncDefLen(b,elmtLen);
    elmtLen += BEncTag1(b,UNIV,PRIM,9);
    structBytesEncoded += elmtLen;
    return structBytesEncoded;
} // TYPE_SensorDisplacement::bEncContent

void TYPE_SensorDisplacement::bDec(BUF_TYPE b,AsnLen& bytesDecoded) {
    AsnTag tagId = BDecTag1(b,bytesDecoded);
    AsnLen elmtLen;
    if (tagId != MAKE_TAG_ID(UNIV,CONS,16)) { TagError(MAKE_TAG_ID(UNIV,CONS,16),tagId); return; }
    elmtLen = BDecLen(b,bytesDecoded);
    int pending_eoc = 0;
    if (elmtLen == INDEFINITE_LEN) ++pending_eoc;
    AsnLen localBytesDecoded = 0;
    bDecContent(b,tagId,elmtLen,localBytesDecoded);
    for(;pending_eoc>0;--pending_eoc) { BDecEoc(b,localBytesDecoded); }
    bytesDecoded += localBytesDecoded;
} // TYPE_SensorDisplacement::bDec

void TYPE_SensorDisplacement::bDecContent(BUF_TYPE b,AsnTag,
        AsnLen len, AsnLen& bytesDecoded) {
    bool structDone = false;
    AsnLen elmtLen, localBytesDecoded = 0;
    AsnTag tagId;
    if (len == 0) { tagId = 0; structDone = true; }
    else tagId = BDecTag(b,localBytesDecoded);
    if (!structDone && (tagId==MAKE_TAG_ID(UNIV,PRIM,9))) {
        elmtLen = BDecLen(b,localBytesDecoded);
        VAR_e().bDecContent(b,tagId,elmtLen,localBytesDecoded);
        if ((len!=INDEFINITE_LEN) && (localBytesDecoded>=len)) structDone = true;
        else tagId = BDecTag(b,localBytesDecoded);
    } else { TagError(MAKE_TAG_ID(UNIV,PRIM,9),tagId); return; }
    if (!structDone && (tagId==MAKE_TAG_ID(UNIV,PRIM,9))) {
        elmtLen = BDecLen(b,localBytesDecoded);
        VAR_n().bDecContent(b,tagId,elmtLen,localBytesDecoded);
        if ((len!=INDEFINITE_LEN) && (localBytesDecoded>=len)) structDone = true;
        else tagId = BDecTag(b,localBytesDecoded);
    } else { TagError(MAKE_TAG_ID(UNIV,PRIM,9),tagId); return; }
    if (!structDone && (tagId==MAKE_TAG_ID(UNIV,PRIM,9))) {
        elmtLen = BDecLen(b,localBytesDecoded);
        VAR_z().bDecContent(b,tagId,elmtLen,localBytesDecoded);
        if ((len!=INDEFINITE_LEN) && (localBytesDecoded>=len)) structDone = true;
        else tagId = BDecTag(b,localBytesDecoded);
    } else { TagError(MAKE_TAG_ID(UNIV,PRIM,9),tagId); return; }
    complete_sequence_decoding(b, len, localBytesDecoded, tagId);
    bytesDecoded += localBytesDecoded;
    set_state(validValue);
} // TYPE_SensorDisplacement::bDecContent

AsnLen TYPE_SensorDisplacement::pEnc(BUF_TYPE2 b) const {
    int elmtLen=0;
    elmtLen += VAR_e().pEnc(b);
    elmtLen += VAR_n().pEnc(b);
    elmtLen += VAR_z().pEnc(b);
    return elmtLen;
}

void TYPE_SensorDisplacement::pDec(BUF_TYPE2 b) {
    VAR_e().pDec(b);
    VAR_n().pDec(b);
    VAR_z().pDec(b);
    set_state(validValue);
}

SDLSeqSetDescription TYPE_SN_LN_Idle::_fdesc(4);

SDLType* TYPE_SN_LN_Idle::copy()const { return new TYPE_SN_LN_Idle(*this); }

void TYPE_SN_LN_Idle::assign(const SDLType* t)
{
  const TYPE_SN_LN_Idle *arg = SITE_DYNAMIC_CAST(const TYPE_SN_LN_Idle*,t);
  if (!arg) SDLSequence::assign(t);
  else *this = *arg;
}

SDLType* TYPE_SN_LN_Idle::create()
{
  static TYPE_SN_LN_Idle* tmpl = new TYPE_SN_LN_Idle;
  return tmpl;
}

const SDLType* TYPE_SN_LN_Idle::create_new() const { return create(); }

TYPE_SN_LN_Idle::TYPE_SN_LN_Idle():SDLSequence(_fields,4){}
TYPE_SN_LN_Idle::TYPE_SN_LN_Idle(SDLType** f,unsigned long c):SDLSequence(f,c){}
TYPE_SN_LN_Idle::TYPE_SN_LN_Idle(const SDLNull&):SDLSequence(_fields,4)
{ set_state(invalidValue); }
TYPE_SN_LN_Idle::TYPE_SN_LN_Idle(const SDLAny& a, AsnCodingSet rule_set):SDLSequence(_fields,4){a.decode(this,rule_set);}
TYPE_SN_LN_Idle::TYPE_SN_LN_Idle(const TYPE_SN_LN_Idle&o):SDLSequence(o){
  if (o.state(SITEtemporaryValue)) {
#ifdef SITE_LOG
    if (SDLType::_type_debug & SITE_COPY_LOG)
      CERR << "(SDLRTE) struct reference copy of " << o << ENDL;
#endif
    for(int i=0; i<4;++i) {
       _fields[i] = o._fields[i]; o._fields[i] = 0;
    }
  } else sequence_copyinit(_fields,o._fields,4);
}
TYPE_SN_LN_Idle::~TYPE_SN_LN_Idle(){clear_fields(_fields,4);}

TYPE_SN_LN_Idle& TYPE_SN_LN_Idle::operator=(const TYPE_SN_LN_Idle& val){
  val.check_valid();
  if (this!=&val) sequence_assign(val);
  return *this;
}

unsigned int TYPE_SN_LN_Idle::hash(unsigned int max_hash)const{
  return sequence_hash(_fields, 4, max_hash);
}

void TYPE_SN_LN_Idle::get_fields(
  SDLSeqSetDescription*& d,SDLType **&field_list){
  d=&_fdesc; field_list=_fields;
}

void TYPE_SN_LN_Idle::get_fields(
  SDLSeqSetDescription*& d,SDLType *const*&field_list) const{
  d=&_fdesc; field_list=_fields;
}


TYPE_DateTime& TYPE_SN_LN_Idle::VAR_gpsTimeStamp() const
{ return *SITE_STATIC_CAST(TYPE_DateTime*,field_access(_fdesc,_fields,0)); }
static SDLSeqSetDescription::Field *_TYPE_SN_LN_IdlegpsTimeStamp=TYPE_SN_LN_Idle::_fdesc.add(0,"gpsTimeStamp",&TYPE_DateTime::create,true);

TYPE_SensorAccelerationAverage& TYPE_SN_LN_Idle::VAR_noiseAverage() const
{ return *SITE_STATIC_CAST(TYPE_SensorAccelerationAverage*,field_access(_fdesc,_fields,1)); }
static SDLSeqSetDescription::Field *_TYPE_SN_LN_IdlenoiseAverage=TYPE_SN_LN_Idle::_fdesc.add(1,"noiseAverage",&TYPE_SensorAccelerationAverage::create,true);

SDLReal& TYPE_SN_LN_Idle::VAR_batteryVoltage() const
{ return *SITE_STATIC_CAST(SDLReal*,field_access(_fdesc,_fields,2)); }

const SDLBool& TYPE_SN_LN_Idle::batteryVoltagePresent()const{
  return field_present(_fdesc,_fields,2);
}

TYPE_SN_LN_Idle TYPE_SN_LN_Idle::batteryVoltageOmit()const{
  TYPE_SN_LN_Idle c(*this);
  field_omit(_fdesc,c._fields,2);
  return c;
}

void TYPE_SN_LN_Idle::_batteryVoltageOmit() {
  field_omit(_fdesc,_fields,2);
}

static SDLSeqSetDescription::Field *_TYPE_SN_LN_IdlebatteryVoltage=TYPE_SN_LN_Idle::_fdesc.add_optional(2,"batteryVoltage",&SDLReal::create,true);

SDLReal& TYPE_SN_LN_Idle::VAR_valueFourthChannel() const
{ return *SITE_STATIC_CAST(SDLReal*,field_access(_fdesc,_fields,3)); }

const SDLBool& TYPE_SN_LN_Idle::valueFourthChannelPresent()const{
  return field_present(_fdesc,_fields,3);
}

TYPE_SN_LN_Idle TYPE_SN_LN_Idle::valueFourthChannelOmit()const{
  TYPE_SN_LN_Idle c(*this);
  field_omit(_fdesc,c._fields,3);
  return c;
}

void TYPE_SN_LN_Idle::_valueFourthChannelOmit() {
  field_omit(_fdesc,_fields,3);
}

static SDLSeqSetDescription::Field *_TYPE_SN_LN_IdlevalueFourthChannel=TYPE_SN_LN_Idle::_fdesc.add_optional(3,"valueFourthChannel",&SDLReal::create,true);



TYPE_SN_LN_Idle::TYPE_SN_LN_Idle(const class TYPE_DateTime& PAR_0, const class TYPE_SensorAccelerationAverage& PAR_1, const class SDLReal& PAR_2, const class SDLReal& PAR_3) {
    set_field(0,PAR_0.copy());
    set_field(1,PAR_1.copy());
    if(PAR_2.valid())
        set_field(2,new SDLReal(PAR_2));
    else
        set_field(2,0);
    if(PAR_3.valid())
        set_field(3,new SDLReal(PAR_3));
    else
        set_field(3,0);
}

AsnLen TYPE_SN_LN_Idle::bEnc(BUF_TYPE b) const{
    AsnLen elmtLen = bEncContent(b);
    elmtLen += BEncDefLen(b,elmtLen);
    elmtLen += BEncTag1(b,UNIV,CONS,16);
    return elmtLen;
} // TYPE_SN_LN_Idle::bEnc

AsnLen TYPE_SN_LN_Idle::bEncContent(BUF_TYPE b) const {
    AsnLen elmtLen, structBytesEncoded = BEncExtraFields(b);
    if (valueFourthChannelPresent().val()) {
        elmtLen = VAR_valueFourthChannel().bEncContent(b);
        elmtLen += BEncDefLen(b,elmtLen);
        elmtLen += BEncTag1(b,UNIV,PRIM,9);
        elmtLen += BEncDefLen(b,elmtLen);
        elmtLen += BEncTag1(b,CNTX,CONS,2);
        structBytesEncoded += elmtLen;
    }
    if (batteryVoltagePresent().val()) {
        elmtLen = VAR_batteryVoltage().bEncContent(b);
        elmtLen += BEncDefLen(b,elmtLen);
        elmtLen += BEncTag1(b,UNIV,PRIM,9);
        elmtLen += BEncDefLen(b,elmtLen);
        elmtLen += BEncTag1(b,CNTX,CONS,1);
        structBytesEncoded += elmtLen;
    }
    elmtLen = VAR_noiseAverage().bEncContent(b);
    elmtLen += BEncDefLen(b,elmtLen);
    elmtLen += BEncTag1(b,UNIV,CONS,16);
    structBytesEncoded += elmtLen;
    elmtLen = VAR_gpsTimeStamp().bEncContent(b);
    elmtLen += BEncDefLen(b,elmtLen);
    elmtLen += BEncTag1(b,UNIV,CONS,16);
    structBytesEncoded += elmtLen;
    return structBytesEncoded;
} // TYPE_SN_LN_Idle::bEncContent

void TYPE_SN_LN_Idle::bDec(BUF_TYPE b,AsnLen& bytesDecoded) {
    AsnTag tagId = BDecTag1(b,bytesDecoded);
    AsnLen elmtLen;
    if (tagId != MAKE_TAG_ID(UNIV,CONS,16)) { TagError(MAKE_TAG_ID(UNIV,CONS,16),tagId); return; }
    elmtLen = BDecLen(b,bytesDecoded);
    int pending_eoc = 0;
    if (elmtLen == INDEFINITE_LEN) ++pending_eoc;
    AsnLen localBytesDecoded = 0;
    bDecContent(b,tagId,elmtLen,localBytesDecoded);
    for(;pending_eoc>0;--pending_eoc) { BDecEoc(b,localBytesDecoded); }
    bytesDecoded += localBytesDecoded;
} // TYPE_SN_LN_Idle::bDec

void TYPE_SN_LN_Idle::bDecContent(BUF_TYPE b,AsnTag,
        AsnLen len, AsnLen& bytesDecoded) {
    bool structDone = false;
    AsnLen elmtLen, localBytesDecoded = 0;
    AsnTag tagId;
    if (len == 0) { tagId = 0; structDone = true; }
    else tagId = BDecTag(b,localBytesDecoded);
    if (!structDone && (tagId==MAKE_TAG_ID(UNIV,CONS,16))) {
        elmtLen = BDecLen(b,localBytesDecoded);
        int pending_eoc = 0;
        if (elmtLen == INDEFINITE_LEN) ++pending_eoc;
        VAR_gpsTimeStamp().bDecContent(b,tagId,elmtLen,localBytesDecoded);
        for(;pending_eoc>0;--pending_eoc) { BDecEoc(b,localBytesDecoded); }
        if ((len!=INDEFINITE_LEN) && (localBytesDecoded>=len)) structDone = true;
        else tagId = BDecTag(b,localBytesDecoded);
    } else { TagError(MAKE_TAG_ID(UNIV,CONS,16),tagId); return; }
    if (!structDone && (tagId==MAKE_TAG_ID(UNIV,CONS,16))) {
        elmtLen = BDecLen(b,localBytesDecoded);
        int pending_eoc = 0;
        if (elmtLen == INDEFINITE_LEN) ++pending_eoc;
        VAR_noiseAverage().bDecContent(b,tagId,elmtLen,localBytesDecoded);
        for(;pending_eoc>0;--pending_eoc) { BDecEoc(b,localBytesDecoded); }
        if ((len!=INDEFINITE_LEN) && (localBytesDecoded>=len)) structDone = true;
        else tagId = BDecTag(b,localBytesDecoded);
    } else { TagError(MAKE_TAG_ID(UNIV,CONS,16),tagId); return; }
    if (!structDone && (tagId==MAKE_TAG_ID(CNTX,CONS,1))) {
        elmtLen = BDecLen(b,localBytesDecoded);
        int pending_eoc = 0;
        if (elmtLen == INDEFINITE_LEN) ++pending_eoc;
        tagId = BDecTag1(b,localBytesDecoded);
        if (tagId == MAKE_TAG_ID(UNIV,PRIM,9)) {
          elmtLen = BDecLen(b,localBytesDecoded);
        } else { TagError(MAKE_TAG_ID(UNIV,PRIM,9),tagId); return; }
        VAR_batteryVoltage().bDecContent(b,tagId,elmtLen,localBytesDecoded);
        for(;pending_eoc>0;--pending_eoc) { BDecEoc(b,localBytesDecoded); }
        if (len!=INDEFINITE_LEN && localBytesDecoded>=len) structDone = true;
        else tagId = BDecTag(b,localBytesDecoded);
    }
    if (!structDone && (tagId==MAKE_TAG_ID(CNTX,CONS,2))) {
        elmtLen = BDecLen(b,localBytesDecoded);
        int pending_eoc = 0;
        if (elmtLen == INDEFINITE_LEN) ++pending_eoc;
        tagId = BDecTag1(b,localBytesDecoded);
        if (tagId == MAKE_TAG_ID(UNIV,PRIM,9)) {
          elmtLen = BDecLen(b,localBytesDecoded);
        } else { TagError(MAKE_TAG_ID(UNIV,PRIM,9),tagId); return; }
        VAR_valueFourthChannel().bDecContent(b,tagId,elmtLen,localBytesDecoded);
        for(;pending_eoc>0;--pending_eoc) { BDecEoc(b,localBytesDecoded); }
        if (len!=INDEFINITE_LEN && localBytesDecoded>=len) structDone = true;
        else tagId = BDecTag(b,localBytesDecoded);
    }
    complete_sequence_decoding(b, len, localBytesDecoded, tagId);
    bytesDecoded += localBytesDecoded;
    set_state(validValue);
} // TYPE_SN_LN_Idle::bDecContent

AsnLen TYPE_SN_LN_Idle::pEnc(BUF_TYPE2 b) const {
    int elmtLen=0;
    b.putBit(batteryVoltagePresent().val()?true:false);
    elmtLen++;
    b.putBit(valueFourthChannelPresent().val()?true:false);
    elmtLen++;
    elmtLen += VAR_gpsTimeStamp().pEnc(b);
    elmtLen += VAR_noiseAverage().pEnc(b);
    if (batteryVoltagePresent().val())
        elmtLen += VAR_batteryVoltage().pEnc(b);
    if (valueFourthChannelPresent().val())
        elmtLen += VAR_valueFourthChannel().pEnc(b);
    return elmtLen;
}

void TYPE_SN_LN_Idle::pDec(BUF_TYPE2 b) {
    bool _field_present0 = b.getBit();
    bool _field_present1 = b.getBit();
    VAR_gpsTimeStamp().pDec(b);
    VAR_noiseAverage().pDec(b);
    if(_field_present0) VAR_batteryVoltage().pDec(b);
    if(_field_present1) VAR_valueFourthChannel().pDec(b);
    set_state(validValue);
}

SDLSeqSetDescription TYPE_SN_LN_Detection::_fdesc(8);

SDLType* TYPE_SN_LN_Detection::copy()const { return new TYPE_SN_LN_Detection(*this); }

void TYPE_SN_LN_Detection::assign(const SDLType* t)
{
  const TYPE_SN_LN_Detection *arg = SITE_DYNAMIC_CAST(const TYPE_SN_LN_Detection*,t);
  if (!arg) SDLSequence::assign(t);
  else *this = *arg;
}

SDLType* TYPE_SN_LN_Detection::create()
{
  static TYPE_SN_LN_Detection* tmpl = new TYPE_SN_LN_Detection;
  return tmpl;
}

const SDLType* TYPE_SN_LN_Detection::create_new() const { return create(); }

TYPE_SN_LN_Detection::TYPE_SN_LN_Detection():SDLSequence(_fields,8){}
TYPE_SN_LN_Detection::TYPE_SN_LN_Detection(SDLType** f,unsigned long c):SDLSequence(f,c){}
TYPE_SN_LN_Detection::TYPE_SN_LN_Detection(const SDLNull&):SDLSequence(_fields,8)
{ set_state(invalidValue); }
TYPE_SN_LN_Detection::TYPE_SN_LN_Detection(const SDLAny& a, AsnCodingSet rule_set):SDLSequence(_fields,8){a.decode(this,rule_set);}
TYPE_SN_LN_Detection::TYPE_SN_LN_Detection(const TYPE_SN_LN_Detection&o):SDLSequence(o){
  if (o.state(SITEtemporaryValue)) {
#ifdef SITE_LOG
    if (SDLType::_type_debug & SITE_COPY_LOG)
      CERR << "(SDLRTE) struct reference copy of " << o << ENDL;
#endif
    for(int i=0; i<8;++i) {
       _fields[i] = o._fields[i]; o._fields[i] = 0;
    }
  } else sequence_copyinit(_fields,o._fields,8);
}
TYPE_SN_LN_Detection::~TYPE_SN_LN_Detection(){clear_fields(_fields,8);}

TYPE_SN_LN_Detection& TYPE_SN_LN_Detection::operator=(const TYPE_SN_LN_Detection& val){
  val.check_valid();
  if (this!=&val) sequence_assign(val);
  return *this;
}

unsigned int TYPE_SN_LN_Detection::hash(unsigned int max_hash)const{
  return sequence_hash(_fields, 8, max_hash);
}

void TYPE_SN_LN_Detection::get_fields(
  SDLSeqSetDescription*& d,SDLType **&field_list){
  d=&_fdesc; field_list=_fields;
}

void TYPE_SN_LN_Detection::get_fields(
  SDLSeqSetDescription*& d,SDLType *const*&field_list) const{
  d=&_fdesc; field_list=_fields;
}


TYPE_DateTime& TYPE_SN_LN_Detection::VAR_gpsTimeStamp() const
{ return *SITE_STATIC_CAST(TYPE_DateTime*,field_access(_fdesc,_fields,0)); }
static SDLSeqSetDescription::Field *_TYPE_SN_LN_DetectiongpsTimeStamp=TYPE_SN_LN_Detection::_fdesc.add(0,"gpsTimeStamp",&TYPE_DateTime::create,true);

TYPE_DateTime& TYPE_SN_LN_Detection::VAR_tp() const
{ return *SITE_STATIC_CAST(TYPE_DateTime*,field_access(_fdesc,_fields,1)); }
static SDLSeqSetDescription::Field *_TYPE_SN_LN_Detectiontp=TYPE_SN_LN_Detection::_fdesc.add(1,"tp",&TYPE_DateTime::create,true);

TYPE_SensorAcceleration& TYPE_SN_LN_Detection::VAR_a_max() const
{ return *SITE_STATIC_CAST(TYPE_SensorAcceleration*,field_access(_fdesc,_fields,2)); }
static SDLSeqSetDescription::Field *_TYPE_SN_LN_Detectiona_max=TYPE_SN_LN_Detection::_fdesc.add(2,"a_max",&TYPE_SensorAcceleration::create,true);

TYPE_SensorVelocity& TYPE_SN_LN_Detection::VAR_v_max() const
{ return *SITE_STATIC_CAST(TYPE_SensorVelocity*,field_access(_fdesc,_fields,3)); }
static SDLSeqSetDescription::Field *_TYPE_SN_LN_Detectionv_max=TYPE_SN_LN_Detection::_fdesc.add(3,"v_max",&TYPE_SensorVelocity::create,true);

TYPE_SensorDisplacement& TYPE_SN_LN_Detection::VAR_d_max() const
{ return *SITE_STATIC_CAST(TYPE_SensorDisplacement*,field_access(_fdesc,_fields,4)); }
static SDLSeqSetDescription::Field *_TYPE_SN_LN_Detectiond_max=TYPE_SN_LN_Detection::_fdesc.add(4,"d_max",&TYPE_SensorDisplacement::create,true);

TYPE_SensorAccelerationAverage& TYPE_SN_LN_Detection::VAR_noiseAverage() const
{ return *SITE_STATIC_CAST(TYPE_SensorAccelerationAverage*,field_access(_fdesc,_fields,5)); }
static SDLSeqSetDescription::Field *_TYPE_SN_LN_DetectionnoiseAverage=TYPE_SN_LN_Detection::_fdesc.add(5,"noiseAverage",&TYPE_SensorAccelerationAverage::create,true);

SDLReal& TYPE_SN_LN_Detection::VAR_valueFourthChannel() const
{ return *SITE_STATIC_CAST(SDLReal*,field_access(_fdesc,_fields,6)); }

const SDLBool& TYPE_SN_LN_Detection::valueFourthChannelPresent()const{
  return field_present(_fdesc,_fields,6);
}

TYPE_SN_LN_Detection TYPE_SN_LN_Detection::valueFourthChannelOmit()const{
  TYPE_SN_LN_Detection c(*this);
  field_omit(_fdesc,c._fields,6);
  return c;
}

void TYPE_SN_LN_Detection::_valueFourthChannelOmit() {
  field_omit(_fdesc,_fields,6);
}

static SDLSeqSetDescription::Field *_TYPE_SN_LN_DetectionvalueFourthChannel=TYPE_SN_LN_Detection::_fdesc.add_optional(6,"valueFourthChannel",&SDLReal::create,true);

SDLReal& TYPE_SN_LN_Detection::VAR_sta_lta_TriggerValue() const
{ return *SITE_STATIC_CAST(SDLReal*,field_access(_fdesc,_fields,7)); }
static SDLSeqSetDescription::Field *_TYPE_SN_LN_Detectionsta_lta_TriggerValue=TYPE_SN_LN_Detection::_fdesc.add(7,"sta_lta_TriggerValue",&SDLReal::create,true);



TYPE_SN_LN_Detection::TYPE_SN_LN_Detection(const class TYPE_DateTime& PAR_0, const class TYPE_DateTime& PAR_1, const class TYPE_SensorAcceleration& PAR_2, const class TYPE_SensorVelocity& PAR_3, const class TYPE_SensorDisplacement& PAR_4, const class TYPE_SensorAccelerationAverage& PAR_5, const class SDLReal& PAR_6, const class SDLReal& PAR_7) {
    set_field(0,PAR_0.copy());
    set_field(1,PAR_1.copy());
    set_field(2,PAR_2.copy());
    set_field(3,PAR_3.copy());
    set_field(4,PAR_4.copy());
    set_field(5,PAR_5.copy());
    if(PAR_6.valid())
        set_field(6,new SDLReal(PAR_6));
    else
        set_field(6,0);
    set_field(7,PAR_7.copy());
}

AsnLen TYPE_SN_LN_Detection::bEnc(BUF_TYPE b) const{
    AsnLen elmtLen = bEncContent(b);
    elmtLen += BEncDefLen(b,elmtLen);
    elmtLen += BEncTag1(b,UNIV,CONS,16);
    return elmtLen;
} // TYPE_SN_LN_Detection::bEnc

AsnLen TYPE_SN_LN_Detection::bEncContent(BUF_TYPE b) const {
    AsnLen elmtLen, structBytesEncoded = BEncExtraFields(b);
    elmtLen = VAR_sta_lta_TriggerValue().bEncContent(b);
    elmtLen += BEncDefLen(b,elmtLen);
    elmtLen += BEncTag1(b,UNIV,PRIM,9);
    structBytesEncoded += elmtLen;
    if (valueFourthChannelPresent().val()) {
        elmtLen = VAR_valueFourthChannel().bEncContent(b);
        elmtLen += BEncDefLen(b,elmtLen);
        elmtLen += BEncTag1(b,UNIV,PRIM,9);
        elmtLen += BEncDefLen(b,elmtLen);
        elmtLen += BEncTag1(b,CNTX,CONS,1);
        structBytesEncoded += elmtLen;
    }
    elmtLen = VAR_noiseAverage().bEncContent(b);
    elmtLen += BEncDefLen(b,elmtLen);
    elmtLen += BEncTag1(b,UNIV,CONS,16);
    structBytesEncoded += elmtLen;
    elmtLen = VAR_d_max().bEncContent(b);
    elmtLen += BEncDefLen(b,elmtLen);
    elmtLen += BEncTag1(b,UNIV,CONS,16);
    structBytesEncoded += elmtLen;
    elmtLen = VAR_v_max().bEncContent(b);
    elmtLen += BEncDefLen(b,elmtLen);
    elmtLen += BEncTag1(b,UNIV,CONS,16);
    structBytesEncoded += elmtLen;
    elmtLen = VAR_a_max().bEncContent(b);
    elmtLen += BEncDefLen(b,elmtLen);
    elmtLen += BEncTag1(b,UNIV,CONS,16);
    structBytesEncoded += elmtLen;
    elmtLen = VAR_tp().bEncContent(b);
    elmtLen += BEncDefLen(b,elmtLen);
    elmtLen += BEncTag1(b,UNIV,CONS,16);
    structBytesEncoded += elmtLen;
    elmtLen = VAR_gpsTimeStamp().bEncContent(b);
    elmtLen += BEncDefLen(b,elmtLen);
    elmtLen += BEncTag1(b,UNIV,CONS,16);
    structBytesEncoded += elmtLen;
    return structBytesEncoded;
} // TYPE_SN_LN_Detection::bEncContent

void TYPE_SN_LN_Detection::bDec(BUF_TYPE b,AsnLen& bytesDecoded) {
    AsnTag tagId = BDecTag1(b,bytesDecoded);
    AsnLen elmtLen;
    if (tagId != MAKE_TAG_ID(UNIV,CONS,16)) { TagError(MAKE_TAG_ID(UNIV,CONS,16),tagId); return; }
    elmtLen = BDecLen(b,bytesDecoded);
    int pending_eoc = 0;
    if (elmtLen == INDEFINITE_LEN) ++pending_eoc;
    AsnLen localBytesDecoded = 0;
    bDecContent(b,tagId,elmtLen,localBytesDecoded);
    for(;pending_eoc>0;--pending_eoc) { BDecEoc(b,localBytesDecoded); }
    bytesDecoded += localBytesDecoded;
} // TYPE_SN_LN_Detection::bDec

void TYPE_SN_LN_Detection::bDecContent(BUF_TYPE b,AsnTag,
        AsnLen len, AsnLen& bytesDecoded) {
    bool structDone = false;
    AsnLen elmtLen, localBytesDecoded = 0;
    AsnTag tagId;
    if (len == 0) { tagId = 0; structDone = true; }
    else tagId = BDecTag(b,localBytesDecoded);
    if (!structDone && (tagId==MAKE_TAG_ID(UNIV,CONS,16))) {
        elmtLen = BDecLen(b,localBytesDecoded);
        int pending_eoc = 0;
        if (elmtLen == INDEFINITE_LEN) ++pending_eoc;
        VAR_gpsTimeStamp().bDecContent(b,tagId,elmtLen,localBytesDecoded);
        for(;pending_eoc>0;--pending_eoc) { BDecEoc(b,localBytesDecoded); }
        if ((len!=INDEFINITE_LEN) && (localBytesDecoded>=len)) structDone = true;
        else tagId = BDecTag(b,localBytesDecoded);
    } else { TagError(MAKE_TAG_ID(UNIV,CONS,16),tagId); return; }
    if (!structDone && (tagId==MAKE_TAG_ID(UNIV,CONS,16))) {
        elmtLen = BDecLen(b,localBytesDecoded);
        int pending_eoc = 0;
        if (elmtLen == INDEFINITE_LEN) ++pending_eoc;
        VAR_tp().bDecContent(b,tagId,elmtLen,localBytesDecoded);
        for(;pending_eoc>0;--pending_eoc) { BDecEoc(b,localBytesDecoded); }
        if ((len!=INDEFINITE_LEN) && (localBytesDecoded>=len)) structDone = true;
        else tagId = BDecTag(b,localBytesDecoded);
    } else { TagError(MAKE_TAG_ID(UNIV,CONS,16),tagId); return; }
    if (!structDone && (tagId==MAKE_TAG_ID(UNIV,CONS,16))) {
        elmtLen = BDecLen(b,localBytesDecoded);
        int pending_eoc = 0;
        if (elmtLen == INDEFINITE_LEN) ++pending_eoc;
        VAR_a_max().bDecContent(b,tagId,elmtLen,localBytesDecoded);
        for(;pending_eoc>0;--pending_eoc) { BDecEoc(b,localBytesDecoded); }
        if ((len!=INDEFINITE_LEN) && (localBytesDecoded>=len)) structDone = true;
        else tagId = BDecTag(b,localBytesDecoded);
    } else { TagError(MAKE_TAG_ID(UNIV,CONS,16),tagId); return; }
    if (!structDone && (tagId==MAKE_TAG_ID(UNIV,CONS,16))) {
        elmtLen = BDecLen(b,localBytesDecoded);
        int pending_eoc = 0;
        if (elmtLen == INDEFINITE_LEN) ++pending_eoc;
        VAR_v_max().bDecContent(b,tagId,elmtLen,localBytesDecoded);
        for(;pending_eoc>0;--pending_eoc) { BDecEoc(b,localBytesDecoded); }
        if ((len!=INDEFINITE_LEN) && (localBytesDecoded>=len)) structDone = true;
        else tagId = BDecTag(b,localBytesDecoded);
    } else { TagError(MAKE_TAG_ID(UNIV,CONS,16),tagId); return; }
    if (!structDone && (tagId==MAKE_TAG_ID(UNIV,CONS,16))) {
        elmtLen = BDecLen(b,localBytesDecoded);
        int pending_eoc = 0;
        if (elmtLen == INDEFINITE_LEN) ++pending_eoc;
        VAR_d_max().bDecContent(b,tagId,elmtLen,localBytesDecoded);
        for(;pending_eoc>0;--pending_eoc) { BDecEoc(b,localBytesDecoded); }
        if ((len!=INDEFINITE_LEN) && (localBytesDecoded>=len)) structDone = true;
        else tagId = BDecTag(b,localBytesDecoded);
    } else { TagError(MAKE_TAG_ID(UNIV,CONS,16),tagId); return; }
    if (!structDone && (tagId==MAKE_TAG_ID(UNIV,CONS,16))) {
        elmtLen = BDecLen(b,localBytesDecoded);
        int pending_eoc = 0;
        if (elmtLen == INDEFINITE_LEN) ++pending_eoc;
        VAR_noiseAverage().bDecContent(b,tagId,elmtLen,localBytesDecoded);
        for(;pending_eoc>0;--pending_eoc) { BDecEoc(b,localBytesDecoded); }
        if ((len!=INDEFINITE_LEN) && (localBytesDecoded>=len)) structDone = true;
        else tagId = BDecTag(b,localBytesDecoded);
    } else { TagError(MAKE_TAG_ID(UNIV,CONS,16),tagId); return; }
    if (!structDone && (tagId==MAKE_TAG_ID(CNTX,CONS,1))) {
        elmtLen = BDecLen(b,localBytesDecoded);
        int pending_eoc = 0;
        if (elmtLen == INDEFINITE_LEN) ++pending_eoc;
        tagId = BDecTag1(b,localBytesDecoded);
        if (tagId == MAKE_TAG_ID(UNIV,PRIM,9)) {
          elmtLen = BDecLen(b,localBytesDecoded);
        } else { TagError(MAKE_TAG_ID(UNIV,PRIM,9),tagId); return; }
        VAR_valueFourthChannel().bDecContent(b,tagId,elmtLen,localBytesDecoded);
        for(;pending_eoc>0;--pending_eoc) { BDecEoc(b,localBytesDecoded); }
        if (len!=INDEFINITE_LEN && localBytesDecoded>=len) structDone = true;
        else tagId = BDecTag(b,localBytesDecoded);
    }
    if (!structDone && (tagId==MAKE_TAG_ID(UNIV,PRIM,9))) {
        elmtLen = BDecLen(b,localBytesDecoded);
        VAR_sta_lta_TriggerValue().bDecContent(b,tagId,elmtLen,localBytesDecoded);
        if ((len!=INDEFINITE_LEN) && (localBytesDecoded>=len)) structDone = true;
        else tagId = BDecTag(b,localBytesDecoded);
    } else { TagError(MAKE_TAG_ID(UNIV,PRIM,9),tagId); return; }
    complete_sequence_decoding(b, len, localBytesDecoded, tagId);
    bytesDecoded += localBytesDecoded;
    set_state(validValue);
} // TYPE_SN_LN_Detection::bDecContent

AsnLen TYPE_SN_LN_Detection::pEnc(BUF_TYPE2 b) const {
    int elmtLen=0;
    b.putBit(valueFourthChannelPresent().val()?true:false);
    elmtLen++;
    elmtLen += VAR_gpsTimeStamp().pEnc(b);
    elmtLen += VAR_tp().pEnc(b);
    elmtLen += VAR_a_max().pEnc(b);
    elmtLen += VAR_v_max().pEnc(b);
    elmtLen += VAR_d_max().pEnc(b);
    elmtLen += VAR_noiseAverage().pEnc(b);
    if (valueFourthChannelPresent().val())
        elmtLen += VAR_valueFourthChannel().pEnc(b);
    elmtLen += VAR_sta_lta_TriggerValue().pEnc(b);
    return elmtLen;
}

void TYPE_SN_LN_Detection::pDec(BUF_TYPE2 b) {
    bool _field_present0 = b.getBit();
    VAR_gpsTimeStamp().pDec(b);
    VAR_tp().pDec(b);
    VAR_a_max().pDec(b);
    VAR_v_max().pDec(b);
    VAR_d_max().pDec(b);
    VAR_noiseAverage().pDec(b);
    if(_field_present0) VAR_valueFourthChannel().pDec(b);
    VAR_sta_lta_TriggerValue().pDec(b);
    set_state(validValue);
}

SDLSeqSetDescription TYPE_SN_LN_Description::_fdesc(11);

SDLType* TYPE_SN_LN_Description::copy()const { return new TYPE_SN_LN_Description(*this); }

void TYPE_SN_LN_Description::assign(const SDLType* t)
{
  const TYPE_SN_LN_Description *arg = SITE_DYNAMIC_CAST(const TYPE_SN_LN_Description*,t);
  if (!arg) SDLSequence::assign(t);
  else *this = *arg;
}

SDLType* TYPE_SN_LN_Description::create()
{
  static TYPE_SN_LN_Description* tmpl = new TYPE_SN_LN_Description;
  return tmpl;
}

const SDLType* TYPE_SN_LN_Description::create_new() const { return create(); }

TYPE_SN_LN_Description::TYPE_SN_LN_Description():SDLSequence(_fields,11){}
TYPE_SN_LN_Description::TYPE_SN_LN_Description(SDLType** f,unsigned long c):SDLSequence(f,c){}
TYPE_SN_LN_Description::TYPE_SN_LN_Description(const SDLNull&):SDLSequence(_fields,11)
{ set_state(invalidValue); }
TYPE_SN_LN_Description::TYPE_SN_LN_Description(const SDLAny& a, AsnCodingSet rule_set):SDLSequence(_fields,11){a.decode(this,rule_set);}
TYPE_SN_LN_Description::TYPE_SN_LN_Description(const TYPE_SN_LN_Description&o):SDLSequence(o){
  if (o.state(SITEtemporaryValue)) {
#ifdef SITE_LOG
    if (SDLType::_type_debug & SITE_COPY_LOG)
      CERR << "(SDLRTE) struct reference copy of " << o << ENDL;
#endif
    for(int i=0; i<11;++i) {
       _fields[i] = o._fields[i]; o._fields[i] = 0;
    }
  } else sequence_copyinit(_fields,o._fields,11);
}
TYPE_SN_LN_Description::~TYPE_SN_LN_Description(){clear_fields(_fields,11);}

TYPE_SN_LN_Description& TYPE_SN_LN_Description::operator=(const TYPE_SN_LN_Description& val){
  val.check_valid();
  if (this!=&val) sequence_assign(val);
  return *this;
}

unsigned int TYPE_SN_LN_Description::hash(unsigned int max_hash)const{
  return sequence_hash(_fields, 11, max_hash);
}

void TYPE_SN_LN_Description::get_fields(
  SDLSeqSetDescription*& d,SDLType **&field_list){
  d=&_fdesc; field_list=_fields;
}

void TYPE_SN_LN_Description::get_fields(
  SDLSeqSetDescription*& d,SDLType *const*&field_list) const{
  d=&_fdesc; field_list=_fields;
}


TYPE_DateTime& TYPE_SN_LN_Description::VAR_gpsTimeStamp() const
{ return *SITE_STATIC_CAST(TYPE_DateTime*,field_access(_fdesc,_fields,0)); }
static SDLSeqSetDescription::Field *_TYPE_SN_LN_DescriptiongpsTimeStamp=TYPE_SN_LN_Description::_fdesc.add(0,"gpsTimeStamp",&TYPE_DateTime::create,true);

TYPE_DateTime& TYPE_SN_LN_Description::VAR_tp() const
{ return *SITE_STATIC_CAST(TYPE_DateTime*,field_access(_fdesc,_fields,1)); }
static SDLSeqSetDescription::Field *_TYPE_SN_LN_Descriptiontp=TYPE_SN_LN_Description::_fdesc.add(1,"tp",&TYPE_DateTime::create,true);

TYPE_APEWProtocol_GEN_8& TYPE_SN_LN_Description::VAR_waveType() const
{ return *SITE_STATIC_CAST(TYPE_APEWProtocol_GEN_8*,field_access(_fdesc,_fields,2)); }
static SDLSeqSetDescription::Field *_TYPE_SN_LN_DescriptionwaveType=TYPE_SN_LN_Description::_fdesc.add(2,"waveType",&TYPE_APEWProtocol_GEN_8::create,true);

TYPE_SensorAcceleration& TYPE_SN_LN_Description::VAR_pga() const
{ return *SITE_STATIC_CAST(TYPE_SensorAcceleration*,field_access(_fdesc,_fields,3)); }
static SDLSeqSetDescription::Field *_TYPE_SN_LN_Descriptionpga=TYPE_SN_LN_Description::_fdesc.add(3,"pga",&TYPE_SensorAcceleration::create,true);

TYPE_SensorVelocity& TYPE_SN_LN_Description::VAR_pgv() const
{ return *SITE_STATIC_CAST(TYPE_SensorVelocity*,field_access(_fdesc,_fields,4)); }
static SDLSeqSetDescription::Field *_TYPE_SN_LN_Descriptionpgv=TYPE_SN_LN_Description::_fdesc.add(4,"pgv",&TYPE_SensorVelocity::create,true);

TYPE_SensorDisplacement& TYPE_SN_LN_Description::VAR_pgd() const
{ return *SITE_STATIC_CAST(TYPE_SensorDisplacement*,field_access(_fdesc,_fields,5)); }
static SDLSeqSetDescription::Field *_TYPE_SN_LN_Descriptionpgd=TYPE_SN_LN_Description::_fdesc.add(5,"pgd",&TYPE_SensorDisplacement::create,true);

TYPE_SensorAccelerationAverage& TYPE_SN_LN_Description::VAR_noiseAverage() const
{ return *SITE_STATIC_CAST(TYPE_SensorAccelerationAverage*,field_access(_fdesc,_fields,6)); }
static SDLSeqSetDescription::Field *_TYPE_SN_LN_DescriptionnoiseAverage=TYPE_SN_LN_Description::_fdesc.add(6,"noiseAverage",&TYPE_SensorAccelerationAverage::create,true);

SDLReal& TYPE_SN_LN_Description::VAR_predominantPeriod() const
{ return *SITE_STATIC_CAST(SDLReal*,field_access(_fdesc,_fields,7)); }

const SDLBool& TYPE_SN_LN_Description::predominantPeriodPresent()const{
  return field_present(_fdesc,_fields,7);
}

TYPE_SN_LN_Description TYPE_SN_LN_Description::predominantPeriodOmit()const{
  TYPE_SN_LN_Description c(*this);
  field_omit(_fdesc,c._fields,7);
  return c;
}

void TYPE_SN_LN_Description::_predominantPeriodOmit() {
  field_omit(_fdesc,_fields,7);
}

static SDLSeqSetDescription::Field *_TYPE_SN_LN_DescriptionpredominantPeriod=TYPE_SN_LN_Description::_fdesc.add_optional(7,"predominantPeriod",&SDLReal::create,true);

SDLReal& TYPE_SN_LN_Description::VAR_cav() const
{ return *SITE_STATIC_CAST(SDLReal*,field_access(_fdesc,_fields,8)); }
static SDLSeqSetDescription::Field *_TYPE_SN_LN_Descriptioncav=TYPE_SN_LN_Description::_fdesc.add(8,"cav",&SDLReal::create,true);

SDLReal& TYPE_SN_LN_Description::VAR_ariasIntensity() const
{ return *SITE_STATIC_CAST(SDLReal*,field_access(_fdesc,_fields,9)); }
static SDLSeqSetDescription::Field *_TYPE_SN_LN_DescriptionariasIntensity=TYPE_SN_LN_Description::_fdesc.add(9,"ariasIntensity",&SDLReal::create,true);

SDLReal& TYPE_SN_LN_Description::VAR_valueFourthChannel() const
{ return *SITE_STATIC_CAST(SDLReal*,field_access(_fdesc,_fields,10)); }

const SDLBool& TYPE_SN_LN_Description::valueFourthChannelPresent()const{
  return field_present(_fdesc,_fields,10);
}

TYPE_SN_LN_Description TYPE_SN_LN_Description::valueFourthChannelOmit()const{
  TYPE_SN_LN_Description c(*this);
  field_omit(_fdesc,c._fields,10);
  return c;
}

void TYPE_SN_LN_Description::_valueFourthChannelOmit() {
  field_omit(_fdesc,_fields,10);
}

static SDLSeqSetDescription::Field *_TYPE_SN_LN_DescriptionvalueFourthChannel=TYPE_SN_LN_Description::_fdesc.add_optional(10,"valueFourthChannel",&SDLReal::create,true);



TYPE_SN_LN_Description::TYPE_SN_LN_Description(const class TYPE_DateTime& PAR_0, const class TYPE_DateTime& PAR_1, const class TYPE_APEWProtocol_GEN_8& PAR_2, const class TYPE_SensorAcceleration& PAR_3, const class TYPE_SensorVelocity& PAR_4, const class TYPE_SensorDisplacement& PAR_5, const class TYPE_SensorAccelerationAverage& PAR_6, const class SDLReal& PAR_7, const class SDLReal& PAR_8, const class SDLReal& PAR_9, const class SDLReal& PAR_10) {
    set_field(0,PAR_0.copy());
    set_field(1,PAR_1.copy());
    set_field(2,PAR_2.copy());
    set_field(3,PAR_3.copy());
    set_field(4,PAR_4.copy());
    set_field(5,PAR_5.copy());
    set_field(6,PAR_6.copy());
    if(PAR_7.valid())
        set_field(7,new SDLReal(PAR_7));
    else
        set_field(7,0);
    set_field(8,PAR_8.copy());
    set_field(9,PAR_9.copy());
    if(PAR_10.valid())
        set_field(10,new SDLReal(PAR_10));
    else
        set_field(10,0);
}

AsnLen TYPE_SN_LN_Description::bEnc(BUF_TYPE b) const{
    AsnLen elmtLen = bEncContent(b);
    elmtLen += BEncDefLen(b,elmtLen);
    elmtLen += BEncTag1(b,UNIV,CONS,16);
    return elmtLen;
} // TYPE_SN_LN_Description::bEnc

AsnLen TYPE_SN_LN_Description::bEncContent(BUF_TYPE b) const {
    AsnLen elmtLen, structBytesEncoded = BEncExtraFields(b);
    if (valueFourthChannelPresent().val()) {
        elmtLen = VAR_valueFourthChannel().bEncContent(b);
        elmtLen += BEncDefLen(b,elmtLen);
        elmtLen += BEncTag1(b,UNIV,PRIM,9);
        elmtLen += BEncDefLen(b,elmtLen);
        elmtLen += BEncTag1(b,CNTX,CONS,2);
        structBytesEncoded += elmtLen;
    }
    elmtLen = VAR_ariasIntensity().bEncContent(b);
    elmtLen += BEncDefLen(b,elmtLen);
    elmtLen += BEncTag1(b,UNIV,PRIM,9);
    structBytesEncoded += elmtLen;
    elmtLen = VAR_cav().bEncContent(b);
    elmtLen += BEncDefLen(b,elmtLen);
    elmtLen += BEncTag1(b,UNIV,PRIM,9);
    structBytesEncoded += elmtLen;
    if (predominantPeriodPresent().val()) {
        elmtLen = VAR_predominantPeriod().bEncContent(b);
        elmtLen += BEncDefLen(b,elmtLen);
        elmtLen += BEncTag1(b,UNIV,PRIM,9);
        elmtLen += BEncDefLen(b,elmtLen);
        elmtLen += BEncTag1(b,CNTX,CONS,1);
        structBytesEncoded += elmtLen;
    }
    elmtLen = VAR_noiseAverage().bEncContent(b);
    elmtLen += BEncDefLen(b,elmtLen);
    elmtLen += BEncTag1(b,UNIV,CONS,16);
    structBytesEncoded += elmtLen;
    elmtLen = VAR_pgd().bEncContent(b);
    elmtLen += BEncDefLen(b,elmtLen);
    elmtLen += BEncTag1(b,UNIV,CONS,16);
    structBytesEncoded += elmtLen;
    elmtLen = VAR_pgv().bEncContent(b);
    elmtLen += BEncDefLen(b,elmtLen);
    elmtLen += BEncTag1(b,UNIV,CONS,16);
    structBytesEncoded += elmtLen;
    elmtLen = VAR_pga().bEncContent(b);
    elmtLen += BEncDefLen(b,elmtLen);
    elmtLen += BEncTag1(b,UNIV,CONS,16);
    structBytesEncoded += elmtLen;
    elmtLen = VAR_waveType().bEncContent(b);
    elmtLen += BEncDefLen(b,elmtLen);
    elmtLen += BEncTag1(b,UNIV,PRIM,10);
    structBytesEncoded += elmtLen;
    elmtLen = VAR_tp().bEncContent(b);
    elmtLen += BEncDefLen(b,elmtLen);
    elmtLen += BEncTag1(b,UNIV,CONS,16);
    structBytesEncoded += elmtLen;
    elmtLen = VAR_gpsTimeStamp().bEncContent(b);
    elmtLen += BEncDefLen(b,elmtLen);
    elmtLen += BEncTag1(b,UNIV,CONS,16);
    structBytesEncoded += elmtLen;
    return structBytesEncoded;
} // TYPE_SN_LN_Description::bEncContent

void TYPE_SN_LN_Description::bDec(BUF_TYPE b,AsnLen& bytesDecoded) {
    AsnTag tagId = BDecTag1(b,bytesDecoded);
    AsnLen elmtLen;
    if (tagId != MAKE_TAG_ID(UNIV,CONS,16)) { TagError(MAKE_TAG_ID(UNIV,CONS,16),tagId); return; }
    elmtLen = BDecLen(b,bytesDecoded);
    int pending_eoc = 0;
    if (elmtLen == INDEFINITE_LEN) ++pending_eoc;
    AsnLen localBytesDecoded = 0;
    bDecContent(b,tagId,elmtLen,localBytesDecoded);
    for(;pending_eoc>0;--pending_eoc) { BDecEoc(b,localBytesDecoded); }
    bytesDecoded += localBytesDecoded;
} // TYPE_SN_LN_Description::bDec

void TYPE_SN_LN_Description::bDecContent(BUF_TYPE b,AsnTag,
        AsnLen len, AsnLen& bytesDecoded) {
    bool structDone = false;
    AsnLen elmtLen, localBytesDecoded = 0;
    AsnTag tagId;
    if (len == 0) { tagId = 0; structDone = true; }
    else tagId = BDecTag(b,localBytesDecoded);
    if (!structDone && (tagId==MAKE_TAG_ID(UNIV,CONS,16))) {
        elmtLen = BDecLen(b,localBytesDecoded);
        int pending_eoc = 0;
        if (elmtLen == INDEFINITE_LEN) ++pending_eoc;
        VAR_gpsTimeStamp().bDecContent(b,tagId,elmtLen,localBytesDecoded);
        for(;pending_eoc>0;--pending_eoc) { BDecEoc(b,localBytesDecoded); }
        if ((len!=INDEFINITE_LEN) && (localBytesDecoded>=len)) structDone = true;
        else tagId = BDecTag(b,localBytesDecoded);
    } else { TagError(MAKE_TAG_ID(UNIV,CONS,16),tagId); return; }
    if (!structDone && (tagId==MAKE_TAG_ID(UNIV,CONS,16))) {
        elmtLen = BDecLen(b,localBytesDecoded);
        int pending_eoc = 0;
        if (elmtLen == INDEFINITE_LEN) ++pending_eoc;
        VAR_tp().bDecContent(b,tagId,elmtLen,localBytesDecoded);
        for(;pending_eoc>0;--pending_eoc) { BDecEoc(b,localBytesDecoded); }
        if ((len!=INDEFINITE_LEN) && (localBytesDecoded>=len)) structDone = true;
        else tagId = BDecTag(b,localBytesDecoded);
    } else { TagError(MAKE_TAG_ID(UNIV,CONS,16),tagId); return; }
    if (!structDone && (tagId==MAKE_TAG_ID(UNIV,PRIM,10))) {
        elmtLen = BDecLen(b,localBytesDecoded);
        VAR_waveType().bDecContent(b,tagId,elmtLen,localBytesDecoded);
        if ((len!=INDEFINITE_LEN) && (localBytesDecoded>=len)) structDone = true;
        else tagId = BDecTag(b,localBytesDecoded);
    } else { TagError(MAKE_TAG_ID(UNIV,PRIM,10),tagId); return; }
    if (!structDone && (tagId==MAKE_TAG_ID(UNIV,CONS,16))) {
        elmtLen = BDecLen(b,localBytesDecoded);
        int pending_eoc = 0;
        if (elmtLen == INDEFINITE_LEN) ++pending_eoc;
        VAR_pga().bDecContent(b,tagId,elmtLen,localBytesDecoded);
        for(;pending_eoc>0;--pending_eoc) { BDecEoc(b,localBytesDecoded); }
        if ((len!=INDEFINITE_LEN) && (localBytesDecoded>=len)) structDone = true;
        else tagId = BDecTag(b,localBytesDecoded);
    } else { TagError(MAKE_TAG_ID(UNIV,CONS,16),tagId); return; }
    if (!structDone && (tagId==MAKE_TAG_ID(UNIV,CONS,16))) {
        elmtLen = BDecLen(b,localBytesDecoded);
        int pending_eoc = 0;
        if (elmtLen == INDEFINITE_LEN) ++pending_eoc;
        VAR_pgv().bDecContent(b,tagId,elmtLen,localBytesDecoded);
        for(;pending_eoc>0;--pending_eoc) { BDecEoc(b,localBytesDecoded); }
        if ((len!=INDEFINITE_LEN) && (localBytesDecoded>=len)) structDone = true;
        else tagId = BDecTag(b,localBytesDecoded);
    } else { TagError(MAKE_TAG_ID(UNIV,CONS,16),tagId); return; }
    if (!structDone && (tagId==MAKE_TAG_ID(UNIV,CONS,16))) {
        elmtLen = BDecLen(b,localBytesDecoded);
        int pending_eoc = 0;
        if (elmtLen == INDEFINITE_LEN) ++pending_eoc;
        VAR_pgd().bDecContent(b,tagId,elmtLen,localBytesDecoded);
        for(;pending_eoc>0;--pending_eoc) { BDecEoc(b,localBytesDecoded); }
        if ((len!=INDEFINITE_LEN) && (localBytesDecoded>=len)) structDone = true;
        else tagId = BDecTag(b,localBytesDecoded);
    } else { TagError(MAKE_TAG_ID(UNIV,CONS,16),tagId); return; }
    if (!structDone && (tagId==MAKE_TAG_ID(UNIV,CONS,16))) {
        elmtLen = BDecLen(b,localBytesDecoded);
        int pending_eoc = 0;
        if (elmtLen == INDEFINITE_LEN) ++pending_eoc;
        VAR_noiseAverage().bDecContent(b,tagId,elmtLen,localBytesDecoded);
        for(;pending_eoc>0;--pending_eoc) { BDecEoc(b,localBytesDecoded); }
        if ((len!=INDEFINITE_LEN) && (localBytesDecoded>=len)) structDone = true;
        else tagId = BDecTag(b,localBytesDecoded);
    } else { TagError(MAKE_TAG_ID(UNIV,CONS,16),tagId); return; }
    if (!structDone && (tagId==MAKE_TAG_ID(CNTX,CONS,1))) {
        elmtLen = BDecLen(b,localBytesDecoded);
        int pending_eoc = 0;
        if (elmtLen == INDEFINITE_LEN) ++pending_eoc;
        tagId = BDecTag1(b,localBytesDecoded);
        if (tagId == MAKE_TAG_ID(UNIV,PRIM,9)) {
          elmtLen = BDecLen(b,localBytesDecoded);
        } else { TagError(MAKE_TAG_ID(UNIV,PRIM,9),tagId); return; }
        VAR_predominantPeriod().bDecContent(b,tagId,elmtLen,localBytesDecoded);
        for(;pending_eoc>0;--pending_eoc) { BDecEoc(b,localBytesDecoded); }
        if (len!=INDEFINITE_LEN && localBytesDecoded>=len) structDone = true;
        else tagId = BDecTag(b,localBytesDecoded);
    }
    if (!structDone && (tagId==MAKE_TAG_ID(UNIV,PRIM,9))) {
        elmtLen = BDecLen(b,localBytesDecoded);
        VAR_cav().bDecContent(b,tagId,elmtLen,localBytesDecoded);
        if ((len!=INDEFINITE_LEN) && (localBytesDecoded>=len)) structDone = true;
        else tagId = BDecTag(b,localBytesDecoded);
    } else { TagError(MAKE_TAG_ID(UNIV,PRIM,9),tagId); return; }
    if (!structDone && (tagId==MAKE_TAG_ID(UNIV,PRIM,9))) {
        elmtLen = BDecLen(b,localBytesDecoded);
        VAR_ariasIntensity().bDecContent(b,tagId,elmtLen,localBytesDecoded);
        if ((len!=INDEFINITE_LEN) && (localBytesDecoded>=len)) structDone = true;
        else tagId = BDecTag(b,localBytesDecoded);
    } else { TagError(MAKE_TAG_ID(UNIV,PRIM,9),tagId); return; }
    if (!structDone && (tagId==MAKE_TAG_ID(CNTX,CONS,2))) {
        elmtLen = BDecLen(b,localBytesDecoded);
        int pending_eoc = 0;
        if (elmtLen == INDEFINITE_LEN) ++pending_eoc;
        tagId = BDecTag1(b,localBytesDecoded);
        if (tagId == MAKE_TAG_ID(UNIV,PRIM,9)) {
          elmtLen = BDecLen(b,localBytesDecoded);
        } else { TagError(MAKE_TAG_ID(UNIV,PRIM,9),tagId); return; }
        VAR_valueFourthChannel().bDecContent(b,tagId,elmtLen,localBytesDecoded);
        for(;pending_eoc>0;--pending_eoc) { BDecEoc(b,localBytesDecoded); }
        if (len!=INDEFINITE_LEN && localBytesDecoded>=len) structDone = true;
        else tagId = BDecTag(b,localBytesDecoded);
    }
    complete_sequence_decoding(b, len, localBytesDecoded, tagId);
    bytesDecoded += localBytesDecoded;
    set_state(validValue);
} // TYPE_SN_LN_Description::bDecContent

AsnLen TYPE_SN_LN_Description::pEnc(BUF_TYPE2 b) const {
    int elmtLen=0;
    b.putBit(predominantPeriodPresent().val()?true:false);
    elmtLen++;
    b.putBit(valueFourthChannelPresent().val()?true:false);
    elmtLen++;
    elmtLen += VAR_gpsTimeStamp().pEnc(b);
    elmtLen += VAR_tp().pEnc(b);
    elmtLen += VAR_waveType().pEnc(b);
    elmtLen += VAR_pga().pEnc(b);
    elmtLen += VAR_pgv().pEnc(b);
    elmtLen += VAR_pgd().pEnc(b);
    elmtLen += VAR_noiseAverage().pEnc(b);
    if (predominantPeriodPresent().val())
        elmtLen += VAR_predominantPeriod().pEnc(b);
    elmtLen += VAR_cav().pEnc(b);
    elmtLen += VAR_ariasIntensity().pEnc(b);
    if (valueFourthChannelPresent().val())
        elmtLen += VAR_valueFourthChannel().pEnc(b);
    return elmtLen;
}

void TYPE_SN_LN_Description::pDec(BUF_TYPE2 b) {
    bool _field_present0 = b.getBit();
    bool _field_present1 = b.getBit();
    VAR_gpsTimeStamp().pDec(b);
    VAR_tp().pDec(b);
    VAR_waveType().pDec(b);
    VAR_pga().pDec(b);
    VAR_pgv().pDec(b);
    VAR_pgd().pDec(b);
    VAR_noiseAverage().pDec(b);
    if(_field_present0) VAR_predominantPeriod().pDec(b);
    VAR_cav().pDec(b);
    VAR_ariasIntensity().pDec(b);
    if(_field_present1) VAR_valueFourthChannel().pDec(b);
    set_state(validValue);
}

SDLSeqSetDescription TYPE_SN_LN_Summary::_fdesc(12);

SDLType* TYPE_SN_LN_Summary::copy()const { return new TYPE_SN_LN_Summary(*this); }

void TYPE_SN_LN_Summary::assign(const SDLType* t)
{
  const TYPE_SN_LN_Summary *arg = SITE_DYNAMIC_CAST(const TYPE_SN_LN_Summary*,t);
  if (!arg) SDLSequence::assign(t);
  else *this = *arg;
}

SDLType* TYPE_SN_LN_Summary::create()
{
  static TYPE_SN_LN_Summary* tmpl = new TYPE_SN_LN_Summary;
  return tmpl;
}

const SDLType* TYPE_SN_LN_Summary::create_new() const { return create(); }

TYPE_SN_LN_Summary::TYPE_SN_LN_Summary():SDLSequence(_fields,12){}
TYPE_SN_LN_Summary::TYPE_SN_LN_Summary(SDLType** f,unsigned long c):SDLSequence(f,c){}
TYPE_SN_LN_Summary::TYPE_SN_LN_Summary(const SDLNull&):SDLSequence(_fields,12)
{ set_state(invalidValue); }
TYPE_SN_LN_Summary::TYPE_SN_LN_Summary(const SDLAny& a, AsnCodingSet rule_set):SDLSequence(_fields,12){a.decode(this,rule_set);}
TYPE_SN_LN_Summary::TYPE_SN_LN_Summary(const TYPE_SN_LN_Summary&o):SDLSequence(o){
  if (o.state(SITEtemporaryValue)) {
#ifdef SITE_LOG
    if (SDLType::_type_debug & SITE_COPY_LOG)
      CERR << "(SDLRTE) struct reference copy of " << o << ENDL;
#endif
    for(int i=0; i<12;++i) {
       _fields[i] = o._fields[i]; o._fields[i] = 0;
    }
  } else sequence_copyinit(_fields,o._fields,12);
}
TYPE_SN_LN_Summary::~TYPE_SN_LN_Summary(){clear_fields(_fields,12);}

TYPE_SN_LN_Summary& TYPE_SN_LN_Summary::operator=(const TYPE_SN_LN_Summary& val){
  val.check_valid();
  if (this!=&val) sequence_assign(val);
  return *this;
}

unsigned int TYPE_SN_LN_Summary::hash(unsigned int max_hash)const{
  return sequence_hash(_fields, 12, max_hash);
}

void TYPE_SN_LN_Summary::get_fields(
  SDLSeqSetDescription*& d,SDLType **&field_list){
  d=&_fdesc; field_list=_fields;
}

void TYPE_SN_LN_Summary::get_fields(
  SDLSeqSetDescription*& d,SDLType *const*&field_list) const{
  d=&_fdesc; field_list=_fields;
}


TYPE_DateTime& TYPE_SN_LN_Summary::VAR_gpsTimeStamp() const
{ return *SITE_STATIC_CAST(TYPE_DateTime*,field_access(_fdesc,_fields,0)); }
static SDLSeqSetDescription::Field *_TYPE_SN_LN_SummarygpsTimeStamp=TYPE_SN_LN_Summary::_fdesc.add(0,"gpsTimeStamp",&TYPE_DateTime::create,true);

TYPE_DateTime& TYPE_SN_LN_Summary::VAR_t_p() const
{ return *SITE_STATIC_CAST(TYPE_DateTime*,field_access(_fdesc,_fields,1)); }
static SDLSeqSetDescription::Field *_TYPE_SN_LN_Summaryt_p=TYPE_SN_LN_Summary::_fdesc.add(1,"t_p",&TYPE_DateTime::create,true);

TYPE_DateTime& TYPE_SN_LN_Summary::VAR_t_s() const
{ return *SITE_STATIC_CAST(TYPE_DateTime*,field_access(_fdesc,_fields,2)); }
static SDLSeqSetDescription::Field *_TYPE_SN_LN_Summaryt_s=TYPE_SN_LN_Summary::_fdesc.add(2,"t_s",&TYPE_DateTime::create,true);

TYPE_DateTime& TYPE_SN_LN_Summary::VAR_t_end() const
{ return *SITE_STATIC_CAST(TYPE_DateTime*,field_access(_fdesc,_fields,3)); }
static SDLSeqSetDescription::Field *_TYPE_SN_LN_Summaryt_end=TYPE_SN_LN_Summary::_fdesc.add(3,"t_end",&TYPE_DateTime::create,true);

TYPE_SensorAcceleration& TYPE_SN_LN_Summary::VAR_pga() const
{ return *SITE_STATIC_CAST(TYPE_SensorAcceleration*,field_access(_fdesc,_fields,4)); }
static SDLSeqSetDescription::Field *_TYPE_SN_LN_Summarypga=TYPE_SN_LN_Summary::_fdesc.add(4,"pga",&TYPE_SensorAcceleration::create,true);

TYPE_SensorVelocity& TYPE_SN_LN_Summary::VAR_pgv() const
{ return *SITE_STATIC_CAST(TYPE_SensorVelocity*,field_access(_fdesc,_fields,5)); }
static SDLSeqSetDescription::Field *_TYPE_SN_LN_Summarypgv=TYPE_SN_LN_Summary::_fdesc.add(5,"pgv",&TYPE_SensorVelocity::create,true);

TYPE_SensorDisplacement& TYPE_SN_LN_Summary::VAR_pgd() const
{ return *SITE_STATIC_CAST(TYPE_SensorDisplacement*,field_access(_fdesc,_fields,6)); }
static SDLSeqSetDescription::Field *_TYPE_SN_LN_Summarypgd=TYPE_SN_LN_Summary::_fdesc.add(6,"pgd",&TYPE_SensorDisplacement::create,true);

TYPE_SensorAccelerationAverage& TYPE_SN_LN_Summary::VAR_noiseAverage() const
{ return *SITE_STATIC_CAST(TYPE_SensorAccelerationAverage*,field_access(_fdesc,_fields,7)); }
static SDLSeqSetDescription::Field *_TYPE_SN_LN_SummarynoiseAverage=TYPE_SN_LN_Summary::_fdesc.add(7,"noiseAverage",&TYPE_SensorAccelerationAverage::create,true);

SDLReal& TYPE_SN_LN_Summary::VAR_cav() const
{ return *SITE_STATIC_CAST(SDLReal*,field_access(_fdesc,_fields,8)); }
static SDLSeqSetDescription::Field *_TYPE_SN_LN_Summarycav=TYPE_SN_LN_Summary::_fdesc.add(8,"cav",&SDLReal::create,true);

SDLReal& TYPE_SN_LN_Summary::VAR_ariasIntensity() const
{ return *SITE_STATIC_CAST(SDLReal*,field_access(_fdesc,_fields,9)); }
static SDLSeqSetDescription::Field *_TYPE_SN_LN_SummaryariasIntensity=TYPE_SN_LN_Summary::_fdesc.add(9,"ariasIntensity",&SDLReal::create,true);

SDLReal& TYPE_SN_LN_Summary::VAR_valueFourthChannel() const
{ return *SITE_STATIC_CAST(SDLReal*,field_access(_fdesc,_fields,10)); }

const SDLBool& TYPE_SN_LN_Summary::valueFourthChannelPresent()const{
  return field_present(_fdesc,_fields,10);
}

TYPE_SN_LN_Summary TYPE_SN_LN_Summary::valueFourthChannelOmit()const{
  TYPE_SN_LN_Summary c(*this);
  field_omit(_fdesc,c._fields,10);
  return c;
}

void TYPE_SN_LN_Summary::_valueFourthChannelOmit() {
  field_omit(_fdesc,_fields,10);
}

static SDLSeqSetDescription::Field *_TYPE_SN_LN_SummaryvalueFourthChannel=TYPE_SN_LN_Summary::_fdesc.add_optional(10,"valueFourthChannel",&SDLReal::create,true);

SDLReal& TYPE_SN_LN_Summary::VAR_batteryVoltage() const
{ return *SITE_STATIC_CAST(SDLReal*,field_access(_fdesc,_fields,11)); }

const SDLBool& TYPE_SN_LN_Summary::batteryVoltagePresent()const{
  return field_present(_fdesc,_fields,11);
}

TYPE_SN_LN_Summary TYPE_SN_LN_Summary::batteryVoltageOmit()const{
  TYPE_SN_LN_Summary c(*this);
  field_omit(_fdesc,c._fields,11);
  return c;
}

void TYPE_SN_LN_Summary::_batteryVoltageOmit() {
  field_omit(_fdesc,_fields,11);
}

static SDLSeqSetDescription::Field *_TYPE_SN_LN_SummarybatteryVoltage=TYPE_SN_LN_Summary::_fdesc.add_optional(11,"batteryVoltage",&SDLReal::create,true);



TYPE_SN_LN_Summary::TYPE_SN_LN_Summary(const class TYPE_DateTime& PAR_0, const class TYPE_DateTime& PAR_1, const class TYPE_DateTime& PAR_2, const class TYPE_DateTime& PAR_3, const class TYPE_SensorAcceleration& PAR_4, const class TYPE_SensorVelocity& PAR_5, const class TYPE_SensorDisplacement& PAR_6, const class TYPE_SensorAccelerationAverage& PAR_7, const class SDLReal& PAR_8, const class SDLReal& PAR_9, const class SDLReal& PAR_10, const class SDLReal& PAR_11) {
    set_field(0,PAR_0.copy());
    set_field(1,PAR_1.copy());
    set_field(2,PAR_2.copy());
    set_field(3,PAR_3.copy());
    set_field(4,PAR_4.copy());
    set_field(5,PAR_5.copy());
    set_field(6,PAR_6.copy());
    set_field(7,PAR_7.copy());
    set_field(8,PAR_8.copy());
    set_field(9,PAR_9.copy());
    if(PAR_10.valid())
        set_field(10,new SDLReal(PAR_10));
    else
        set_field(10,0);
    if(PAR_11.valid())
        set_field(11,new SDLReal(PAR_11));
    else
        set_field(11,0);
}

AsnLen TYPE_SN_LN_Summary::bEnc(BUF_TYPE b) const{
    AsnLen elmtLen = bEncContent(b);
    elmtLen += BEncDefLen(b,elmtLen);
    elmtLen += BEncTag1(b,UNIV,CONS,16);
    return elmtLen;
} // TYPE_SN_LN_Summary::bEnc

AsnLen TYPE_SN_LN_Summary::bEncContent(BUF_TYPE b) const {
    AsnLen elmtLen, structBytesEncoded = BEncExtraFields(b);
    if (batteryVoltagePresent().val()) {
        elmtLen = VAR_batteryVoltage().bEncContent(b);
        elmtLen += BEncDefLen(b,elmtLen);
        elmtLen += BEncTag1(b,UNIV,PRIM,9);
        elmtLen += BEncDefLen(b,elmtLen);
        elmtLen += BEncTag1(b,CNTX,CONS,2);
        structBytesEncoded += elmtLen;
    }
    if (valueFourthChannelPresent().val()) {
        elmtLen = VAR_valueFourthChannel().bEncContent(b);
        elmtLen += BEncDefLen(b,elmtLen);
        elmtLen += BEncTag1(b,UNIV,PRIM,9);
        elmtLen += BEncDefLen(b,elmtLen);
        elmtLen += BEncTag1(b,CNTX,CONS,1);
        structBytesEncoded += elmtLen;
    }
    elmtLen = VAR_ariasIntensity().bEncContent(b);
    elmtLen += BEncDefLen(b,elmtLen);
    elmtLen += BEncTag1(b,UNIV,PRIM,9);
    structBytesEncoded += elmtLen;
    elmtLen = VAR_cav().bEncContent(b);
    elmtLen += BEncDefLen(b,elmtLen);
    elmtLen += BEncTag1(b,UNIV,PRIM,9);
    structBytesEncoded += elmtLen;
    elmtLen = VAR_noiseAverage().bEncContent(b);
    elmtLen += BEncDefLen(b,elmtLen);
    elmtLen += BEncTag1(b,UNIV,CONS,16);
    structBytesEncoded += elmtLen;
    elmtLen = VAR_pgd().bEncContent(b);
    elmtLen += BEncDefLen(b,elmtLen);
    elmtLen += BEncTag1(b,UNIV,CONS,16);
    structBytesEncoded += elmtLen;
    elmtLen = VAR_pgv().bEncContent(b);
    elmtLen += BEncDefLen(b,elmtLen);
    elmtLen += BEncTag1(b,UNIV,CONS,16);
    structBytesEncoded += elmtLen;
    elmtLen = VAR_pga().bEncContent(b);
    elmtLen += BEncDefLen(b,elmtLen);
    elmtLen += BEncTag1(b,UNIV,CONS,16);
    structBytesEncoded += elmtLen;
    elmtLen = VAR_t_end().bEncContent(b);
    elmtLen += BEncDefLen(b,elmtLen);
    elmtLen += BEncTag1(b,UNIV,CONS,16);
    structBytesEncoded += elmtLen;
    elmtLen = VAR_t_s().bEncContent(b);
    elmtLen += BEncDefLen(b,elmtLen);
    elmtLen += BEncTag1(b,UNIV,CONS,16);
    structBytesEncoded += elmtLen;
    elmtLen = VAR_t_p().bEncContent(b);
    elmtLen += BEncDefLen(b,elmtLen);
    elmtLen += BEncTag1(b,UNIV,CONS,16);
    structBytesEncoded += elmtLen;
    elmtLen = VAR_gpsTimeStamp().bEncContent(b);
    elmtLen += BEncDefLen(b,elmtLen);
    elmtLen += BEncTag1(b,UNIV,CONS,16);
    structBytesEncoded += elmtLen;
    return structBytesEncoded;
} // TYPE_SN_LN_Summary::bEncContent

void TYPE_SN_LN_Summary::bDec(BUF_TYPE b,AsnLen& bytesDecoded) {
    AsnTag tagId = BDecTag1(b,bytesDecoded);
    AsnLen elmtLen;
    if (tagId != MAKE_TAG_ID(UNIV,CONS,16)) { TagError(MAKE_TAG_ID(UNIV,CONS,16),tagId); return; }
    elmtLen = BDecLen(b,bytesDecoded);
    int pending_eoc = 0;
    if (elmtLen == INDEFINITE_LEN) ++pending_eoc;
    AsnLen localBytesDecoded = 0;
    bDecContent(b,tagId,elmtLen,localBytesDecoded);
    for(;pending_eoc>0;--pending_eoc) { BDecEoc(b,localBytesDecoded); }
    bytesDecoded += localBytesDecoded;
} // TYPE_SN_LN_Summary::bDec

void TYPE_SN_LN_Summary::bDecContent(BUF_TYPE b,AsnTag,
        AsnLen len, AsnLen& bytesDecoded) {
    bool structDone = false;
    AsnLen elmtLen, localBytesDecoded = 0;
    AsnTag tagId;
    if (len == 0) { tagId = 0; structDone = true; }
    else tagId = BDecTag(b,localBytesDecoded);
    if (!structDone && (tagId==MAKE_TAG_ID(UNIV,CONS,16))) {
        elmtLen = BDecLen(b,localBytesDecoded);
        int pending_eoc = 0;
        if (elmtLen == INDEFINITE_LEN) ++pending_eoc;
        VAR_gpsTimeStamp().bDecContent(b,tagId,elmtLen,localBytesDecoded);
        for(;pending_eoc>0;--pending_eoc) { BDecEoc(b,localBytesDecoded); }
        if ((len!=INDEFINITE_LEN) && (localBytesDecoded>=len)) structDone = true;
        else tagId = BDecTag(b,localBytesDecoded);
    } else { TagError(MAKE_TAG_ID(UNIV,CONS,16),tagId); return; }
    if (!structDone && (tagId==MAKE_TAG_ID(UNIV,CONS,16))) {
        elmtLen = BDecLen(b,localBytesDecoded);
        int pending_eoc = 0;
        if (elmtLen == INDEFINITE_LEN) ++pending_eoc;
        VAR_t_p().bDecContent(b,tagId,elmtLen,localBytesDecoded);
        for(;pending_eoc>0;--pending_eoc) { BDecEoc(b,localBytesDecoded); }
        if ((len!=INDEFINITE_LEN) && (localBytesDecoded>=len)) structDone = true;
        else tagId = BDecTag(b,localBytesDecoded);
    } else { TagError(MAKE_TAG_ID(UNIV,CONS,16),tagId); return; }
    if (!structDone && (tagId==MAKE_TAG_ID(UNIV,CONS,16))) {
        elmtLen = BDecLen(b,localBytesDecoded);
        int pending_eoc = 0;
        if (elmtLen == INDEFINITE_LEN) ++pending_eoc;
        VAR_t_s().bDecContent(b,tagId,elmtLen,localBytesDecoded);
        for(;pending_eoc>0;--pending_eoc) { BDecEoc(b,localBytesDecoded); }
        if ((len!=INDEFINITE_LEN) && (localBytesDecoded>=len)) structDone = true;
        else tagId = BDecTag(b,localBytesDecoded);
    } else { TagError(MAKE_TAG_ID(UNIV,CONS,16),tagId); return; }
    if (!structDone && (tagId==MAKE_TAG_ID(UNIV,CONS,16))) {
        elmtLen = BDecLen(b,localBytesDecoded);
        int pending_eoc = 0;
        if (elmtLen == INDEFINITE_LEN) ++pending_eoc;
        VAR_t_end().bDecContent(b,tagId,elmtLen,localBytesDecoded);
        for(;pending_eoc>0;--pending_eoc) { BDecEoc(b,localBytesDecoded); }
        if ((len!=INDEFINITE_LEN) && (localBytesDecoded>=len)) structDone = true;
        else tagId = BDecTag(b,localBytesDecoded);
    } else { TagError(MAKE_TAG_ID(UNIV,CONS,16),tagId); return; }
    if (!structDone && (tagId==MAKE_TAG_ID(UNIV,CONS,16))) {
        elmtLen = BDecLen(b,localBytesDecoded);
        int pending_eoc = 0;
        if (elmtLen == INDEFINITE_LEN) ++pending_eoc;
        VAR_pga().bDecContent(b,tagId,elmtLen,localBytesDecoded);
        for(;pending_eoc>0;--pending_eoc) { BDecEoc(b,localBytesDecoded); }
        if ((len!=INDEFINITE_LEN) && (localBytesDecoded>=len)) structDone = true;
        else tagId = BDecTag(b,localBytesDecoded);
    } else { TagError(MAKE_TAG_ID(UNIV,CONS,16),tagId); return; }
    if (!structDone && (tagId==MAKE_TAG_ID(UNIV,CONS,16))) {
        elmtLen = BDecLen(b,localBytesDecoded);
        int pending_eoc = 0;
        if (elmtLen == INDEFINITE_LEN) ++pending_eoc;
        VAR_pgv().bDecContent(b,tagId,elmtLen,localBytesDecoded);
        for(;pending_eoc>0;--pending_eoc) { BDecEoc(b,localBytesDecoded); }
        if ((len!=INDEFINITE_LEN) && (localBytesDecoded>=len)) structDone = true;
        else tagId = BDecTag(b,localBytesDecoded);
    } else { TagError(MAKE_TAG_ID(UNIV,CONS,16),tagId); return; }
    if (!structDone && (tagId==MAKE_TAG_ID(UNIV,CONS,16))) {
        elmtLen = BDecLen(b,localBytesDecoded);
        int pending_eoc = 0;
        if (elmtLen == INDEFINITE_LEN) ++pending_eoc;
        VAR_pgd().bDecContent(b,tagId,elmtLen,localBytesDecoded);
        for(;pending_eoc>0;--pending_eoc) { BDecEoc(b,localBytesDecoded); }
        if ((len!=INDEFINITE_LEN) && (localBytesDecoded>=len)) structDone = true;
        else tagId = BDecTag(b,localBytesDecoded);
    } else { TagError(MAKE_TAG_ID(UNIV,CONS,16),tagId); return; }
    if (!structDone && (tagId==MAKE_TAG_ID(UNIV,CONS,16))) {
        elmtLen = BDecLen(b,localBytesDecoded);
        int pending_eoc = 0;
        if (elmtLen == INDEFINITE_LEN) ++pending_eoc;
        VAR_noiseAverage().bDecContent(b,tagId,elmtLen,localBytesDecoded);
        for(;pending_eoc>0;--pending_eoc) { BDecEoc(b,localBytesDecoded); }
        if ((len!=INDEFINITE_LEN) && (localBytesDecoded>=len)) structDone = true;
        else tagId = BDecTag(b,localBytesDecoded);
    } else { TagError(MAKE_TAG_ID(UNIV,CONS,16),tagId); return; }
    if (!structDone && (tagId==MAKE_TAG_ID(UNIV,PRIM,9))) {
        elmtLen = BDecLen(b,localBytesDecoded);
        VAR_cav().bDecContent(b,tagId,elmtLen,localBytesDecoded);
        if ((len!=INDEFINITE_LEN) && (localBytesDecoded>=len)) structDone = true;
        else tagId = BDecTag(b,localBytesDecoded);
    } else { TagError(MAKE_TAG_ID(UNIV,PRIM,9),tagId); return; }
    if (!structDone && (tagId==MAKE_TAG_ID(UNIV,PRIM,9))) {
        elmtLen = BDecLen(b,localBytesDecoded);
        VAR_ariasIntensity().bDecContent(b,tagId,elmtLen,localBytesDecoded);
        if ((len!=INDEFINITE_LEN) && (localBytesDecoded>=len)) structDone = true;
        else tagId = BDecTag(b,localBytesDecoded);
    } else { TagError(MAKE_TAG_ID(UNIV,PRIM,9),tagId); return; }
    if (!structDone && (tagId==MAKE_TAG_ID(CNTX,CONS,1))) {
        elmtLen = BDecLen(b,localBytesDecoded);
        int pending_eoc = 0;
        if (elmtLen == INDEFINITE_LEN) ++pending_eoc;
        tagId = BDecTag1(b,localBytesDecoded);
        if (tagId == MAKE_TAG_ID(UNIV,PRIM,9)) {
          elmtLen = BDecLen(b,localBytesDecoded);
        } else { TagError(MAKE_TAG_ID(UNIV,PRIM,9),tagId); return; }
        VAR_valueFourthChannel().bDecContent(b,tagId,elmtLen,localBytesDecoded);
        for(;pending_eoc>0;--pending_eoc) { BDecEoc(b,localBytesDecoded); }
        if (len!=INDEFINITE_LEN && localBytesDecoded>=len) structDone = true;
        else tagId = BDecTag(b,localBytesDecoded);
    }
    if (!structDone && (tagId==MAKE_TAG_ID(CNTX,CONS,2))) {
        elmtLen = BDecLen(b,localBytesDecoded);
        int pending_eoc = 0;
        if (elmtLen == INDEFINITE_LEN) ++pending_eoc;
        tagId = BDecTag1(b,localBytesDecoded);
        if (tagId == MAKE_TAG_ID(UNIV,PRIM,9)) {
          elmtLen = BDecLen(b,localBytesDecoded);
        } else { TagError(MAKE_TAG_ID(UNIV,PRIM,9),tagId); return; }
        VAR_batteryVoltage().bDecContent(b,tagId,elmtLen,localBytesDecoded);
        for(;pending_eoc>0;--pending_eoc) { BDecEoc(b,localBytesDecoded); }
        if (len!=INDEFINITE_LEN && localBytesDecoded>=len) structDone = true;
        else tagId = BDecTag(b,localBytesDecoded);
    }
    complete_sequence_decoding(b, len, localBytesDecoded, tagId);
    bytesDecoded += localBytesDecoded;
    set_state(validValue);
} // TYPE_SN_LN_Summary::bDecContent

AsnLen TYPE_SN_LN_Summary::pEnc(BUF_TYPE2 b) const {
    int elmtLen=0;
    b.putBit(valueFourthChannelPresent().val()?true:false);
    elmtLen++;
    b.putBit(batteryVoltagePresent().val()?true:false);
    elmtLen++;
    elmtLen += VAR_gpsTimeStamp().pEnc(b);
    elmtLen += VAR_t_p().pEnc(b);
    elmtLen += VAR_t_s().pEnc(b);
    elmtLen += VAR_t_end().pEnc(b);
    elmtLen += VAR_pga().pEnc(b);
    elmtLen += VAR_pgv().pEnc(b);
    elmtLen += VAR_pgd().pEnc(b);
    elmtLen += VAR_noiseAverage().pEnc(b);
    elmtLen += VAR_cav().pEnc(b);
    elmtLen += VAR_ariasIntensity().pEnc(b);
    if (valueFourthChannelPresent().val())
        elmtLen += VAR_valueFourthChannel().pEnc(b);
    if (batteryVoltagePresent().val())
        elmtLen += VAR_batteryVoltage().pEnc(b);
    return elmtLen;
}

void TYPE_SN_LN_Summary::pDec(BUF_TYPE2 b) {
    bool _field_present0 = b.getBit();
    bool _field_present1 = b.getBit();
    VAR_gpsTimeStamp().pDec(b);
    VAR_t_p().pDec(b);
    VAR_t_s().pDec(b);
    VAR_t_end().pDec(b);
    VAR_pga().pDec(b);
    VAR_pgv().pDec(b);
    VAR_pgd().pDec(b);
    VAR_noiseAverage().pDec(b);
    VAR_cav().pDec(b);
    VAR_ariasIntensity().pDec(b);
    if(_field_present0) VAR_valueFourthChannel().pDec(b);
    if(_field_present1) VAR_batteryVoltage().pDec(b);
    set_state(validValue);
}

SDLSeqSetDescription TYPE_ResponseSpectra::_fdesc(3);

SDLType* TYPE_ResponseSpectra::copy()const { return new TYPE_ResponseSpectra(*this); }

void TYPE_ResponseSpectra::assign(const SDLType* t)
{
  const TYPE_ResponseSpectra *arg = SITE_DYNAMIC_CAST(const TYPE_ResponseSpectra*,t);
  if (!arg) SDLSequence::assign(t);
  else *this = *arg;
}

SDLType* TYPE_ResponseSpectra::create()
{
  static TYPE_ResponseSpectra* tmpl = new TYPE_ResponseSpectra;
  return tmpl;
}

const SDLType* TYPE_ResponseSpectra::create_new() const { return create(); }

TYPE_ResponseSpectra::TYPE_ResponseSpectra():SDLSequence(_fields,3){}
TYPE_ResponseSpectra::TYPE_ResponseSpectra(SDLType** f,unsigned long c):SDLSequence(f,c){}
TYPE_ResponseSpectra::TYPE_ResponseSpectra(const SDLNull&):SDLSequence(_fields,3)
{ set_state(invalidValue); }
TYPE_ResponseSpectra::TYPE_ResponseSpectra(const SDLAny& a, AsnCodingSet rule_set):SDLSequence(_fields,3){a.decode(this,rule_set);}
TYPE_ResponseSpectra::TYPE_ResponseSpectra(const TYPE_ResponseSpectra&o):SDLSequence(o){
  if (o.state(SITEtemporaryValue)) {
#ifdef SITE_LOG
    if (SDLType::_type_debug & SITE_COPY_LOG)
      CERR << "(SDLRTE) struct reference copy of " << o << ENDL;
#endif
    for(int i=0; i<3;++i) {
       _fields[i] = o._fields[i]; o._fields[i] = 0;
    }
  } else sequence_copyinit(_fields,o._fields,3);
}
TYPE_ResponseSpectra::~TYPE_ResponseSpectra(){clear_fields(_fields,3);}

TYPE_ResponseSpectra& TYPE_ResponseSpectra::operator=(const TYPE_ResponseSpectra& val){
  val.check_valid();
  if (this!=&val) sequence_assign(val);
  return *this;
}

unsigned int TYPE_ResponseSpectra::hash(unsigned int max_hash)const{
  return sequence_hash(_fields, 3, max_hash);
}

void TYPE_ResponseSpectra::get_fields(
  SDLSeqSetDescription*& d,SDLType **&field_list){
  d=&_fdesc; field_list=_fields;
}

void TYPE_ResponseSpectra::get_fields(
  SDLSeqSetDescription*& d,SDLType *const*&field_list) const{
  d=&_fdesc; field_list=_fields;
}


TYPE_SensorAcceleration& TYPE_ResponseSpectra::VAR_a_0_3sec() const
{ return *SITE_STATIC_CAST(TYPE_SensorAcceleration*,field_access(_fdesc,_fields,0)); }
static SDLSeqSetDescription::Field *_TYPE_ResponseSpectraa_0_3sec=TYPE_ResponseSpectra::_fdesc.add(0,"a_0_3sec",&TYPE_SensorAcceleration::create,true);

TYPE_SensorAcceleration& TYPE_ResponseSpectra::VAR_a_1sec() const
{ return *SITE_STATIC_CAST(TYPE_SensorAcceleration*,field_access(_fdesc,_fields,1)); }
static SDLSeqSetDescription::Field *_TYPE_ResponseSpectraa_1sec=TYPE_ResponseSpectra::_fdesc.add(1,"a_1sec",&TYPE_SensorAcceleration::create,true);

TYPE_SensorAcceleration& TYPE_ResponseSpectra::VAR_a_3sec() const
{ return *SITE_STATIC_CAST(TYPE_SensorAcceleration*,field_access(_fdesc,_fields,2)); }
static SDLSeqSetDescription::Field *_TYPE_ResponseSpectraa_3sec=TYPE_ResponseSpectra::_fdesc.add(2,"a_3sec",&TYPE_SensorAcceleration::create,true);



TYPE_ResponseSpectra::TYPE_ResponseSpectra(const class TYPE_SensorAcceleration& PAR_0, const class TYPE_SensorAcceleration& PAR_1, const class TYPE_SensorAcceleration& PAR_2) {
    set_field(0,PAR_0.copy());
    set_field(1,PAR_1.copy());
    set_field(2,PAR_2.copy());
}

AsnLen TYPE_ResponseSpectra::bEnc(BUF_TYPE b) const{
    AsnLen elmtLen = bEncContent(b);
    elmtLen += BEncDefLen(b,elmtLen);
    elmtLen += BEncTag1(b,UNIV,CONS,16);
    return elmtLen;
} // TYPE_ResponseSpectra::bEnc

AsnLen TYPE_ResponseSpectra::bEncContent(BUF_TYPE b) const {
    AsnLen elmtLen, structBytesEncoded = BEncExtraFields(b);
    elmtLen = VAR_a_3sec().bEncContent(b);
    elmtLen += BEncDefLen(b,elmtLen);
    elmtLen += BEncTag1(b,UNIV,CONS,16);
    structBytesEncoded += elmtLen;
    elmtLen = VAR_a_1sec().bEncContent(b);
    elmtLen += BEncDefLen(b,elmtLen);
    elmtLen += BEncTag1(b,UNIV,CONS,16);
    structBytesEncoded += elmtLen;
    elmtLen = VAR_a_0_3sec().bEncContent(b);
    elmtLen += BEncDefLen(b,elmtLen);
    elmtLen += BEncTag1(b,UNIV,CONS,16);
    structBytesEncoded += elmtLen;
    return structBytesEncoded;
} // TYPE_ResponseSpectra::bEncContent

void TYPE_ResponseSpectra::bDec(BUF_TYPE b,AsnLen& bytesDecoded) {
    AsnTag tagId = BDecTag1(b,bytesDecoded);
    AsnLen elmtLen;
    if (tagId != MAKE_TAG_ID(UNIV,CONS,16)) { TagError(MAKE_TAG_ID(UNIV,CONS,16),tagId); return; }
    elmtLen = BDecLen(b,bytesDecoded);
    int pending_eoc = 0;
    if (elmtLen == INDEFINITE_LEN) ++pending_eoc;
    AsnLen localBytesDecoded = 0;
    bDecContent(b,tagId,elmtLen,localBytesDecoded);
    for(;pending_eoc>0;--pending_eoc) { BDecEoc(b,localBytesDecoded); }
    bytesDecoded += localBytesDecoded;
} // TYPE_ResponseSpectra::bDec

void TYPE_ResponseSpectra::bDecContent(BUF_TYPE b,AsnTag,
        AsnLen len, AsnLen& bytesDecoded) {
    bool structDone = false;
    AsnLen elmtLen, localBytesDecoded = 0;
    AsnTag tagId;
    if (len == 0) { tagId = 0; structDone = true; }
    else tagId = BDecTag(b,localBytesDecoded);
    if (!structDone && (tagId==MAKE_TAG_ID(UNIV,CONS,16))) {
        elmtLen = BDecLen(b,localBytesDecoded);
        int pending_eoc = 0;
        if (elmtLen == INDEFINITE_LEN) ++pending_eoc;
        VAR_a_0_3sec().bDecContent(b,tagId,elmtLen,localBytesDecoded);
        for(;pending_eoc>0;--pending_eoc) { BDecEoc(b,localBytesDecoded); }
        if ((len!=INDEFINITE_LEN) && (localBytesDecoded>=len)) structDone = true;
        else tagId = BDecTag(b,localBytesDecoded);
    } else { TagError(MAKE_TAG_ID(UNIV,CONS,16),tagId); return; }
    if (!structDone && (tagId==MAKE_TAG_ID(UNIV,CONS,16))) {
        elmtLen = BDecLen(b,localBytesDecoded);
        int pending_eoc = 0;
        if (elmtLen == INDEFINITE_LEN) ++pending_eoc;
        VAR_a_1sec().bDecContent(b,tagId,elmtLen,localBytesDecoded);
        for(;pending_eoc>0;--pending_eoc) { BDecEoc(b,localBytesDecoded); }
        if ((len!=INDEFINITE_LEN) && (localBytesDecoded>=len)) structDone = true;
        else tagId = BDecTag(b,localBytesDecoded);
    } else { TagError(MAKE_TAG_ID(UNIV,CONS,16),tagId); return; }
    if (!structDone && (tagId==MAKE_TAG_ID(UNIV,CONS,16))) {
        elmtLen = BDecLen(b,localBytesDecoded);
        int pending_eoc = 0;
        if (elmtLen == INDEFINITE_LEN) ++pending_eoc;
        VAR_a_3sec().bDecContent(b,tagId,elmtLen,localBytesDecoded);
        for(;pending_eoc>0;--pending_eoc) { BDecEoc(b,localBytesDecoded); }
        if ((len!=INDEFINITE_LEN) && (localBytesDecoded>=len)) structDone = true;
        else tagId = BDecTag(b,localBytesDecoded);
    } else { TagError(MAKE_TAG_ID(UNIV,CONS,16),tagId); return; }
    complete_sequence_decoding(b, len, localBytesDecoded, tagId);
    bytesDecoded += localBytesDecoded;
    set_state(validValue);
} // TYPE_ResponseSpectra::bDecContent

AsnLen TYPE_ResponseSpectra::pEnc(BUF_TYPE2 b) const {
    int elmtLen=0;
    elmtLen += VAR_a_0_3sec().pEnc(b);
    elmtLen += VAR_a_1sec().pEnc(b);
    elmtLen += VAR_a_3sec().pEnc(b);
    return elmtLen;
}

void TYPE_ResponseSpectra::pDec(BUF_TYPE2 b) {
    VAR_a_0_3sec().pDec(b);
    VAR_a_1sec().pDec(b);
    VAR_a_3sec().pDec(b);
    set_state(validValue);
}

SDLSeqSetDescription TYPE_SN_LN_PositionChange::_fdesc(3);

SDLType* TYPE_SN_LN_PositionChange::copy()const { return new TYPE_SN_LN_PositionChange(*this); }

void TYPE_SN_LN_PositionChange::assign(const SDLType* t)
{
  const TYPE_SN_LN_PositionChange *arg = SITE_DYNAMIC_CAST(const TYPE_SN_LN_PositionChange*,t);
  if (!arg) SDLSequence::assign(t);
  else *this = *arg;
}

SDLType* TYPE_SN_LN_PositionChange::create()
{
  static TYPE_SN_LN_PositionChange* tmpl = new TYPE_SN_LN_PositionChange;
  return tmpl;
}

const SDLType* TYPE_SN_LN_PositionChange::create_new() const { return create(); }

TYPE_SN_LN_PositionChange::TYPE_SN_LN_PositionChange():SDLSequence(_fields,3){}
TYPE_SN_LN_PositionChange::TYPE_SN_LN_PositionChange(SDLType** f,unsigned long c):SDLSequence(f,c){}
TYPE_SN_LN_PositionChange::TYPE_SN_LN_PositionChange(const SDLNull&):SDLSequence(_fields,3)
{ set_state(invalidValue); }
TYPE_SN_LN_PositionChange::TYPE_SN_LN_PositionChange(const SDLAny& a, AsnCodingSet rule_set):SDLSequence(_fields,3){a.decode(this,rule_set);}
TYPE_SN_LN_PositionChange::TYPE_SN_LN_PositionChange(const TYPE_SN_LN_PositionChange&o):SDLSequence(o){
  if (o.state(SITEtemporaryValue)) {
#ifdef SITE_LOG
    if (SDLType::_type_debug & SITE_COPY_LOG)
      CERR << "(SDLRTE) struct reference copy of " << o << ENDL;
#endif
    for(int i=0; i<3;++i) {
       _fields[i] = o._fields[i]; o._fields[i] = 0;
    }
  } else sequence_copyinit(_fields,o._fields,3);
}
TYPE_SN_LN_PositionChange::~TYPE_SN_LN_PositionChange(){clear_fields(_fields,3);}

TYPE_SN_LN_PositionChange& TYPE_SN_LN_PositionChange::operator=(const TYPE_SN_LN_PositionChange& val){
  val.check_valid();
  if (this!=&val) sequence_assign(val);
  return *this;
}

unsigned int TYPE_SN_LN_PositionChange::hash(unsigned int max_hash)const{
  return sequence_hash(_fields, 3, max_hash);
}

void TYPE_SN_LN_PositionChange::get_fields(
  SDLSeqSetDescription*& d,SDLType **&field_list){
  d=&_fdesc; field_list=_fields;
}

void TYPE_SN_LN_PositionChange::get_fields(
  SDLSeqSetDescription*& d,SDLType *const*&field_list) const{
  d=&_fdesc; field_list=_fields;
}


TYPE_DateTime& TYPE_SN_LN_PositionChange::VAR_gpsTimeStamp() const
{ return *SITE_STATIC_CAST(TYPE_DateTime*,field_access(_fdesc,_fields,0)); }
static SDLSeqSetDescription::Field *_TYPE_SN_LN_PositionChangegpsTimeStamp=TYPE_SN_LN_PositionChange::_fdesc.add(0,"gpsTimeStamp",&TYPE_DateTime::create,true);

TYPE_GeographicCoordinate& TYPE_SN_LN_PositionChange::VAR_oldCoordinate() const
{ return *SITE_STATIC_CAST(TYPE_GeographicCoordinate*,field_access(_fdesc,_fields,1)); }
static SDLSeqSetDescription::Field *_TYPE_SN_LN_PositionChangeoldCoordinate=TYPE_SN_LN_PositionChange::_fdesc.add(1,"oldCoordinate",&TYPE_GeographicCoordinate::create,true);

TYPE_GeographicCoordinate& TYPE_SN_LN_PositionChange::VAR_newCoordinate() const
{ return *SITE_STATIC_CAST(TYPE_GeographicCoordinate*,field_access(_fdesc,_fields,2)); }
static SDLSeqSetDescription::Field *_TYPE_SN_LN_PositionChangenewCoordinate=TYPE_SN_LN_PositionChange::_fdesc.add(2,"newCoordinate",&TYPE_GeographicCoordinate::create,true);



TYPE_SN_LN_PositionChange::TYPE_SN_LN_PositionChange(const class TYPE_DateTime& PAR_0, const class TYPE_GeographicCoordinate& PAR_1, const class TYPE_GeographicCoordinate& PAR_2) {
    set_field(0,PAR_0.copy());
    set_field(1,PAR_1.copy());
    set_field(2,PAR_2.copy());
}

AsnLen TYPE_SN_LN_PositionChange::bEnc(BUF_TYPE b) const{
    AsnLen elmtLen = bEncContent(b);
    elmtLen += BEncDefLen(b,elmtLen);
    elmtLen += BEncTag1(b,UNIV,CONS,16);
    return elmtLen;
} // TYPE_SN_LN_PositionChange::bEnc

AsnLen TYPE_SN_LN_PositionChange::bEncContent(BUF_TYPE b) const {
    AsnLen elmtLen, structBytesEncoded = BEncExtraFields(b);
    elmtLen = VAR_newCoordinate().bEncContent(b);
    elmtLen += BEncDefLen(b,elmtLen);
    elmtLen += BEncTag1(b,UNIV,CONS,16);
    structBytesEncoded += elmtLen;
    elmtLen = VAR_oldCoordinate().bEncContent(b);
    elmtLen += BEncDefLen(b,elmtLen);
    elmtLen += BEncTag1(b,UNIV,CONS,16);
    structBytesEncoded += elmtLen;
    elmtLen = VAR_gpsTimeStamp().bEncContent(b);
    elmtLen += BEncDefLen(b,elmtLen);
    elmtLen += BEncTag1(b,UNIV,CONS,16);
    structBytesEncoded += elmtLen;
    return structBytesEncoded;
} // TYPE_SN_LN_PositionChange::bEncContent

void TYPE_SN_LN_PositionChange::bDec(BUF_TYPE b,AsnLen& bytesDecoded) {
    AsnTag tagId = BDecTag1(b,bytesDecoded);
    AsnLen elmtLen;
    if (tagId != MAKE_TAG_ID(UNIV,CONS,16)) { TagError(MAKE_TAG_ID(UNIV,CONS,16),tagId); return; }
    elmtLen = BDecLen(b,bytesDecoded);
    int pending_eoc = 0;
    if (elmtLen == INDEFINITE_LEN) ++pending_eoc;
    AsnLen localBytesDecoded = 0;
    bDecContent(b,tagId,elmtLen,localBytesDecoded);
    for(;pending_eoc>0;--pending_eoc) { BDecEoc(b,localBytesDecoded); }
    bytesDecoded += localBytesDecoded;
} // TYPE_SN_LN_PositionChange::bDec

void TYPE_SN_LN_PositionChange::bDecContent(BUF_TYPE b,AsnTag,
        AsnLen len, AsnLen& bytesDecoded) {
    bool structDone = false;
    AsnLen elmtLen, localBytesDecoded = 0;
    AsnTag tagId;
    if (len == 0) { tagId = 0; structDone = true; }
    else tagId = BDecTag(b,localBytesDecoded);
    if (!structDone && (tagId==MAKE_TAG_ID(UNIV,CONS,16))) {
        elmtLen = BDecLen(b,localBytesDecoded);
        int pending_eoc = 0;
        if (elmtLen == INDEFINITE_LEN) ++pending_eoc;
        VAR_gpsTimeStamp().bDecContent(b,tagId,elmtLen,localBytesDecoded);
        for(;pending_eoc>0;--pending_eoc) { BDecEoc(b,localBytesDecoded); }
        if ((len!=INDEFINITE_LEN) && (localBytesDecoded>=len)) structDone = true;
        else tagId = BDecTag(b,localBytesDecoded);
    } else { TagError(MAKE_TAG_ID(UNIV,CONS,16),tagId); return; }
    if (!structDone && (tagId==MAKE_TAG_ID(UNIV,CONS,16))) {
        elmtLen = BDecLen(b,localBytesDecoded);
        int pending_eoc = 0;
        if (elmtLen == INDEFINITE_LEN) ++pending_eoc;
        VAR_oldCoordinate().bDecContent(b,tagId,elmtLen,localBytesDecoded);
        for(;pending_eoc>0;--pending_eoc) { BDecEoc(b,localBytesDecoded); }
        if ((len!=INDEFINITE_LEN) && (localBytesDecoded>=len)) structDone = true;
        else tagId = BDecTag(b,localBytesDecoded);
    } else { TagError(MAKE_TAG_ID(UNIV,CONS,16),tagId); return; }
    if (!structDone && (tagId==MAKE_TAG_ID(UNIV,CONS,16))) {
        elmtLen = BDecLen(b,localBytesDecoded);
        int pending_eoc = 0;
        if (elmtLen == INDEFINITE_LEN) ++pending_eoc;
        VAR_newCoordinate().bDecContent(b,tagId,elmtLen,localBytesDecoded);
        for(;pending_eoc>0;--pending_eoc) { BDecEoc(b,localBytesDecoded); }
        if ((len!=INDEFINITE_LEN) && (localBytesDecoded>=len)) structDone = true;
        else tagId = BDecTag(b,localBytesDecoded);
    } else { TagError(MAKE_TAG_ID(UNIV,CONS,16),tagId); return; }
    complete_sequence_decoding(b, len, localBytesDecoded, tagId);
    bytesDecoded += localBytesDecoded;
    set_state(validValue);
} // TYPE_SN_LN_PositionChange::bDecContent

AsnLen TYPE_SN_LN_PositionChange::pEnc(BUF_TYPE2 b) const {
    int elmtLen=0;
    elmtLen += VAR_gpsTimeStamp().pEnc(b);
    elmtLen += VAR_oldCoordinate().pEnc(b);
    elmtLen += VAR_newCoordinate().pEnc(b);
    return elmtLen;
}

void TYPE_SN_LN_PositionChange::pDec(BUF_TYPE2 b) {
    VAR_gpsTimeStamp().pDec(b);
    VAR_oldCoordinate().pDec(b);
    VAR_newCoordinate().pDec(b);
    set_state(validValue);
}

SDLSeqSetDescription TYPE_StatusSNInfo::_fdesc(11);

SDLType* TYPE_StatusSNInfo::copy()const { return new TYPE_StatusSNInfo(*this); }

void TYPE_StatusSNInfo::assign(const SDLType* t)
{
  const TYPE_StatusSNInfo *arg = SITE_DYNAMIC_CAST(const TYPE_StatusSNInfo*,t);
  if (!arg) SDLSequence::assign(t);
  else *this = *arg;
}

SDLType* TYPE_StatusSNInfo::create()
{
  static TYPE_StatusSNInfo* tmpl = new TYPE_StatusSNInfo;
  return tmpl;
}

const SDLType* TYPE_StatusSNInfo::create_new() const { return create(); }

TYPE_StatusSNInfo::TYPE_StatusSNInfo():SDLSequence(_fields,11){}
TYPE_StatusSNInfo::TYPE_StatusSNInfo(SDLType** f,unsigned long c):SDLSequence(f,c){}
TYPE_StatusSNInfo::TYPE_StatusSNInfo(const SDLNull&):SDLSequence(_fields,11)
{ set_state(invalidValue); }
TYPE_StatusSNInfo::TYPE_StatusSNInfo(const SDLAny& a, AsnCodingSet rule_set):SDLSequence(_fields,11){a.decode(this,rule_set);}
TYPE_StatusSNInfo::TYPE_StatusSNInfo(const TYPE_StatusSNInfo&o):SDLSequence(o){
  if (o.state(SITEtemporaryValue)) {
#ifdef SITE_LOG
    if (SDLType::_type_debug & SITE_COPY_LOG)
      CERR << "(SDLRTE) struct reference copy of " << o << ENDL;
#endif
    for(int i=0; i<11;++i) {
       _fields[i] = o._fields[i]; o._fields[i] = 0;
    }
  } else sequence_copyinit(_fields,o._fields,11);
}
TYPE_StatusSNInfo::~TYPE_StatusSNInfo(){clear_fields(_fields,11);}

TYPE_StatusSNInfo& TYPE_StatusSNInfo::operator=(const TYPE_StatusSNInfo& val){
  val.check_valid();
  if (this!=&val) sequence_assign(val);
  return *this;
}

unsigned int TYPE_StatusSNInfo::hash(unsigned int max_hash)const{
  return sequence_hash(_fields, 11, max_hash);
}

void TYPE_StatusSNInfo::get_fields(
  SDLSeqSetDescription*& d,SDLType **&field_list){
  d=&_fdesc; field_list=_fields;
}

void TYPE_StatusSNInfo::get_fields(
  SDLSeqSetDescription*& d,SDLType *const*&field_list) const{
  d=&_fdesc; field_list=_fields;
}


TYPE_DateTime& TYPE_StatusSNInfo::VAR_gpsTimeStamp() const
{ return *SITE_STATIC_CAST(TYPE_DateTime*,field_access(_fdesc,_fields,0)); }
static SDLSeqSetDescription::Field *_TYPE_StatusSNInfogpsTimeStamp=TYPE_StatusSNInfo::_fdesc.add(0,"gpsTimeStamp",&TYPE_DateTime::create,true);

TYPE_IPAddress& TYPE_StatusSNInfo::VAR_sourceSN() const
{ return *SITE_STATIC_CAST(TYPE_IPAddress*,field_access(_fdesc,_fields,1)); }
static SDLSeqSetDescription::Field *_TYPE_StatusSNInfosourceSN=TYPE_StatusSNInfo::_fdesc.add(1,"sourceSN",&TYPE_IPAddress::create,true);

TYPE_SensorAcceleration& TYPE_StatusSNInfo::VAR_pga() const
{ return *SITE_STATIC_CAST(TYPE_SensorAcceleration*,field_access(_fdesc,_fields,2)); }
static SDLSeqSetDescription::Field *_TYPE_StatusSNInfopga=TYPE_StatusSNInfo::_fdesc.add(2,"pga",&TYPE_SensorAcceleration::create,true);

TYPE_SensorVelocity& TYPE_StatusSNInfo::VAR_pgv() const
{ return *SITE_STATIC_CAST(TYPE_SensorVelocity*,field_access(_fdesc,_fields,3)); }
static SDLSeqSetDescription::Field *_TYPE_StatusSNInfopgv=TYPE_StatusSNInfo::_fdesc.add(3,"pgv",&TYPE_SensorVelocity::create,true);

TYPE_SensorDisplacement& TYPE_StatusSNInfo::VAR_pgd() const
{ return *SITE_STATIC_CAST(TYPE_SensorDisplacement*,field_access(_fdesc,_fields,4)); }
static SDLSeqSetDescription::Field *_TYPE_StatusSNInfopgd=TYPE_StatusSNInfo::_fdesc.add(4,"pgd",&TYPE_SensorDisplacement::create,true);

SDLReal& TYPE_StatusSNInfo::VAR_predominantPeriod() const
{ return *SITE_STATIC_CAST(SDLReal*,field_access(_fdesc,_fields,5)); }
static SDLSeqSetDescription::Field *_TYPE_StatusSNInfopredominantPeriod=TYPE_StatusSNInfo::_fdesc.add(5,"predominantPeriod",&SDLReal::create,true);

SDLReal& TYPE_StatusSNInfo::VAR_cav() const
{ return *SITE_STATIC_CAST(SDLReal*,field_access(_fdesc,_fields,6)); }
static SDLSeqSetDescription::Field *_TYPE_StatusSNInfocav=TYPE_StatusSNInfo::_fdesc.add(6,"cav",&SDLReal::create,true);

SDLReal& TYPE_StatusSNInfo::VAR_instrumentalIntensity() const
{ return *SITE_STATIC_CAST(SDLReal*,field_access(_fdesc,_fields,7)); }

const SDLBool& TYPE_StatusSNInfo::instrumentalIntensityPresent()const{
  return field_present(_fdesc,_fields,7);
}

TYPE_StatusSNInfo TYPE_StatusSNInfo::instrumentalIntensityOmit()const{
  TYPE_StatusSNInfo c(*this);
  field_omit(_fdesc,c._fields,7);
  return c;
}

void TYPE_StatusSNInfo::_instrumentalIntensityOmit() {
  field_omit(_fdesc,_fields,7);
}

static SDLSeqSetDescription::Field *_TYPE_StatusSNInfoinstrumentalIntensity=TYPE_StatusSNInfo::_fdesc.add_optional(7,"instrumentalIntensity",&SDLReal::create,true);

SDLReal& TYPE_StatusSNInfo::VAR_ariasIntensity() const
{ return *SITE_STATIC_CAST(SDLReal*,field_access(_fdesc,_fields,8)); }

const SDLBool& TYPE_StatusSNInfo::ariasIntensityPresent()const{
  return field_present(_fdesc,_fields,8);
}

TYPE_StatusSNInfo TYPE_StatusSNInfo::ariasIntensityOmit()const{
  TYPE_StatusSNInfo c(*this);
  field_omit(_fdesc,c._fields,8);
  return c;
}

void TYPE_StatusSNInfo::_ariasIntensityOmit() {
  field_omit(_fdesc,_fields,8);
}

static SDLSeqSetDescription::Field *_TYPE_StatusSNInfoariasIntensity=TYPE_StatusSNInfo::_fdesc.add_optional(8,"ariasIntensity",&SDLReal::create,true);

SDLReal& TYPE_StatusSNInfo::VAR_valueFourthChannel() const
{ return *SITE_STATIC_CAST(SDLReal*,field_access(_fdesc,_fields,9)); }

const SDLBool& TYPE_StatusSNInfo::valueFourthChannelPresent()const{
  return field_present(_fdesc,_fields,9);
}

TYPE_StatusSNInfo TYPE_StatusSNInfo::valueFourthChannelOmit()const{
  TYPE_StatusSNInfo c(*this);
  field_omit(_fdesc,c._fields,9);
  return c;
}

void TYPE_StatusSNInfo::_valueFourthChannelOmit() {
  field_omit(_fdesc,_fields,9);
}

static SDLSeqSetDescription::Field *_TYPE_StatusSNInfovalueFourthChannel=TYPE_StatusSNInfo::_fdesc.add_optional(9,"valueFourthChannel",&SDLReal::create,true);

TYPE_ResponseSpectra& TYPE_StatusSNInfo::VAR_responseSpectra() const
{ return *SITE_STATIC_CAST(TYPE_ResponseSpectra*,field_access(_fdesc,_fields,10)); }

const SDLBool& TYPE_StatusSNInfo::responseSpectraPresent()const{
  return field_present(_fdesc,_fields,10);
}

TYPE_StatusSNInfo TYPE_StatusSNInfo::responseSpectraOmit()const{
  TYPE_StatusSNInfo c(*this);
  field_omit(_fdesc,c._fields,10);
  return c;
}

void TYPE_StatusSNInfo::_responseSpectraOmit() {
  field_omit(_fdesc,_fields,10);
}

static SDLSeqSetDescription::Field *_TYPE_StatusSNInforesponseSpectra=TYPE_StatusSNInfo::_fdesc.add_optional(10,"responseSpectra",&TYPE_ResponseSpectra::create,true);



TYPE_StatusSNInfo::TYPE_StatusSNInfo(const class TYPE_DateTime& PAR_0, const class TYPE_IPAddress& PAR_1, const class TYPE_SensorAcceleration& PAR_2, const class TYPE_SensorVelocity& PAR_3, const class TYPE_SensorDisplacement& PAR_4, const class SDLReal& PAR_5, const class SDLReal& PAR_6, const class SDLReal& PAR_7, const class SDLReal& PAR_8, const class SDLReal& PAR_9, const class TYPE_ResponseSpectra& PAR_10) {
    set_field(0,PAR_0.copy());
    set_field(1,PAR_1.copy());
    set_field(2,PAR_2.copy());
    set_field(3,PAR_3.copy());
    set_field(4,PAR_4.copy());
    set_field(5,PAR_5.copy());
    set_field(6,PAR_6.copy());
    if(PAR_7.valid())
        set_field(7,new SDLReal(PAR_7));
    else
        set_field(7,0);
    if(PAR_8.valid())
        set_field(8,new SDLReal(PAR_8));
    else
        set_field(8,0);
    if(PAR_9.valid())
        set_field(9,new SDLReal(PAR_9));
    else
        set_field(9,0);
    if(PAR_10.valid())
        set_field(10,new TYPE_ResponseSpectra(PAR_10));
    else
        set_field(10,0);
}

AsnLen TYPE_StatusSNInfo::bEnc(BUF_TYPE b) const{
    AsnLen elmtLen = bEncContent(b);
    elmtLen += BEncDefLen(b,elmtLen);
    elmtLen += BEncTag1(b,UNIV,CONS,16);
    return elmtLen;
} // TYPE_StatusSNInfo::bEnc

AsnLen TYPE_StatusSNInfo::bEncContent(BUF_TYPE b) const {
    AsnLen elmtLen, structBytesEncoded = BEncExtraFields(b);
    if (responseSpectraPresent().val()) {
        elmtLen = VAR_responseSpectra().bEncContent(b);
        elmtLen += BEncDefLen(b,elmtLen);
        elmtLen += BEncTag1(b,UNIV,CONS,16);
        elmtLen += BEncDefLen(b,elmtLen);
        elmtLen += BEncTag1(b,CNTX,CONS,4);
        structBytesEncoded += elmtLen;
    }
    if (valueFourthChannelPresent().val()) {
        elmtLen = VAR_valueFourthChannel().bEncContent(b);
        elmtLen += BEncDefLen(b,elmtLen);
        elmtLen += BEncTag1(b,UNIV,PRIM,9);
        elmtLen += BEncDefLen(b,elmtLen);
        elmtLen += BEncTag1(b,CNTX,CONS,3);
        structBytesEncoded += elmtLen;
    }
    if (ariasIntensityPresent().val()) {
        elmtLen = VAR_ariasIntensity().bEncContent(b);
        elmtLen += BEncDefLen(b,elmtLen);
        elmtLen += BEncTag1(b,UNIV,PRIM,9);
        elmtLen += BEncDefLen(b,elmtLen);
        elmtLen += BEncTag1(b,CNTX,CONS,2);
        structBytesEncoded += elmtLen;
    }
    if (instrumentalIntensityPresent().val()) {
        elmtLen = VAR_instrumentalIntensity().bEncContent(b);
        elmtLen += BEncDefLen(b,elmtLen);
        elmtLen += BEncTag1(b,UNIV,PRIM,9);
        elmtLen += BEncDefLen(b,elmtLen);
        elmtLen += BEncTag1(b,CNTX,CONS,1);
        structBytesEncoded += elmtLen;
    }
    elmtLen = VAR_cav().bEncContent(b);
    elmtLen += BEncDefLen(b,elmtLen);
    elmtLen += BEncTag1(b,UNIV,PRIM,9);
    structBytesEncoded += elmtLen;
    elmtLen = VAR_predominantPeriod().bEncContent(b);
    elmtLen += BEncDefLen(b,elmtLen);
    elmtLen += BEncTag1(b,UNIV,PRIM,9);
    structBytesEncoded += elmtLen;
    elmtLen = VAR_pgd().bEncContent(b);
    elmtLen += BEncDefLen(b,elmtLen);
    elmtLen += BEncTag1(b,UNIV,CONS,16);
    structBytesEncoded += elmtLen;
    elmtLen = VAR_pgv().bEncContent(b);
    elmtLen += BEncDefLen(b,elmtLen);
    elmtLen += BEncTag1(b,UNIV,CONS,16);
    structBytesEncoded += elmtLen;
    elmtLen = VAR_pga().bEncContent(b);
    elmtLen += BEncDefLen(b,elmtLen);
    elmtLen += BEncTag1(b,UNIV,CONS,16);
    structBytesEncoded += elmtLen;
    elmtLen = VAR_sourceSN().bEncContent(b);
    elmtLen += BEncDefLen(b,elmtLen);
    elmtLen += BEncTag1(b,UNIV,PRIM,22);
    structBytesEncoded += elmtLen;
    elmtLen = VAR_gpsTimeStamp().bEncContent(b);
    elmtLen += BEncDefLen(b,elmtLen);
    elmtLen += BEncTag1(b,UNIV,CONS,16);
    structBytesEncoded += elmtLen;
    return structBytesEncoded;
} // TYPE_StatusSNInfo::bEncContent

void TYPE_StatusSNInfo::bDec(BUF_TYPE b,AsnLen& bytesDecoded) {
    AsnTag tagId = BDecTag1(b,bytesDecoded);
    AsnLen elmtLen;
    if (tagId != MAKE_TAG_ID(UNIV,CONS,16)) { TagError(MAKE_TAG_ID(UNIV,CONS,16),tagId); return; }
    elmtLen = BDecLen(b,bytesDecoded);
    int pending_eoc = 0;
    if (elmtLen == INDEFINITE_LEN) ++pending_eoc;
    AsnLen localBytesDecoded = 0;
    bDecContent(b,tagId,elmtLen,localBytesDecoded);
    for(;pending_eoc>0;--pending_eoc) { BDecEoc(b,localBytesDecoded); }
    bytesDecoded += localBytesDecoded;
} // TYPE_StatusSNInfo::bDec

void TYPE_StatusSNInfo::bDecContent(BUF_TYPE b,AsnTag,
        AsnLen len, AsnLen& bytesDecoded) {
    bool structDone = false;
    AsnLen elmtLen, localBytesDecoded = 0;
    AsnTag tagId;
    if (len == 0) { tagId = 0; structDone = true; }
    else tagId = BDecTag(b,localBytesDecoded);
    if (!structDone && (tagId==MAKE_TAG_ID(UNIV,CONS,16))) {
        elmtLen = BDecLen(b,localBytesDecoded);
        int pending_eoc = 0;
        if (elmtLen == INDEFINITE_LEN) ++pending_eoc;
        VAR_gpsTimeStamp().bDecContent(b,tagId,elmtLen,localBytesDecoded);
        for(;pending_eoc>0;--pending_eoc) { BDecEoc(b,localBytesDecoded); }
        if ((len!=INDEFINITE_LEN) && (localBytesDecoded>=len)) structDone = true;
        else tagId = BDecTag(b,localBytesDecoded);
    } else { TagError(MAKE_TAG_ID(UNIV,CONS,16),tagId); return; }
    if (!structDone && (tagId==MAKE_TAG_ID(UNIV,PRIM,22) ||
                        tagId==MAKE_TAG_ID(UNIV,CONS,22))) {
        elmtLen = BDecLen(b,localBytesDecoded);
        VAR_sourceSN().bDecContent(b,tagId,elmtLen,localBytesDecoded);
        if ((len!=INDEFINITE_LEN) && (localBytesDecoded>=len)) structDone = true;
        else tagId = BDecTag(b,localBytesDecoded);
    } else { TagError(MAKE_TAG_ID(UNIV,PRIM,22),tagId); return; }
    if (!structDone && (tagId==MAKE_TAG_ID(UNIV,CONS,16))) {
        elmtLen = BDecLen(b,localBytesDecoded);
        int pending_eoc = 0;
        if (elmtLen == INDEFINITE_LEN) ++pending_eoc;
        VAR_pga().bDecContent(b,tagId,elmtLen,localBytesDecoded);
        for(;pending_eoc>0;--pending_eoc) { BDecEoc(b,localBytesDecoded); }
        if ((len!=INDEFINITE_LEN) && (localBytesDecoded>=len)) structDone = true;
        else tagId = BDecTag(b,localBytesDecoded);
    } else { TagError(MAKE_TAG_ID(UNIV,CONS,16),tagId); return; }
    if (!structDone && (tagId==MAKE_TAG_ID(UNIV,CONS,16))) {
        elmtLen = BDecLen(b,localBytesDecoded);
        int pending_eoc = 0;
        if (elmtLen == INDEFINITE_LEN) ++pending_eoc;
        VAR_pgv().bDecContent(b,tagId,elmtLen,localBytesDecoded);
        for(;pending_eoc>0;--pending_eoc) { BDecEoc(b,localBytesDecoded); }
        if ((len!=INDEFINITE_LEN) && (localBytesDecoded>=len)) structDone = true;
        else tagId = BDecTag(b,localBytesDecoded);
    } else { TagError(MAKE_TAG_ID(UNIV,CONS,16),tagId); return; }
    if (!structDone && (tagId==MAKE_TAG_ID(UNIV,CONS,16))) {
        elmtLen = BDecLen(b,localBytesDecoded);
        int pending_eoc = 0;
        if (elmtLen == INDEFINITE_LEN) ++pending_eoc;
        VAR_pgd().bDecContent(b,tagId,elmtLen,localBytesDecoded);
        for(;pending_eoc>0;--pending_eoc) { BDecEoc(b,localBytesDecoded); }
        if ((len!=INDEFINITE_LEN) && (localBytesDecoded>=len)) structDone = true;
        else tagId = BDecTag(b,localBytesDecoded);
    } else { TagError(MAKE_TAG_ID(UNIV,CONS,16),tagId); return; }
    if (!structDone && (tagId==MAKE_TAG_ID(UNIV,PRIM,9))) {
        elmtLen = BDecLen(b,localBytesDecoded);
        VAR_predominantPeriod().bDecContent(b,tagId,elmtLen,localBytesDecoded);
        if ((len!=INDEFINITE_LEN) && (localBytesDecoded>=len)) structDone = true;
        else tagId = BDecTag(b,localBytesDecoded);
    } else { TagError(MAKE_TAG_ID(UNIV,PRIM,9),tagId); return; }
    if (!structDone && (tagId==MAKE_TAG_ID(UNIV,PRIM,9))) {
        elmtLen = BDecLen(b,localBytesDecoded);
        VAR_cav().bDecContent(b,tagId,elmtLen,localBytesDecoded);
        if ((len!=INDEFINITE_LEN) && (localBytesDecoded>=len)) structDone = true;
        else tagId = BDecTag(b,localBytesDecoded);
    } else { TagError(MAKE_TAG_ID(UNIV,PRIM,9),tagId); return; }
    if (!structDone && (tagId==MAKE_TAG_ID(CNTX,CONS,1))) {
        elmtLen = BDecLen(b,localBytesDecoded);
        int pending_eoc = 0;
        if (elmtLen == INDEFINITE_LEN) ++pending_eoc;
        tagId = BDecTag1(b,localBytesDecoded);
        if (tagId == MAKE_TAG_ID(UNIV,PRIM,9)) {
          elmtLen = BDecLen(b,localBytesDecoded);
        } else { TagError(MAKE_TAG_ID(UNIV,PRIM,9),tagId); return; }
        VAR_instrumentalIntensity().bDecContent(b,tagId,elmtLen,localBytesDecoded);
        for(;pending_eoc>0;--pending_eoc) { BDecEoc(b,localBytesDecoded); }
        if (len!=INDEFINITE_LEN && localBytesDecoded>=len) structDone = true;
        else tagId = BDecTag(b,localBytesDecoded);
    }
    if (!structDone && (tagId==MAKE_TAG_ID(CNTX,CONS,2))) {
        elmtLen = BDecLen(b,localBytesDecoded);
        int pending_eoc = 0;
        if (elmtLen == INDEFINITE_LEN) ++pending_eoc;
        tagId = BDecTag1(b,localBytesDecoded);
        if (tagId == MAKE_TAG_ID(UNIV,PRIM,9)) {
          elmtLen = BDecLen(b,localBytesDecoded);
        } else { TagError(MAKE_TAG_ID(UNIV,PRIM,9),tagId); return; }
        VAR_ariasIntensity().bDecContent(b,tagId,elmtLen,localBytesDecoded);
        for(;pending_eoc>0;--pending_eoc) { BDecEoc(b,localBytesDecoded); }
        if (len!=INDEFINITE_LEN && localBytesDecoded>=len) structDone = true;
        else tagId = BDecTag(b,localBytesDecoded);
    }
    if (!structDone && (tagId==MAKE_TAG_ID(CNTX,CONS,3))) {
        elmtLen = BDecLen(b,localBytesDecoded);
        int pending_eoc = 0;
        if (elmtLen == INDEFINITE_LEN) ++pending_eoc;
        tagId = BDecTag1(b,localBytesDecoded);
        if (tagId == MAKE_TAG_ID(UNIV,PRIM,9)) {
          elmtLen = BDecLen(b,localBytesDecoded);
        } else { TagError(MAKE_TAG_ID(UNIV,PRIM,9),tagId); return; }
        VAR_valueFourthChannel().bDecContent(b,tagId,elmtLen,localBytesDecoded);
        for(;pending_eoc>0;--pending_eoc) { BDecEoc(b,localBytesDecoded); }
        if (len!=INDEFINITE_LEN && localBytesDecoded>=len) structDone = true;
        else tagId = BDecTag(b,localBytesDecoded);
    }
    if (!structDone && (tagId==MAKE_TAG_ID(CNTX,CONS,4))) {
        elmtLen = BDecLen(b,localBytesDecoded);
        int pending_eoc = 0;
        if (elmtLen == INDEFINITE_LEN) ++pending_eoc;
        tagId = BDecTag1(b,localBytesDecoded);
        if (tagId == MAKE_TAG_ID(UNIV,CONS,16)) {
          elmtLen = BDecLen(b,localBytesDecoded);
        } else { TagError(MAKE_TAG_ID(UNIV,CONS,16),tagId); return; }
        VAR_responseSpectra().bDecContent(b,tagId,elmtLen,localBytesDecoded);
        for(;pending_eoc>0;--pending_eoc) { BDecEoc(b,localBytesDecoded); }
        if (len!=INDEFINITE_LEN && localBytesDecoded>=len) structDone = true;
        else tagId = BDecTag(b,localBytesDecoded);
    }
    complete_sequence_decoding(b, len, localBytesDecoded, tagId);
    bytesDecoded += localBytesDecoded;
    set_state(validValue);
} // TYPE_StatusSNInfo::bDecContent

AsnLen TYPE_StatusSNInfo::pEnc(BUF_TYPE2 b) const {
    int elmtLen=0;
    b.putBit(instrumentalIntensityPresent().val()?true:false);
    elmtLen++;
    b.putBit(ariasIntensityPresent().val()?true:false);
    elmtLen++;
    b.putBit(valueFourthChannelPresent().val()?true:false);
    elmtLen++;
    b.putBit(responseSpectraPresent().val()?true:false);
    elmtLen++;
    elmtLen += VAR_gpsTimeStamp().pEnc(b);
    elmtLen += VAR_sourceSN().pEnc(b);
    elmtLen += VAR_pga().pEnc(b);
    elmtLen += VAR_pgv().pEnc(b);
    elmtLen += VAR_pgd().pEnc(b);
    elmtLen += VAR_predominantPeriod().pEnc(b);
    elmtLen += VAR_cav().pEnc(b);
    if (instrumentalIntensityPresent().val())
        elmtLen += VAR_instrumentalIntensity().pEnc(b);
    if (ariasIntensityPresent().val())
        elmtLen += VAR_ariasIntensity().pEnc(b);
    if (valueFourthChannelPresent().val())
        elmtLen += VAR_valueFourthChannel().pEnc(b);
    if (responseSpectraPresent().val())
        elmtLen += VAR_responseSpectra().pEnc(b);
    return elmtLen;
}

void TYPE_StatusSNInfo::pDec(BUF_TYPE2 b) {
    bool _field_present0 = b.getBit();
    bool _field_present1 = b.getBit();
    bool _field_present2 = b.getBit();
    bool _field_present3 = b.getBit();
    VAR_gpsTimeStamp().pDec(b);
    VAR_sourceSN().pDec(b);
    VAR_pga().pDec(b);
    VAR_pgv().pDec(b);
    VAR_pgd().pDec(b);
    VAR_predominantPeriod().pDec(b);
    VAR_cav().pDec(b);
    if(_field_present0) VAR_instrumentalIntensity().pDec(b);
    if(_field_present1) VAR_ariasIntensity().pDec(b);
    if(_field_present2) VAR_valueFourthChannel().pDec(b);
    if(_field_present3) VAR_responseSpectra().pDec(b);
    set_state(validValue);
}

SDLSeqSetDescription TYPE_LN_SN_Alarm::_fdesc(3);

SDLType* TYPE_LN_SN_Alarm::copy()const { return new TYPE_LN_SN_Alarm(*this); }

void TYPE_LN_SN_Alarm::assign(const SDLType* t)
{
  const TYPE_LN_SN_Alarm *arg = SITE_DYNAMIC_CAST(const TYPE_LN_SN_Alarm*,t);
  if (!arg) SDLSequence::assign(t);
  else *this = *arg;
}

SDLType* TYPE_LN_SN_Alarm::create()
{
  static TYPE_LN_SN_Alarm* tmpl = new TYPE_LN_SN_Alarm;
  return tmpl;
}

const SDLType* TYPE_LN_SN_Alarm::create_new() const { return create(); }

TYPE_LN_SN_Alarm::TYPE_LN_SN_Alarm():SDLSequence(_fields,3){}
TYPE_LN_SN_Alarm::TYPE_LN_SN_Alarm(SDLType** f,unsigned long c):SDLSequence(f,c){}
TYPE_LN_SN_Alarm::TYPE_LN_SN_Alarm(const SDLNull&):SDLSequence(_fields,3)
{ set_state(invalidValue); }
TYPE_LN_SN_Alarm::TYPE_LN_SN_Alarm(const SDLAny& a, AsnCodingSet rule_set):SDLSequence(_fields,3){a.decode(this,rule_set);}
TYPE_LN_SN_Alarm::TYPE_LN_SN_Alarm(const TYPE_LN_SN_Alarm&o):SDLSequence(o){
  if (o.state(SITEtemporaryValue)) {
#ifdef SITE_LOG
    if (SDLType::_type_debug & SITE_COPY_LOG)
      CERR << "(SDLRTE) struct reference copy of " << o << ENDL;
#endif
    for(int i=0; i<3;++i) {
       _fields[i] = o._fields[i]; o._fields[i] = 0;
    }
  } else sequence_copyinit(_fields,o._fields,3);
}
TYPE_LN_SN_Alarm::~TYPE_LN_SN_Alarm(){clear_fields(_fields,3);}

TYPE_LN_SN_Alarm& TYPE_LN_SN_Alarm::operator=(const TYPE_LN_SN_Alarm& val){
  val.check_valid();
  if (this!=&val) sequence_assign(val);
  return *this;
}

unsigned int TYPE_LN_SN_Alarm::hash(unsigned int max_hash)const{
  return sequence_hash(_fields, 3, max_hash);
}

void TYPE_LN_SN_Alarm::get_fields(
  SDLSeqSetDescription*& d,SDLType **&field_list){
  d=&_fdesc; field_list=_fields;
}

void TYPE_LN_SN_Alarm::get_fields(
  SDLSeqSetDescription*& d,SDLType *const*&field_list) const{
  d=&_fdesc; field_list=_fields;
}


TYPE_DateTime& TYPE_LN_SN_Alarm::VAR_gpsTimeStamp() const
{ return *SITE_STATIC_CAST(TYPE_DateTime*,field_access(_fdesc,_fields,0)); }
static SDLSeqSetDescription::Field *_TYPE_LN_SN_AlarmgpsTimeStamp=TYPE_LN_SN_Alarm::_fdesc.add(0,"gpsTimeStamp",&TYPE_DateTime::create,true);

TYPE_EventID& TYPE_LN_SN_Alarm::VAR_event() const
{ return *SITE_STATIC_CAST(TYPE_EventID*,field_access(_fdesc,_fields,1)); }
static SDLSeqSetDescription::Field *_TYPE_LN_SN_Alarmevent=TYPE_LN_SN_Alarm::_fdesc.add(1,"event",&TYPE_EventID::create,true);

TYPE_APEWProtocol_GEN_9& TYPE_LN_SN_Alarm::VAR_decisionMakingSNs() const
{ return *SITE_STATIC_CAST(TYPE_APEWProtocol_GEN_9*,field_access(_fdesc,_fields,2)); }
static SDLSeqSetDescription::Field *_TYPE_LN_SN_AlarmdecisionMakingSNs=TYPE_LN_SN_Alarm::_fdesc.add(2,"decisionMakingSNs",&TYPE_APEWProtocol_GEN_9::create,true);



TYPE_LN_SN_Alarm::TYPE_LN_SN_Alarm(const class TYPE_DateTime& PAR_0, const class TYPE_EventID& PAR_1, const class TYPE_APEWProtocol_GEN_9& PAR_2) {
    set_field(0,PAR_0.copy());
    set_field(1,PAR_1.copy());
    set_field(2,PAR_2.copy());
}

AsnLen TYPE_LN_SN_Alarm::bEnc(BUF_TYPE b) const{
    AsnLen elmtLen = bEncContent(b);
    elmtLen += BEncDefLen(b,elmtLen);
    elmtLen += BEncTag1(b,UNIV,CONS,16);
    return elmtLen;
} // TYPE_LN_SN_Alarm::bEnc

AsnLen TYPE_LN_SN_Alarm::bEncContent(BUF_TYPE b) const {
    AsnLen elmtLen, structBytesEncoded = BEncExtraFields(b);
    elmtLen = VAR_decisionMakingSNs().bEncContent(b);
    elmtLen += BEncDefLen(b,elmtLen);
    elmtLen += BEncTag1(b,UNIV,CONS,17);
    structBytesEncoded += elmtLen;
    elmtLen = VAR_event().bEncContent(b);
    elmtLen += BEncDefLen(b,elmtLen);
    elmtLen += BEncTag1(b,UNIV,PRIM,2);
    structBytesEncoded += elmtLen;
    elmtLen = VAR_gpsTimeStamp().bEncContent(b);
    elmtLen += BEncDefLen(b,elmtLen);
    elmtLen += BEncTag1(b,UNIV,CONS,16);
    structBytesEncoded += elmtLen;
    return structBytesEncoded;
} // TYPE_LN_SN_Alarm::bEncContent

void TYPE_LN_SN_Alarm::bDec(BUF_TYPE b,AsnLen& bytesDecoded) {
    AsnTag tagId = BDecTag1(b,bytesDecoded);
    AsnLen elmtLen;
    if (tagId != MAKE_TAG_ID(UNIV,CONS,16)) { TagError(MAKE_TAG_ID(UNIV,CONS,16),tagId); return; }
    elmtLen = BDecLen(b,bytesDecoded);
    int pending_eoc = 0;
    if (elmtLen == INDEFINITE_LEN) ++pending_eoc;
    AsnLen localBytesDecoded = 0;
    bDecContent(b,tagId,elmtLen,localBytesDecoded);
    for(;pending_eoc>0;--pending_eoc) { BDecEoc(b,localBytesDecoded); }
    bytesDecoded += localBytesDecoded;
} // TYPE_LN_SN_Alarm::bDec

void TYPE_LN_SN_Alarm::bDecContent(BUF_TYPE b,AsnTag,
        AsnLen len, AsnLen& bytesDecoded) {
    bool structDone = false;
    AsnLen elmtLen, localBytesDecoded = 0;
    AsnTag tagId;
    if (len == 0) { tagId = 0; structDone = true; }
    else tagId = BDecTag(b,localBytesDecoded);
    if (!structDone && (tagId==MAKE_TAG_ID(UNIV,CONS,16))) {
        elmtLen = BDecLen(b,localBytesDecoded);
        int pending_eoc = 0;
        if (elmtLen == INDEFINITE_LEN) ++pending_eoc;
        VAR_gpsTimeStamp().bDecContent(b,tagId,elmtLen,localBytesDecoded);
        for(;pending_eoc>0;--pending_eoc) { BDecEoc(b,localBytesDecoded); }
        if ((len!=INDEFINITE_LEN) && (localBytesDecoded>=len)) structDone = true;
        else tagId = BDecTag(b,localBytesDecoded);
    } else { TagError(MAKE_TAG_ID(UNIV,CONS,16),tagId); return; }
    if (!structDone && (tagId==MAKE_TAG_ID(UNIV,PRIM,2))) {
        elmtLen = BDecLen(b,localBytesDecoded);
        VAR_event().bDecContent(b,tagId,elmtLen,localBytesDecoded);
        if ((len!=INDEFINITE_LEN) && (localBytesDecoded>=len)) structDone = true;
        else tagId = BDecTag(b,localBytesDecoded);
    } else { TagError(MAKE_TAG_ID(UNIV,PRIM,2),tagId); return; }
    if (!structDone && (tagId==MAKE_TAG_ID(UNIV,CONS,17))) {
        elmtLen = BDecLen(b,localBytesDecoded);
        int pending_eoc = 0;
        if (elmtLen == INDEFINITE_LEN) ++pending_eoc;
        VAR_decisionMakingSNs().bDecContent(b,tagId,elmtLen,localBytesDecoded);
        for(;pending_eoc>0;--pending_eoc) { BDecEoc(b,localBytesDecoded); }
        if ((len!=INDEFINITE_LEN) && (localBytesDecoded>=len)) structDone = true;
        else tagId = BDecTag(b,localBytesDecoded);
    } else { TagError(MAKE_TAG_ID(UNIV,CONS,17),tagId); return; }
    complete_sequence_decoding(b, len, localBytesDecoded, tagId);
    bytesDecoded += localBytesDecoded;
    set_state(validValue);
} // TYPE_LN_SN_Alarm::bDecContent

AsnLen TYPE_LN_SN_Alarm::pEnc(BUF_TYPE2 b) const {
    int elmtLen=0;
    elmtLen += VAR_gpsTimeStamp().pEnc(b);
    elmtLen += VAR_event().pEnc(b);
    elmtLen += VAR_decisionMakingSNs().pEnc(b);
    return elmtLen;
}

void TYPE_LN_SN_Alarm::pDec(BUF_TYPE2 b) {
    VAR_gpsTimeStamp().pDec(b);
    VAR_event().pDec(b);
    VAR_decisionMakingSNs().pDec(b);
    set_state(validValue);
}

SDLSeqSetDescription TYPE_LN_SN_FalseAlarm::_fdesc(2);

SDLType* TYPE_LN_SN_FalseAlarm::copy()const { return new TYPE_LN_SN_FalseAlarm(*this); }

void TYPE_LN_SN_FalseAlarm::assign(const SDLType* t)
{
  const TYPE_LN_SN_FalseAlarm *arg = SITE_DYNAMIC_CAST(const TYPE_LN_SN_FalseAlarm*,t);
  if (!arg) SDLSequence::assign(t);
  else *this = *arg;
}

SDLType* TYPE_LN_SN_FalseAlarm::create()
{
  static TYPE_LN_SN_FalseAlarm* tmpl = new TYPE_LN_SN_FalseAlarm;
  return tmpl;
}

const SDLType* TYPE_LN_SN_FalseAlarm::create_new() const { return create(); }

TYPE_LN_SN_FalseAlarm::TYPE_LN_SN_FalseAlarm():SDLSequence(_fields,2){}
TYPE_LN_SN_FalseAlarm::TYPE_LN_SN_FalseAlarm(SDLType** f,unsigned long c):SDLSequence(f,c){}
TYPE_LN_SN_FalseAlarm::TYPE_LN_SN_FalseAlarm(const SDLNull&):SDLSequence(_fields,2)
{ set_state(invalidValue); }
TYPE_LN_SN_FalseAlarm::TYPE_LN_SN_FalseAlarm(const SDLAny& a, AsnCodingSet rule_set):SDLSequence(_fields,2){a.decode(this,rule_set);}
TYPE_LN_SN_FalseAlarm::TYPE_LN_SN_FalseAlarm(const TYPE_LN_SN_FalseAlarm&o):SDLSequence(o){
  if (o.state(SITEtemporaryValue)) {
#ifdef SITE_LOG
    if (SDLType::_type_debug & SITE_COPY_LOG)
      CERR << "(SDLRTE) struct reference copy of " << o << ENDL;
#endif
    for(int i=0; i<2;++i) {
       _fields[i] = o._fields[i]; o._fields[i] = 0;
    }
  } else sequence_copyinit(_fields,o._fields,2);
}
TYPE_LN_SN_FalseAlarm::~TYPE_LN_SN_FalseAlarm(){clear_fields(_fields,2);}

TYPE_LN_SN_FalseAlarm& TYPE_LN_SN_FalseAlarm::operator=(const TYPE_LN_SN_FalseAlarm& val){
  val.check_valid();
  if (this!=&val) sequence_assign(val);
  return *this;
}

unsigned int TYPE_LN_SN_FalseAlarm::hash(unsigned int max_hash)const{
  return sequence_hash(_fields, 2, max_hash);
}

void TYPE_LN_SN_FalseAlarm::get_fields(
  SDLSeqSetDescription*& d,SDLType **&field_list){
  d=&_fdesc; field_list=_fields;
}

void TYPE_LN_SN_FalseAlarm::get_fields(
  SDLSeqSetDescription*& d,SDLType *const*&field_list) const{
  d=&_fdesc; field_list=_fields;
}


TYPE_DateTime& TYPE_LN_SN_FalseAlarm::VAR_gpsTimeStamp() const
{ return *SITE_STATIC_CAST(TYPE_DateTime*,field_access(_fdesc,_fields,0)); }
static SDLSeqSetDescription::Field *_TYPE_LN_SN_FalseAlarmgpsTimeStamp=TYPE_LN_SN_FalseAlarm::_fdesc.add(0,"gpsTimeStamp",&TYPE_DateTime::create,true);

TYPE_DateTime& TYPE_LN_SN_FalseAlarm::VAR_timeOfFalseAlarm() const
{ return *SITE_STATIC_CAST(TYPE_DateTime*,field_access(_fdesc,_fields,1)); }
static SDLSeqSetDescription::Field *_TYPE_LN_SN_FalseAlarmtimeOfFalseAlarm=TYPE_LN_SN_FalseAlarm::_fdesc.add(1,"timeOfFalseAlarm",&TYPE_DateTime::create,true);



TYPE_LN_SN_FalseAlarm::TYPE_LN_SN_FalseAlarm(const class TYPE_DateTime& PAR_0, const class TYPE_DateTime& PAR_1) {
    set_field(0,PAR_0.copy());
    set_field(1,PAR_1.copy());
}

AsnLen TYPE_LN_SN_FalseAlarm::bEnc(BUF_TYPE b) const{
    AsnLen elmtLen = bEncContent(b);
    elmtLen += BEncDefLen(b,elmtLen);
    elmtLen += BEncTag1(b,UNIV,CONS,16);
    return elmtLen;
} // TYPE_LN_SN_FalseAlarm::bEnc

AsnLen TYPE_LN_SN_FalseAlarm::bEncContent(BUF_TYPE b) const {
    AsnLen elmtLen, structBytesEncoded = BEncExtraFields(b);
    elmtLen = VAR_timeOfFalseAlarm().bEncContent(b);
    elmtLen += BEncDefLen(b,elmtLen);
    elmtLen += BEncTag1(b,UNIV,CONS,16);
    structBytesEncoded += elmtLen;
    elmtLen = VAR_gpsTimeStamp().bEncContent(b);
    elmtLen += BEncDefLen(b,elmtLen);
    elmtLen += BEncTag1(b,UNIV,CONS,16);
    structBytesEncoded += elmtLen;
    return structBytesEncoded;
} // TYPE_LN_SN_FalseAlarm::bEncContent

void TYPE_LN_SN_FalseAlarm::bDec(BUF_TYPE b,AsnLen& bytesDecoded) {
    AsnTag tagId = BDecTag1(b,bytesDecoded);
    AsnLen elmtLen;
    if (tagId != MAKE_TAG_ID(UNIV,CONS,16)) { TagError(MAKE_TAG_ID(UNIV,CONS,16),tagId); return; }
    elmtLen = BDecLen(b,bytesDecoded);
    int pending_eoc = 0;
    if (elmtLen == INDEFINITE_LEN) ++pending_eoc;
    AsnLen localBytesDecoded = 0;
    bDecContent(b,tagId,elmtLen,localBytesDecoded);
    for(;pending_eoc>0;--pending_eoc) { BDecEoc(b,localBytesDecoded); }
    bytesDecoded += localBytesDecoded;
} // TYPE_LN_SN_FalseAlarm::bDec

void TYPE_LN_SN_FalseAlarm::bDecContent(BUF_TYPE b,AsnTag,
        AsnLen len, AsnLen& bytesDecoded) {
    bool structDone = false;
    AsnLen elmtLen, localBytesDecoded = 0;
    AsnTag tagId;
    if (len == 0) { tagId = 0; structDone = true; }
    else tagId = BDecTag(b,localBytesDecoded);
    if (!structDone && (tagId==MAKE_TAG_ID(UNIV,CONS,16))) {
        elmtLen = BDecLen(b,localBytesDecoded);
        int pending_eoc = 0;
        if (elmtLen == INDEFINITE_LEN) ++pending_eoc;
        VAR_gpsTimeStamp().bDecContent(b,tagId,elmtLen,localBytesDecoded);
        for(;pending_eoc>0;--pending_eoc) { BDecEoc(b,localBytesDecoded); }
        if ((len!=INDEFINITE_LEN) && (localBytesDecoded>=len)) structDone = true;
        else tagId = BDecTag(b,localBytesDecoded);
    } else { TagError(MAKE_TAG_ID(UNIV,CONS,16),tagId); return; }
    if (!structDone && (tagId==MAKE_TAG_ID(UNIV,CONS,16))) {
        elmtLen = BDecLen(b,localBytesDecoded);
        int pending_eoc = 0;
        if (elmtLen == INDEFINITE_LEN) ++pending_eoc;
        VAR_timeOfFalseAlarm().bDecContent(b,tagId,elmtLen,localBytesDecoded);
        for(;pending_eoc>0;--pending_eoc) { BDecEoc(b,localBytesDecoded); }
        if ((len!=INDEFINITE_LEN) && (localBytesDecoded>=len)) structDone = true;
        else tagId = BDecTag(b,localBytesDecoded);
    } else { TagError(MAKE_TAG_ID(UNIV,CONS,16),tagId); return; }
    complete_sequence_decoding(b, len, localBytesDecoded, tagId);
    bytesDecoded += localBytesDecoded;
    set_state(validValue);
} // TYPE_LN_SN_FalseAlarm::bDecContent

AsnLen TYPE_LN_SN_FalseAlarm::pEnc(BUF_TYPE2 b) const {
    int elmtLen=0;
    elmtLen += VAR_gpsTimeStamp().pEnc(b);
    elmtLen += VAR_timeOfFalseAlarm().pEnc(b);
    return elmtLen;
}

void TYPE_LN_SN_FalseAlarm::pDec(BUF_TYPE2 b) {
    VAR_gpsTimeStamp().pDec(b);
    VAR_timeOfFalseAlarm().pDec(b);
    set_state(validValue);
}

SDLSeqSetDescription TYPE_LN_SN_Describe::_fdesc(2);

SDLType* TYPE_LN_SN_Describe::copy()const { return new TYPE_LN_SN_Describe(*this); }

void TYPE_LN_SN_Describe::assign(const SDLType* t)
{
  const TYPE_LN_SN_Describe *arg = SITE_DYNAMIC_CAST(const TYPE_LN_SN_Describe*,t);
  if (!arg) SDLSequence::assign(t);
  else *this = *arg;
}

SDLType* TYPE_LN_SN_Describe::create()
{
  static TYPE_LN_SN_Describe* tmpl = new TYPE_LN_SN_Describe;
  return tmpl;
}

const SDLType* TYPE_LN_SN_Describe::create_new() const { return create(); }

TYPE_LN_SN_Describe::TYPE_LN_SN_Describe():SDLSequence(_fields,2){}
TYPE_LN_SN_Describe::TYPE_LN_SN_Describe(SDLType** f,unsigned long c):SDLSequence(f,c){}
TYPE_LN_SN_Describe::TYPE_LN_SN_Describe(const SDLNull&):SDLSequence(_fields,2)
{ set_state(invalidValue); }
TYPE_LN_SN_Describe::TYPE_LN_SN_Describe(const SDLAny& a, AsnCodingSet rule_set):SDLSequence(_fields,2){a.decode(this,rule_set);}
TYPE_LN_SN_Describe::TYPE_LN_SN_Describe(const TYPE_LN_SN_Describe&o):SDLSequence(o){
  if (o.state(SITEtemporaryValue)) {
#ifdef SITE_LOG
    if (SDLType::_type_debug & SITE_COPY_LOG)
      CERR << "(SDLRTE) struct reference copy of " << o << ENDL;
#endif
    for(int i=0; i<2;++i) {
       _fields[i] = o._fields[i]; o._fields[i] = 0;
    }
  } else sequence_copyinit(_fields,o._fields,2);
}
TYPE_LN_SN_Describe::~TYPE_LN_SN_Describe(){clear_fields(_fields,2);}

TYPE_LN_SN_Describe& TYPE_LN_SN_Describe::operator=(const TYPE_LN_SN_Describe& val){
  val.check_valid();
  if (this!=&val) sequence_assign(val);
  return *this;
}

unsigned int TYPE_LN_SN_Describe::hash(unsigned int max_hash)const{
  return sequence_hash(_fields, 2, max_hash);
}

void TYPE_LN_SN_Describe::get_fields(
  SDLSeqSetDescription*& d,SDLType **&field_list){
  d=&_fdesc; field_list=_fields;
}

void TYPE_LN_SN_Describe::get_fields(
  SDLSeqSetDescription*& d,SDLType *const*&field_list) const{
  d=&_fdesc; field_list=_fields;
}


TYPE_DateTime& TYPE_LN_SN_Describe::VAR_gpsTimeStamp() const
{ return *SITE_STATIC_CAST(TYPE_DateTime*,field_access(_fdesc,_fields,0)); }
static SDLSeqSetDescription::Field *_TYPE_LN_SN_DescribegpsTimeStamp=TYPE_LN_SN_Describe::_fdesc.add(0,"gpsTimeStamp",&TYPE_DateTime::create,true);

TYPE_EventID& TYPE_LN_SN_Describe::VAR_event() const
{ return *SITE_STATIC_CAST(TYPE_EventID*,field_access(_fdesc,_fields,1)); }

const SDLBool& TYPE_LN_SN_Describe::eventPresent()const{
  return field_present(_fdesc,_fields,1);
}

TYPE_LN_SN_Describe TYPE_LN_SN_Describe::eventOmit()const{
  TYPE_LN_SN_Describe c(*this);
  field_omit(_fdesc,c._fields,1);
  return c;
}

void TYPE_LN_SN_Describe::_eventOmit() {
  field_omit(_fdesc,_fields,1);
}

static SDLSeqSetDescription::Field *_TYPE_LN_SN_Describeevent=TYPE_LN_SN_Describe::_fdesc.add_optional(1,"event",&TYPE_EventID::create,true);



TYPE_LN_SN_Describe::TYPE_LN_SN_Describe(const class TYPE_DateTime& PAR_0, const class TYPE_EventID& PAR_1) {
    set_field(0,PAR_0.copy());
    if(PAR_1.valid())
        set_field(1,new TYPE_EventID(PAR_1));
    else
        set_field(1,0);
}

AsnLen TYPE_LN_SN_Describe::bEnc(BUF_TYPE b) const{
    AsnLen elmtLen = bEncContent(b);
    elmtLen += BEncDefLen(b,elmtLen);
    elmtLen += BEncTag1(b,UNIV,CONS,16);
    return elmtLen;
} // TYPE_LN_SN_Describe::bEnc

AsnLen TYPE_LN_SN_Describe::bEncContent(BUF_TYPE b) const {
    AsnLen elmtLen, structBytesEncoded = BEncExtraFields(b);
    if (eventPresent().val()) {
        elmtLen = VAR_event().bEncContent(b);
        elmtLen += BEncDefLen(b,elmtLen);
        elmtLen += BEncTag1(b,UNIV,PRIM,2);
        structBytesEncoded += elmtLen;
    }
    elmtLen = VAR_gpsTimeStamp().bEncContent(b);
    elmtLen += BEncDefLen(b,elmtLen);
    elmtLen += BEncTag1(b,UNIV,CONS,16);
    structBytesEncoded += elmtLen;
    return structBytesEncoded;
} // TYPE_LN_SN_Describe::bEncContent

void TYPE_LN_SN_Describe::bDec(BUF_TYPE b,AsnLen& bytesDecoded) {
    AsnTag tagId = BDecTag1(b,bytesDecoded);
    AsnLen elmtLen;
    if (tagId != MAKE_TAG_ID(UNIV,CONS,16)) { TagError(MAKE_TAG_ID(UNIV,CONS,16),tagId); return; }
    elmtLen = BDecLen(b,bytesDecoded);
    int pending_eoc = 0;
    if (elmtLen == INDEFINITE_LEN) ++pending_eoc;
    AsnLen localBytesDecoded = 0;
    bDecContent(b,tagId,elmtLen,localBytesDecoded);
    for(;pending_eoc>0;--pending_eoc) { BDecEoc(b,localBytesDecoded); }
    bytesDecoded += localBytesDecoded;
} // TYPE_LN_SN_Describe::bDec

void TYPE_LN_SN_Describe::bDecContent(BUF_TYPE b,AsnTag,
        AsnLen len, AsnLen& bytesDecoded) {
    bool structDone = false;
    AsnLen elmtLen, localBytesDecoded = 0;
    AsnTag tagId;
    if (len == 0) { tagId = 0; structDone = true; }
    else tagId = BDecTag(b,localBytesDecoded);
    if (!structDone && (tagId==MAKE_TAG_ID(UNIV,CONS,16))) {
        elmtLen = BDecLen(b,localBytesDecoded);
        int pending_eoc = 0;
        if (elmtLen == INDEFINITE_LEN) ++pending_eoc;
        VAR_gpsTimeStamp().bDecContent(b,tagId,elmtLen,localBytesDecoded);
        for(;pending_eoc>0;--pending_eoc) { BDecEoc(b,localBytesDecoded); }
        if ((len!=INDEFINITE_LEN) && (localBytesDecoded>=len)) structDone = true;
        else tagId = BDecTag(b,localBytesDecoded);
    } else { TagError(MAKE_TAG_ID(UNIV,CONS,16),tagId); return; }
    if (!structDone && (tagId==MAKE_TAG_ID(UNIV,PRIM,2))) {
        elmtLen = BDecLen(b,localBytesDecoded);
        VAR_event().bDecContent(b,tagId,elmtLen,localBytesDecoded);
        if (len!=INDEFINITE_LEN && localBytesDecoded>=len) structDone = true;
        else tagId = BDecTag(b,localBytesDecoded);
    }
    complete_sequence_decoding(b, len, localBytesDecoded, tagId);
    bytesDecoded += localBytesDecoded;
    set_state(validValue);
} // TYPE_LN_SN_Describe::bDecContent

AsnLen TYPE_LN_SN_Describe::pEnc(BUF_TYPE2 b) const {
    int elmtLen=0;
    b.putBit(eventPresent().val()?true:false);
    elmtLen++;
    elmtLen += VAR_gpsTimeStamp().pEnc(b);
    if (eventPresent().val())
        elmtLen += VAR_event().pEnc(b);
    return elmtLen;
}

void TYPE_LN_SN_Describe::pDec(BUF_TYPE2 b) {
    bool _field_present0 = b.getBit();
    VAR_gpsTimeStamp().pDec(b);
    if(_field_present0) VAR_event().pDec(b);
    set_state(validValue);
}

SDLSeqSetDescription TYPE_LN_SN_Summarise::_fdesc(2);

SDLType* TYPE_LN_SN_Summarise::copy()const { return new TYPE_LN_SN_Summarise(*this); }

void TYPE_LN_SN_Summarise::assign(const SDLType* t)
{
  const TYPE_LN_SN_Summarise *arg = SITE_DYNAMIC_CAST(const TYPE_LN_SN_Summarise*,t);
  if (!arg) SDLSequence::assign(t);
  else *this = *arg;
}

SDLType* TYPE_LN_SN_Summarise::create()
{
  static TYPE_LN_SN_Summarise* tmpl = new TYPE_LN_SN_Summarise;
  return tmpl;
}

const SDLType* TYPE_LN_SN_Summarise::create_new() const { return create(); }

TYPE_LN_SN_Summarise::TYPE_LN_SN_Summarise():SDLSequence(_fields,2){}
TYPE_LN_SN_Summarise::TYPE_LN_SN_Summarise(SDLType** f,unsigned long c):SDLSequence(f,c){}
TYPE_LN_SN_Summarise::TYPE_LN_SN_Summarise(const SDLNull&):SDLSequence(_fields,2)
{ set_state(invalidValue); }
TYPE_LN_SN_Summarise::TYPE_LN_SN_Summarise(const SDLAny& a, AsnCodingSet rule_set):SDLSequence(_fields,2){a.decode(this,rule_set);}
TYPE_LN_SN_Summarise::TYPE_LN_SN_Summarise(const TYPE_LN_SN_Summarise&o):SDLSequence(o){
  if (o.state(SITEtemporaryValue)) {
#ifdef SITE_LOG
    if (SDLType::_type_debug & SITE_COPY_LOG)
      CERR << "(SDLRTE) struct reference copy of " << o << ENDL;
#endif
    for(int i=0; i<2;++i) {
       _fields[i] = o._fields[i]; o._fields[i] = 0;
    }
  } else sequence_copyinit(_fields,o._fields,2);
}
TYPE_LN_SN_Summarise::~TYPE_LN_SN_Summarise(){clear_fields(_fields,2);}

TYPE_LN_SN_Summarise& TYPE_LN_SN_Summarise::operator=(const TYPE_LN_SN_Summarise& val){
  val.check_valid();
  if (this!=&val) sequence_assign(val);
  return *this;
}

unsigned int TYPE_LN_SN_Summarise::hash(unsigned int max_hash)const{
  return sequence_hash(_fields, 2, max_hash);
}

void TYPE_LN_SN_Summarise::get_fields(
  SDLSeqSetDescription*& d,SDLType **&field_list){
  d=&_fdesc; field_list=_fields;
}

void TYPE_LN_SN_Summarise::get_fields(
  SDLSeqSetDescription*& d,SDLType *const*&field_list) const{
  d=&_fdesc; field_list=_fields;
}


TYPE_DateTime& TYPE_LN_SN_Summarise::VAR_gpsTimeStamp() const
{ return *SITE_STATIC_CAST(TYPE_DateTime*,field_access(_fdesc,_fields,0)); }
static SDLSeqSetDescription::Field *_TYPE_LN_SN_SummarisegpsTimeStamp=TYPE_LN_SN_Summarise::_fdesc.add(0,"gpsTimeStamp",&TYPE_DateTime::create,true);

TYPE_EventID& TYPE_LN_SN_Summarise::VAR_event() const
{ return *SITE_STATIC_CAST(TYPE_EventID*,field_access(_fdesc,_fields,1)); }

const SDLBool& TYPE_LN_SN_Summarise::eventPresent()const{
  return field_present(_fdesc,_fields,1);
}

TYPE_LN_SN_Summarise TYPE_LN_SN_Summarise::eventOmit()const{
  TYPE_LN_SN_Summarise c(*this);
  field_omit(_fdesc,c._fields,1);
  return c;
}

void TYPE_LN_SN_Summarise::_eventOmit() {
  field_omit(_fdesc,_fields,1);
}

static SDLSeqSetDescription::Field *_TYPE_LN_SN_Summariseevent=TYPE_LN_SN_Summarise::_fdesc.add_optional(1,"event",&TYPE_EventID::create,true);



TYPE_LN_SN_Summarise::TYPE_LN_SN_Summarise(const class TYPE_DateTime& PAR_0, const class TYPE_EventID& PAR_1) {
    set_field(0,PAR_0.copy());
    if(PAR_1.valid())
        set_field(1,new TYPE_EventID(PAR_1));
    else
        set_field(1,0);
}

AsnLen TYPE_LN_SN_Summarise::bEnc(BUF_TYPE b) const{
    AsnLen elmtLen = bEncContent(b);
    elmtLen += BEncDefLen(b,elmtLen);
    elmtLen += BEncTag1(b,UNIV,CONS,16);
    return elmtLen;
} // TYPE_LN_SN_Summarise::bEnc

AsnLen TYPE_LN_SN_Summarise::bEncContent(BUF_TYPE b) const {
    AsnLen elmtLen, structBytesEncoded = BEncExtraFields(b);
    if (eventPresent().val()) {
        elmtLen = VAR_event().bEncContent(b);
        elmtLen += BEncDefLen(b,elmtLen);
        elmtLen += BEncTag1(b,UNIV,PRIM,2);
        structBytesEncoded += elmtLen;
    }
    elmtLen = VAR_gpsTimeStamp().bEncContent(b);
    elmtLen += BEncDefLen(b,elmtLen);
    elmtLen += BEncTag1(b,UNIV,CONS,16);
    structBytesEncoded += elmtLen;
    return structBytesEncoded;
} // TYPE_LN_SN_Summarise::bEncContent

void TYPE_LN_SN_Summarise::bDec(BUF_TYPE b,AsnLen& bytesDecoded) {
    AsnTag tagId = BDecTag1(b,bytesDecoded);
    AsnLen elmtLen;
    if (tagId != MAKE_TAG_ID(UNIV,CONS,16)) { TagError(MAKE_TAG_ID(UNIV,CONS,16),tagId); return; }
    elmtLen = BDecLen(b,bytesDecoded);
    int pending_eoc = 0;
    if (elmtLen == INDEFINITE_LEN) ++pending_eoc;
    AsnLen localBytesDecoded = 0;
    bDecContent(b,tagId,elmtLen,localBytesDecoded);
    for(;pending_eoc>0;--pending_eoc) { BDecEoc(b,localBytesDecoded); }
    bytesDecoded += localBytesDecoded;
} // TYPE_LN_SN_Summarise::bDec

void TYPE_LN_SN_Summarise::bDecContent(BUF_TYPE b,AsnTag,
        AsnLen len, AsnLen& bytesDecoded) {
    bool structDone = false;
    AsnLen elmtLen, localBytesDecoded = 0;
    AsnTag tagId;
    if (len == 0) { tagId = 0; structDone = true; }
    else tagId = BDecTag(b,localBytesDecoded);
    if (!structDone && (tagId==MAKE_TAG_ID(UNIV,CONS,16))) {
        elmtLen = BDecLen(b,localBytesDecoded);
        int pending_eoc = 0;
        if (elmtLen == INDEFINITE_LEN) ++pending_eoc;
        VAR_gpsTimeStamp().bDecContent(b,tagId,elmtLen,localBytesDecoded);
        for(;pending_eoc>0;--pending_eoc) { BDecEoc(b,localBytesDecoded); }
        if ((len!=INDEFINITE_LEN) && (localBytesDecoded>=len)) structDone = true;
        else tagId = BDecTag(b,localBytesDecoded);
    } else { TagError(MAKE_TAG_ID(UNIV,CONS,16),tagId); return; }
    if (!structDone && (tagId==MAKE_TAG_ID(UNIV,PRIM,2))) {
        elmtLen = BDecLen(b,localBytesDecoded);
        VAR_event().bDecContent(b,tagId,elmtLen,localBytesDecoded);
        if (len!=INDEFINITE_LEN && localBytesDecoded>=len) structDone = true;
        else tagId = BDecTag(b,localBytesDecoded);
    }
    complete_sequence_decoding(b, len, localBytesDecoded, tagId);
    bytesDecoded += localBytesDecoded;
    set_state(validValue);
} // TYPE_LN_SN_Summarise::bDecContent

AsnLen TYPE_LN_SN_Summarise::pEnc(BUF_TYPE2 b) const {
    int elmtLen=0;
    b.putBit(eventPresent().val()?true:false);
    elmtLen++;
    elmtLen += VAR_gpsTimeStamp().pEnc(b);
    if (eventPresent().val())
        elmtLen += VAR_event().pEnc(b);
    return elmtLen;
}

void TYPE_LN_SN_Summarise::pDec(BUF_TYPE2 b) {
    bool _field_present0 = b.getBit();
    VAR_gpsTimeStamp().pDec(b);
    if(_field_present0) VAR_event().pDec(b);
    set_state(validValue);
}

TYPE_BreakdownReason::TYPE_BreakdownReason(const SDLAny& a, AsnCodingSet rule_set){                                      a.decode(this,rule_set); }

SDLType* TYPE_BreakdownReason::copy()const { return new TYPE_BreakdownReason(*this); }

void TYPE_BreakdownReason::assign(const SDLType* t)
{
  const TYPE_BreakdownReason *arg = SITE_DYNAMIC_CAST(const TYPE_BreakdownReason*,t);
  if (!arg) SDLEnum::assign(t);
  else *this = *arg;
}

SDLType* TYPE_BreakdownReason::create()
{
  static TYPE_BreakdownReason* tmpl = new TYPE_BreakdownReason;
  return tmpl;
}

const SDLType* TYPE_BreakdownReason::create_new() const { return create(); }

const TYPE_BreakdownReason& TYPE_BreakdownReason::LIT_linkDown() {
    static TYPE_BreakdownReason v(1);
    return v;
}

const TYPE_BreakdownReason& TYPE_BreakdownReason::LIT_batteryLow() {
    static TYPE_BreakdownReason v(2);
    return v;
}

AsnLen TYPE_BreakdownReason::pEnc(BUF_TYPE2 b) const {
    SITE_SDL_UINT off;
    switch(_value){
        case 1: off = 0; break;
        case 2: off = 1; break;
        default: raise(new SDLCodingError("Encoding of ASN enum: value invalid"));}
    return pEncSmallNumber(b, off);
}

void TYPE_BreakdownReason::pDec(BUF_TYPE2 b) {
    SITE_SDL_UINT off=pDecSmallNumber(b);
    switch(off){
        case 0: _value = 1; break;
        case 1: _value = 2; break;
        default: raise(new SDLCodingError("Decoding of ASN enum: value invalid"));}
    set_state(validValue);
}

bool TYPE_BreakdownReason::datainfo(long index,SDLIA5String& var_name,
          const SDLType*& var)const
{
    switch(index) {
        case 1: var_name="linkDown";var=&LIT_linkDown();break;
        case 2: var_name="batteryLow";var=&LIT_batteryLow();break;
        default: return SDLEnum::datainfo(index,var_name,var);
    }
    return true;
} /* TYPE_BreakdownReason::datainfo */

int TYPE_BreakdownReason::nr_literals() const { return SDLEnum::nr_literals()+2; }

bool TYPE_BreakdownReason::get_literal(int index,const SDLEnum** literal,long* enum_val)const
{
    switch(index) {
        case 1: *literal=&LIT_linkDown();*enum_val=LIT_linkDown().val();break;
        case 2: *literal=&LIT_batteryLow();*enum_val=LIT_batteryLow().val();break;
        default: return SDLEnum::get_literal(index,literal,enum_val);
    }
    return true;
} /* TYPE_BreakdownReason::get_literal */

SDLSeqSetDescription TYPE_InoperativeSNInfo::_fdesc(3);

SDLType* TYPE_InoperativeSNInfo::copy()const { return new TYPE_InoperativeSNInfo(*this); }

void TYPE_InoperativeSNInfo::assign(const SDLType* t)
{
  const TYPE_InoperativeSNInfo *arg = SITE_DYNAMIC_CAST(const TYPE_InoperativeSNInfo*,t);
  if (!arg) SDLSequence::assign(t);
  else *this = *arg;
}

SDLType* TYPE_InoperativeSNInfo::create()
{
  static TYPE_InoperativeSNInfo* tmpl = new TYPE_InoperativeSNInfo;
  return tmpl;
}

const SDLType* TYPE_InoperativeSNInfo::create_new() const { return create(); }

TYPE_InoperativeSNInfo::TYPE_InoperativeSNInfo():SDLSequence(_fields,3){}
TYPE_InoperativeSNInfo::TYPE_InoperativeSNInfo(SDLType** f,unsigned long c):SDLSequence(f,c){}
TYPE_InoperativeSNInfo::TYPE_InoperativeSNInfo(const SDLNull&):SDLSequence(_fields,3)
{ set_state(invalidValue); }
TYPE_InoperativeSNInfo::TYPE_InoperativeSNInfo(const SDLAny& a, AsnCodingSet rule_set):SDLSequence(_fields,3){a.decode(this,rule_set);}
TYPE_InoperativeSNInfo::TYPE_InoperativeSNInfo(const TYPE_InoperativeSNInfo&o):SDLSequence(o){
  if (o.state(SITEtemporaryValue)) {
#ifdef SITE_LOG
    if (SDLType::_type_debug & SITE_COPY_LOG)
      CERR << "(SDLRTE) struct reference copy of " << o << ENDL;
#endif
    for(int i=0; i<3;++i) {
       _fields[i] = o._fields[i]; o._fields[i] = 0;
    }
  } else sequence_copyinit(_fields,o._fields,3);
}
TYPE_InoperativeSNInfo::~TYPE_InoperativeSNInfo(){clear_fields(_fields,3);}

TYPE_InoperativeSNInfo& TYPE_InoperativeSNInfo::operator=(const TYPE_InoperativeSNInfo& val){
  val.check_valid();
  if (this!=&val) sequence_assign(val);
  return *this;
}

unsigned int TYPE_InoperativeSNInfo::hash(unsigned int max_hash)const{
  return sequence_hash(_fields, 3, max_hash);
}

void TYPE_InoperativeSNInfo::get_fields(
  SDLSeqSetDescription*& d,SDLType **&field_list){
  d=&_fdesc; field_list=_fields;
}

void TYPE_InoperativeSNInfo::get_fields(
  SDLSeqSetDescription*& d,SDLType *const*&field_list) const{
  d=&_fdesc; field_list=_fields;
}


TYPE_DateTime& TYPE_InoperativeSNInfo::VAR_lastOperativeAt() const
{ return *SITE_STATIC_CAST(TYPE_DateTime*,field_access(_fdesc,_fields,0)); }
static SDLSeqSetDescription::Field *_TYPE_InoperativeSNInfolastOperativeAt=TYPE_InoperativeSNInfo::_fdesc.add(0,"lastOperativeAt",&TYPE_DateTime::create,true);

TYPE_IPAddress& TYPE_InoperativeSNInfo::VAR_sourceSN() const
{ return *SITE_STATIC_CAST(TYPE_IPAddress*,field_access(_fdesc,_fields,1)); }
static SDLSeqSetDescription::Field *_TYPE_InoperativeSNInfosourceSN=TYPE_InoperativeSNInfo::_fdesc.add(1,"sourceSN",&TYPE_IPAddress::create,true);

TYPE_BreakdownReason& TYPE_InoperativeSNInfo::VAR_reason() const
{ return *SITE_STATIC_CAST(TYPE_BreakdownReason*,field_access(_fdesc,_fields,2)); }

const SDLBool& TYPE_InoperativeSNInfo::reasonPresent()const{
  return field_present(_fdesc,_fields,2);
}

TYPE_InoperativeSNInfo TYPE_InoperativeSNInfo::reasonOmit()const{
  TYPE_InoperativeSNInfo c(*this);
  field_omit(_fdesc,c._fields,2);
  return c;
}

void TYPE_InoperativeSNInfo::_reasonOmit() {
  field_omit(_fdesc,_fields,2);
}

static SDLSeqSetDescription::Field *_TYPE_InoperativeSNInforeason=TYPE_InoperativeSNInfo::_fdesc.add_optional(2,"reason",&TYPE_BreakdownReason::create,true);



TYPE_InoperativeSNInfo::TYPE_InoperativeSNInfo(const class TYPE_DateTime& PAR_0, const class TYPE_IPAddress& PAR_1, const class TYPE_BreakdownReason& PAR_2) {
    set_field(0,PAR_0.copy());
    set_field(1,PAR_1.copy());
    if(PAR_2.valid())
        set_field(2,new TYPE_BreakdownReason(PAR_2));
    else
        set_field(2,0);
}

AsnLen TYPE_InoperativeSNInfo::bEnc(BUF_TYPE b) const{
    AsnLen elmtLen = bEncContent(b);
    elmtLen += BEncDefLen(b,elmtLen);
    elmtLen += BEncTag1(b,UNIV,CONS,16);
    return elmtLen;
} // TYPE_InoperativeSNInfo::bEnc

AsnLen TYPE_InoperativeSNInfo::bEncContent(BUF_TYPE b) const {
    AsnLen elmtLen, structBytesEncoded = BEncExtraFields(b);
    if (reasonPresent().val()) {
        elmtLen = VAR_reason().bEncContent(b);
        elmtLen += BEncDefLen(b,elmtLen);
        elmtLen += BEncTag1(b,UNIV,PRIM,10);
        structBytesEncoded += elmtLen;
    }
    elmtLen = VAR_sourceSN().bEncContent(b);
    elmtLen += BEncDefLen(b,elmtLen);
    elmtLen += BEncTag1(b,UNIV,PRIM,22);
    structBytesEncoded += elmtLen;
    elmtLen = VAR_lastOperativeAt().bEncContent(b);
    elmtLen += BEncDefLen(b,elmtLen);
    elmtLen += BEncTag1(b,UNIV,CONS,16);
    structBytesEncoded += elmtLen;
    return structBytesEncoded;
} // TYPE_InoperativeSNInfo::bEncContent

void TYPE_InoperativeSNInfo::bDec(BUF_TYPE b,AsnLen& bytesDecoded) {
    AsnTag tagId = BDecTag1(b,bytesDecoded);
    AsnLen elmtLen;
    if (tagId != MAKE_TAG_ID(UNIV,CONS,16)) { TagError(MAKE_TAG_ID(UNIV,CONS,16),tagId); return; }
    elmtLen = BDecLen(b,bytesDecoded);
    int pending_eoc = 0;
    if (elmtLen == INDEFINITE_LEN) ++pending_eoc;
    AsnLen localBytesDecoded = 0;
    bDecContent(b,tagId,elmtLen,localBytesDecoded);
    for(;pending_eoc>0;--pending_eoc) { BDecEoc(b,localBytesDecoded); }
    bytesDecoded += localBytesDecoded;
} // TYPE_InoperativeSNInfo::bDec

void TYPE_InoperativeSNInfo::bDecContent(BUF_TYPE b,AsnTag,
        AsnLen len, AsnLen& bytesDecoded) {
    bool structDone = false;
    AsnLen elmtLen, localBytesDecoded = 0;
    AsnTag tagId;
    if (len == 0) { tagId = 0; structDone = true; }
    else tagId = BDecTag(b,localBytesDecoded);
    if (!structDone && (tagId==MAKE_TAG_ID(UNIV,CONS,16))) {
        elmtLen = BDecLen(b,localBytesDecoded);
        int pending_eoc = 0;
        if (elmtLen == INDEFINITE_LEN) ++pending_eoc;
        VAR_lastOperativeAt().bDecContent(b,tagId,elmtLen,localBytesDecoded);
        for(;pending_eoc>0;--pending_eoc) { BDecEoc(b,localBytesDecoded); }
        if ((len!=INDEFINITE_LEN) && (localBytesDecoded>=len)) structDone = true;
        else tagId = BDecTag(b,localBytesDecoded);
    } else { TagError(MAKE_TAG_ID(UNIV,CONS,16),tagId); return; }
    if (!structDone && (tagId==MAKE_TAG_ID(UNIV,PRIM,22) ||
                        tagId==MAKE_TAG_ID(UNIV,CONS,22))) {
        elmtLen = BDecLen(b,localBytesDecoded);
        VAR_sourceSN().bDecContent(b,tagId,elmtLen,localBytesDecoded);
        if ((len!=INDEFINITE_LEN) && (localBytesDecoded>=len)) structDone = true;
        else tagId = BDecTag(b,localBytesDecoded);
    } else { TagError(MAKE_TAG_ID(UNIV,PRIM,22),tagId); return; }
    if (!structDone && (tagId==MAKE_TAG_ID(UNIV,PRIM,10))) {
        elmtLen = BDecLen(b,localBytesDecoded);
        VAR_reason().bDecContent(b,tagId,elmtLen,localBytesDecoded);
        if (len!=INDEFINITE_LEN && localBytesDecoded>=len) structDone = true;
        else tagId = BDecTag(b,localBytesDecoded);
    }
    complete_sequence_decoding(b, len, localBytesDecoded, tagId);
    bytesDecoded += localBytesDecoded;
    set_state(validValue);
} // TYPE_InoperativeSNInfo::bDecContent

AsnLen TYPE_InoperativeSNInfo::pEnc(BUF_TYPE2 b) const {
    int elmtLen=0;
    b.putBit(reasonPresent().val()?true:false);
    elmtLen++;
    elmtLen += VAR_lastOperativeAt().pEnc(b);
    elmtLen += VAR_sourceSN().pEnc(b);
    if (reasonPresent().val())
        elmtLen += VAR_reason().pEnc(b);
    return elmtLen;
}

void TYPE_InoperativeSNInfo::pDec(BUF_TYPE2 b) {
    bool _field_present0 = b.getBit();
    VAR_lastOperativeAt().pDec(b);
    VAR_sourceSN().pDec(b);
    if(_field_present0) VAR_reason().pDec(b);
    set_state(validValue);
}

SDLSeqSetDescription TYPE_TriggeredSNInfo::_fdesc(9);

SDLType* TYPE_TriggeredSNInfo::copy()const { return new TYPE_TriggeredSNInfo(*this); }

void TYPE_TriggeredSNInfo::assign(const SDLType* t)
{
  const TYPE_TriggeredSNInfo *arg = SITE_DYNAMIC_CAST(const TYPE_TriggeredSNInfo*,t);
  if (!arg) SDLSequence::assign(t);
  else *this = *arg;
}

SDLType* TYPE_TriggeredSNInfo::create()
{
  static TYPE_TriggeredSNInfo* tmpl = new TYPE_TriggeredSNInfo;
  return tmpl;
}

const SDLType* TYPE_TriggeredSNInfo::create_new() const { return create(); }

TYPE_TriggeredSNInfo::TYPE_TriggeredSNInfo():SDLSequence(_fields,9){}
TYPE_TriggeredSNInfo::TYPE_TriggeredSNInfo(SDLType** f,unsigned long c):SDLSequence(f,c){}
TYPE_TriggeredSNInfo::TYPE_TriggeredSNInfo(const SDLNull&):SDLSequence(_fields,9)
{ set_state(invalidValue); }
TYPE_TriggeredSNInfo::TYPE_TriggeredSNInfo(const SDLAny& a, AsnCodingSet rule_set):SDLSequence(_fields,9){a.decode(this,rule_set);}
TYPE_TriggeredSNInfo::TYPE_TriggeredSNInfo(const TYPE_TriggeredSNInfo&o):SDLSequence(o){
  if (o.state(SITEtemporaryValue)) {
#ifdef SITE_LOG
    if (SDLType::_type_debug & SITE_COPY_LOG)
      CERR << "(SDLRTE) struct reference copy of " << o << ENDL;
#endif
    for(int i=0; i<9;++i) {
       _fields[i] = o._fields[i]; o._fields[i] = 0;
    }
  } else sequence_copyinit(_fields,o._fields,9);
}
TYPE_TriggeredSNInfo::~TYPE_TriggeredSNInfo(){clear_fields(_fields,9);}

TYPE_TriggeredSNInfo& TYPE_TriggeredSNInfo::operator=(const TYPE_TriggeredSNInfo& val){
  val.check_valid();
  if (this!=&val) sequence_assign(val);
  return *this;
}

unsigned int TYPE_TriggeredSNInfo::hash(unsigned int max_hash)const{
  return sequence_hash(_fields, 9, max_hash);
}

void TYPE_TriggeredSNInfo::get_fields(
  SDLSeqSetDescription*& d,SDLType **&field_list){
  d=&_fdesc; field_list=_fields;
}

void TYPE_TriggeredSNInfo::get_fields(
  SDLSeqSetDescription*& d,SDLType *const*&field_list) const{
  d=&_fdesc; field_list=_fields;
}


TYPE_DateTime& TYPE_TriggeredSNInfo::VAR_gpsTimeStamp() const
{ return *SITE_STATIC_CAST(TYPE_DateTime*,field_access(_fdesc,_fields,0)); }
static SDLSeqSetDescription::Field *_TYPE_TriggeredSNInfogpsTimeStamp=TYPE_TriggeredSNInfo::_fdesc.add(0,"gpsTimeStamp",&TYPE_DateTime::create,true);

TYPE_IPAddress& TYPE_TriggeredSNInfo::VAR_sourceSN() const
{ return *SITE_STATIC_CAST(TYPE_IPAddress*,field_access(_fdesc,_fields,1)); }
static SDLSeqSetDescription::Field *_TYPE_TriggeredSNInfosourceSN=TYPE_TriggeredSNInfo::_fdesc.add(1,"sourceSN",&TYPE_IPAddress::create,true);

TYPE_SensorAcceleration& TYPE_TriggeredSNInfo::VAR_currentSensorValues() const
{ return *SITE_STATIC_CAST(TYPE_SensorAcceleration*,field_access(_fdesc,_fields,2)); }
static SDLSeqSetDescription::Field *_TYPE_TriggeredSNInfocurrentSensorValues=TYPE_TriggeredSNInfo::_fdesc.add(2,"currentSensorValues",&TYPE_SensorAcceleration::create,true);

TYPE_DateTime& TYPE_TriggeredSNInfo::VAR_tp() const
{ return *SITE_STATIC_CAST(TYPE_DateTime*,field_access(_fdesc,_fields,3)); }
static SDLSeqSetDescription::Field *_TYPE_TriggeredSNInfotp=TYPE_TriggeredSNInfo::_fdesc.add(3,"tp",&TYPE_DateTime::create,true);

TYPE_Acceleration& TYPE_TriggeredSNInfo::VAR_az_max() const
{ return *SITE_STATIC_CAST(TYPE_Acceleration*,field_access(_fdesc,_fields,4)); }
static SDLSeqSetDescription::Field *_TYPE_TriggeredSNInfoaz_max=TYPE_TriggeredSNInfo::_fdesc.add(4,"az_max",&TYPE_Acceleration::create,true);

TYPE_DateTime& TYPE_TriggeredSNInfo::VAR_t_max() const
{ return *SITE_STATIC_CAST(TYPE_DateTime*,field_access(_fdesc,_fields,5)); }
static SDLSeqSetDescription::Field *_TYPE_TriggeredSNInfot_max=TYPE_TriggeredSNInfo::_fdesc.add(5,"t_max",&TYPE_DateTime::create,true);

SDLReal& TYPE_TriggeredSNInfo::VAR_max_noise() const
{ return *SITE_STATIC_CAST(SDLReal*,field_access(_fdesc,_fields,6)); }
static SDLSeqSetDescription::Field *_TYPE_TriggeredSNInfomax_noise=TYPE_TriggeredSNInfo::_fdesc.add(6,"max_noise",&SDLReal::create,true);

SDLReal& TYPE_TriggeredSNInfo::VAR_valueFourthChannel() const
{ return *SITE_STATIC_CAST(SDLReal*,field_access(_fdesc,_fields,7)); }

const SDLBool& TYPE_TriggeredSNInfo::valueFourthChannelPresent()const{
  return field_present(_fdesc,_fields,7);
}

TYPE_TriggeredSNInfo TYPE_TriggeredSNInfo::valueFourthChannelOmit()const{
  TYPE_TriggeredSNInfo c(*this);
  field_omit(_fdesc,c._fields,7);
  return c;
}

void TYPE_TriggeredSNInfo::_valueFourthChannelOmit() {
  field_omit(_fdesc,_fields,7);
}

static SDLSeqSetDescription::Field *_TYPE_TriggeredSNInfovalueFourthChannel=TYPE_TriggeredSNInfo::_fdesc.add_optional(7,"valueFourthChannel",&SDLReal::create,true);

SDLReal& TYPE_TriggeredSNInfo::VAR_sta_lta_TriggerValue() const
{ return *SITE_STATIC_CAST(SDLReal*,field_access(_fdesc,_fields,8)); }
static SDLSeqSetDescription::Field *_TYPE_TriggeredSNInfosta_lta_TriggerValue=TYPE_TriggeredSNInfo::_fdesc.add(8,"sta_lta_TriggerValue",&SDLReal::create,true);



TYPE_TriggeredSNInfo::TYPE_TriggeredSNInfo(const class TYPE_DateTime& PAR_0, const class TYPE_IPAddress& PAR_1, const class TYPE_SensorAcceleration& PAR_2, const class TYPE_DateTime& PAR_3, const class TYPE_Acceleration& PAR_4, const class TYPE_DateTime& PAR_5, const class SDLReal& PAR_6, const class SDLReal& PAR_7, const class SDLReal& PAR_8) {
    set_field(0,PAR_0.copy());
    set_field(1,PAR_1.copy());
    set_field(2,PAR_2.copy());
    set_field(3,PAR_3.copy());
    set_field(4,PAR_4.copy());
    set_field(5,PAR_5.copy());
    set_field(6,PAR_6.copy());
    if(PAR_7.valid())
        set_field(7,new SDLReal(PAR_7));
    else
        set_field(7,0);
    set_field(8,PAR_8.copy());
}

AsnLen TYPE_TriggeredSNInfo::bEnc(BUF_TYPE b) const{
    AsnLen elmtLen = bEncContent(b);
    elmtLen += BEncDefLen(b,elmtLen);
    elmtLen += BEncTag1(b,UNIV,CONS,16);
    return elmtLen;
} // TYPE_TriggeredSNInfo::bEnc

AsnLen TYPE_TriggeredSNInfo::bEncContent(BUF_TYPE b) const {
    AsnLen elmtLen, structBytesEncoded = BEncExtraFields(b);
    elmtLen = VAR_sta_lta_TriggerValue().bEncContent(b);
    elmtLen += BEncDefLen(b,elmtLen);
    elmtLen += BEncTag1(b,UNIV,PRIM,9);
    structBytesEncoded += elmtLen;
    if (valueFourthChannelPresent().val()) {
        elmtLen = VAR_valueFourthChannel().bEncContent(b);
        elmtLen += BEncDefLen(b,elmtLen);
        elmtLen += BEncTag1(b,UNIV,PRIM,9);
        elmtLen += BEncDefLen(b,elmtLen);
        elmtLen += BEncTag1(b,CNTX,CONS,1);
        structBytesEncoded += elmtLen;
    }
    elmtLen = VAR_max_noise().bEncContent(b);
    elmtLen += BEncDefLen(b,elmtLen);
    elmtLen += BEncTag1(b,UNIV,PRIM,9);
    structBytesEncoded += elmtLen;
    elmtLen = VAR_t_max().bEncContent(b);
    elmtLen += BEncDefLen(b,elmtLen);
    elmtLen += BEncTag1(b,UNIV,CONS,16);
    structBytesEncoded += elmtLen;
    elmtLen = VAR_az_max().bEncContent(b);
    elmtLen += BEncDefLen(b,elmtLen);
    elmtLen += BEncTag1(b,UNIV,PRIM,9);
    structBytesEncoded += elmtLen;
    elmtLen = VAR_tp().bEncContent(b);
    elmtLen += BEncDefLen(b,elmtLen);
    elmtLen += BEncTag1(b,UNIV,CONS,16);
    structBytesEncoded += elmtLen;
    elmtLen = VAR_currentSensorValues().bEncContent(b);
    elmtLen += BEncDefLen(b,elmtLen);
    elmtLen += BEncTag1(b,UNIV,CONS,16);
    structBytesEncoded += elmtLen;
    elmtLen = VAR_sourceSN().bEncContent(b);
    elmtLen += BEncDefLen(b,elmtLen);
    elmtLen += BEncTag1(b,UNIV,PRIM,22);
    structBytesEncoded += elmtLen;
    elmtLen = VAR_gpsTimeStamp().bEncContent(b);
    elmtLen += BEncDefLen(b,elmtLen);
    elmtLen += BEncTag1(b,UNIV,CONS,16);
    structBytesEncoded += elmtLen;
    return structBytesEncoded;
} // TYPE_TriggeredSNInfo::bEncContent

void TYPE_TriggeredSNInfo::bDec(BUF_TYPE b,AsnLen& bytesDecoded) {
    AsnTag tagId = BDecTag1(b,bytesDecoded);
    AsnLen elmtLen;
    if (tagId != MAKE_TAG_ID(UNIV,CONS,16)) { TagError(MAKE_TAG_ID(UNIV,CONS,16),tagId); return; }
    elmtLen = BDecLen(b,bytesDecoded);
    int pending_eoc = 0;
    if (elmtLen == INDEFINITE_LEN) ++pending_eoc;
    AsnLen localBytesDecoded = 0;
    bDecContent(b,tagId,elmtLen,localBytesDecoded);
    for(;pending_eoc>0;--pending_eoc) { BDecEoc(b,localBytesDecoded); }
    bytesDecoded += localBytesDecoded;
} // TYPE_TriggeredSNInfo::bDec

void TYPE_TriggeredSNInfo::bDecContent(BUF_TYPE b,AsnTag,
        AsnLen len, AsnLen& bytesDecoded) {
    bool structDone = false;
    AsnLen elmtLen, localBytesDecoded = 0;
    AsnTag tagId;
    if (len == 0) { tagId = 0; structDone = true; }
    else tagId = BDecTag(b,localBytesDecoded);
    if (!structDone && (tagId==MAKE_TAG_ID(UNIV,CONS,16))) {
        elmtLen = BDecLen(b,localBytesDecoded);
        int pending_eoc = 0;
        if (elmtLen == INDEFINITE_LEN) ++pending_eoc;
        VAR_gpsTimeStamp().bDecContent(b,tagId,elmtLen,localBytesDecoded);
        for(;pending_eoc>0;--pending_eoc) { BDecEoc(b,localBytesDecoded); }
        if ((len!=INDEFINITE_LEN) && (localBytesDecoded>=len)) structDone = true;
        else tagId = BDecTag(b,localBytesDecoded);
    } else { TagError(MAKE_TAG_ID(UNIV,CONS,16),tagId); return; }
    if (!structDone && (tagId==MAKE_TAG_ID(UNIV,PRIM,22) ||
                        tagId==MAKE_TAG_ID(UNIV,CONS,22))) {
        elmtLen = BDecLen(b,localBytesDecoded);
        VAR_sourceSN().bDecContent(b,tagId,elmtLen,localBytesDecoded);
        if ((len!=INDEFINITE_LEN) && (localBytesDecoded>=len)) structDone = true;
        else tagId = BDecTag(b,localBytesDecoded);
    } else { TagError(MAKE_TAG_ID(UNIV,PRIM,22),tagId); return; }
    if (!structDone && (tagId==MAKE_TAG_ID(UNIV,CONS,16))) {
        elmtLen = BDecLen(b,localBytesDecoded);
        int pending_eoc = 0;
        if (elmtLen == INDEFINITE_LEN) ++pending_eoc;
        VAR_currentSensorValues().bDecContent(b,tagId,elmtLen,localBytesDecoded);
        for(;pending_eoc>0;--pending_eoc) { BDecEoc(b,localBytesDecoded); }
        if ((len!=INDEFINITE_LEN) && (localBytesDecoded>=len)) structDone = true;
        else tagId = BDecTag(b,localBytesDecoded);
    } else { TagError(MAKE_TAG_ID(UNIV,CONS,16),tagId); return; }
    if (!structDone && (tagId==MAKE_TAG_ID(UNIV,CONS,16))) {
        elmtLen = BDecLen(b,localBytesDecoded);
        int pending_eoc = 0;
        if (elmtLen == INDEFINITE_LEN) ++pending_eoc;
        VAR_tp().bDecContent(b,tagId,elmtLen,localBytesDecoded);
        for(;pending_eoc>0;--pending_eoc) { BDecEoc(b,localBytesDecoded); }
        if ((len!=INDEFINITE_LEN) && (localBytesDecoded>=len)) structDone = true;
        else tagId = BDecTag(b,localBytesDecoded);
    } else { TagError(MAKE_TAG_ID(UNIV,CONS,16),tagId); return; }
    if (!structDone && (tagId==MAKE_TAG_ID(UNIV,PRIM,9))) {
        elmtLen = BDecLen(b,localBytesDecoded);
        VAR_az_max().bDecContent(b,tagId,elmtLen,localBytesDecoded);
        if ((len!=INDEFINITE_LEN) && (localBytesDecoded>=len)) structDone = true;
        else tagId = BDecTag(b,localBytesDecoded);
    } else { TagError(MAKE_TAG_ID(UNIV,PRIM,9),tagId); return; }
    if (!structDone && (tagId==MAKE_TAG_ID(UNIV,CONS,16))) {
        elmtLen = BDecLen(b,localBytesDecoded);
        int pending_eoc = 0;
        if (elmtLen == INDEFINITE_LEN) ++pending_eoc;
        VAR_t_max().bDecContent(b,tagId,elmtLen,localBytesDecoded);
        for(;pending_eoc>0;--pending_eoc) { BDecEoc(b,localBytesDecoded); }
        if ((len!=INDEFINITE_LEN) && (localBytesDecoded>=len)) structDone = true;
        else tagId = BDecTag(b,localBytesDecoded);
    } else { TagError(MAKE_TAG_ID(UNIV,CONS,16),tagId); return; }
    if (!structDone && (tagId==MAKE_TAG_ID(UNIV,PRIM,9))) {
        elmtLen = BDecLen(b,localBytesDecoded);
        VAR_max_noise().bDecContent(b,tagId,elmtLen,localBytesDecoded);
        if ((len!=INDEFINITE_LEN) && (localBytesDecoded>=len)) structDone = true;
        else tagId = BDecTag(b,localBytesDecoded);
    } else { TagError(MAKE_TAG_ID(UNIV,PRIM,9),tagId); return; }
    if (!structDone && (tagId==MAKE_TAG_ID(CNTX,CONS,1))) {
        elmtLen = BDecLen(b,localBytesDecoded);
        int pending_eoc = 0;
        if (elmtLen == INDEFINITE_LEN) ++pending_eoc;
        tagId = BDecTag1(b,localBytesDecoded);
        if (tagId == MAKE_TAG_ID(UNIV,PRIM,9)) {
          elmtLen = BDecLen(b,localBytesDecoded);
        } else { TagError(MAKE_TAG_ID(UNIV,PRIM,9),tagId); return; }
        VAR_valueFourthChannel().bDecContent(b,tagId,elmtLen,localBytesDecoded);
        for(;pending_eoc>0;--pending_eoc) { BDecEoc(b,localBytesDecoded); }
        if (len!=INDEFINITE_LEN && localBytesDecoded>=len) structDone = true;
        else tagId = BDecTag(b,localBytesDecoded);
    }
    if (!structDone && (tagId==MAKE_TAG_ID(UNIV,PRIM,9))) {
        elmtLen = BDecLen(b,localBytesDecoded);
        VAR_sta_lta_TriggerValue().bDecContent(b,tagId,elmtLen,localBytesDecoded);
        if ((len!=INDEFINITE_LEN) && (localBytesDecoded>=len)) structDone = true;
        else tagId = BDecTag(b,localBytesDecoded);
    } else { TagError(MAKE_TAG_ID(UNIV,PRIM,9),tagId); return; }
    complete_sequence_decoding(b, len, localBytesDecoded, tagId);
    bytesDecoded += localBytesDecoded;
    set_state(validValue);
} // TYPE_TriggeredSNInfo::bDecContent

AsnLen TYPE_TriggeredSNInfo::pEnc(BUF_TYPE2 b) const {
    int elmtLen=0;
    b.putBit(valueFourthChannelPresent().val()?true:false);
    elmtLen++;
    elmtLen += VAR_gpsTimeStamp().pEnc(b);
    elmtLen += VAR_sourceSN().pEnc(b);
    elmtLen += VAR_currentSensorValues().pEnc(b);
    elmtLen += VAR_tp().pEnc(b);
    elmtLen += VAR_az_max().pEnc(b);
    elmtLen += VAR_t_max().pEnc(b);
    elmtLen += VAR_max_noise().pEnc(b);
    if (valueFourthChannelPresent().val())
        elmtLen += VAR_valueFourthChannel().pEnc(b);
    elmtLen += VAR_sta_lta_TriggerValue().pEnc(b);
    return elmtLen;
}

void TYPE_TriggeredSNInfo::pDec(BUF_TYPE2 b) {
    bool _field_present0 = b.getBit();
    VAR_gpsTimeStamp().pDec(b);
    VAR_sourceSN().pDec(b);
    VAR_currentSensorValues().pDec(b);
    VAR_tp().pDec(b);
    VAR_az_max().pDec(b);
    VAR_t_max().pDec(b);
    VAR_max_noise().pDec(b);
    if(_field_present0) VAR_valueFourthChannel().pDec(b);
    VAR_sta_lta_TriggerValue().pDec(b);
    set_state(validValue);
}

SDLSeqSetDescription TYPE_LN_LN_Idle::_fdesc(4);

SDLType* TYPE_LN_LN_Idle::copy()const { return new TYPE_LN_LN_Idle(*this); }

void TYPE_LN_LN_Idle::assign(const SDLType* t)
{
  const TYPE_LN_LN_Idle *arg = SITE_DYNAMIC_CAST(const TYPE_LN_LN_Idle*,t);
  if (!arg) SDLSequence::assign(t);
  else *this = *arg;
}

SDLType* TYPE_LN_LN_Idle::create()
{
  static TYPE_LN_LN_Idle* tmpl = new TYPE_LN_LN_Idle;
  return tmpl;
}

const SDLType* TYPE_LN_LN_Idle::create_new() const { return create(); }

TYPE_LN_LN_Idle::TYPE_LN_LN_Idle():SDLSequence(_fields,4){}
TYPE_LN_LN_Idle::TYPE_LN_LN_Idle(SDLType** f,unsigned long c):SDLSequence(f,c){}
TYPE_LN_LN_Idle::TYPE_LN_LN_Idle(const SDLNull&):SDLSequence(_fields,4)
{ set_state(invalidValue); }
TYPE_LN_LN_Idle::TYPE_LN_LN_Idle(const SDLAny& a, AsnCodingSet rule_set):SDLSequence(_fields,4){a.decode(this,rule_set);}
TYPE_LN_LN_Idle::TYPE_LN_LN_Idle(const TYPE_LN_LN_Idle&o):SDLSequence(o){
  if (o.state(SITEtemporaryValue)) {
#ifdef SITE_LOG
    if (SDLType::_type_debug & SITE_COPY_LOG)
      CERR << "(SDLRTE) struct reference copy of " << o << ENDL;
#endif
    for(int i=0; i<4;++i) {
       _fields[i] = o._fields[i]; o._fields[i] = 0;
    }
  } else sequence_copyinit(_fields,o._fields,4);
}
TYPE_LN_LN_Idle::~TYPE_LN_LN_Idle(){clear_fields(_fields,4);}

TYPE_LN_LN_Idle& TYPE_LN_LN_Idle::operator=(const TYPE_LN_LN_Idle& val){
  val.check_valid();
  if (this!=&val) sequence_assign(val);
  return *this;
}

unsigned int TYPE_LN_LN_Idle::hash(unsigned int max_hash)const{
  return sequence_hash(_fields, 4, max_hash);
}

void TYPE_LN_LN_Idle::get_fields(
  SDLSeqSetDescription*& d,SDLType **&field_list){
  d=&_fdesc; field_list=_fields;
}

void TYPE_LN_LN_Idle::get_fields(
  SDLSeqSetDescription*& d,SDLType *const*&field_list) const{
  d=&_fdesc; field_list=_fields;
}


TYPE_DateTime& TYPE_LN_LN_Idle::VAR_gpsTimeStamp() const
{ return *SITE_STATIC_CAST(TYPE_DateTime*,field_access(_fdesc,_fields,0)); }
static SDLSeqSetDescription::Field *_TYPE_LN_LN_IdlegpsTimeStamp=TYPE_LN_LN_Idle::_fdesc.add(0,"gpsTimeStamp",&TYPE_DateTime::create,true);

TYPE_APEWProtocol_GEN_10& TYPE_LN_LN_Idle::VAR_operativeSNs() const
{ return *SITE_STATIC_CAST(TYPE_APEWProtocol_GEN_10*,field_access(_fdesc,_fields,1)); }
static SDLSeqSetDescription::Field *_TYPE_LN_LN_IdleoperativeSNs=TYPE_LN_LN_Idle::_fdesc.add(1,"operativeSNs",&TYPE_APEWProtocol_GEN_10::create,true);

TYPE_APEWProtocol_GEN_11& TYPE_LN_LN_Idle::VAR_inoperativeSNs() const
{ return *SITE_STATIC_CAST(TYPE_APEWProtocol_GEN_11*,field_access(_fdesc,_fields,2)); }
static SDLSeqSetDescription::Field *_TYPE_LN_LN_IdleinoperativeSNs=TYPE_LN_LN_Idle::_fdesc.add(2,"inoperativeSNs",&TYPE_APEWProtocol_GEN_11::create,true);

TYPE_SensorAccelerationAverage& TYPE_LN_LN_Idle::VAR_noiseAverage() const
{ return *SITE_STATIC_CAST(TYPE_SensorAccelerationAverage*,field_access(_fdesc,_fields,3)); }
static SDLSeqSetDescription::Field *_TYPE_LN_LN_IdlenoiseAverage=TYPE_LN_LN_Idle::_fdesc.add(3,"noiseAverage",&TYPE_SensorAccelerationAverage::create,true);



TYPE_LN_LN_Idle::TYPE_LN_LN_Idle(const class TYPE_DateTime& PAR_0, const class TYPE_APEWProtocol_GEN_10& PAR_1, const class TYPE_APEWProtocol_GEN_11& PAR_2, const class TYPE_SensorAccelerationAverage& PAR_3) {
    set_field(0,PAR_0.copy());
    set_field(1,PAR_1.copy());
    set_field(2,PAR_2.copy());
    set_field(3,PAR_3.copy());
}

AsnLen TYPE_LN_LN_Idle::bEnc(BUF_TYPE b) const{
    AsnLen elmtLen = bEncContent(b);
    elmtLen += BEncDefLen(b,elmtLen);
    elmtLen += BEncTag1(b,UNIV,CONS,16);
    return elmtLen;
} // TYPE_LN_LN_Idle::bEnc

AsnLen TYPE_LN_LN_Idle::bEncContent(BUF_TYPE b) const {
    AsnLen elmtLen, structBytesEncoded = BEncExtraFields(b);
    elmtLen = VAR_noiseAverage().bEncContent(b);
    elmtLen += BEncDefLen(b,elmtLen);
    elmtLen += BEncTag1(b,UNIV,CONS,16);
    structBytesEncoded += elmtLen;
    elmtLen = VAR_inoperativeSNs().bEncContent(b);
    elmtLen += BEncDefLen(b,elmtLen);
    elmtLen += BEncTag1(b,UNIV,CONS,17);
    structBytesEncoded += elmtLen;
    elmtLen = VAR_operativeSNs().bEncContent(b);
    elmtLen += BEncDefLen(b,elmtLen);
    elmtLen += BEncTag1(b,UNIV,CONS,17);
    structBytesEncoded += elmtLen;
    elmtLen = VAR_gpsTimeStamp().bEncContent(b);
    elmtLen += BEncDefLen(b,elmtLen);
    elmtLen += BEncTag1(b,UNIV,CONS,16);
    structBytesEncoded += elmtLen;
    return structBytesEncoded;
} // TYPE_LN_LN_Idle::bEncContent

void TYPE_LN_LN_Idle::bDec(BUF_TYPE b,AsnLen& bytesDecoded) {
    AsnTag tagId = BDecTag1(b,bytesDecoded);
    AsnLen elmtLen;
    if (tagId != MAKE_TAG_ID(UNIV,CONS,16)) { TagError(MAKE_TAG_ID(UNIV,CONS,16),tagId); return; }
    elmtLen = BDecLen(b,bytesDecoded);
    int pending_eoc = 0;
    if (elmtLen == INDEFINITE_LEN) ++pending_eoc;
    AsnLen localBytesDecoded = 0;
    bDecContent(b,tagId,elmtLen,localBytesDecoded);
    for(;pending_eoc>0;--pending_eoc) { BDecEoc(b,localBytesDecoded); }
    bytesDecoded += localBytesDecoded;
} // TYPE_LN_LN_Idle::bDec

void TYPE_LN_LN_Idle::bDecContent(BUF_TYPE b,AsnTag,
        AsnLen len, AsnLen& bytesDecoded) {
    bool structDone = false;
    AsnLen elmtLen, localBytesDecoded = 0;
    AsnTag tagId;
    if (len == 0) { tagId = 0; structDone = true; }
    else tagId = BDecTag(b,localBytesDecoded);
    if (!structDone && (tagId==MAKE_TAG_ID(UNIV,CONS,16))) {
        elmtLen = BDecLen(b,localBytesDecoded);
        int pending_eoc = 0;
        if (elmtLen == INDEFINITE_LEN) ++pending_eoc;
        VAR_gpsTimeStamp().bDecContent(b,tagId,elmtLen,localBytesDecoded);
        for(;pending_eoc>0;--pending_eoc) { BDecEoc(b,localBytesDecoded); }
        if ((len!=INDEFINITE_LEN) && (localBytesDecoded>=len)) structDone = true;
        else tagId = BDecTag(b,localBytesDecoded);
    } else { TagError(MAKE_TAG_ID(UNIV,CONS,16),tagId); return; }
    if (!structDone && (tagId==MAKE_TAG_ID(UNIV,CONS,17))) {
        elmtLen = BDecLen(b,localBytesDecoded);
        int pending_eoc = 0;
        if (elmtLen == INDEFINITE_LEN) ++pending_eoc;
        VAR_operativeSNs().bDecContent(b,tagId,elmtLen,localBytesDecoded);
        for(;pending_eoc>0;--pending_eoc) { BDecEoc(b,localBytesDecoded); }
        if ((len!=INDEFINITE_LEN) && (localBytesDecoded>=len)) structDone = true;
        else tagId = BDecTag(b,localBytesDecoded);
    } else { TagError(MAKE_TAG_ID(UNIV,CONS,17),tagId); return; }
    if (!structDone && (tagId==MAKE_TAG_ID(UNIV,CONS,17))) {
        elmtLen = BDecLen(b,localBytesDecoded);
        int pending_eoc = 0;
        if (elmtLen == INDEFINITE_LEN) ++pending_eoc;
        VAR_inoperativeSNs().bDecContent(b,tagId,elmtLen,localBytesDecoded);
        for(;pending_eoc>0;--pending_eoc) { BDecEoc(b,localBytesDecoded); }
        if ((len!=INDEFINITE_LEN) && (localBytesDecoded>=len)) structDone = true;
        else tagId = BDecTag(b,localBytesDecoded);
    } else { TagError(MAKE_TAG_ID(UNIV,CONS,17),tagId); return; }
    if (!structDone && (tagId==MAKE_TAG_ID(UNIV,CONS,16))) {
        elmtLen = BDecLen(b,localBytesDecoded);
        int pending_eoc = 0;
        if (elmtLen == INDEFINITE_LEN) ++pending_eoc;
        VAR_noiseAverage().bDecContent(b,tagId,elmtLen,localBytesDecoded);
        for(;pending_eoc>0;--pending_eoc) { BDecEoc(b,localBytesDecoded); }
        if ((len!=INDEFINITE_LEN) && (localBytesDecoded>=len)) structDone = true;
        else tagId = BDecTag(b,localBytesDecoded);
    } else { TagError(MAKE_TAG_ID(UNIV,CONS,16),tagId); return; }
    complete_sequence_decoding(b, len, localBytesDecoded, tagId);
    bytesDecoded += localBytesDecoded;
    set_state(validValue);
} // TYPE_LN_LN_Idle::bDecContent

AsnLen TYPE_LN_LN_Idle::pEnc(BUF_TYPE2 b) const {
    int elmtLen=0;
    elmtLen += VAR_gpsTimeStamp().pEnc(b);
    elmtLen += VAR_operativeSNs().pEnc(b);
    elmtLen += VAR_inoperativeSNs().pEnc(b);
    elmtLen += VAR_noiseAverage().pEnc(b);
    return elmtLen;
}

void TYPE_LN_LN_Idle::pDec(BUF_TYPE2 b) {
    VAR_gpsTimeStamp().pDec(b);
    VAR_operativeSNs().pDec(b);
    VAR_inoperativeSNs().pDec(b);
    VAR_noiseAverage().pDec(b);
    set_state(validValue);
}

SDLSeqSetDescription TYPE_LN_LN_Detection::_fdesc(5);

SDLType* TYPE_LN_LN_Detection::copy()const { return new TYPE_LN_LN_Detection(*this); }

void TYPE_LN_LN_Detection::assign(const SDLType* t)
{
  const TYPE_LN_LN_Detection *arg = SITE_DYNAMIC_CAST(const TYPE_LN_LN_Detection*,t);
  if (!arg) SDLSequence::assign(t);
  else *this = *arg;
}

SDLType* TYPE_LN_LN_Detection::create()
{
  static TYPE_LN_LN_Detection* tmpl = new TYPE_LN_LN_Detection;
  return tmpl;
}

const SDLType* TYPE_LN_LN_Detection::create_new() const { return create(); }

TYPE_LN_LN_Detection::TYPE_LN_LN_Detection():SDLSequence(_fields,5){}
TYPE_LN_LN_Detection::TYPE_LN_LN_Detection(SDLType** f,unsigned long c):SDLSequence(f,c){}
TYPE_LN_LN_Detection::TYPE_LN_LN_Detection(const SDLNull&):SDLSequence(_fields,5)
{ set_state(invalidValue); }
TYPE_LN_LN_Detection::TYPE_LN_LN_Detection(const SDLAny& a, AsnCodingSet rule_set):SDLSequence(_fields,5){a.decode(this,rule_set);}
TYPE_LN_LN_Detection::TYPE_LN_LN_Detection(const TYPE_LN_LN_Detection&o):SDLSequence(o){
  if (o.state(SITEtemporaryValue)) {
#ifdef SITE_LOG
    if (SDLType::_type_debug & SITE_COPY_LOG)
      CERR << "(SDLRTE) struct reference copy of " << o << ENDL;
#endif
    for(int i=0; i<5;++i) {
       _fields[i] = o._fields[i]; o._fields[i] = 0;
    }
  } else sequence_copyinit(_fields,o._fields,5);
}
TYPE_LN_LN_Detection::~TYPE_LN_LN_Detection(){clear_fields(_fields,5);}

TYPE_LN_LN_Detection& TYPE_LN_LN_Detection::operator=(const TYPE_LN_LN_Detection& val){
  val.check_valid();
  if (this!=&val) sequence_assign(val);
  return *this;
}

unsigned int TYPE_LN_LN_Detection::hash(unsigned int max_hash)const{
  return sequence_hash(_fields, 5, max_hash);
}

void TYPE_LN_LN_Detection::get_fields(
  SDLSeqSetDescription*& d,SDLType **&field_list){
  d=&_fdesc; field_list=_fields;
}

void TYPE_LN_LN_Detection::get_fields(
  SDLSeqSetDescription*& d,SDLType *const*&field_list) const{
  d=&_fdesc; field_list=_fields;
}


TYPE_DateTime& TYPE_LN_LN_Detection::VAR_gpsTimeStamp() const
{ return *SITE_STATIC_CAST(TYPE_DateTime*,field_access(_fdesc,_fields,0)); }
static SDLSeqSetDescription::Field *_TYPE_LN_LN_DetectiongpsTimeStamp=TYPE_LN_LN_Detection::_fdesc.add(0,"gpsTimeStamp",&TYPE_DateTime::create,true);

TYPE_EventID& TYPE_LN_LN_Detection::VAR_event() const
{ return *SITE_STATIC_CAST(TYPE_EventID*,field_access(_fdesc,_fields,1)); }
static SDLSeqSetDescription::Field *_TYPE_LN_LN_Detectionevent=TYPE_LN_LN_Detection::_fdesc.add(1,"event",&TYPE_EventID::create,true);

TYPE_APEWProtocol_GEN_12& TYPE_LN_LN_Detection::VAR_triggeredSNs() const
{ return *SITE_STATIC_CAST(TYPE_APEWProtocol_GEN_12*,field_access(_fdesc,_fields,2)); }
static SDLSeqSetDescription::Field *_TYPE_LN_LN_DetectiontriggeredSNs=TYPE_LN_LN_Detection::_fdesc.add(2,"triggeredSNs",&TYPE_APEWProtocol_GEN_12::create,true);

TYPE_APEWProtocol_GEN_13& TYPE_LN_LN_Detection::VAR_inoperativeSNs() const
{ return *SITE_STATIC_CAST(TYPE_APEWProtocol_GEN_13*,field_access(_fdesc,_fields,3)); }
static SDLSeqSetDescription::Field *_TYPE_LN_LN_DetectioninoperativeSNs=TYPE_LN_LN_Detection::_fdesc.add(3,"inoperativeSNs",&TYPE_APEWProtocol_GEN_13::create,true);

TYPE_SensorAccelerationAverage& TYPE_LN_LN_Detection::VAR_noiseAveragePreEvent() const
{ return *SITE_STATIC_CAST(TYPE_SensorAccelerationAverage*,field_access(_fdesc,_fields,4)); }
static SDLSeqSetDescription::Field *_TYPE_LN_LN_DetectionnoiseAveragePreEvent=TYPE_LN_LN_Detection::_fdesc.add(4,"noiseAveragePreEvent",&TYPE_SensorAccelerationAverage::create,true);



TYPE_LN_LN_Detection::TYPE_LN_LN_Detection(const class TYPE_DateTime& PAR_0, const class TYPE_EventID& PAR_1, const class TYPE_APEWProtocol_GEN_12& PAR_2, const class TYPE_APEWProtocol_GEN_13& PAR_3, const class TYPE_SensorAccelerationAverage& PAR_4) {
    set_field(0,PAR_0.copy());
    set_field(1,PAR_1.copy());
    set_field(2,PAR_2.copy());
    set_field(3,PAR_3.copy());
    set_field(4,PAR_4.copy());
}

AsnLen TYPE_LN_LN_Detection::bEnc(BUF_TYPE b) const{
    AsnLen elmtLen = bEncContent(b);
    elmtLen += BEncDefLen(b,elmtLen);
    elmtLen += BEncTag1(b,UNIV,CONS,16);
    return elmtLen;
} // TYPE_LN_LN_Detection::bEnc

AsnLen TYPE_LN_LN_Detection::bEncContent(BUF_TYPE b) const {
    AsnLen elmtLen, structBytesEncoded = BEncExtraFields(b);
    elmtLen = VAR_noiseAveragePreEvent().bEncContent(b);
    elmtLen += BEncDefLen(b,elmtLen);
    elmtLen += BEncTag1(b,UNIV,CONS,16);
    structBytesEncoded += elmtLen;
    elmtLen = VAR_inoperativeSNs().bEncContent(b);
    elmtLen += BEncDefLen(b,elmtLen);
    elmtLen += BEncTag1(b,UNIV,CONS,17);
    structBytesEncoded += elmtLen;
    elmtLen = VAR_triggeredSNs().bEncContent(b);
    elmtLen += BEncDefLen(b,elmtLen);
    elmtLen += BEncTag1(b,UNIV,CONS,17);
    structBytesEncoded += elmtLen;
    elmtLen = VAR_event().bEncContent(b);
    elmtLen += BEncDefLen(b,elmtLen);
    elmtLen += BEncTag1(b,UNIV,PRIM,2);
    structBytesEncoded += elmtLen;
    elmtLen = VAR_gpsTimeStamp().bEncContent(b);
    elmtLen += BEncDefLen(b,elmtLen);
    elmtLen += BEncTag1(b,UNIV,CONS,16);
    structBytesEncoded += elmtLen;
    return structBytesEncoded;
} // TYPE_LN_LN_Detection::bEncContent

void TYPE_LN_LN_Detection::bDec(BUF_TYPE b,AsnLen& bytesDecoded) {
    AsnTag tagId = BDecTag1(b,bytesDecoded);
    AsnLen elmtLen;
    if (tagId != MAKE_TAG_ID(UNIV,CONS,16)) { TagError(MAKE_TAG_ID(UNIV,CONS,16),tagId); return; }
    elmtLen = BDecLen(b,bytesDecoded);
    int pending_eoc = 0;
    if (elmtLen == INDEFINITE_LEN) ++pending_eoc;
    AsnLen localBytesDecoded = 0;
    bDecContent(b,tagId,elmtLen,localBytesDecoded);
    for(;pending_eoc>0;--pending_eoc) { BDecEoc(b,localBytesDecoded); }
    bytesDecoded += localBytesDecoded;
} // TYPE_LN_LN_Detection::bDec

void TYPE_LN_LN_Detection::bDecContent(BUF_TYPE b,AsnTag,
        AsnLen len, AsnLen& bytesDecoded) {
    bool structDone = false;
    AsnLen elmtLen, localBytesDecoded = 0;
    AsnTag tagId;
    if (len == 0) { tagId = 0; structDone = true; }
    else tagId = BDecTag(b,localBytesDecoded);
    if (!structDone && (tagId==MAKE_TAG_ID(UNIV,CONS,16))) {
        elmtLen = BDecLen(b,localBytesDecoded);
        int pending_eoc = 0;
        if (elmtLen == INDEFINITE_LEN) ++pending_eoc;
        VAR_gpsTimeStamp().bDecContent(b,tagId,elmtLen,localBytesDecoded);
        for(;pending_eoc>0;--pending_eoc) { BDecEoc(b,localBytesDecoded); }
        if ((len!=INDEFINITE_LEN) && (localBytesDecoded>=len)) structDone = true;
        else tagId = BDecTag(b,localBytesDecoded);
    } else { TagError(MAKE_TAG_ID(UNIV,CONS,16),tagId); return; }
    if (!structDone && (tagId==MAKE_TAG_ID(UNIV,PRIM,2))) {
        elmtLen = BDecLen(b,localBytesDecoded);
        VAR_event().bDecContent(b,tagId,elmtLen,localBytesDecoded);
        if ((len!=INDEFINITE_LEN) && (localBytesDecoded>=len)) structDone = true;
        else tagId = BDecTag(b,localBytesDecoded);
    } else { TagError(MAKE_TAG_ID(UNIV,PRIM,2),tagId); return; }
    if (!structDone && (tagId==MAKE_TAG_ID(UNIV,CONS,17))) {
        elmtLen = BDecLen(b,localBytesDecoded);
        int pending_eoc = 0;
        if (elmtLen == INDEFINITE_LEN) ++pending_eoc;
        VAR_triggeredSNs().bDecContent(b,tagId,elmtLen,localBytesDecoded);
        for(;pending_eoc>0;--pending_eoc) { BDecEoc(b,localBytesDecoded); }
        if ((len!=INDEFINITE_LEN) && (localBytesDecoded>=len)) structDone = true;
        else tagId = BDecTag(b,localBytesDecoded);
    } else { TagError(MAKE_TAG_ID(UNIV,CONS,17),tagId); return; }
    if (!structDone && (tagId==MAKE_TAG_ID(UNIV,CONS,17))) {
        elmtLen = BDecLen(b,localBytesDecoded);
        int pending_eoc = 0;
        if (elmtLen == INDEFINITE_LEN) ++pending_eoc;
        VAR_inoperativeSNs().bDecContent(b,tagId,elmtLen,localBytesDecoded);
        for(;pending_eoc>0;--pending_eoc) { BDecEoc(b,localBytesDecoded); }
        if ((len!=INDEFINITE_LEN) && (localBytesDecoded>=len)) structDone = true;
        else tagId = BDecTag(b,localBytesDecoded);
    } else { TagError(MAKE_TAG_ID(UNIV,CONS,17),tagId); return; }
    if (!structDone && (tagId==MAKE_TAG_ID(UNIV,CONS,16))) {
        elmtLen = BDecLen(b,localBytesDecoded);
        int pending_eoc = 0;
        if (elmtLen == INDEFINITE_LEN) ++pending_eoc;
        VAR_noiseAveragePreEvent().bDecContent(b,tagId,elmtLen,localBytesDecoded);
        for(;pending_eoc>0;--pending_eoc) { BDecEoc(b,localBytesDecoded); }
        if ((len!=INDEFINITE_LEN) && (localBytesDecoded>=len)) structDone = true;
        else tagId = BDecTag(b,localBytesDecoded);
    } else { TagError(MAKE_TAG_ID(UNIV,CONS,16),tagId); return; }
    complete_sequence_decoding(b, len, localBytesDecoded, tagId);
    bytesDecoded += localBytesDecoded;
    set_state(validValue);
} // TYPE_LN_LN_Detection::bDecContent

AsnLen TYPE_LN_LN_Detection::pEnc(BUF_TYPE2 b) const {
    int elmtLen=0;
    elmtLen += VAR_gpsTimeStamp().pEnc(b);
    elmtLen += VAR_event().pEnc(b);
    elmtLen += VAR_triggeredSNs().pEnc(b);
    elmtLen += VAR_inoperativeSNs().pEnc(b);
    elmtLen += VAR_noiseAveragePreEvent().pEnc(b);
    return elmtLen;
}

void TYPE_LN_LN_Detection::pDec(BUF_TYPE2 b) {
    VAR_gpsTimeStamp().pDec(b);
    VAR_event().pDec(b);
    VAR_triggeredSNs().pDec(b);
    VAR_inoperativeSNs().pDec(b);
    VAR_noiseAveragePreEvent().pDec(b);
    set_state(validValue);
}

SDLSeqSetDescription TYPE_LN_LN_Alarm::_fdesc(3);

SDLType* TYPE_LN_LN_Alarm::copy()const { return new TYPE_LN_LN_Alarm(*this); }

void TYPE_LN_LN_Alarm::assign(const SDLType* t)
{
  const TYPE_LN_LN_Alarm *arg = SITE_DYNAMIC_CAST(const TYPE_LN_LN_Alarm*,t);
  if (!arg) SDLSequence::assign(t);
  else *this = *arg;
}

SDLType* TYPE_LN_LN_Alarm::create()
{
  static TYPE_LN_LN_Alarm* tmpl = new TYPE_LN_LN_Alarm;
  return tmpl;
}

const SDLType* TYPE_LN_LN_Alarm::create_new() const { return create(); }

TYPE_LN_LN_Alarm::TYPE_LN_LN_Alarm():SDLSequence(_fields,3){}
TYPE_LN_LN_Alarm::TYPE_LN_LN_Alarm(SDLType** f,unsigned long c):SDLSequence(f,c){}
TYPE_LN_LN_Alarm::TYPE_LN_LN_Alarm(const SDLNull&):SDLSequence(_fields,3)
{ set_state(invalidValue); }
TYPE_LN_LN_Alarm::TYPE_LN_LN_Alarm(const SDLAny& a, AsnCodingSet rule_set):SDLSequence(_fields,3){a.decode(this,rule_set);}
TYPE_LN_LN_Alarm::TYPE_LN_LN_Alarm(const TYPE_LN_LN_Alarm&o):SDLSequence(o){
  if (o.state(SITEtemporaryValue)) {
#ifdef SITE_LOG
    if (SDLType::_type_debug & SITE_COPY_LOG)
      CERR << "(SDLRTE) struct reference copy of " << o << ENDL;
#endif
    for(int i=0; i<3;++i) {
       _fields[i] = o._fields[i]; o._fields[i] = 0;
    }
  } else sequence_copyinit(_fields,o._fields,3);
}
TYPE_LN_LN_Alarm::~TYPE_LN_LN_Alarm(){clear_fields(_fields,3);}

TYPE_LN_LN_Alarm& TYPE_LN_LN_Alarm::operator=(const TYPE_LN_LN_Alarm& val){
  val.check_valid();
  if (this!=&val) sequence_assign(val);
  return *this;
}

unsigned int TYPE_LN_LN_Alarm::hash(unsigned int max_hash)const{
  return sequence_hash(_fields, 3, max_hash);
}

void TYPE_LN_LN_Alarm::get_fields(
  SDLSeqSetDescription*& d,SDLType **&field_list){
  d=&_fdesc; field_list=_fields;
}

void TYPE_LN_LN_Alarm::get_fields(
  SDLSeqSetDescription*& d,SDLType *const*&field_list) const{
  d=&_fdesc; field_list=_fields;
}


TYPE_DateTime& TYPE_LN_LN_Alarm::VAR_gpsTimeStamp() const
{ return *SITE_STATIC_CAST(TYPE_DateTime*,field_access(_fdesc,_fields,0)); }
static SDLSeqSetDescription::Field *_TYPE_LN_LN_AlarmgpsTimeStamp=TYPE_LN_LN_Alarm::_fdesc.add(0,"gpsTimeStamp",&TYPE_DateTime::create,true);

TYPE_EventID& TYPE_LN_LN_Alarm::VAR_event() const
{ return *SITE_STATIC_CAST(TYPE_EventID*,field_access(_fdesc,_fields,1)); }
static SDLSeqSetDescription::Field *_TYPE_LN_LN_Alarmevent=TYPE_LN_LN_Alarm::_fdesc.add(1,"event",&TYPE_EventID::create,true);

TYPE_APEWProtocol_GEN_14& TYPE_LN_LN_Alarm::VAR_decisionMakingSNs() const
{ return *SITE_STATIC_CAST(TYPE_APEWProtocol_GEN_14*,field_access(_fdesc,_fields,2)); }
static SDLSeqSetDescription::Field *_TYPE_LN_LN_AlarmdecisionMakingSNs=TYPE_LN_LN_Alarm::_fdesc.add(2,"decisionMakingSNs",&TYPE_APEWProtocol_GEN_14::create,true);



TYPE_LN_LN_Alarm::TYPE_LN_LN_Alarm(const class TYPE_DateTime& PAR_0, const class TYPE_EventID& PAR_1, const class TYPE_APEWProtocol_GEN_14& PAR_2) {
    set_field(0,PAR_0.copy());
    set_field(1,PAR_1.copy());
    set_field(2,PAR_2.copy());
}

AsnLen TYPE_LN_LN_Alarm::bEnc(BUF_TYPE b) const{
    AsnLen elmtLen = bEncContent(b);
    elmtLen += BEncDefLen(b,elmtLen);
    elmtLen += BEncTag1(b,UNIV,CONS,16);
    return elmtLen;
} // TYPE_LN_LN_Alarm::bEnc

AsnLen TYPE_LN_LN_Alarm::bEncContent(BUF_TYPE b) const {
    AsnLen elmtLen, structBytesEncoded = BEncExtraFields(b);
    elmtLen = VAR_decisionMakingSNs().bEncContent(b);
    elmtLen += BEncDefLen(b,elmtLen);
    elmtLen += BEncTag1(b,UNIV,CONS,17);
    structBytesEncoded += elmtLen;
    elmtLen = VAR_event().bEncContent(b);
    elmtLen += BEncDefLen(b,elmtLen);
    elmtLen += BEncTag1(b,UNIV,PRIM,2);
    structBytesEncoded += elmtLen;
    elmtLen = VAR_gpsTimeStamp().bEncContent(b);
    elmtLen += BEncDefLen(b,elmtLen);
    elmtLen += BEncTag1(b,UNIV,CONS,16);
    structBytesEncoded += elmtLen;
    return structBytesEncoded;
} // TYPE_LN_LN_Alarm::bEncContent

void TYPE_LN_LN_Alarm::bDec(BUF_TYPE b,AsnLen& bytesDecoded) {
    AsnTag tagId = BDecTag1(b,bytesDecoded);
    AsnLen elmtLen;
    if (tagId != MAKE_TAG_ID(UNIV,CONS,16)) { TagError(MAKE_TAG_ID(UNIV,CONS,16),tagId); return; }
    elmtLen = BDecLen(b,bytesDecoded);
    int pending_eoc = 0;
    if (elmtLen == INDEFINITE_LEN) ++pending_eoc;
    AsnLen localBytesDecoded = 0;
    bDecContent(b,tagId,elmtLen,localBytesDecoded);
    for(;pending_eoc>0;--pending_eoc) { BDecEoc(b,localBytesDecoded); }
    bytesDecoded += localBytesDecoded;
} // TYPE_LN_LN_Alarm::bDec

void TYPE_LN_LN_Alarm::bDecContent(BUF_TYPE b,AsnTag,
        AsnLen len, AsnLen& bytesDecoded) {
    bool structDone = false;
    AsnLen elmtLen, localBytesDecoded = 0;
    AsnTag tagId;
    if (len == 0) { tagId = 0; structDone = true; }
    else tagId = BDecTag(b,localBytesDecoded);
    if (!structDone && (tagId==MAKE_TAG_ID(UNIV,CONS,16))) {
        elmtLen = BDecLen(b,localBytesDecoded);
        int pending_eoc = 0;
        if (elmtLen == INDEFINITE_LEN) ++pending_eoc;
        VAR_gpsTimeStamp().bDecContent(b,tagId,elmtLen,localBytesDecoded);
        for(;pending_eoc>0;--pending_eoc) { BDecEoc(b,localBytesDecoded); }
        if ((len!=INDEFINITE_LEN) && (localBytesDecoded>=len)) structDone = true;
        else tagId = BDecTag(b,localBytesDecoded);
    } else { TagError(MAKE_TAG_ID(UNIV,CONS,16),tagId); return; }
    if (!structDone && (tagId==MAKE_TAG_ID(UNIV,PRIM,2))) {
        elmtLen = BDecLen(b,localBytesDecoded);
        VAR_event().bDecContent(b,tagId,elmtLen,localBytesDecoded);
        if ((len!=INDEFINITE_LEN) && (localBytesDecoded>=len)) structDone = true;
        else tagId = BDecTag(b,localBytesDecoded);
    } else { TagError(MAKE_TAG_ID(UNIV,PRIM,2),tagId); return; }
    if (!structDone && (tagId==MAKE_TAG_ID(UNIV,CONS,17))) {
        elmtLen = BDecLen(b,localBytesDecoded);
        int pending_eoc = 0;
        if (elmtLen == INDEFINITE_LEN) ++pending_eoc;
        VAR_decisionMakingSNs().bDecContent(b,tagId,elmtLen,localBytesDecoded);
        for(;pending_eoc>0;--pending_eoc) { BDecEoc(b,localBytesDecoded); }
        if ((len!=INDEFINITE_LEN) && (localBytesDecoded>=len)) structDone = true;
        else tagId = BDecTag(b,localBytesDecoded);
    } else { TagError(MAKE_TAG_ID(UNIV,CONS,17),tagId); return; }
    complete_sequence_decoding(b, len, localBytesDecoded, tagId);
    bytesDecoded += localBytesDecoded;
    set_state(validValue);
} // TYPE_LN_LN_Alarm::bDecContent

AsnLen TYPE_LN_LN_Alarm::pEnc(BUF_TYPE2 b) const {
    int elmtLen=0;
    elmtLen += VAR_gpsTimeStamp().pEnc(b);
    elmtLen += VAR_event().pEnc(b);
    elmtLen += VAR_decisionMakingSNs().pEnc(b);
    return elmtLen;
}

void TYPE_LN_LN_Alarm::pDec(BUF_TYPE2 b) {
    VAR_gpsTimeStamp().pDec(b);
    VAR_event().pDec(b);
    VAR_decisionMakingSNs().pDec(b);
    set_state(validValue);
}

SDLSeqSetDescription TYPE_LN_LN_Description::_fdesc(2);

SDLType* TYPE_LN_LN_Description::copy()const { return new TYPE_LN_LN_Description(*this); }

void TYPE_LN_LN_Description::assign(const SDLType* t)
{
  const TYPE_LN_LN_Description *arg = SITE_DYNAMIC_CAST(const TYPE_LN_LN_Description*,t);
  if (!arg) SDLSequence::assign(t);
  else *this = *arg;
}

SDLType* TYPE_LN_LN_Description::create()
{
  static TYPE_LN_LN_Description* tmpl = new TYPE_LN_LN_Description;
  return tmpl;
}

const SDLType* TYPE_LN_LN_Description::create_new() const { return create(); }

TYPE_LN_LN_Description::TYPE_LN_LN_Description():SDLSequence(_fields,2){}
TYPE_LN_LN_Description::TYPE_LN_LN_Description(SDLType** f,unsigned long c):SDLSequence(f,c){}
TYPE_LN_LN_Description::TYPE_LN_LN_Description(const SDLNull&):SDLSequence(_fields,2)
{ set_state(invalidValue); }
TYPE_LN_LN_Description::TYPE_LN_LN_Description(const SDLAny& a, AsnCodingSet rule_set):SDLSequence(_fields,2){a.decode(this,rule_set);}
TYPE_LN_LN_Description::TYPE_LN_LN_Description(const TYPE_LN_LN_Description&o):SDLSequence(o){
  if (o.state(SITEtemporaryValue)) {
#ifdef SITE_LOG
    if (SDLType::_type_debug & SITE_COPY_LOG)
      CERR << "(SDLRTE) struct reference copy of " << o << ENDL;
#endif
    for(int i=0; i<2;++i) {
       _fields[i] = o._fields[i]; o._fields[i] = 0;
    }
  } else sequence_copyinit(_fields,o._fields,2);
}
TYPE_LN_LN_Description::~TYPE_LN_LN_Description(){clear_fields(_fields,2);}

TYPE_LN_LN_Description& TYPE_LN_LN_Description::operator=(const TYPE_LN_LN_Description& val){
  val.check_valid();
  if (this!=&val) sequence_assign(val);
  return *this;
}

unsigned int TYPE_LN_LN_Description::hash(unsigned int max_hash)const{
  return sequence_hash(_fields, 2, max_hash);
}

void TYPE_LN_LN_Description::get_fields(
  SDLSeqSetDescription*& d,SDLType **&field_list){
  d=&_fdesc; field_list=_fields;
}

void TYPE_LN_LN_Description::get_fields(
  SDLSeqSetDescription*& d,SDLType *const*&field_list) const{
  d=&_fdesc; field_list=_fields;
}


TYPE_DateTime& TYPE_LN_LN_Description::VAR_gpsTimeStamp() const
{ return *SITE_STATIC_CAST(TYPE_DateTime*,field_access(_fdesc,_fields,0)); }
static SDLSeqSetDescription::Field *_TYPE_LN_LN_DescriptiongpsTimeStamp=TYPE_LN_LN_Description::_fdesc.add(0,"gpsTimeStamp",&TYPE_DateTime::create,true);

TYPE_EventID& TYPE_LN_LN_Description::VAR_event() const
{ return *SITE_STATIC_CAST(TYPE_EventID*,field_access(_fdesc,_fields,1)); }

const SDLBool& TYPE_LN_LN_Description::eventPresent()const{
  return field_present(_fdesc,_fields,1);
}

TYPE_LN_LN_Description TYPE_LN_LN_Description::eventOmit()const{
  TYPE_LN_LN_Description c(*this);
  field_omit(_fdesc,c._fields,1);
  return c;
}

void TYPE_LN_LN_Description::_eventOmit() {
  field_omit(_fdesc,_fields,1);
}

static SDLSeqSetDescription::Field *_TYPE_LN_LN_Descriptionevent=TYPE_LN_LN_Description::_fdesc.add_optional(1,"event",&TYPE_EventID::create,true);



TYPE_LN_LN_Description::TYPE_LN_LN_Description(const class TYPE_DateTime& PAR_0, const class TYPE_EventID& PAR_1) {
    set_field(0,PAR_0.copy());
    if(PAR_1.valid())
        set_field(1,new TYPE_EventID(PAR_1));
    else
        set_field(1,0);
}

AsnLen TYPE_LN_LN_Description::bEnc(BUF_TYPE b) const{
    AsnLen elmtLen = bEncContent(b);
    elmtLen += BEncDefLen(b,elmtLen);
    elmtLen += BEncTag1(b,UNIV,CONS,16);
    return elmtLen;
} // TYPE_LN_LN_Description::bEnc

AsnLen TYPE_LN_LN_Description::bEncContent(BUF_TYPE b) const {
    AsnLen elmtLen, structBytesEncoded = BEncExtraFields(b);
    if (eventPresent().val()) {
        elmtLen = VAR_event().bEncContent(b);
        elmtLen += BEncDefLen(b,elmtLen);
        elmtLen += BEncTag1(b,UNIV,PRIM,2);
        elmtLen += BEncDefLen(b,elmtLen);
        elmtLen += BEncTag1(b,CNTX,CONS,1);
        structBytesEncoded += elmtLen;
    }
    elmtLen = VAR_gpsTimeStamp().bEncContent(b);
    elmtLen += BEncDefLen(b,elmtLen);
    elmtLen += BEncTag1(b,UNIV,CONS,16);
    structBytesEncoded += elmtLen;
    return structBytesEncoded;
} // TYPE_LN_LN_Description::bEncContent

void TYPE_LN_LN_Description::bDec(BUF_TYPE b,AsnLen& bytesDecoded) {
    AsnTag tagId = BDecTag1(b,bytesDecoded);
    AsnLen elmtLen;
    if (tagId != MAKE_TAG_ID(UNIV,CONS,16)) { TagError(MAKE_TAG_ID(UNIV,CONS,16),tagId); return; }
    elmtLen = BDecLen(b,bytesDecoded);
    int pending_eoc = 0;
    if (elmtLen == INDEFINITE_LEN) ++pending_eoc;
    AsnLen localBytesDecoded = 0;
    bDecContent(b,tagId,elmtLen,localBytesDecoded);
    for(;pending_eoc>0;--pending_eoc) { BDecEoc(b,localBytesDecoded); }
    bytesDecoded += localBytesDecoded;
} // TYPE_LN_LN_Description::bDec

void TYPE_LN_LN_Description::bDecContent(BUF_TYPE b,AsnTag,
        AsnLen len, AsnLen& bytesDecoded) {
    bool structDone = false;
    AsnLen elmtLen, localBytesDecoded = 0;
    AsnTag tagId;
    if (len == 0) { tagId = 0; structDone = true; }
    else tagId = BDecTag(b,localBytesDecoded);
    if (!structDone && (tagId==MAKE_TAG_ID(UNIV,CONS,16))) {
        elmtLen = BDecLen(b,localBytesDecoded);
        int pending_eoc = 0;
        if (elmtLen == INDEFINITE_LEN) ++pending_eoc;
        VAR_gpsTimeStamp().bDecContent(b,tagId,elmtLen,localBytesDecoded);
        for(;pending_eoc>0;--pending_eoc) { BDecEoc(b,localBytesDecoded); }
        if ((len!=INDEFINITE_LEN) && (localBytesDecoded>=len)) structDone = true;
        else tagId = BDecTag(b,localBytesDecoded);
    } else { TagError(MAKE_TAG_ID(UNIV,CONS,16),tagId); return; }
    if (!structDone && (tagId==MAKE_TAG_ID(CNTX,CONS,1))) {
        elmtLen = BDecLen(b,localBytesDecoded);
        int pending_eoc = 0;
        if (elmtLen == INDEFINITE_LEN) ++pending_eoc;
        tagId = BDecTag1(b,localBytesDecoded);
        if (tagId == MAKE_TAG_ID(UNIV,PRIM,2)) {
          elmtLen = BDecLen(b,localBytesDecoded);
        } else { TagError(MAKE_TAG_ID(UNIV,PRIM,2),tagId); return; }
        VAR_event().bDecContent(b,tagId,elmtLen,localBytesDecoded);
        for(;pending_eoc>0;--pending_eoc) { BDecEoc(b,localBytesDecoded); }
        if (len!=INDEFINITE_LEN && localBytesDecoded>=len) structDone = true;
        else tagId = BDecTag(b,localBytesDecoded);
    }
    complete_sequence_decoding(b, len, localBytesDecoded, tagId);
    bytesDecoded += localBytesDecoded;
    set_state(validValue);
} // TYPE_LN_LN_Description::bDecContent

AsnLen TYPE_LN_LN_Description::pEnc(BUF_TYPE2 b) const {
    int elmtLen=0;
    b.putBit(eventPresent().val()?true:false);
    elmtLen++;
    elmtLen += VAR_gpsTimeStamp().pEnc(b);
    if (eventPresent().val())
        elmtLen += VAR_event().pEnc(b);
    return elmtLen;
}

void TYPE_LN_LN_Description::pDec(BUF_TYPE2 b) {
    bool _field_present0 = b.getBit();
    VAR_gpsTimeStamp().pDec(b);
    if(_field_present0) VAR_event().pDec(b);
    set_state(validValue);
}

SDLSeqSetDescription TYPE_LN_EN_Alarm::_fdesc(3);

SDLType* TYPE_LN_EN_Alarm::copy()const { return new TYPE_LN_EN_Alarm(*this); }

void TYPE_LN_EN_Alarm::assign(const SDLType* t)
{
  const TYPE_LN_EN_Alarm *arg = SITE_DYNAMIC_CAST(const TYPE_LN_EN_Alarm*,t);
  if (!arg) SDLSequence::assign(t);
  else *this = *arg;
}

SDLType* TYPE_LN_EN_Alarm::create()
{
  static TYPE_LN_EN_Alarm* tmpl = new TYPE_LN_EN_Alarm;
  return tmpl;
}

const SDLType* TYPE_LN_EN_Alarm::create_new() const { return create(); }

TYPE_LN_EN_Alarm::TYPE_LN_EN_Alarm():SDLSequence(_fields,3){}
TYPE_LN_EN_Alarm::TYPE_LN_EN_Alarm(SDLType** f,unsigned long c):SDLSequence(f,c){}
TYPE_LN_EN_Alarm::TYPE_LN_EN_Alarm(const SDLNull&):SDLSequence(_fields,3)
{ set_state(invalidValue); }
TYPE_LN_EN_Alarm::TYPE_LN_EN_Alarm(const SDLAny& a, AsnCodingSet rule_set):SDLSequence(_fields,3){a.decode(this,rule_set);}
TYPE_LN_EN_Alarm::TYPE_LN_EN_Alarm(const TYPE_LN_EN_Alarm&o):SDLSequence(o){
  if (o.state(SITEtemporaryValue)) {
#ifdef SITE_LOG
    if (SDLType::_type_debug & SITE_COPY_LOG)
      CERR << "(SDLRTE) struct reference copy of " << o << ENDL;
#endif
    for(int i=0; i<3;++i) {
       _fields[i] = o._fields[i]; o._fields[i] = 0;
    }
  } else sequence_copyinit(_fields,o._fields,3);
}
TYPE_LN_EN_Alarm::~TYPE_LN_EN_Alarm(){clear_fields(_fields,3);}

TYPE_LN_EN_Alarm& TYPE_LN_EN_Alarm::operator=(const TYPE_LN_EN_Alarm& val){
  val.check_valid();
  if (this!=&val) sequence_assign(val);
  return *this;
}

unsigned int TYPE_LN_EN_Alarm::hash(unsigned int max_hash)const{
  return sequence_hash(_fields, 3, max_hash);
}

void TYPE_LN_EN_Alarm::get_fields(
  SDLSeqSetDescription*& d,SDLType **&field_list){
  d=&_fdesc; field_list=_fields;
}

void TYPE_LN_EN_Alarm::get_fields(
  SDLSeqSetDescription*& d,SDLType *const*&field_list) const{
  d=&_fdesc; field_list=_fields;
}


TYPE_DateTime& TYPE_LN_EN_Alarm::VAR_gpsTimeStamp() const
{ return *SITE_STATIC_CAST(TYPE_DateTime*,field_access(_fdesc,_fields,0)); }
static SDLSeqSetDescription::Field *_TYPE_LN_EN_AlarmgpsTimeStamp=TYPE_LN_EN_Alarm::_fdesc.add(0,"gpsTimeStamp",&TYPE_DateTime::create,true);

TYPE_EventID& TYPE_LN_EN_Alarm::VAR_event() const
{ return *SITE_STATIC_CAST(TYPE_EventID*,field_access(_fdesc,_fields,1)); }
static SDLSeqSetDescription::Field *_TYPE_LN_EN_Alarmevent=TYPE_LN_EN_Alarm::_fdesc.add(1,"event",&TYPE_EventID::create,true);

TYPE_APEWProtocol_GEN_15& TYPE_LN_EN_Alarm::VAR_decisionMakingSNs() const
{ return *SITE_STATIC_CAST(TYPE_APEWProtocol_GEN_15*,field_access(_fdesc,_fields,2)); }
static SDLSeqSetDescription::Field *_TYPE_LN_EN_AlarmdecisionMakingSNs=TYPE_LN_EN_Alarm::_fdesc.add(2,"decisionMakingSNs",&TYPE_APEWProtocol_GEN_15::create,true);



TYPE_LN_EN_Alarm::TYPE_LN_EN_Alarm(const class TYPE_DateTime& PAR_0, const class TYPE_EventID& PAR_1, const class TYPE_APEWProtocol_GEN_15& PAR_2) {
    set_field(0,PAR_0.copy());
    set_field(1,PAR_1.copy());
    set_field(2,PAR_2.copy());
}

AsnLen TYPE_LN_EN_Alarm::bEnc(BUF_TYPE b) const{
    AsnLen elmtLen = bEncContent(b);
    elmtLen += BEncDefLen(b,elmtLen);
    elmtLen += BEncTag1(b,UNIV,CONS,16);
    return elmtLen;
} // TYPE_LN_EN_Alarm::bEnc

AsnLen TYPE_LN_EN_Alarm::bEncContent(BUF_TYPE b) const {
    AsnLen elmtLen, structBytesEncoded = BEncExtraFields(b);
    elmtLen = VAR_decisionMakingSNs().bEncContent(b);
    elmtLen += BEncDefLen(b,elmtLen);
    elmtLen += BEncTag1(b,UNIV,CONS,17);
    structBytesEncoded += elmtLen;
    elmtLen = VAR_event().bEncContent(b);
    elmtLen += BEncDefLen(b,elmtLen);
    elmtLen += BEncTag1(b,UNIV,PRIM,2);
    structBytesEncoded += elmtLen;
    elmtLen = VAR_gpsTimeStamp().bEncContent(b);
    elmtLen += BEncDefLen(b,elmtLen);
    elmtLen += BEncTag1(b,UNIV,CONS,16);
    structBytesEncoded += elmtLen;
    return structBytesEncoded;
} // TYPE_LN_EN_Alarm::bEncContent

void TYPE_LN_EN_Alarm::bDec(BUF_TYPE b,AsnLen& bytesDecoded) {
    AsnTag tagId = BDecTag1(b,bytesDecoded);
    AsnLen elmtLen;
    if (tagId != MAKE_TAG_ID(UNIV,CONS,16)) { TagError(MAKE_TAG_ID(UNIV,CONS,16),tagId); return; }
    elmtLen = BDecLen(b,bytesDecoded);
    int pending_eoc = 0;
    if (elmtLen == INDEFINITE_LEN) ++pending_eoc;
    AsnLen localBytesDecoded = 0;
    bDecContent(b,tagId,elmtLen,localBytesDecoded);
    for(;pending_eoc>0;--pending_eoc) { BDecEoc(b,localBytesDecoded); }
    bytesDecoded += localBytesDecoded;
} // TYPE_LN_EN_Alarm::bDec

void TYPE_LN_EN_Alarm::bDecContent(BUF_TYPE b,AsnTag,
        AsnLen len, AsnLen& bytesDecoded) {
    bool structDone = false;
    AsnLen elmtLen, localBytesDecoded = 0;
    AsnTag tagId;
    if (len == 0) { tagId = 0; structDone = true; }
    else tagId = BDecTag(b,localBytesDecoded);
    if (!structDone && (tagId==MAKE_TAG_ID(UNIV,CONS,16))) {
        elmtLen = BDecLen(b,localBytesDecoded);
        int pending_eoc = 0;
        if (elmtLen == INDEFINITE_LEN) ++pending_eoc;
        VAR_gpsTimeStamp().bDecContent(b,tagId,elmtLen,localBytesDecoded);
        for(;pending_eoc>0;--pending_eoc) { BDecEoc(b,localBytesDecoded); }
        if ((len!=INDEFINITE_LEN) && (localBytesDecoded>=len)) structDone = true;
        else tagId = BDecTag(b,localBytesDecoded);
    } else { TagError(MAKE_TAG_ID(UNIV,CONS,16),tagId); return; }
    if (!structDone && (tagId==MAKE_TAG_ID(UNIV,PRIM,2))) {
        elmtLen = BDecLen(b,localBytesDecoded);
        VAR_event().bDecContent(b,tagId,elmtLen,localBytesDecoded);
        if ((len!=INDEFINITE_LEN) && (localBytesDecoded>=len)) structDone = true;
        else tagId = BDecTag(b,localBytesDecoded);
    } else { TagError(MAKE_TAG_ID(UNIV,PRIM,2),tagId); return; }
    if (!structDone && (tagId==MAKE_TAG_ID(UNIV,CONS,17))) {
        elmtLen = BDecLen(b,localBytesDecoded);
        int pending_eoc = 0;
        if (elmtLen == INDEFINITE_LEN) ++pending_eoc;
        VAR_decisionMakingSNs().bDecContent(b,tagId,elmtLen,localBytesDecoded);
        for(;pending_eoc>0;--pending_eoc) { BDecEoc(b,localBytesDecoded); }
        if ((len!=INDEFINITE_LEN) && (localBytesDecoded>=len)) structDone = true;
        else tagId = BDecTag(b,localBytesDecoded);
    } else { TagError(MAKE_TAG_ID(UNIV,CONS,17),tagId); return; }
    complete_sequence_decoding(b, len, localBytesDecoded, tagId);
    bytesDecoded += localBytesDecoded;
    set_state(validValue);
} // TYPE_LN_EN_Alarm::bDecContent

AsnLen TYPE_LN_EN_Alarm::pEnc(BUF_TYPE2 b) const {
    int elmtLen=0;
    elmtLen += VAR_gpsTimeStamp().pEnc(b);
    elmtLen += VAR_event().pEnc(b);
    elmtLen += VAR_decisionMakingSNs().pEnc(b);
    return elmtLen;
}

void TYPE_LN_EN_Alarm::pDec(BUF_TYPE2 b) {
    VAR_gpsTimeStamp().pDec(b);
    VAR_event().pDec(b);
    VAR_decisionMakingSNs().pDec(b);
    set_state(validValue);
}

SDLSeqSetDescription TYPE_LN_EN_Summary::_fdesc(6);

SDLType* TYPE_LN_EN_Summary::copy()const { return new TYPE_LN_EN_Summary(*this); }

void TYPE_LN_EN_Summary::assign(const SDLType* t)
{
  const TYPE_LN_EN_Summary *arg = SITE_DYNAMIC_CAST(const TYPE_LN_EN_Summary*,t);
  if (!arg) SDLSequence::assign(t);
  else *this = *arg;
}

SDLType* TYPE_LN_EN_Summary::create()
{
  static TYPE_LN_EN_Summary* tmpl = new TYPE_LN_EN_Summary;
  return tmpl;
}

const SDLType* TYPE_LN_EN_Summary::create_new() const { return create(); }

TYPE_LN_EN_Summary::TYPE_LN_EN_Summary():SDLSequence(_fields,6){}
TYPE_LN_EN_Summary::TYPE_LN_EN_Summary(SDLType** f,unsigned long c):SDLSequence(f,c){}
TYPE_LN_EN_Summary::TYPE_LN_EN_Summary(const SDLNull&):SDLSequence(_fields,6)
{ set_state(invalidValue); }
TYPE_LN_EN_Summary::TYPE_LN_EN_Summary(const SDLAny& a, AsnCodingSet rule_set):SDLSequence(_fields,6){a.decode(this,rule_set);}
TYPE_LN_EN_Summary::TYPE_LN_EN_Summary(const TYPE_LN_EN_Summary&o):SDLSequence(o){
  if (o.state(SITEtemporaryValue)) {
#ifdef SITE_LOG
    if (SDLType::_type_debug & SITE_COPY_LOG)
      CERR << "(SDLRTE) struct reference copy of " << o << ENDL;
#endif
    for(int i=0; i<6;++i) {
       _fields[i] = o._fields[i]; o._fields[i] = 0;
    }
  } else sequence_copyinit(_fields,o._fields,6);
}
TYPE_LN_EN_Summary::~TYPE_LN_EN_Summary(){clear_fields(_fields,6);}

TYPE_LN_EN_Summary& TYPE_LN_EN_Summary::operator=(const TYPE_LN_EN_Summary& val){
  val.check_valid();
  if (this!=&val) sequence_assign(val);
  return *this;
}

unsigned int TYPE_LN_EN_Summary::hash(unsigned int max_hash)const{
  return sequence_hash(_fields, 6, max_hash);
}

void TYPE_LN_EN_Summary::get_fields(
  SDLSeqSetDescription*& d,SDLType **&field_list){
  d=&_fdesc; field_list=_fields;
}

void TYPE_LN_EN_Summary::get_fields(
  SDLSeqSetDescription*& d,SDLType *const*&field_list) const{
  d=&_fdesc; field_list=_fields;
}


TYPE_DateTime& TYPE_LN_EN_Summary::VAR_gpsTimeStamp() const
{ return *SITE_STATIC_CAST(TYPE_DateTime*,field_access(_fdesc,_fields,0)); }
static SDLSeqSetDescription::Field *_TYPE_LN_EN_SummarygpsTimeStamp=TYPE_LN_EN_Summary::_fdesc.add(0,"gpsTimeStamp",&TYPE_DateTime::create,true);

TYPE_EventID& TYPE_LN_EN_Summary::VAR_event() const
{ return *SITE_STATIC_CAST(TYPE_EventID*,field_access(_fdesc,_fields,1)); }
static SDLSeqSetDescription::Field *_TYPE_LN_EN_Summaryevent=TYPE_LN_EN_Summary::_fdesc.add(1,"event",&TYPE_EventID::create,true);

TYPE_APEWProtocol_GEN_16& TYPE_LN_EN_Summary::VAR_operativeSNs() const
{ return *SITE_STATIC_CAST(TYPE_APEWProtocol_GEN_16*,field_access(_fdesc,_fields,2)); }
static SDLSeqSetDescription::Field *_TYPE_LN_EN_SummaryoperativeSNs=TYPE_LN_EN_Summary::_fdesc.add(2,"operativeSNs",&TYPE_APEWProtocol_GEN_16::create,true);

TYPE_APEWProtocol_GEN_17& TYPE_LN_EN_Summary::VAR_inoperativeSNs() const
{ return *SITE_STATIC_CAST(TYPE_APEWProtocol_GEN_17*,field_access(_fdesc,_fields,3)); }
static SDLSeqSetDescription::Field *_TYPE_LN_EN_SummaryinoperativeSNs=TYPE_LN_EN_Summary::_fdesc.add(3,"inoperativeSNs",&TYPE_APEWProtocol_GEN_17::create,true);

TYPE_APEWProtocol_GEN_18& TYPE_LN_EN_Summary::VAR_decisionMakingSNs() const
{ return *SITE_STATIC_CAST(TYPE_APEWProtocol_GEN_18*,field_access(_fdesc,_fields,4)); }
static SDLSeqSetDescription::Field *_TYPE_LN_EN_SummarydecisionMakingSNs=TYPE_LN_EN_Summary::_fdesc.add(4,"decisionMakingSNs",&TYPE_APEWProtocol_GEN_18::create,true);

SDLReal& TYPE_LN_EN_Summary::VAR_ariasIntensity() const
{ return *SITE_STATIC_CAST(SDLReal*,field_access(_fdesc,_fields,5)); }
static SDLSeqSetDescription::Field *_TYPE_LN_EN_SummaryariasIntensity=TYPE_LN_EN_Summary::_fdesc.add(5,"ariasIntensity",&SDLReal::create,true);



TYPE_LN_EN_Summary::TYPE_LN_EN_Summary(const class TYPE_DateTime& PAR_0, const class TYPE_EventID& PAR_1, const class TYPE_APEWProtocol_GEN_16& PAR_2, const class TYPE_APEWProtocol_GEN_17& PAR_3, const class TYPE_APEWProtocol_GEN_18& PAR_4, const class SDLReal& PAR_5) {
    set_field(0,PAR_0.copy());
    set_field(1,PAR_1.copy());
    set_field(2,PAR_2.copy());
    set_field(3,PAR_3.copy());
    set_field(4,PAR_4.copy());
    set_field(5,PAR_5.copy());
}

AsnLen TYPE_LN_EN_Summary::bEnc(BUF_TYPE b) const{
    AsnLen elmtLen = bEncContent(b);
    elmtLen += BEncDefLen(b,elmtLen);
    elmtLen += BEncTag1(b,UNIV,CONS,16);
    return elmtLen;
} // TYPE_LN_EN_Summary::bEnc

AsnLen TYPE_LN_EN_Summary::bEncContent(BUF_TYPE b) const {
    AsnLen elmtLen, structBytesEncoded = BEncExtraFields(b);
    elmtLen = VAR_ariasIntensity().bEncContent(b);
    elmtLen += BEncDefLen(b,elmtLen);
    elmtLen += BEncTag1(b,UNIV,PRIM,9);
    structBytesEncoded += elmtLen;
    elmtLen = VAR_decisionMakingSNs().bEncContent(b);
    elmtLen += BEncDefLen(b,elmtLen);
    elmtLen += BEncTag1(b,UNIV,CONS,17);
    structBytesEncoded += elmtLen;
    elmtLen = VAR_inoperativeSNs().bEncContent(b);
    elmtLen += BEncDefLen(b,elmtLen);
    elmtLen += BEncTag1(b,UNIV,CONS,17);
    structBytesEncoded += elmtLen;
    elmtLen = VAR_operativeSNs().bEncContent(b);
    elmtLen += BEncDefLen(b,elmtLen);
    elmtLen += BEncTag1(b,UNIV,CONS,17);
    structBytesEncoded += elmtLen;
    elmtLen = VAR_event().bEncContent(b);
    elmtLen += BEncDefLen(b,elmtLen);
    elmtLen += BEncTag1(b,UNIV,PRIM,2);
    structBytesEncoded += elmtLen;
    elmtLen = VAR_gpsTimeStamp().bEncContent(b);
    elmtLen += BEncDefLen(b,elmtLen);
    elmtLen += BEncTag1(b,UNIV,CONS,16);
    structBytesEncoded += elmtLen;
    return structBytesEncoded;
} // TYPE_LN_EN_Summary::bEncContent

void TYPE_LN_EN_Summary::bDec(BUF_TYPE b,AsnLen& bytesDecoded) {
    AsnTag tagId = BDecTag1(b,bytesDecoded);
    AsnLen elmtLen;
    if (tagId != MAKE_TAG_ID(UNIV,CONS,16)) { TagError(MAKE_TAG_ID(UNIV,CONS,16),tagId); return; }
    elmtLen = BDecLen(b,bytesDecoded);
    int pending_eoc = 0;
    if (elmtLen == INDEFINITE_LEN) ++pending_eoc;
    AsnLen localBytesDecoded = 0;
    bDecContent(b,tagId,elmtLen,localBytesDecoded);
    for(;pending_eoc>0;--pending_eoc) { BDecEoc(b,localBytesDecoded); }
    bytesDecoded += localBytesDecoded;
} // TYPE_LN_EN_Summary::bDec

void TYPE_LN_EN_Summary::bDecContent(BUF_TYPE b,AsnTag,
        AsnLen len, AsnLen& bytesDecoded) {
    bool structDone = false;
    AsnLen elmtLen, localBytesDecoded = 0;
    AsnTag tagId;
    if (len == 0) { tagId = 0; structDone = true; }
    else tagId = BDecTag(b,localBytesDecoded);
    if (!structDone && (tagId==MAKE_TAG_ID(UNIV,CONS,16))) {
        elmtLen = BDecLen(b,localBytesDecoded);
        int pending_eoc = 0;
        if (elmtLen == INDEFINITE_LEN) ++pending_eoc;
        VAR_gpsTimeStamp().bDecContent(b,tagId,elmtLen,localBytesDecoded);
        for(;pending_eoc>0;--pending_eoc) { BDecEoc(b,localBytesDecoded); }
        if ((len!=INDEFINITE_LEN) && (localBytesDecoded>=len)) structDone = true;
        else tagId = BDecTag(b,localBytesDecoded);
    } else { TagError(MAKE_TAG_ID(UNIV,CONS,16),tagId); return; }
    if (!structDone && (tagId==MAKE_TAG_ID(UNIV,PRIM,2))) {
        elmtLen = BDecLen(b,localBytesDecoded);
        VAR_event().bDecContent(b,tagId,elmtLen,localBytesDecoded);
        if ((len!=INDEFINITE_LEN) && (localBytesDecoded>=len)) structDone = true;
        else tagId = BDecTag(b,localBytesDecoded);
    } else { TagError(MAKE_TAG_ID(UNIV,PRIM,2),tagId); return; }
    if (!structDone && (tagId==MAKE_TAG_ID(UNIV,CONS,17))) {
        elmtLen = BDecLen(b,localBytesDecoded);
        int pending_eoc = 0;
        if (elmtLen == INDEFINITE_LEN) ++pending_eoc;
        VAR_operativeSNs().bDecContent(b,tagId,elmtLen,localBytesDecoded);
        for(;pending_eoc>0;--pending_eoc) { BDecEoc(b,localBytesDecoded); }
        if ((len!=INDEFINITE_LEN) && (localBytesDecoded>=len)) structDone = true;
        else tagId = BDecTag(b,localBytesDecoded);
    } else { TagError(MAKE_TAG_ID(UNIV,CONS,17),tagId); return; }
    if (!structDone && (tagId==MAKE_TAG_ID(UNIV,CONS,17))) {
        elmtLen = BDecLen(b,localBytesDecoded);
        int pending_eoc = 0;
        if (elmtLen == INDEFINITE_LEN) ++pending_eoc;
        VAR_inoperativeSNs().bDecContent(b,tagId,elmtLen,localBytesDecoded);
        for(;pending_eoc>0;--pending_eoc) { BDecEoc(b,localBytesDecoded); }
        if ((len!=INDEFINITE_LEN) && (localBytesDecoded>=len)) structDone = true;
        else tagId = BDecTag(b,localBytesDecoded);
    } else { TagError(MAKE_TAG_ID(UNIV,CONS,17),tagId); return; }
    if (!structDone && (tagId==MAKE_TAG_ID(UNIV,CONS,17))) {
        elmtLen = BDecLen(b,localBytesDecoded);
        int pending_eoc = 0;
        if (elmtLen == INDEFINITE_LEN) ++pending_eoc;
        VAR_decisionMakingSNs().bDecContent(b,tagId,elmtLen,localBytesDecoded);
        for(;pending_eoc>0;--pending_eoc) { BDecEoc(b,localBytesDecoded); }
        if ((len!=INDEFINITE_LEN) && (localBytesDecoded>=len)) structDone = true;
        else tagId = BDecTag(b,localBytesDecoded);
    } else { TagError(MAKE_TAG_ID(UNIV,CONS,17),tagId); return; }
    if (!structDone && (tagId==MAKE_TAG_ID(UNIV,PRIM,9))) {
        elmtLen = BDecLen(b,localBytesDecoded);
        VAR_ariasIntensity().bDecContent(b,tagId,elmtLen,localBytesDecoded);
        if ((len!=INDEFINITE_LEN) && (localBytesDecoded>=len)) structDone = true;
        else tagId = BDecTag(b,localBytesDecoded);
    } else { TagError(MAKE_TAG_ID(UNIV,PRIM,9),tagId); return; }
    complete_sequence_decoding(b, len, localBytesDecoded, tagId);
    bytesDecoded += localBytesDecoded;
    set_state(validValue);
} // TYPE_LN_EN_Summary::bDecContent

AsnLen TYPE_LN_EN_Summary::pEnc(BUF_TYPE2 b) const {
    int elmtLen=0;
    elmtLen += VAR_gpsTimeStamp().pEnc(b);
    elmtLen += VAR_event().pEnc(b);
    elmtLen += VAR_operativeSNs().pEnc(b);
    elmtLen += VAR_inoperativeSNs().pEnc(b);
    elmtLen += VAR_decisionMakingSNs().pEnc(b);
    elmtLen += VAR_ariasIntensity().pEnc(b);
    return elmtLen;
}

void TYPE_LN_EN_Summary::pDec(BUF_TYPE2 b) {
    VAR_gpsTimeStamp().pDec(b);
    VAR_event().pDec(b);
    VAR_operativeSNs().pDec(b);
    VAR_inoperativeSNs().pDec(b);
    VAR_decisionMakingSNs().pDec(b);
    VAR_ariasIntensity().pDec(b);
    set_state(validValue);
}

TYPE_APEWProtocol_GEN_1::TYPE_APEWProtocol_GEN_1(const SDLAny& a, AsnCodingSet rule_set){                                      a.decode(this,rule_set); }

SDLType* TYPE_APEWProtocol_GEN_1::copy()const { return new TYPE_APEWProtocol_GEN_1(*this); }

void TYPE_APEWProtocol_GEN_1::assign(const SDLType* t)
{
  const TYPE_APEWProtocol_GEN_1 *arg = SITE_DYNAMIC_CAST(const TYPE_APEWProtocol_GEN_1*,t);
  if (!arg) SDLInt::assign(t);
  else *this = *arg;
}

SDLType* TYPE_APEWProtocol_GEN_1::create()
{
  static TYPE_APEWProtocol_GEN_1* tmpl = new TYPE_APEWProtocol_GEN_1;
  return tmpl;
}

const SDLType* TYPE_APEWProtocol_GEN_1::create_new() const { return create(); }

AsnLen TYPE_APEWProtocol_GEN_1::pEnc(BUF_TYPE2 b) const {
    SITE_SDL_UINT off = _value - 0LL;
    SITE_SDL_UINT mask = 0xff00000000000000LL;
    int len;
    for(len=8; len>1; mask>>8,len--)
        if(off & mask) break;
    pEncLen(b, len);
    for(int i=len-1; i>=0; mask>>=8,i--)
        b.putByte(static_cast<char>((off & mask)>>(i*8)));
    return 8*(len+1);
}

void TYPE_APEWProtocol_GEN_1::pDec(BUF_TYPE2 b) {
    /* PER UNALIGNED VARIANT */
    SITE_SDL_UINT off = 0;
    int len = pDecLen(b);
    for(int i=0; i<len; i++)
        off = (off << 8) | b.getByte();
    _value = off + 0LL;
    set_state(validValue);
}

const SDLBool& TYPE_APEWProtocol_GEN_1::check() const{
    if(((ge(0))&&true /* half open intervall */)) return SDLBool::SDLTrue();
    return SDLBool::SDLFalse();
}

TYPE_APEWProtocol_GEN_2::TYPE_APEWProtocol_GEN_2(const SDLAny& a, AsnCodingSet rule_set){                                      a.decode(this,rule_set); }

SDLType* TYPE_APEWProtocol_GEN_2::copy()const { return new TYPE_APEWProtocol_GEN_2(*this); }

void TYPE_APEWProtocol_GEN_2::assign(const SDLType* t)
{
  const TYPE_APEWProtocol_GEN_2 *arg = SITE_DYNAMIC_CAST(const TYPE_APEWProtocol_GEN_2*,t);
  if (!arg) SDLInt::assign(t);
  else *this = *arg;
}

SDLType* TYPE_APEWProtocol_GEN_2::create()
{
  static TYPE_APEWProtocol_GEN_2* tmpl = new TYPE_APEWProtocol_GEN_2;
  return tmpl;
}

const SDLType* TYPE_APEWProtocol_GEN_2::create_new() const { return create(); }

AsnLen TYPE_APEWProtocol_GEN_2::pEnc(BUF_TYPE2 b) const {
    /* PER UNALIGNED VARIANT */
    SITE_SDL_UINT off = _value - 0LL;
    SITE_SDL_UINT mask = 0x200LL;
    for(int i=0; i<2; mask>>=1,i++)
      b.putBit(off & mask);
    mask = 0xffLL;
    for(int i=0; i>=0; mask>>=8,i--)
      b.putByte(static_cast<Byte>((off & mask)>>(i*8)));
    return 10;
}

void TYPE_APEWProtocol_GEN_2::pDec(BUF_TYPE2 b) {
    SITE_SDL_UINT off = 0;
    for(int i=0; i<2; i++)
      off = (off << 1) | (b.getBit()?1:0);
    for(int i=0; i<1; i++)
      off = (off << 8) | b.getByte();
    _value = off + 0LL;
    set_state(validValue);
}

const SDLBool& TYPE_APEWProtocol_GEN_2::check() const{
    if(((ge(0))&&(le(1000)))) return SDLBool::SDLTrue();
    return SDLBool::SDLFalse();
}

TYPE_APEWProtocol_GEN_3::TYPE_APEWProtocol_GEN_3(const SDLAny& a, AsnCodingSet rule_set){                                      a.decode(this,rule_set); }

SDLType* TYPE_APEWProtocol_GEN_3::copy()const { return new TYPE_APEWProtocol_GEN_3(*this); }

void TYPE_APEWProtocol_GEN_3::assign(const SDLType* t)
{
  const TYPE_APEWProtocol_GEN_3 *arg = SITE_DYNAMIC_CAST(const TYPE_APEWProtocol_GEN_3*,t);
  if (!arg) SDLReal::assign(t);
  else *this = *arg;
}

SDLType* TYPE_APEWProtocol_GEN_3::create()
{
  static TYPE_APEWProtocol_GEN_3* tmpl = new TYPE_APEWProtocol_GEN_3;
  return tmpl;
}

const SDLType* TYPE_APEWProtocol_GEN_3::create_new() const { return create(); }

const SDLBool& TYPE_APEWProtocol_GEN_3::check() const{
    if(((ge(SDLReal(90).neg()))&&(le(90)))) return SDLBool::SDLTrue();
    return SDLBool::SDLFalse();
}

TYPE_APEWProtocol_GEN_4::TYPE_APEWProtocol_GEN_4(const SDLAny& a, AsnCodingSet rule_set){                                      a.decode(this,rule_set); }

SDLType* TYPE_APEWProtocol_GEN_4::copy()const { return new TYPE_APEWProtocol_GEN_4(*this); }

void TYPE_APEWProtocol_GEN_4::assign(const SDLType* t)
{
  const TYPE_APEWProtocol_GEN_4 *arg = SITE_DYNAMIC_CAST(const TYPE_APEWProtocol_GEN_4*,t);
  if (!arg) SDLReal::assign(t);
  else *this = *arg;
}

SDLType* TYPE_APEWProtocol_GEN_4::create()
{
  static TYPE_APEWProtocol_GEN_4* tmpl = new TYPE_APEWProtocol_GEN_4;
  return tmpl;
}

const SDLType* TYPE_APEWProtocol_GEN_4::create_new() const { return create(); }

const SDLBool& TYPE_APEWProtocol_GEN_4::check() const{
    if(((ge(SDLReal(180).neg()))&&(le(180)))) return SDLBool::SDLTrue();
    return SDLBool::SDLFalse();
}

TYPE_APEWProtocol_GEN_5::TYPE_APEWProtocol_GEN_5(const SDLAny& a, AsnCodingSet rule_set){                                      a.decode(this,rule_set); }

SDLType* TYPE_APEWProtocol_GEN_5::copy()const { return new TYPE_APEWProtocol_GEN_5(*this); }

void TYPE_APEWProtocol_GEN_5::assign(const SDLType* t)
{
  const TYPE_APEWProtocol_GEN_5 *arg = SITE_DYNAMIC_CAST(const TYPE_APEWProtocol_GEN_5*,t);
  if (!arg) TYPE_APEWProtocol_GEN_6::assign(t);
  else *this = *arg;
}

SDLType* TYPE_APEWProtocol_GEN_5::create()
{
  static TYPE_APEWProtocol_GEN_5* tmpl = new TYPE_APEWProtocol_GEN_5;
  return tmpl;
}

const SDLType* TYPE_APEWProtocol_GEN_5::create_new() const { return create(); }

AsnLen TYPE_APEWProtocol_GEN_5::bEnc(BUF_TYPE b) const {
    AsnLen elmtLen = bEncContent(b);
    elmtLen += BEncDefLen(b,elmtLen);
    elmtLen += BEncTag1(b,UNIV,PRIM,9);
    elmtLen += BEncDefLen(b,elmtLen);
    elmtLen += BEncTag1(b,CNTX,CONS,1);
    return elmtLen;
} // TYPE_APEWProtocol_GEN_5::bEnc

void TYPE_APEWProtocol_GEN_5::bDec(BUF_TYPE b,AsnLen& bytesDecoded) {
    AsnTag tagId = BDecTag1(b,bytesDecoded);
    AsnLen elmtLen;
    if (tagId != MAKE_TAG_ID(CNTX,CONS,1)) { TagError(MAKE_TAG_ID(CNTX,CONS,1),tagId); return; }
    elmtLen = BDecLen(b,bytesDecoded);
    int pending_eoc = 0;
    if (elmtLen == INDEFINITE_LEN) ++pending_eoc;
    AsnLen localBytesDecoded = 0;
    tagId = BDecTag1(b,localBytesDecoded);
    if (tagId == MAKE_TAG_ID(UNIV,PRIM,9)) {
      elmtLen = BDecLen(b,localBytesDecoded);
    } else { TagError(MAKE_TAG_ID(UNIV,PRIM,9),tagId); return; }
    bDecContent(b,tagId,elmtLen,localBytesDecoded);
    for(;pending_eoc>0;--pending_eoc) { BDecEoc(b,localBytesDecoded); }
    bytesDecoded += localBytesDecoded;
} // TYPE_APEWProtocol_GEN_5::bDec

const SDLBool& TYPE_APEWProtocol_GEN_5::check() const{
    if(((ge(SDLReal(1000).neg()))&&(le(10000)))) return SDLBool::SDLTrue();
    return SDLBool::SDLFalse();
}

// data type "TYPE_APEWProtocol_GEN_6" is just a #define

TYPE_APEWProtocol_GEN_7::TYPE_APEWProtocol_GEN_7(const SDLAny& a, AsnCodingSet rule_set){                                      a.decode(this,rule_set); }

SDLType* TYPE_APEWProtocol_GEN_7::copy()const { return new TYPE_APEWProtocol_GEN_7(*this); }

void TYPE_APEWProtocol_GEN_7::assign(const SDLType* t)
{
  const TYPE_APEWProtocol_GEN_7 *arg = SITE_DYNAMIC_CAST(const TYPE_APEWProtocol_GEN_7*,t);
  if (!arg) SDLInt::assign(t);
  else *this = *arg;
}

SDLType* TYPE_APEWProtocol_GEN_7::create()
{
  static TYPE_APEWProtocol_GEN_7* tmpl = new TYPE_APEWProtocol_GEN_7;
  return tmpl;
}

const SDLType* TYPE_APEWProtocol_GEN_7::create_new() const { return create(); }

AsnLen TYPE_APEWProtocol_GEN_7::pEnc(BUF_TYPE2 b) const {
    /* PER UNALIGNED VARIANT */
    SITE_SDL_UINT off = _value - 0LL;
    SITE_SDL_UINT mask = 0x2000LL;
    for(int i=0; i<6; mask>>=1,i++)
      b.putBit(off & mask);
    mask = 0xffLL;
    for(int i=0; i>=0; mask>>=8,i--)
      b.putByte(static_cast<Byte>((off & mask)>>(i*8)));
    return 14;
}

void TYPE_APEWProtocol_GEN_7::pDec(BUF_TYPE2 b) {
    SITE_SDL_UINT off = 0;
    for(int i=0; i<6; i++)
      off = (off << 1) | (b.getBit()?1:0);
    for(int i=0; i<1; i++)
      off = (off << 8) | b.getByte();
    _value = off + 0LL;
    set_state(validValue);
}

const SDLBool& TYPE_APEWProtocol_GEN_7::check() const{
    if(((ge(0))&&(le(10000)))) return SDLBool::SDLTrue();
    return SDLBool::SDLFalse();
}

TYPE_APEWProtocol_GEN_8::TYPE_APEWProtocol_GEN_8(const SDLAny& a, AsnCodingSet rule_set){                                      a.decode(this,rule_set); }

SDLType* TYPE_APEWProtocol_GEN_8::copy()const { return new TYPE_APEWProtocol_GEN_8(*this); }

void TYPE_APEWProtocol_GEN_8::assign(const SDLType* t)
{
  const TYPE_APEWProtocol_GEN_8 *arg = SITE_DYNAMIC_CAST(const TYPE_APEWProtocol_GEN_8*,t);
  if (!arg) SDLEnum::assign(t);
  else *this = *arg;
}

SDLType* TYPE_APEWProtocol_GEN_8::create()
{
  static TYPE_APEWProtocol_GEN_8* tmpl = new TYPE_APEWProtocol_GEN_8;
  return tmpl;
}

const SDLType* TYPE_APEWProtocol_GEN_8::create_new() const { return create(); }

const TYPE_APEWProtocol_GEN_8& TYPE_APEWProtocol_GEN_8::LIT_pWave() {
    static TYPE_APEWProtocol_GEN_8 v(1);
    return v;
}

const TYPE_APEWProtocol_GEN_8& TYPE_APEWProtocol_GEN_8::LIT_sWave() {
    static TYPE_APEWProtocol_GEN_8 v(2);
    return v;
}

AsnLen TYPE_APEWProtocol_GEN_8::pEnc(BUF_TYPE2 b) const {
    SITE_SDL_UINT off;
    switch(_value){
        case 1: off = 0; break;
        case 2: off = 1; break;
        default: raise(new SDLCodingError("Encoding of ASN enum: value invalid"));}
    return pEncSmallNumber(b, off);
}

void TYPE_APEWProtocol_GEN_8::pDec(BUF_TYPE2 b) {
    SITE_SDL_UINT off=pDecSmallNumber(b);
    switch(off){
        case 0: _value = 1; break;
        case 1: _value = 2; break;
        default: raise(new SDLCodingError("Decoding of ASN enum: value invalid"));}
    set_state(validValue);
}

bool TYPE_APEWProtocol_GEN_8::datainfo(long index,SDLIA5String& var_name,
          const SDLType*& var)const
{
    switch(index) {
        case 1: var_name="pWave";var=&LIT_pWave();break;
        case 2: var_name="sWave";var=&LIT_sWave();break;
        default: return SDLEnum::datainfo(index,var_name,var);
    }
    return true;
} /* TYPE_APEWProtocol_GEN_8::datainfo */

int TYPE_APEWProtocol_GEN_8::nr_literals() const { return SDLEnum::nr_literals()+2; }

bool TYPE_APEWProtocol_GEN_8::get_literal(int index,const SDLEnum** literal,long* enum_val)const
{
    switch(index) {
        case 1: *literal=&LIT_pWave();*enum_val=LIT_pWave().val();break;
        case 2: *literal=&LIT_sWave();*enum_val=LIT_sWave().val();break;
        default: return SDLEnum::get_literal(index,literal,enum_val);
    }
    return true;
} /* TYPE_APEWProtocol_GEN_8::get_literal */

TYPE_APEWProtocol_GEN_9::TYPE_APEWProtocol_GEN_9(const SDLAny& a, AsnCodingSet rule_set){                                      a.decode(this,rule_set); }

SDLType* TYPE_APEWProtocol_GEN_9::copy()const { return new TYPE_APEWProtocol_GEN_9(*this); }

void TYPE_APEWProtocol_GEN_9::assign(const SDLType* t)
{
  const TYPE_APEWProtocol_GEN_9 *arg = SITE_DYNAMIC_CAST(const TYPE_APEWProtocol_GEN_9*,t);
  if (!arg) super::assign(t);
  else *this = *arg;
}

SDLType* TYPE_APEWProtocol_GEN_9::create()
{
  static TYPE_APEWProtocol_GEN_9* tmpl = new TYPE_APEWProtocol_GEN_9;
  return tmpl;
}

const SDLType* TYPE_APEWProtocol_GEN_9::create_new() const { return create(); }


AsnLen TYPE_APEWProtocol_GEN_9::bEnc(BUF_TYPE b) const {
    AsnLen elmtLen = bEncContent(b);
    elmtLen += BEncDefLen(b,elmtLen);
    elmtLen += BEncTag1(b,UNIV,CONS,17);
    return elmtLen;
} // TYPE_APEWProtocol_GEN_9::bEnc

AsnLen TYPE_APEWProtocol_GEN_9::bEncContent(BUF_TYPE b) const {
    AsnLen elmtLen, localBytesEncoded = 0;
    for(SITE_SDL_INT i=lengthAsLong(); i>0; i--) {
        elmtLen = elem(i)->bEncContent(b);
        elmtLen += BEncDefLen(b,elmtLen);
        elmtLen += BEncTag1(b,UNIV,CONS,16);
        localBytesEncoded += elmtLen;
    }
    return localBytesEncoded;
} // TYPE_APEWProtocol_GEN_9::bEncContent

void TYPE_APEWProtocol_GEN_9::bDec(BUF_TYPE b,AsnLen& bytesDecoded) {
    AsnTag tagId = BDecTag1(b,bytesDecoded);
    AsnLen elmtLen;
    if (tagId != MAKE_TAG_ID(UNIV,CONS,17)) { TagError(MAKE_TAG_ID(UNIV,CONS,17),tagId); return; }
    elmtLen = BDecLen(b,bytesDecoded);
    int pending_eoc = 0;
    if (elmtLen == INDEFINITE_LEN) ++pending_eoc;
    AsnLen localBytesDecoded = 0;
    bDecContent(b,tagId,elmtLen,localBytesDecoded);
    for(;pending_eoc>0;--pending_eoc) { BDecEoc(b,localBytesDecoded); }
    bytesDecoded += localBytesDecoded;
} // TYPE_APEWProtocol_GEN_9::bDec

void TYPE_APEWProtocol_GEN_9::bDecContent(BUF_TYPE b,AsnTag,
        AsnLen len, AsnLen& bytesDecoded) {
    AsnLen elmtLen, localBytesDecoded = 0;
    for(int i=1; (localBytesDecoded<len) || (len==INDEFINITE_LEN); i++) {
        AsnTag tagId = BDecTag1(b,localBytesDecoded);
        if (tagId == MAKE_TAG_ID(UNIV,CONS,16)) {
            elmtLen = BDecLen(b,localBytesDecoded);
            int pending_eoc = 0;
            if (elmtLen == INDEFINITE_LEN) ++pending_eoc;
            elem(i)->bDecContent(b,tagId,elmtLen,localBytesDecoded);
            for(;pending_eoc>0;--pending_eoc) { BDecEoc(b,localBytesDecoded); }
        } else if ((tagId==EOC_TAG_ID) && (len==INDEFINITE_LEN)) {
            BDEC_2ND_EOC_OCTET(b,localBytesDecoded);
            break;
        } else { TagError(MAKE_TAG_ID(UNIV,CONS,16),tagId); return; }
    }
    bytesDecoded += localBytesDecoded;
} /* TYPE_APEWProtocol_GEN_9::bDecContent */

TYPE_APEWProtocol_GEN_10::TYPE_APEWProtocol_GEN_10(const SDLAny& a, AsnCodingSet rule_set){                                      a.decode(this,rule_set); }

SDLType* TYPE_APEWProtocol_GEN_10::copy()const { return new TYPE_APEWProtocol_GEN_10(*this); }

void TYPE_APEWProtocol_GEN_10::assign(const SDLType* t)
{
  const TYPE_APEWProtocol_GEN_10 *arg = SITE_DYNAMIC_CAST(const TYPE_APEWProtocol_GEN_10*,t);
  if (!arg) super::assign(t);
  else *this = *arg;
}

SDLType* TYPE_APEWProtocol_GEN_10::create()
{
  static TYPE_APEWProtocol_GEN_10* tmpl = new TYPE_APEWProtocol_GEN_10;
  return tmpl;
}

const SDLType* TYPE_APEWProtocol_GEN_10::create_new() const { return create(); }


AsnLen TYPE_APEWProtocol_GEN_10::bEnc(BUF_TYPE b) const {
    AsnLen elmtLen = bEncContent(b);
    elmtLen += BEncDefLen(b,elmtLen);
    elmtLen += BEncTag1(b,UNIV,CONS,17);
    return elmtLen;
} // TYPE_APEWProtocol_GEN_10::bEnc

AsnLen TYPE_APEWProtocol_GEN_10::bEncContent(BUF_TYPE b) const {
    AsnLen elmtLen, localBytesEncoded = 0;
    for(SITE_SDL_INT i=lengthAsLong(); i>0; i--) {
        elmtLen = elem(i)->bEncContent(b);
        elmtLen += BEncDefLen(b,elmtLen);
        elmtLen += BEncTag1(b,UNIV,PRIM,22);
        localBytesEncoded += elmtLen;
    }
    return localBytesEncoded;
} // TYPE_APEWProtocol_GEN_10::bEncContent

void TYPE_APEWProtocol_GEN_10::bDec(BUF_TYPE b,AsnLen& bytesDecoded) {
    AsnTag tagId = BDecTag1(b,bytesDecoded);
    AsnLen elmtLen;
    if (tagId != MAKE_TAG_ID(UNIV,CONS,17)) { TagError(MAKE_TAG_ID(UNIV,CONS,17),tagId); return; }
    elmtLen = BDecLen(b,bytesDecoded);
    int pending_eoc = 0;
    if (elmtLen == INDEFINITE_LEN) ++pending_eoc;
    AsnLen localBytesDecoded = 0;
    bDecContent(b,tagId,elmtLen,localBytesDecoded);
    for(;pending_eoc>0;--pending_eoc) { BDecEoc(b,localBytesDecoded); }
    bytesDecoded += localBytesDecoded;
} // TYPE_APEWProtocol_GEN_10::bDec

void TYPE_APEWProtocol_GEN_10::bDecContent(BUF_TYPE b,AsnTag,
        AsnLen len, AsnLen& bytesDecoded) {
    AsnLen elmtLen, localBytesDecoded = 0;
    for(int i=1; (localBytesDecoded<len) || (len==INDEFINITE_LEN); i++) {
        AsnTag tagId = BDecTag1(b,localBytesDecoded);
        if (tagId == MAKE_TAG_ID(UNIV,PRIM,22)) {
            elmtLen = BDecLen(b,localBytesDecoded);
            elem(i)->bDecContent(b,tagId,elmtLen,localBytesDecoded);
        } else if ((tagId==EOC_TAG_ID) && (len==INDEFINITE_LEN)) {
            BDEC_2ND_EOC_OCTET(b,localBytesDecoded);
            break;
        } else { TagError(MAKE_TAG_ID(UNIV,PRIM,22),tagId); return; }
    }
    bytesDecoded += localBytesDecoded;
} /* TYPE_APEWProtocol_GEN_10::bDecContent */

TYPE_APEWProtocol_GEN_11::TYPE_APEWProtocol_GEN_11(const SDLAny& a, AsnCodingSet rule_set){                                      a.decode(this,rule_set); }

SDLType* TYPE_APEWProtocol_GEN_11::copy()const { return new TYPE_APEWProtocol_GEN_11(*this); }

void TYPE_APEWProtocol_GEN_11::assign(const SDLType* t)
{
  const TYPE_APEWProtocol_GEN_11 *arg = SITE_DYNAMIC_CAST(const TYPE_APEWProtocol_GEN_11*,t);
  if (!arg) super::assign(t);
  else *this = *arg;
}

SDLType* TYPE_APEWProtocol_GEN_11::create()
{
  static TYPE_APEWProtocol_GEN_11* tmpl = new TYPE_APEWProtocol_GEN_11;
  return tmpl;
}

const SDLType* TYPE_APEWProtocol_GEN_11::create_new() const { return create(); }


AsnLen TYPE_APEWProtocol_GEN_11::bEnc(BUF_TYPE b) const {
    AsnLen elmtLen = bEncContent(b);
    elmtLen += BEncDefLen(b,elmtLen);
    elmtLen += BEncTag1(b,UNIV,CONS,17);
    return elmtLen;
} // TYPE_APEWProtocol_GEN_11::bEnc

AsnLen TYPE_APEWProtocol_GEN_11::bEncContent(BUF_TYPE b) const {
    AsnLen elmtLen, localBytesEncoded = 0;
    for(SITE_SDL_INT i=lengthAsLong(); i>0; i--) {
        elmtLen = elem(i)->bEncContent(b);
        elmtLen += BEncDefLen(b,elmtLen);
        elmtLen += BEncTag1(b,UNIV,CONS,16);
        localBytesEncoded += elmtLen;
    }
    return localBytesEncoded;
} // TYPE_APEWProtocol_GEN_11::bEncContent

void TYPE_APEWProtocol_GEN_11::bDec(BUF_TYPE b,AsnLen& bytesDecoded) {
    AsnTag tagId = BDecTag1(b,bytesDecoded);
    AsnLen elmtLen;
    if (tagId != MAKE_TAG_ID(UNIV,CONS,17)) { TagError(MAKE_TAG_ID(UNIV,CONS,17),tagId); return; }
    elmtLen = BDecLen(b,bytesDecoded);
    int pending_eoc = 0;
    if (elmtLen == INDEFINITE_LEN) ++pending_eoc;
    AsnLen localBytesDecoded = 0;
    bDecContent(b,tagId,elmtLen,localBytesDecoded);
    for(;pending_eoc>0;--pending_eoc) { BDecEoc(b,localBytesDecoded); }
    bytesDecoded += localBytesDecoded;
} // TYPE_APEWProtocol_GEN_11::bDec

void TYPE_APEWProtocol_GEN_11::bDecContent(BUF_TYPE b,AsnTag,
        AsnLen len, AsnLen& bytesDecoded) {
    AsnLen elmtLen, localBytesDecoded = 0;
    for(int i=1; (localBytesDecoded<len) || (len==INDEFINITE_LEN); i++) {
        AsnTag tagId = BDecTag1(b,localBytesDecoded);
        if (tagId == MAKE_TAG_ID(UNIV,CONS,16)) {
            elmtLen = BDecLen(b,localBytesDecoded);
            int pending_eoc = 0;
            if (elmtLen == INDEFINITE_LEN) ++pending_eoc;
            elem(i)->bDecContent(b,tagId,elmtLen,localBytesDecoded);
            for(;pending_eoc>0;--pending_eoc) { BDecEoc(b,localBytesDecoded); }
        } else if ((tagId==EOC_TAG_ID) && (len==INDEFINITE_LEN)) {
            BDEC_2ND_EOC_OCTET(b,localBytesDecoded);
            break;
        } else { TagError(MAKE_TAG_ID(UNIV,CONS,16),tagId); return; }
    }
    bytesDecoded += localBytesDecoded;
} /* TYPE_APEWProtocol_GEN_11::bDecContent */

TYPE_APEWProtocol_GEN_12::TYPE_APEWProtocol_GEN_12(const SDLAny& a, AsnCodingSet rule_set){                                      a.decode(this,rule_set); }

SDLType* TYPE_APEWProtocol_GEN_12::copy()const { return new TYPE_APEWProtocol_GEN_12(*this); }

void TYPE_APEWProtocol_GEN_12::assign(const SDLType* t)
{
  const TYPE_APEWProtocol_GEN_12 *arg = SITE_DYNAMIC_CAST(const TYPE_APEWProtocol_GEN_12*,t);
  if (!arg) super::assign(t);
  else *this = *arg;
}

SDLType* TYPE_APEWProtocol_GEN_12::create()
{
  static TYPE_APEWProtocol_GEN_12* tmpl = new TYPE_APEWProtocol_GEN_12;
  return tmpl;
}

const SDLType* TYPE_APEWProtocol_GEN_12::create_new() const { return create(); }


AsnLen TYPE_APEWProtocol_GEN_12::bEnc(BUF_TYPE b) const {
    AsnLen elmtLen = bEncContent(b);
    elmtLen += BEncDefLen(b,elmtLen);
    elmtLen += BEncTag1(b,UNIV,CONS,17);
    return elmtLen;
} // TYPE_APEWProtocol_GEN_12::bEnc

AsnLen TYPE_APEWProtocol_GEN_12::bEncContent(BUF_TYPE b) const {
    AsnLen elmtLen, localBytesEncoded = 0;
    for(SITE_SDL_INT i=lengthAsLong(); i>0; i--) {
        elmtLen = elem(i)->bEncContent(b);
        elmtLen += BEncDefLen(b,elmtLen);
        elmtLen += BEncTag1(b,UNIV,CONS,16);
        localBytesEncoded += elmtLen;
    }
    return localBytesEncoded;
} // TYPE_APEWProtocol_GEN_12::bEncContent

void TYPE_APEWProtocol_GEN_12::bDec(BUF_TYPE b,AsnLen& bytesDecoded) {
    AsnTag tagId = BDecTag1(b,bytesDecoded);
    AsnLen elmtLen;
    if (tagId != MAKE_TAG_ID(UNIV,CONS,17)) { TagError(MAKE_TAG_ID(UNIV,CONS,17),tagId); return; }
    elmtLen = BDecLen(b,bytesDecoded);
    int pending_eoc = 0;
    if (elmtLen == INDEFINITE_LEN) ++pending_eoc;
    AsnLen localBytesDecoded = 0;
    bDecContent(b,tagId,elmtLen,localBytesDecoded);
    for(;pending_eoc>0;--pending_eoc) { BDecEoc(b,localBytesDecoded); }
    bytesDecoded += localBytesDecoded;
} // TYPE_APEWProtocol_GEN_12::bDec

void TYPE_APEWProtocol_GEN_12::bDecContent(BUF_TYPE b,AsnTag,
        AsnLen len, AsnLen& bytesDecoded) {
    AsnLen elmtLen, localBytesDecoded = 0;
    for(int i=1; (localBytesDecoded<len) || (len==INDEFINITE_LEN); i++) {
        AsnTag tagId = BDecTag1(b,localBytesDecoded);
        if (tagId == MAKE_TAG_ID(UNIV,CONS,16)) {
            elmtLen = BDecLen(b,localBytesDecoded);
            int pending_eoc = 0;
            if (elmtLen == INDEFINITE_LEN) ++pending_eoc;
            elem(i)->bDecContent(b,tagId,elmtLen,localBytesDecoded);
            for(;pending_eoc>0;--pending_eoc) { BDecEoc(b,localBytesDecoded); }
        } else if ((tagId==EOC_TAG_ID) && (len==INDEFINITE_LEN)) {
            BDEC_2ND_EOC_OCTET(b,localBytesDecoded);
            break;
        } else { TagError(MAKE_TAG_ID(UNIV,CONS,16),tagId); return; }
    }
    bytesDecoded += localBytesDecoded;
} /* TYPE_APEWProtocol_GEN_12::bDecContent */

TYPE_APEWProtocol_GEN_13::TYPE_APEWProtocol_GEN_13(const SDLAny& a, AsnCodingSet rule_set){                                      a.decode(this,rule_set); }

SDLType* TYPE_APEWProtocol_GEN_13::copy()const { return new TYPE_APEWProtocol_GEN_13(*this); }

void TYPE_APEWProtocol_GEN_13::assign(const SDLType* t)
{
  const TYPE_APEWProtocol_GEN_13 *arg = SITE_DYNAMIC_CAST(const TYPE_APEWProtocol_GEN_13*,t);
  if (!arg) super::assign(t);
  else *this = *arg;
}

SDLType* TYPE_APEWProtocol_GEN_13::create()
{
  static TYPE_APEWProtocol_GEN_13* tmpl = new TYPE_APEWProtocol_GEN_13;
  return tmpl;
}

const SDLType* TYPE_APEWProtocol_GEN_13::create_new() const { return create(); }


AsnLen TYPE_APEWProtocol_GEN_13::bEnc(BUF_TYPE b) const {
    AsnLen elmtLen = bEncContent(b);
    elmtLen += BEncDefLen(b,elmtLen);
    elmtLen += BEncTag1(b,UNIV,CONS,17);
    return elmtLen;
} // TYPE_APEWProtocol_GEN_13::bEnc

AsnLen TYPE_APEWProtocol_GEN_13::bEncContent(BUF_TYPE b) const {
    AsnLen elmtLen, localBytesEncoded = 0;
    for(SITE_SDL_INT i=lengthAsLong(); i>0; i--) {
        elmtLen = elem(i)->bEncContent(b);
        elmtLen += BEncDefLen(b,elmtLen);
        elmtLen += BEncTag1(b,UNIV,CONS,16);
        localBytesEncoded += elmtLen;
    }
    return localBytesEncoded;
} // TYPE_APEWProtocol_GEN_13::bEncContent

void TYPE_APEWProtocol_GEN_13::bDec(BUF_TYPE b,AsnLen& bytesDecoded) {
    AsnTag tagId = BDecTag1(b,bytesDecoded);
    AsnLen elmtLen;
    if (tagId != MAKE_TAG_ID(UNIV,CONS,17)) { TagError(MAKE_TAG_ID(UNIV,CONS,17),tagId); return; }
    elmtLen = BDecLen(b,bytesDecoded);
    int pending_eoc = 0;
    if (elmtLen == INDEFINITE_LEN) ++pending_eoc;
    AsnLen localBytesDecoded = 0;
    bDecContent(b,tagId,elmtLen,localBytesDecoded);
    for(;pending_eoc>0;--pending_eoc) { BDecEoc(b,localBytesDecoded); }
    bytesDecoded += localBytesDecoded;
} // TYPE_APEWProtocol_GEN_13::bDec

void TYPE_APEWProtocol_GEN_13::bDecContent(BUF_TYPE b,AsnTag,
        AsnLen len, AsnLen& bytesDecoded) {
    AsnLen elmtLen, localBytesDecoded = 0;
    for(int i=1; (localBytesDecoded<len) || (len==INDEFINITE_LEN); i++) {
        AsnTag tagId = BDecTag1(b,localBytesDecoded);
        if (tagId == MAKE_TAG_ID(UNIV,CONS,16)) {
            elmtLen = BDecLen(b,localBytesDecoded);
            int pending_eoc = 0;
            if (elmtLen == INDEFINITE_LEN) ++pending_eoc;
            elem(i)->bDecContent(b,tagId,elmtLen,localBytesDecoded);
            for(;pending_eoc>0;--pending_eoc) { BDecEoc(b,localBytesDecoded); }
        } else if ((tagId==EOC_TAG_ID) && (len==INDEFINITE_LEN)) {
            BDEC_2ND_EOC_OCTET(b,localBytesDecoded);
            break;
        } else { TagError(MAKE_TAG_ID(UNIV,CONS,16),tagId); return; }
    }
    bytesDecoded += localBytesDecoded;
} /* TYPE_APEWProtocol_GEN_13::bDecContent */

TYPE_APEWProtocol_GEN_14::TYPE_APEWProtocol_GEN_14(const SDLAny& a, AsnCodingSet rule_set){                                      a.decode(this,rule_set); }

SDLType* TYPE_APEWProtocol_GEN_14::copy()const { return new TYPE_APEWProtocol_GEN_14(*this); }

void TYPE_APEWProtocol_GEN_14::assign(const SDLType* t)
{
  const TYPE_APEWProtocol_GEN_14 *arg = SITE_DYNAMIC_CAST(const TYPE_APEWProtocol_GEN_14*,t);
  if (!arg) super::assign(t);
  else *this = *arg;
}

SDLType* TYPE_APEWProtocol_GEN_14::create()
{
  static TYPE_APEWProtocol_GEN_14* tmpl = new TYPE_APEWProtocol_GEN_14;
  return tmpl;
}

const SDLType* TYPE_APEWProtocol_GEN_14::create_new() const { return create(); }


AsnLen TYPE_APEWProtocol_GEN_14::bEnc(BUF_TYPE b) const {
    AsnLen elmtLen = bEncContent(b);
    elmtLen += BEncDefLen(b,elmtLen);
    elmtLen += BEncTag1(b,UNIV,CONS,17);
    return elmtLen;
} // TYPE_APEWProtocol_GEN_14::bEnc

AsnLen TYPE_APEWProtocol_GEN_14::bEncContent(BUF_TYPE b) const {
    AsnLen elmtLen, localBytesEncoded = 0;
    for(SITE_SDL_INT i=lengthAsLong(); i>0; i--) {
        elmtLen = elem(i)->bEncContent(b);
        elmtLen += BEncDefLen(b,elmtLen);
        elmtLen += BEncTag1(b,UNIV,CONS,16);
        localBytesEncoded += elmtLen;
    }
    return localBytesEncoded;
} // TYPE_APEWProtocol_GEN_14::bEncContent

void TYPE_APEWProtocol_GEN_14::bDec(BUF_TYPE b,AsnLen& bytesDecoded) {
    AsnTag tagId = BDecTag1(b,bytesDecoded);
    AsnLen elmtLen;
    if (tagId != MAKE_TAG_ID(UNIV,CONS,17)) { TagError(MAKE_TAG_ID(UNIV,CONS,17),tagId); return; }
    elmtLen = BDecLen(b,bytesDecoded);
    int pending_eoc = 0;
    if (elmtLen == INDEFINITE_LEN) ++pending_eoc;
    AsnLen localBytesDecoded = 0;
    bDecContent(b,tagId,elmtLen,localBytesDecoded);
    for(;pending_eoc>0;--pending_eoc) { BDecEoc(b,localBytesDecoded); }
    bytesDecoded += localBytesDecoded;
} // TYPE_APEWProtocol_GEN_14::bDec

void TYPE_APEWProtocol_GEN_14::bDecContent(BUF_TYPE b,AsnTag,
        AsnLen len, AsnLen& bytesDecoded) {
    AsnLen elmtLen, localBytesDecoded = 0;
    for(int i=1; (localBytesDecoded<len) || (len==INDEFINITE_LEN); i++) {
        AsnTag tagId = BDecTag1(b,localBytesDecoded);
        if (tagId == MAKE_TAG_ID(UNIV,CONS,16)) {
            elmtLen = BDecLen(b,localBytesDecoded);
            int pending_eoc = 0;
            if (elmtLen == INDEFINITE_LEN) ++pending_eoc;
            elem(i)->bDecContent(b,tagId,elmtLen,localBytesDecoded);
            for(;pending_eoc>0;--pending_eoc) { BDecEoc(b,localBytesDecoded); }
        } else if ((tagId==EOC_TAG_ID) && (len==INDEFINITE_LEN)) {
            BDEC_2ND_EOC_OCTET(b,localBytesDecoded);
            break;
        } else { TagError(MAKE_TAG_ID(UNIV,CONS,16),tagId); return; }
    }
    bytesDecoded += localBytesDecoded;
} /* TYPE_APEWProtocol_GEN_14::bDecContent */

TYPE_APEWProtocol_GEN_15::TYPE_APEWProtocol_GEN_15(const SDLAny& a, AsnCodingSet rule_set){                                      a.decode(this,rule_set); }

SDLType* TYPE_APEWProtocol_GEN_15::copy()const { return new TYPE_APEWProtocol_GEN_15(*this); }

void TYPE_APEWProtocol_GEN_15::assign(const SDLType* t)
{
  const TYPE_APEWProtocol_GEN_15 *arg = SITE_DYNAMIC_CAST(const TYPE_APEWProtocol_GEN_15*,t);
  if (!arg) super::assign(t);
  else *this = *arg;
}

SDLType* TYPE_APEWProtocol_GEN_15::create()
{
  static TYPE_APEWProtocol_GEN_15* tmpl = new TYPE_APEWProtocol_GEN_15;
  return tmpl;
}

const SDLType* TYPE_APEWProtocol_GEN_15::create_new() const { return create(); }


AsnLen TYPE_APEWProtocol_GEN_15::bEnc(BUF_TYPE b) const {
    AsnLen elmtLen = bEncContent(b);
    elmtLen += BEncDefLen(b,elmtLen);
    elmtLen += BEncTag1(b,UNIV,CONS,17);
    return elmtLen;
} // TYPE_APEWProtocol_GEN_15::bEnc

AsnLen TYPE_APEWProtocol_GEN_15::bEncContent(BUF_TYPE b) const {
    AsnLen elmtLen, localBytesEncoded = 0;
    for(SITE_SDL_INT i=lengthAsLong(); i>0; i--) {
        elmtLen = elem(i)->bEncContent(b);
        elmtLen += BEncDefLen(b,elmtLen);
        elmtLen += BEncTag1(b,UNIV,CONS,16);
        localBytesEncoded += elmtLen;
    }
    return localBytesEncoded;
} // TYPE_APEWProtocol_GEN_15::bEncContent

void TYPE_APEWProtocol_GEN_15::bDec(BUF_TYPE b,AsnLen& bytesDecoded) {
    AsnTag tagId = BDecTag1(b,bytesDecoded);
    AsnLen elmtLen;
    if (tagId != MAKE_TAG_ID(UNIV,CONS,17)) { TagError(MAKE_TAG_ID(UNIV,CONS,17),tagId); return; }
    elmtLen = BDecLen(b,bytesDecoded);
    int pending_eoc = 0;
    if (elmtLen == INDEFINITE_LEN) ++pending_eoc;
    AsnLen localBytesDecoded = 0;
    bDecContent(b,tagId,elmtLen,localBytesDecoded);
    for(;pending_eoc>0;--pending_eoc) { BDecEoc(b,localBytesDecoded); }
    bytesDecoded += localBytesDecoded;
} // TYPE_APEWProtocol_GEN_15::bDec

void TYPE_APEWProtocol_GEN_15::bDecContent(BUF_TYPE b,AsnTag,
        AsnLen len, AsnLen& bytesDecoded) {
    AsnLen elmtLen, localBytesDecoded = 0;
    for(int i=1; (localBytesDecoded<len) || (len==INDEFINITE_LEN); i++) {
        AsnTag tagId = BDecTag1(b,localBytesDecoded);
        if (tagId == MAKE_TAG_ID(UNIV,CONS,16)) {
            elmtLen = BDecLen(b,localBytesDecoded);
            int pending_eoc = 0;
            if (elmtLen == INDEFINITE_LEN) ++pending_eoc;
            elem(i)->bDecContent(b,tagId,elmtLen,localBytesDecoded);
            for(;pending_eoc>0;--pending_eoc) { BDecEoc(b,localBytesDecoded); }
        } else if ((tagId==EOC_TAG_ID) && (len==INDEFINITE_LEN)) {
            BDEC_2ND_EOC_OCTET(b,localBytesDecoded);
            break;
        } else { TagError(MAKE_TAG_ID(UNIV,CONS,16),tagId); return; }
    }
    bytesDecoded += localBytesDecoded;
} /* TYPE_APEWProtocol_GEN_15::bDecContent */

TYPE_APEWProtocol_GEN_16::TYPE_APEWProtocol_GEN_16(const SDLAny& a, AsnCodingSet rule_set){                                      a.decode(this,rule_set); }

SDLType* TYPE_APEWProtocol_GEN_16::copy()const { return new TYPE_APEWProtocol_GEN_16(*this); }

void TYPE_APEWProtocol_GEN_16::assign(const SDLType* t)
{
  const TYPE_APEWProtocol_GEN_16 *arg = SITE_DYNAMIC_CAST(const TYPE_APEWProtocol_GEN_16*,t);
  if (!arg) super::assign(t);
  else *this = *arg;
}

SDLType* TYPE_APEWProtocol_GEN_16::create()
{
  static TYPE_APEWProtocol_GEN_16* tmpl = new TYPE_APEWProtocol_GEN_16;
  return tmpl;
}

const SDLType* TYPE_APEWProtocol_GEN_16::create_new() const { return create(); }


AsnLen TYPE_APEWProtocol_GEN_16::bEnc(BUF_TYPE b) const {
    AsnLen elmtLen = bEncContent(b);
    elmtLen += BEncDefLen(b,elmtLen);
    elmtLen += BEncTag1(b,UNIV,CONS,17);
    return elmtLen;
} // TYPE_APEWProtocol_GEN_16::bEnc

AsnLen TYPE_APEWProtocol_GEN_16::bEncContent(BUF_TYPE b) const {
    AsnLen elmtLen, localBytesEncoded = 0;
    for(SITE_SDL_INT i=lengthAsLong(); i>0; i--) {
        elmtLen = elem(i)->bEncContent(b);
        elmtLen += BEncDefLen(b,elmtLen);
        elmtLen += BEncTag1(b,UNIV,PRIM,22);
        localBytesEncoded += elmtLen;
    }
    return localBytesEncoded;
} // TYPE_APEWProtocol_GEN_16::bEncContent

void TYPE_APEWProtocol_GEN_16::bDec(BUF_TYPE b,AsnLen& bytesDecoded) {
    AsnTag tagId = BDecTag1(b,bytesDecoded);
    AsnLen elmtLen;
    if (tagId != MAKE_TAG_ID(UNIV,CONS,17)) { TagError(MAKE_TAG_ID(UNIV,CONS,17),tagId); return; }
    elmtLen = BDecLen(b,bytesDecoded);
    int pending_eoc = 0;
    if (elmtLen == INDEFINITE_LEN) ++pending_eoc;
    AsnLen localBytesDecoded = 0;
    bDecContent(b,tagId,elmtLen,localBytesDecoded);
    for(;pending_eoc>0;--pending_eoc) { BDecEoc(b,localBytesDecoded); }
    bytesDecoded += localBytesDecoded;
} // TYPE_APEWProtocol_GEN_16::bDec

void TYPE_APEWProtocol_GEN_16::bDecContent(BUF_TYPE b,AsnTag,
        AsnLen len, AsnLen& bytesDecoded) {
    AsnLen elmtLen, localBytesDecoded = 0;
    for(int i=1; (localBytesDecoded<len) || (len==INDEFINITE_LEN); i++) {
        AsnTag tagId = BDecTag1(b,localBytesDecoded);
        if (tagId == MAKE_TAG_ID(UNIV,PRIM,22)) {
            elmtLen = BDecLen(b,localBytesDecoded);
            elem(i)->bDecContent(b,tagId,elmtLen,localBytesDecoded);
        } else if ((tagId==EOC_TAG_ID) && (len==INDEFINITE_LEN)) {
            BDEC_2ND_EOC_OCTET(b,localBytesDecoded);
            break;
        } else { TagError(MAKE_TAG_ID(UNIV,PRIM,22),tagId); return; }
    }
    bytesDecoded += localBytesDecoded;
} /* TYPE_APEWProtocol_GEN_16::bDecContent */

TYPE_APEWProtocol_GEN_17::TYPE_APEWProtocol_GEN_17(const SDLAny& a, AsnCodingSet rule_set){                                      a.decode(this,rule_set); }

SDLType* TYPE_APEWProtocol_GEN_17::copy()const { return new TYPE_APEWProtocol_GEN_17(*this); }

void TYPE_APEWProtocol_GEN_17::assign(const SDLType* t)
{
  const TYPE_APEWProtocol_GEN_17 *arg = SITE_DYNAMIC_CAST(const TYPE_APEWProtocol_GEN_17*,t);
  if (!arg) super::assign(t);
  else *this = *arg;
}

SDLType* TYPE_APEWProtocol_GEN_17::create()
{
  static TYPE_APEWProtocol_GEN_17* tmpl = new TYPE_APEWProtocol_GEN_17;
  return tmpl;
}

const SDLType* TYPE_APEWProtocol_GEN_17::create_new() const { return create(); }


AsnLen TYPE_APEWProtocol_GEN_17::bEnc(BUF_TYPE b) const {
    AsnLen elmtLen = bEncContent(b);
    elmtLen += BEncDefLen(b,elmtLen);
    elmtLen += BEncTag1(b,UNIV,CONS,17);
    return elmtLen;
} // TYPE_APEWProtocol_GEN_17::bEnc

AsnLen TYPE_APEWProtocol_GEN_17::bEncContent(BUF_TYPE b) const {
    AsnLen elmtLen, localBytesEncoded = 0;
    for(SITE_SDL_INT i=lengthAsLong(); i>0; i--) {
        elmtLen = elem(i)->bEncContent(b);
        elmtLen += BEncDefLen(b,elmtLen);
        elmtLen += BEncTag1(b,UNIV,CONS,16);
        localBytesEncoded += elmtLen;
    }
    return localBytesEncoded;
} // TYPE_APEWProtocol_GEN_17::bEncContent

void TYPE_APEWProtocol_GEN_17::bDec(BUF_TYPE b,AsnLen& bytesDecoded) {
    AsnTag tagId = BDecTag1(b,bytesDecoded);
    AsnLen elmtLen;
    if (tagId != MAKE_TAG_ID(UNIV,CONS,17)) { TagError(MAKE_TAG_ID(UNIV,CONS,17),tagId); return; }
    elmtLen = BDecLen(b,bytesDecoded);
    int pending_eoc = 0;
    if (elmtLen == INDEFINITE_LEN) ++pending_eoc;
    AsnLen localBytesDecoded = 0;
    bDecContent(b,tagId,elmtLen,localBytesDecoded);
    for(;pending_eoc>0;--pending_eoc) { BDecEoc(b,localBytesDecoded); }
    bytesDecoded += localBytesDecoded;
} // TYPE_APEWProtocol_GEN_17::bDec

void TYPE_APEWProtocol_GEN_17::bDecContent(BUF_TYPE b,AsnTag,
        AsnLen len, AsnLen& bytesDecoded) {
    AsnLen elmtLen, localBytesDecoded = 0;
    for(int i=1; (localBytesDecoded<len) || (len==INDEFINITE_LEN); i++) {
        AsnTag tagId = BDecTag1(b,localBytesDecoded);
        if (tagId == MAKE_TAG_ID(UNIV,CONS,16)) {
            elmtLen = BDecLen(b,localBytesDecoded);
            int pending_eoc = 0;
            if (elmtLen == INDEFINITE_LEN) ++pending_eoc;
            elem(i)->bDecContent(b,tagId,elmtLen,localBytesDecoded);
            for(;pending_eoc>0;--pending_eoc) { BDecEoc(b,localBytesDecoded); }
        } else if ((tagId==EOC_TAG_ID) && (len==INDEFINITE_LEN)) {
            BDEC_2ND_EOC_OCTET(b,localBytesDecoded);
            break;
        } else { TagError(MAKE_TAG_ID(UNIV,CONS,16),tagId); return; }
    }
    bytesDecoded += localBytesDecoded;
} /* TYPE_APEWProtocol_GEN_17::bDecContent */

TYPE_APEWProtocol_GEN_18::TYPE_APEWProtocol_GEN_18(const SDLAny& a, AsnCodingSet rule_set){                                      a.decode(this,rule_set); }

SDLType* TYPE_APEWProtocol_GEN_18::copy()const { return new TYPE_APEWProtocol_GEN_18(*this); }

void TYPE_APEWProtocol_GEN_18::assign(const SDLType* t)
{
  const TYPE_APEWProtocol_GEN_18 *arg = SITE_DYNAMIC_CAST(const TYPE_APEWProtocol_GEN_18*,t);
  if (!arg) super::assign(t);
  else *this = *arg;
}

SDLType* TYPE_APEWProtocol_GEN_18::create()
{
  static TYPE_APEWProtocol_GEN_18* tmpl = new TYPE_APEWProtocol_GEN_18;
  return tmpl;
}

const SDLType* TYPE_APEWProtocol_GEN_18::create_new() const { return create(); }


AsnLen TYPE_APEWProtocol_GEN_18::bEnc(BUF_TYPE b) const {
    AsnLen elmtLen = bEncContent(b);
    elmtLen += BEncDefLen(b,elmtLen);
    elmtLen += BEncTag1(b,UNIV,CONS,17);
    return elmtLen;
} // TYPE_APEWProtocol_GEN_18::bEnc

AsnLen TYPE_APEWProtocol_GEN_18::bEncContent(BUF_TYPE b) const {
    AsnLen elmtLen, localBytesEncoded = 0;
    for(SITE_SDL_INT i=lengthAsLong(); i>0; i--) {
        elmtLen = elem(i)->bEncContent(b);
        elmtLen += BEncDefLen(b,elmtLen);
        elmtLen += BEncTag1(b,UNIV,CONS,16);
        localBytesEncoded += elmtLen;
    }
    return localBytesEncoded;
} // TYPE_APEWProtocol_GEN_18::bEncContent

void TYPE_APEWProtocol_GEN_18::bDec(BUF_TYPE b,AsnLen& bytesDecoded) {
    AsnTag tagId = BDecTag1(b,bytesDecoded);
    AsnLen elmtLen;
    if (tagId != MAKE_TAG_ID(UNIV,CONS,17)) { TagError(MAKE_TAG_ID(UNIV,CONS,17),tagId); return; }
    elmtLen = BDecLen(b,bytesDecoded);
    int pending_eoc = 0;
    if (elmtLen == INDEFINITE_LEN) ++pending_eoc;
    AsnLen localBytesDecoded = 0;
    bDecContent(b,tagId,elmtLen,localBytesDecoded);
    for(;pending_eoc>0;--pending_eoc) { BDecEoc(b,localBytesDecoded); }
    bytesDecoded += localBytesDecoded;
} // TYPE_APEWProtocol_GEN_18::bDec

void TYPE_APEWProtocol_GEN_18::bDecContent(BUF_TYPE b,AsnTag,
        AsnLen len, AsnLen& bytesDecoded) {
    AsnLen elmtLen, localBytesDecoded = 0;
    for(int i=1; (localBytesDecoded<len) || (len==INDEFINITE_LEN); i++) {
        AsnTag tagId = BDecTag1(b,localBytesDecoded);
        if (tagId == MAKE_TAG_ID(UNIV,CONS,16)) {
            elmtLen = BDecLen(b,localBytesDecoded);
            int pending_eoc = 0;
            if (elmtLen == INDEFINITE_LEN) ++pending_eoc;
            elem(i)->bDecContent(b,tagId,elmtLen,localBytesDecoded);
            for(;pending_eoc>0;--pending_eoc) { BDecEoc(b,localBytesDecoded); }
        } else if ((tagId==EOC_TAG_ID) && (len==INDEFINITE_LEN)) {
            BDEC_2ND_EOC_OCTET(b,localBytesDecoded);
            break;
        } else { TagError(MAKE_TAG_ID(UNIV,CONS,16),tagId); return; }
    }
    bytesDecoded += localBytesDecoded;
} /* TYPE_APEWProtocol_GEN_18::bDecContent */

END_SITE_NAMESPACE
