/* ===== PA_APGeneralProtocol_P.cxx ===== */

#include "PA_APGeneralProtocol.h"
#include "version.h"

BEGIN_SITE_NAMESPACE(AP_GeneralProtocol)
TYPE_APGeneralProtocol::TYPE_APGeneralProtocol(const SDLAny& a, AsnCodingSet rule_set){                                      a.decode(this,rule_set); }

SDLType* TYPE_APGeneralProtocol::copy()const { return new TYPE_APGeneralProtocol(*this); }

void TYPE_APGeneralProtocol::assign(const SDLType* t)
{
  const TYPE_APGeneralProtocol *arg = SITE_DYNAMIC_CAST(const TYPE_APGeneralProtocol*,t);
  if (!arg) SDLChoice::assign(t);
  else *this = *arg;
}

SDLType* TYPE_APGeneralProtocol::create()
{
  static TYPE_APGeneralProtocol* tmpl = new TYPE_APGeneralProtocol;
  return tmpl;
}

const SDLType* TYPE_APGeneralProtocol::create_new() const { return create(); }

TYPE_APEWProtocol& TYPE_APGeneralProtocol::VAR_mAPEWProtocol() const {
    if (_u && _present!=CHOICE_mAPEWProtocol) {
        delete _u; _u=0;
    }
    if(!_u) {
        _u = new TYPE_APEWProtocol;
        _present = CHOICE_mAPEWProtocol;
    } else {
        SITEASSERT(SITE_DYNAMIC_CAST(TYPE_APEWProtocol*,_u),
                   "dynamic cast failure for CHOICE element");
    }
    return *SITE_STATIC_CAST(TYPE_APEWProtocol*,_u);
}

TYPE_APManagingProtocol& TYPE_APGeneralProtocol::VAR_mAPManagingProtocol() const {
    if (_u && _present!=CHOICE_mAPManagingProtocol) {
        delete _u; _u=0;
    }
    if(!_u) {
        _u = new TYPE_APManagingProtocol;
        _present = CHOICE_mAPManagingProtocol;
    } else {
        SITEASSERT(SITE_DYNAMIC_CAST(TYPE_APManagingProtocol*,_u),
                   "dynamic cast failure for CHOICE element");
    }
    return *SITE_STATIC_CAST(TYPE_APManagingProtocol*,_u);
}

void TYPE_APGeneralProtocol::assign_field(unsigned int variant,const SDLType& elem)
{
    switch(variant) {
        case CHOICE_mAPEWProtocol: VAR_mAPEWProtocol().assign(&elem); break;
        case CHOICE_mAPManagingProtocol: VAR_mAPManagingProtocol().assign(&elem); break;
        default : SDLASSERT(0,"wrong choice variant");
    }
    SDLASSERT(_u,"type error for choice variant");
} // TYPE_APGeneralProtocol::assign_field

AsnLen TYPE_APGeneralProtocol::bEnc(BUF_TYPE b) const {
    AsnLen elmtLen = bEncContent(b);
    return elmtLen;
} // TYPE_APGeneralProtocol::bEnc

AsnLen TYPE_APGeneralProtocol::bEncContent(BUF_TYPE b) const {
    AsnLen elmtLen;
    switch(_present) {
        case CHOICE_mAPEWProtocol :
            elmtLen = VAR_mAPEWProtocol().bEncContent(b);
            elmtLen += BEncDefLen(b,elmtLen);
            elmtLen += BEncTag1(b,CNTX,CONS,1);
            return elmtLen;
        case CHOICE_mAPManagingProtocol :
            elmtLen = VAR_mAPManagingProtocol().bEncContent(b);
            elmtLen += BEncDefLen(b,elmtLen);
            elmtLen += BEncTag1(b,CNTX,CONS,2);
            return elmtLen;
        default:;
    }
    ChoiceError("ERROR no valid field");
    return 0;
} // TYPE_APGeneralProtocol::bEncContent

void TYPE_APGeneralProtocol::bDec(BUF_TYPE b,AsnLen& bytesDecoded) {
    AsnTag tagId = BDecTag(b,bytesDecoded);
    AsnLen elmtLen = BDecLen(b,bytesDecoded);
    bDecContent(b,tagId,elmtLen,bytesDecoded);
} // TYPE_APGeneralProtocol::bDec

void TYPE_APGeneralProtocol::bDecContent(BUF_TYPE b,AsnTag tagId,
        AsnLen len, AsnLen& bytesDecoded) {
    AsnLen elmtLen = len, localBytesDecoded = 0;
    int pending_eoc = 0; // can be unused if implicit tagged 
    switch(tagId) {
        case MAKE_TAG_ID(CNTX,CONS,1):
            if (elmtLen == INDEFINITE_LEN) ++pending_eoc;
            tagId = BDecTag(b,localBytesDecoded);
            elmtLen = BDecLen(b,localBytesDecoded);
            VAR_mAPEWProtocol().bDecContent(b,tagId,elmtLen,localBytesDecoded);
            break;
        case MAKE_TAG_ID(CNTX,CONS,2):
            if (elmtLen == INDEFINITE_LEN) ++pending_eoc;
            tagId = BDecTag(b,localBytesDecoded);
            elmtLen = BDecLen(b,localBytesDecoded);
            VAR_mAPManagingProtocol().bDecContent(b,tagId,elmtLen,localBytesDecoded);
            break;
        default: TagError(0,tagId); return;
    } /* tag switch */
    bytesDecoded += localBytesDecoded;
    for(;pending_eoc>0;--pending_eoc) { BDecEoc(b,localBytesDecoded); }
    if ((len!=INDEFINITE_LEN) && (localBytesDecoded!=len)) { LengthError();return; }
    set_state(validValue);
} // TYPE_APGeneralProtocol::bDecContent

AsnLen TYPE_APGeneralProtocol::pEnc(BUF_TYPE2 b) const {
    int off, elmtLen;
    switch(_present){
        case CHOICE_mAPManagingProtocol : off=0; break;
        case CHOICE_mAPEWProtocol : off=1; break;
    }
    SITE_SDL_UINT mask = 0x2LL;
    for(int i=0; i<2; mask>>=1,i++)
      b.putBit(off & mask);
    switch(_present){
        case CHOICE_mAPManagingProtocol : elmtLen = VAR_mAPManagingProtocol().pEnc(b); break;
        case CHOICE_mAPEWProtocol : elmtLen = VAR_mAPEWProtocol().pEnc(b); break;
    }
    return elmtLen + 2;
}

void TYPE_APGeneralProtocol::pDec(BUF_TYPE2 b) {
    SITE_SDL_UINT off = 0;
    for(int i=0; i<2; i++)
      off = (off << 1) | (b.getBit()?1:0);
    switch(off){
        case 0 : _present = CHOICE_mAPManagingProtocol; VAR_mAPManagingProtocol().pDec(b); break;
        case 1 : _present = CHOICE_mAPEWProtocol; VAR_mAPEWProtocol().pDec(b); break;
    }
    set_state(validValue);
}

bool TYPE_APGeneralProtocol::datainfo(long index,SDLIA5String& var_name,
    SDLIA5String& var_type,SDLType*& var,SDLType::infotype it)
{
    switch(index) {
    case 1:
        var_name="mAPEWProtocol";
        var_type="APEWProtocol";
        if (_present!=CHOICE_mAPEWProtocol && it==SDLType::info_get)
          var = 0;
        else
          var = &VAR_mAPEWProtocol();
        break;
    case 2:
        var_name="mAPManagingProtocol";
        var_type="APManagingProtocol";
        if (_present!=CHOICE_mAPManagingProtocol && it==SDLType::info_get)
          var = 0;
        else
          var = &VAR_mAPManagingProtocol();
        break;
    default: return false;
    }
    return true;
} /* TYPE_APGeneralProtocol::datainfo */

END_SITE_NAMESPACE
