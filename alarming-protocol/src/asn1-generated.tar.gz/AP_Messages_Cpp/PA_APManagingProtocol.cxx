/* ===== PA_APManagingProtocol.cxx ===== */

#include "PA_APManagingProtocol.h"

#include "version.h"

#include "PA_APManagingProtocol.h"
#define OPTIONS_RANGE_SHIFT 0LL
BEGIN_SITE_NAMESPACE(AP_GeneralProtocol)
int PA_APManagingProtocol507664_has_been_changed=0;

static void check_package_versions()
{
    PA_APEWProtocol1241092_has_been_changed = 0;
    PA_APEWProtocol1241092_has_been_changed = 0;
    PA_APEWProtocol1241092_has_been_changed = 0;
}

implementASNPackageLib(PA_APManagingProtocol)
PA_APManagingProtocol::PA_APManagingProtocol (const char * myname) :
SDLPackage(myname)
{
    SDL_LIB_3_28=1;
    SITE_CONSISTENCY_CHECK;
    _non_standard_compilation_option = " --case-sensitive --mangeling short";
} /* PA_APManagingProtocol::PA_APManagingProtocol */

void PA_APManagingProtocol::init()
{
    SDLPackage::init();
    package_init(MY_PA_APEWProtocol);
    package_init(MY_PA_APEWProtocol);
    package_init(MY_PA_APEWProtocol);
    TYPE_APManagingProtocol::create()->init_type();
    TYPE_TN_SN_AssignLeadershipForGroup::create()->init_type();
    TYPE_TN_LN_AssignLNsInNetwork::create()->init_type();
    TYPE_TN_LN_AssignGNsInNetwork::create()->init_type();
    TYPE_LN_SN_PrimaryLN::create()->init_type();
    TYPE_LN_SN_SecondaryLN::create()->init_type();
    TYPE_TN_SN_UseMSDP::create()->init_type();
    TYPE_TN_SN_AskGroupId::create()->init_type();
    TYPE_SN_TN_HaveGroupId::create()->init_type();
    TYPE_KeyValuePair::create()->init_type();
    TYPE_TN_SN_ConfigureSetKeyValue::create()->init_type();
    TYPE_TN_SN_CloseMessageLogfile::create()->init_type();
    TYPE_TN_SN_StartMessageLogging::create()->init_type();
    TYPE_TN_SN_StopMessageLogging::create()->init_type();
    TYPE_APManagingProtocol_GEN_1::create()->init_type();
    TYPE_APManagingProtocol_GEN_2::create()->init_type();
    TYPE_APManagingProtocol_GEN_3::create()->init_type();
    TYPE_APManagingProtocol_GEN_4::create()->init_type();
    TYPE_APManagingProtocol_GEN_5::create()->init_type();
}/* PA_APManagingProtocol:: init */

PA_APManagingProtocol::~PA_APManagingProtocol()
{
} /* PA_APManagingProtocol::~PA_APManagingProtocol */

PA_APManagingProtocol*
PA_APManagingProtocol::Instance()
{
    static PA_APManagingProtocol * _instance = new PA_APManagingProtocol("PA_APManagingProtocol");
    return _instance;
} /* PA_APManagingProtocol::Instance */

bool PA_APManagingProtocol::datainfo(long index,
        SDLIA5String& var_name,SDLIA5String& var_type,SDLType*& var){

    switch(index) {
        default: return SDLPackage::datainfo(index-0,var_name,var_type,var);
    }
    return true;
} /* PA_APManagingProtocol::datainfo */
END_SITE_NAMESPACE
