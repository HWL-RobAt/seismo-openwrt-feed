/*******************************************************************************
*   vim:sw=2:ts=2:et
*
*   File    : sdlconfig.h
*   Author  : Ralf Schr�der and Martin von L�wis
*             Humboldt University Berlin
*             Department of Computer Science / System Analysis
*   e-mail  : schroed2/loewis@informatik.hu-berlin.de
*   Project : @vantage platform
*   $Date: 2005-05-05 17:38:41 +0200 (Thu, 05 May 2005) $
*   $Revision: 1.11 $
*
*******************************************************************************/
#ifndef _SDLCONFIG_H
#define _SDLCONFIG_H

#ifdef __GNUC__
// bug in FrwException.h
#include <stdarg.h>
// gcc specific
#define UNUSED __attribute__((unused))
#else
#define UNUSED
#endif

#define FRWUNUSED UNUSED
#define SITE_RCS_IDENT
#if defined (WIN32) && defined (SDLPredefined_LIB)
#define DllExport __declspec(dllexport)
#define DllImport __declspec(dllimport)
#define SDL_API DllExport
#else
#define DllExport
#define DllImport
#define SDL_API
#endif
static const char* SDLCONFIG_RCSID UNUSED = "$Id: sdlconfig.h 554 2005-05-05 15:38:41Z tneumann $";


/**@name Name space management.
    The SITE code generator can be called with option -N --namespace <name>.
    This implies the generation namespace macros for all generated
    classes. With -DNO_SITE_NAMESPACE the generated name space can be
    deactivated at C++ compile time.
*/
//@{
#ifdef  NO_SITE_NAMESPACE
#define BEGIN_SITE_NAMESPACE(x)
#define END_SITE_NAMESPACE
#else
#define BEGIN_SITE_NAMESPACE(ns) namespace ns {
#define END_SITE_NAMESPACE }
#endif
//@}


/**@name SDL configurations.
*/
//@{

#include <sstream>

/** sdl-cg name of the ostream for Print methods */
#define SITE_OSTREAM std::ostream

/*= integer size part =*/
/*= this part should always be identical to that in file codegen/cg_global.k =*/

/** Size of SDL predefined type Integer, can be 32 or 64 */
#define SITE_SDL_INT_SIZE 64

#if defined (__GNUC__) && !defined (__GNUC_PREREQ)
#define __GNUC_PREREQ(maj, min) \
  ((__GNUC__ << 16) + __GNUC_MINOR__ >= ((maj) << 16) + (min))
#endif

#if SITE_SDL_INT_SIZE == 64
#define SITE_INT_MAX 0x7fffffffffffffffLL
#define SITE_INT_MIN (-SITE_INT_MAX - 1LL)
#define SITE_UINT_MAX 0xffffffffffffffffULL
# ifdef __sparc
#   include <inttypes.h>
    typedef int64_t SITE_SDL_INT;
    typedef uint64_t SITE_SDL_UINT;
# elif defined(_MSC_VER)
    typedef __int64 SITE_SDL_INT;
    typedef unsigned __int64 SITE_SDL_UINT;
# elif defined(__GNUC__)
#   if __GNUC_PREREQ (3,2)
#     include <stdint.h>
      typedef int64_t SITE_SDL_INT;
      typedef uint64_t SITE_SDL_UINT;
#   else
      typedef long long SITE_SDL_INT;
      typedef unsigned long long SITE_SDL_UINT;
#   endif
# else
#   error no 64 bit integer type available
# endif /* __sparc */
#elif SITE_SDL_INT_SIZE == 32
#define SITE_INT_MAX 0x7fffffffL
#define SITE_INT_MIN (-SITE_INT_MAX - 1L)
#define SITE_UINT_MAX 0xffffffffUL
# ifdef __sparc
#   include <inttypes.h>
    typedef int32_t SITE_SDL_INT;
    typedef uint32_t SITE_SDL_UINT;
# elif defined(_MSC_VER)
    typedef long SITE_SDL_INT;
    typedef unsigned long SITE_SDL_UINT;
# elif defined(__GNUC__) && __GNUC_PREREQ (3,2)
#     include <stdint.h>
      typedef int32_t SITE_SDL_INT;
      typedef uint32_t SITE_SDL_UINT;
# else
      typedef long SITE_SDL_INT;
      typedef unsigned long SITE_SDL_UINT;
# endif /* __sparc */
#else
# error SITE integer size (SITE_SDL_INT_SIZE) must be either 32 or 64
#endif /* SITE_SDL_INT_SIZE */

/** Implementation type of SDL Integer.
    In case, that sizeof(SITE_SDL_INT)!=sizeof(size_t) we have
    massive conversion problems with memory allocation for
    string types. The solution is a cast to size_t an all relevant
    places and the introduction of SDLASSERT with a check, that
    the SITE_SDL_INT value is not larger than allocable memory.
*/

/*= end of integer size part =*/


/** An SDLASSERT is introduced as a better assert implementation.
    If SDLAssert is defined in package Predefined, then an assert
    can be caught on SDL level. It is not recommended to switch
    off this assert implementation.
*/
#define SDLASSERT(cond,msg) { if (!(cond)) throw SDLAssert(msg); }

#ifdef DEBUG

/** An SITEASSERT is introduced as a better assert implementation.
    If SDLAssert is defined in package Predefined, then an assert
    can be caught on SDL level. These asserts are activated
    in debug releases, only.
*/
#define SITEASSERT(cond,msg) SDLASSERT(cond,msg)
#define SITE_LOG

/* All SDL tracer prints uncondional to cerr */
//#define SITE_TRACE2CERR_ON

#else
#define SITEASSERT(cond,msg)
#endif



/** Macro for dynamic_cast operations.
    The macro is used for class conversions with a
    background, that the cast can fail because of CG errors.
    Nevertheless, it can be configured as static cast.
*/
#define SITE_DYNAMIC_CAST(TYPE,VALUE) dynamic_cast<TYPE>(VALUE)

/** Macro for static_cast operations.
    The macro is used for class conversions with a logical
    background, that the cast is type safe. Nevertheless,
    It can be configured as dynamic cast. Note, that not
    all static cast operations are macro based - for other
    good reasons.
*/
#define SITE_STATIC_CAST(TYPE,VALUE) static_cast<TYPE>(VALUE)

/** Macro for const_cast operations.
*/
#define SITE_CONST_CAST(TYPE,VALUE) const_cast<TYPE>(VALUE)

/** Macro for reinterpret_cast */
#define SITE_REINTERPRET_CAST(TYPE,VALUE) reinterpret_cast<TYPE>(VALUE)

/** How to cast SDL context parameter values,... secure! */
#define CONTEXT_CAST(TYPE,VALUE)     SITE_DYNAMIC_CAST(TYPE,VALUE)

/* use these macros for simple type conversion */
#define TO_LONG(val)   ((long)(val))
#define TO_INT32(val)  ((long)(val))
#define TO_UINT32(val) ((unsigned long)(val))
#define TO_SIZE_T(val) ((size_t)(val))
#define TO_UCHAR(val)  ((unsigned char)(val))
#define TO_CHAR(val)   ((char)(val))


/** CG generates some macros for Windows, move away... */
/*#ifdef SDLPredefined_LIB
#define SDL_API DllExport
#else
#define SDL_API
#endif
*/

/**@name ASN.1 configurations
*/

/** Data type used for encoding length information.
    There are some compare actions between SITE_SDL_INT and AsnLen.
    Hence, it is a good idea to set it to the same type.
    XXX the length type should be unsigned
*/
typedef SITE_SDL_INT AsnLen;


/** Configure the buffer types used by the code generator
    for ASN.1 coding support.
*/
#define BUF_TYPE AsnBuf&
#define BUF_TYPE2 pAsnBuf&


/** Forward declaration of the ASN.1 BER buffer class.
    It is a buffer for bytewise reading and reverse writing.
*/
class AsnBuf;

/** Forward declaration of the ASN.1 PER buffer class.
    It is a buffer for bitwise and bytewise reading and forward writing.
*/
class pAsnBuf;


/** Default size of the ASN.1 buffer.
*/
#define ASN_BUF_SIZE 1024*16

/** In C++ a tag is represented as a 4 byte unsigned long.
    Consequently, tagging is restricted to the range of 0..2^21=2097152.
    The integer representation allows efficient comparing of tags and the
    calculation of tag values from constant arguments with the C++ compiler
    optimization step.
*/
typedef unsigned long AsnTag;

//@}
//XXX still necessary? which sdl construct does it represent?
/** Fix the if-then-else-fi problem system dependent.
    It is not allowed to use the macro for hand written code.
    Background:
      Reliant CC is not able to handle standard conform ? expressions and
      there are rare cases, where the generated code is not standard
      conform by using the simple way with ?: expression.
      There is a general and especially efficient solution for that problem
      but SUN CC 6.2 PL1 has a problem with tempory values nd corrupts
      the memory.
      Therefore we use for Solaris the old approach. With 6.2 PL2
      and temporary-fix flag the problem disappears.
*/
#ifdef SOLARIS
#define SITE_if_fi(TYPE,COND,E1,E2) ((COND)?(E1):(E2))
#else
#define SITE_if_fi(TYPE,COND,E1,E2) \
  ((COND).val()?TYPE::convert(E1):TYPE::convert(E2))
#endif

/* a value of 0 in a variable argument list of a constructor of a derived class
   totally confuses the MS VC in Visual Studio versions before 7.0. We use this
   macro to terminate lists instead. */
#if defined(_MSC_VER) && _MSC_VER<1300
#define SIGNAL_LIST_END -1
#else
#define SIGNAL_LIST_END 0
#endif

#endif
