/*******************************************************************************
*   vim:sw=2:ts=2:et
*
*   File    : SDLString.cxx
*   Author  : Ralf Schr�der
*             Humboldt University Berlin
*             Department of Computer Science / System Analysis
*   e-mail  : r.schroeder@informatik.hu-berlin.de
*   Project : @vantage platform
*   $Date: 2006-04-04 13:14:09 +0200 (tir, 04 apr 2006) $
*   $Revision: 586 $
*
*******************************************************************************/
#include "SDLString.h"
#include "BasicEncoding.h"
#include "SDLBool.h"
#include "SDLInt.h"

#ifdef SITE_RCS_IDENT
static const char* SDLSTRING_IMPL_RCSID FRWUNUSED = "$Id: SDLString.cc 586 2006-04-04 11:14:09Z tneumann $";
#else
static const char* SDLSTRING_IMPL_SCCSID FRWUNUSED = "@(#) ";
#endif

void
SDLStringBase::del_elems()
{
  // we have to iter until _string_size because a cut only set _length
  for(SITE_SDL_INT i=0;i<_string_size;i++) {
    delete _string[i]; _string[i]=0;
  }
  _length = 0;
}

SDLStringBase::SDLStringBase()  :
  _length(0),_string(0),_string_size(0)
{ set_state(validValue); }

SDLStringBase::SDLStringBase(const SDLType& e, SITE_SDL_INT size):
  _length(size),
  _string(new SDLType*[TO_SIZE_T(size)]),
  _string_size(size)
{
  for(SITE_SDL_INT i=0; i<size; i++) {
    _string[i] = e.copy();
  }
  set_state(validValue);
}

SDLStringBase::SDLStringBase(const SDLStringBase& str):
  SDLType(str),
  _length(str._length),
  _string(0),
  _string_size(0)
{
  if (str.state(SITEtemporaryValue)) {
#ifdef SITE_LOG
    if (SDLType::_type_debug & SITE_COPY_LOG)
      std::cerr << "(SDLRTE) stringbase reference copy of value "
           << str << std::endl;
#endif
    _string = str._string;
    _string_size = str._string_size;
    SDLStringBase*s = SITE_CONST_CAST(SDLStringBase*,&str);
    s->_length = s->_string_size = 0;
    s->_string = 0;
    return;
  }
#ifdef SITE_LOG
  if (SDLType::_type_debug & SITE_COPY_LOG)
    std::cerr << "(SDLRTE) stringbase copy of value "
           << str << std::endl;
#endif
  if (!_length) return;
  _string = new SDLType*[TO_SIZE_T(_length)];
  _string_size = _length;
  for(SITE_SDL_INT i=0; i<_length; i++) {
    if (str._string[i]) {
      _string[i] = str._string[i]->copy();
    } else _string[i] = 0;
  }
}

SDLStringBase::SDLStringBase(const SDLStringBase& str,SITE_SDL_INT reserve):
  SDLType(str),
  _length(str._length),
  _string(new SDLType*[TO_SIZE_T(str._length+reserve)]),
  _string_size(str._length+reserve)
{
  SITE_SDL_INT i;
  for(i=0; i<_length; i++)
    if (str._string[i]) {
      _string[i] = str._string[i]->copy();
    } else _string[i] = 0;
  for(;i<_string_size;i++)
    _string[i] = 0;
}

void
SDLStringBase::resize(SITE_SDL_INT new_len)
{
  if (new_len>_string_size) {
    // good value for the internal buffer, probably!
    SITE_SDL_INT newsize = 2*new_len-_string_size+_length;
    if (newsize<16) newsize = 16;
    SDLType** newlist = new SDLType*[TO_SIZE_T(newsize)];
    if (_length) memcpy(newlist,_string,TO_SIZE_T(_length*sizeof(SDLType*)));
    memset(newlist+_length,0,TO_SIZE_T((newsize-_length)*sizeof(SDLType*)));
    delete[]_string;
    _string=newlist;
    _string_size = newsize;
  }
  for (;_length > new_len; _length--) {
    delete _string[_length-1]; _string[_length-1] = 0;
  }
  // set the new length (can cause pending elems behind the limit)
  _length=new_len;
}


SDLStringBase::~SDLStringBase()
{
  del_elems();
  delete[]_string; _string = 0;
  _string_size = 0;
}


bool
SDLStringBase::valid()const
{
  if (!state(validValue)) return false;
  return true;
}

AsnLen
SDLStringBase::bEnc(BUF_TYPE b) const
{
  AsnLen len = bEncContent(b);
  len += BEncDefLen(b,len);
  len += BEncTag1(b, UNIV, CONS, SEQ_TAG_CODE);
  return len;
}

AsnLen
SDLStringBase::bEncContent(BUF_TYPE b) const
{
#ifdef SITE_LOG
  if (SDLType::_type_debug & SITE_BER_LOG)
    std::cerr << "encode stringbase value " << *this << std::endl;
#endif
  AsnLen len = 0;
  for(SITE_SDL_INT i = _length-1; i>=0; i--) {
    if (_string[i]) len += _string[i]->bEnc(b);
    else throw SDLInvalidIndex("empty field during encoding");
  }
  return len;
}

void
SDLStringBase::bDec(BUF_TYPE b, AsnLen& bytesDecoded)
{
  AsnTag tagId = BDecTag1(b,bytesDecoded);
  AsnLen elmtLen;
  if (tagId != MAKE_TAG_ID(UNIV,CONS, SEQ_TAG_CODE)) {
    TagError(MAKE_TAG_ID(UNIV,CONS,SEQ_TAG_CODE),tagId); return;
  }
  elmtLen = BDecLen(b,bytesDecoded);
  AsnLen localBytesDecoded = 0;
  bDecContent(b,tagId,elmtLen,localBytesDecoded);
  if (elmtLen == INDEFINITE_LEN) { BDecEoc(b,localBytesDecoded); }
  bytesDecoded += localBytesDecoded;
}

void
SDLStringBase::bDecContent(BUF_TYPE b,AsnTag,
    AsnLen len, AsnLen& bytesDecoded)
{
  AsnLen localBytesDecoded = 0;
  set_state(invalidValue);
  for(SITE_SDL_INT i=0;(localBytesDecoded<len)||(len==INDEFINITE_LEN);i++) {
    if (len==INDEFINITE_LEN) {
      AsnBufCursor cursor = b.get_cursor();
      AsnLen tagLen = 0;
      AsnTag tagId = BDecTag(b,tagLen);
      if (tagId==EOC_TAG_ID) {
        BDEC_2ND_EOC_OCTET(b,localBytesDecoded);
        localBytesDecoded += tagLen;
        break;
      }
      b.set_cursor(cursor);
    }
    _elem(i)->bDec(b,localBytesDecoded);
  }
  bytesDecoded += localBytesDecoded;
  set_state(validValue);
#ifdef SITE_LOG
  if (SDLType::_type_debug & SITE_BER_LOG)
    std::cerr << "decoded stringbase value " << *this << std::endl;
#endif
}

AsnLen
SDLStringBase::pEnc(BUF_TYPE2 b) const
{
  AsnLen elmtLen=pEncLen(b, _length);
  AsnLen rem=_length;
  AsnLen pos=0;
  int cur;
  while(rem>0){
    // compute size of next fragment
    cur = (rem<16384?rem: (rem>>14)<=4?(rem>>14)*16384: 4*16384);
    for(AsnLen max_pos=pos+cur;pos<max_pos;pos++)
      if (_string[pos]) elmtLen += _string[pos]->pEnc(b);
      else throw SDLInvalidIndex("empty field during encoding");
    rem-=cur;
    // this is not the last fragment
    if(!(cur%16384))
      elmtLen+=pEncLen(b,rem);
  }
  return elmtLen;
}

void
SDLStringBase::pDec(BUF_TYPE2 b)
{
  int rem=pDecLen(b);
  AsnLen pos=0;
  while(rem>0){
    AsnLen max_pos=pos+rem;
    for(;pos<max_pos;pos++)
      _elem(pos)->pDec(b);
    #if defined(_MSC_VER) && _MSC_VER<1300
      if(rem%16384 != 0) rem=0;
      else rem=pDecLen(b);
    #else
      rem=(rem%16384)?0:pDecLen(b);
    #endif
  }
  set_state(validValue);
}

SDLTypeId
SDLStringBase::sdl_type_id()const
{ return TypeId_SDLSequenceof; }


void
SDLStringBase::_Print(std::ostream& out,SITE_SDL_INT start)const
{
  if (!valid()) { out << "<invalid value>"; return; }
  out << "-- SEQUENCE OF [" << TO_SIZE_T(_length) << "/" << TO_SIZE_T(_string_size) << "] -- {";
  char nl = (_length>2)?'\n':' ';
  for(SITE_SDL_INT i=0;i<_length;i++) {
    out << nl << "  --["<< TO_SIZE_T(i+start)<< "]-- ";
    if(!_string[i])
      out << "<invalid value>";
    else
      _string[i]->Print(out);
  }
  out << nl << "}";
}


unsigned int
SDLStringBase::hash(unsigned int max_hash)const
{
  unsigned int res = TO_UINT32(_length);
  for(SITE_SDL_INT i=0;i<_length;i++)
    if (_string[i])
      res=(res+_string[i]->hash(max_hash))%max_hash;
  return res;
}

SDLStringBase&
SDLStringBase::operator=(
  const SDLStringBase& str)
{
#ifdef SITE_LOG
  if (SDLType::_type_debug & SITE_ASSIGNMENT_LOG)
    std::cerr << "(SDLRTE) stringbase " <<
            (str.state(SITEtemporaryValue)?"reference ":"") <<
            "assignment of " << str <<
            " to variable with value " << *this << std::endl;
#endif
  str.check_valid();
  if (this==&str) return *this;
  set_state(~SITEtemporaryValue);
  if (str.state(SITEtemporaryValue)) {
    del_elems(); delete[]_string;
    _length = str._length;
    _string = str._string;
    _string_size = str._string_size;
    set_state(validValue);
    SDLStringBase*s = SITE_CONST_CAST(SDLStringBase*,&str);
    s->_length = s->_string_size = 0;
    s->_string = 0;
    return *this;
  }
  set_state(invalidValue);
  SITE_SDL_INT i;
  if ((_string_size < str._length) // too small
      || (str._length>32 && _string_size>8*str._length) // too large
     ) {
    // set up a new string item
    del_elems(); delete[]_string;
    _string_size = str._length;
    _length = str._length;
    _string = new SDLType*[TO_SIZE_T(_string_size)];
    for(i=0;i<_length;i++) {
      _string[i] = str._string[i]?str._string[i]->copy():0;
    }
  } else {
    for(i=0;i<str._length;i++) {
      if (_string[i]) {
        if (str._string[i]) { _string[i]->assign(str._string[i]); }
        else { delete _string[i]; _string[i]=0; }
      } else {
        _string[i] = str._string[i]?str._string[i]->copy():0;
      }
    }
    for(;i<_length;i++) {
      delete _string[i]; _string[i] = 0;
    }
    _length = str._length;
  }
  set_state(validValue);
  return *this;
}


const SDLBool&
SDLStringBase::eq(const SDLStringBase& s)const
{
  const SDLStringBase &str = s;
  check_valid(); str.check_valid();
  if (_length !=str._length) return SDLBool::SDLFalse();
  for(int i=0; i<_length; i++) {
    if (!_string[i]) {
      if (!str._string[i]) continue;
      else return SDLBool::SDLFalse();
    } else {
      if (!str._string[i]) return SDLBool::SDLFalse();
      else {
        if (!_string[i]->equal(*str._string[i])) return SDLBool::SDLFalse();
      }
    }
  }
  return SDLBool::SDLTrue();
}

const SDLBool&
SDLStringBase::ne(const SDLStringBase& str)const
{ return eq(str).val()?SDLBool::SDLFalse():SDLBool::SDLTrue(); }


bool
SDLStringBase::equal(const SDLType& str)const
{ return eq(SITE_DYNAMIC_CAST(const SDLStringBase&,str)); }


SDLInt
SDLStringBase::length()const
{
  check_valid(); return _length;
}

const SDLType&
SDLStringBase::first()const
{
  check_valid();
  if(!_length) { throw SDLInvalidIndex("empty set"); }
  if(!_string[0]) { throw SDLInvalidIndex("no value"); }
  return *_string[0];
}

const SDLType&
SDLStringBase::last()const
{
  check_valid();
  if(!_length) { throw SDLInvalidIndex("empty set"); }
  if(!_string[_length-1]) { throw SDLInvalidIndex("no value"); }
  return *_string[_length-1];
}

void
SDLStringBase::_cat(const SDLStringBase& str)
{
  check_valid(); str.check_valid();
  if (_string_size<_length+str._length) {
    // set up a new string item
    SDLType** new_string = new SDLType*[TO_SIZE_T(_length+str._length)];
    for (SITE_SDL_INT i=0; i<_length; i++)
      new_string[i] = _string[i];
    delete[] _string; _string = new_string;
    _string_size = _length+str._length;
  }
  for(SITE_SDL_INT my_i=_length, str_i=0; str_i<str._length; my_i++,str_i++) {
    if (_string[my_i]) {
      if (str._string[str_i]) *_string[my_i] = *str._string[str_i];
      else { delete _string[my_i]; _string[my_i]=0; }
    } else {
      _string[my_i] = str._string[str_i]?str._string[str_i]->copy():0;
    }
  }
  _length += str._length;
}

SDLType&
SDLStringBase::operator()(SITE_SDL_INT index)
{
  check_valid();
  if (index<0) { throw SDLInvalidIndex(); }
  return *_elem(index);
}

const SDLType&
SDLStringBase::operator[](SITE_SDL_INT index)const
{
  check_valid();
  if (index<0 || _length-1<index) { throw SDLInvalidIndex(); }
  if (!_string[index]) { throw SDLInvalidIndex("no value"); }
  return *_string[index];
}

SDLType*
SDLStringBase::_elem(SITE_SDL_INT index)
{
  if (index>=_length) { resize(index+1); }
  if (!_string[index]) {
    _string[index] = _create_elem();
  }
  set_state(validValue); // changes default value
  return _string[index];
}

void
SDLStringBase::_substr(
  const SDLStringBase&src,SITE_SDL_INT from,SITE_SDL_INT len)
{
  src.check_valid();
  // if src._length==from and len==0, return empty string
  if (from<0 || src._length<from || len<0 || (src._length==from && len!=0)) {
    throw SDLInvalidIndex();
  }
  // non SDL-2000
  if (from+len>src._length) {
    len = src._length-from;
  }
  _length = len;
  _string_size = len;
  SITEASSERT(_string==0,"_substr non empty this");
  _string = new SDLType*[TO_SIZE_T(len)];
  for(SITE_SDL_INT i=0; i<len; i++) {
    _string[i] = src._string[i+from]?src._string[i+from]->copy():0;
  }
  set_state(validValue);
  set_state(SITEtemporaryValue);
}

void
SDLStringBase::_cut(SITE_SDL_INT index)
{
  if (index<0 || _length-1<index) return;
  // instead of worrying about the final 0 I assign always 0
  delete _string[index]; _string[index] = 0;
  SITE_SDL_INT i;
  // and move left
  for(i=index+1; i<_length; i++) {
    _string[i-1] = _string[i];
    _string[i] = 0;
  }
  _length--;
}

void
SDLStringBase::assign_new()
{
  del_elems();
  delete[]_string; _string = 0;
  _string_size = 0;
  SDLType::assign_new();
}

void
SDLStringBase::init_type()
{
  SDLType::init_type();
  delete _create_elem();
}
