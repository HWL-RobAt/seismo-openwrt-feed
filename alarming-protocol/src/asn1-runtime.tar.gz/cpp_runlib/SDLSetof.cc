/*******************************************************************************
*   vim:sw=2:ts=2:et
*
*   File    : SDLSetof.cxx
*   Author  : Ralf Schr�der
*             Humboldt University Berlin
*             Department of Computer Science / System Analysis
*   e-mail  : r.schroeder@informatik.hu-berlin.de
*   Project : @vantage platform
*   $Date: 2005-05-05 17:38:41 +0200 (Thu, 05 May 2005) $
*   $Revision: 1.4 $
*
*******************************************************************************/
#include "SDLSetof.h"
#include "SDLBool.h"
#include "BasicEncoding.h"

#ifdef SITE_RCS_IDENT
static const char* SDLSETOF_IMPL_RCSID FRWUNUSED = "$Id: SDLSetof.cc 554 2005-05-05 15:38:41Z tneumann $";
#else
static const char* SDLSETOF_IMPL_SCCSID FRWUNUSED = "@(#) ";
#endif

AsnLen
SDLSetofBase::bEnc(BUF_TYPE b) const
{
  AsnLen len = bEncContent(b);
  len += BEncDefLen(b,len);
  len += BEncTag1(b, UNIV, CONS, SET_TAG_CODE);
  return len;
}

void
SDLSetofBase::bDec(BUF_TYPE b, AsnLen& bytesDecoded)
{
  AsnTag tagId = BDecTag1(b,bytesDecoded);
  AsnLen elmtLen;
  if (tagId != MAKE_TAG_ID(UNIV,CONS, SET_TAG_CODE)) {
    TagError(MAKE_TAG_ID(UNIV,CONS,SET_TAG_CODE),tagId); return;
  }
  elmtLen = BDecLen(b,bytesDecoded);
  AsnLen localBytesDecoded = 0;
  bDecContent(b,tagId,elmtLen,localBytesDecoded);
  if (elmtLen == INDEFINITE_LEN) { BDecEoc(b,localBytesDecoded); }
  bytesDecoded += localBytesDecoded;
}

SDLTypeId
SDLSetofBase::sdl_type_id()const
{ return TypeId_SDLSetof; }


void
SDLSetofBase::Print(std::ostream& out)const
{
  if (!valid()) { out << "<invalid bag value>"; return; }
  out << "-- SET OF -- {";
  char nl = (lengthAsLong()>2)?'\n':' ';
  for(SITE_SDL_INT i=0;i<lengthAsLong();i++) {
    if (i>0) out << ",";
    out << nl;
    if(!val()[i]) out << "<internal error> field " << i << " not present";
    else { out << "  "; val()[i]->Print(out); }
  }
  out << nl << "}";
}

const SDLBool&
SDLSetofBase::eq(const SDLStringBase& bag)const
{
  check_valid(); bag.check_valid();
  // at least equal length
  if (bag.lengthAsLong()!=(lengthAsLong())) return SDLBool::SDLFalse();

  // because the underlaying strings are unsorted, one string is
  // deleted succesive during elem checks
  SITE_SDL_INT my_len = lengthAsLong();
  SDLSetofBase *tmp = SITE_STATIC_CAST(SDLSetofBase*,copy());
  SITE_SDL_INT i,j;
  try {
    for(i=0;i<my_len;i++) {
      SITEASSERT(bag.val()[i]!=0,"null element in SDLSetof");
      for(j=0;j<my_len;j++) {
        if (!tmp->val()[j]) continue;  // deleted element
        if (tmp->val()[j]->equal(*(bag.val()[i]))) {
          // equal element found, delete it and break the inner loop
          delete tmp->val()[j]; tmp->val()[j] = 0;
          break;
        }
      }
      // if the inner loop did not break, I have a different elem
      if (j==lengthAsLong()) { delete tmp; return SDLBool::SDLFalse(); }
    }
    // because the size is equal, all elements of tmp are 0 now
    delete tmp;
    return SDLBool::SDLTrue();
  } catch(...) { delete tmp; throw; }
}

const SDLBool&
SDLSetofBase::ne(const SDLStringBase& b)const
{
  return eq(b).val()?SDLBool::SDLFalse():SDLBool::SDLTrue();
}


bool
SDLSetofBase::equal(const SDLType& b)const
{
  return eq(SITE_DYNAMIC_CAST(const SDLSetofBase&,b));
}

void
SDLSetofBase::_incl(const SDLType& e)
{
  check_valid(); e.check_valid();
  _elem(lengthAsLong())->assign(&e);
}

void
SDLSetofBase::_del(const SDLType& e)
{
  check_valid(); e.check_valid();
  bool deleted = false;
  SITE_SDL_INT i;
  for(i=0;i<lengthAsLong();i++) {
    SITEASSERT(val()[i]!=0,"null element in SDLSetof");
    if (val()[i]->equal(e)) {
      delete val()[i]; val()[i] = 0;
      deleted = true; break;
    }
  }
  for(i=i+1;i<lengthAsLong();i++) {
    SITEASSERT(val()[i]!=0,"null element in SDLSetof");
    val()[i-1] = val()[i]; val()[i] = 0;
  }
  if (deleted) resize(lengthAsLong()-1);
}

const SDLType&
SDLSetofBase::_take()
{ return first(); }

const SDLBool&
SDLSetofBase::in(const SDLType& e) const
{
  check_valid(); e.check_valid();
  for(SITE_SDL_INT i=0;i<lengthAsLong();i++) {
    SITEASSERT(val()[i]!=0,"null element in SDLSetof");
    if (val()[i]->equal(e)) {
      return SDLBool::SDLTrue();
    }
  }
  return SDLBool::SDLFalse();
}

const SDLBool&
SDLSetofBase::lt(const SDLSetofBase& b)const
{
  check_valid(); b.check_valid();
  if (!lengthAsLong()) {
    // the short way for empty sets...
    return (b.lengthAsLong()>0)?SDLBool::SDLTrue():SDLBool::SDLFalse();
  }
  SDLSetofBase *tmp = SITE_STATIC_CAST(SDLSetofBase*,b.copy());
  try {
    for(SITE_SDL_INT i=0;i<lengthAsLong();i++) {
      SITE_SDL_INT j;
      for(j=0;j<tmp->lengthAsLong();j++) {
        if (tmp->val()[j] && tmp->val()[j]->equal(*val()[i])) {
          delete tmp->val()[j]; tmp->val()[j] = 0; break;
        }
      }
      if (j==tmp->lengthAsLong()) {
        delete tmp; return SDLBool::SDLFalse();
      }
    }
    bool ret = false;
    for(SITE_SDL_INT k=0;k<tmp->lengthAsLong();k++) {
      if (tmp->val()[k]) { ret = true; break; }
    }
    delete tmp;
    return ret?SDLBool::SDLTrue():SDLBool::SDLFalse();
  } catch(...) { delete tmp; throw; }
}


const SDLBool&
SDLSetofBase::gt(const SDLSetofBase& b)const
{
  return b.lt(*this);
}

const SDLBool&
SDLSetofBase::le(const SDLSetofBase& b)const
{
  check_valid(); b.check_valid();
  if (!lengthAsLong()) return SDLBool::SDLTrue();
  SDLSetofBase *tmp = SITE_STATIC_CAST(SDLSetofBase*,b.copy());
  try {
    for(SITE_SDL_INT i=0;i<lengthAsLong();i++) {
      SITE_SDL_INT j;
      for(j=0;j<tmp->lengthAsLong();j++) {
        if (tmp->val()[j] && tmp->val()[j]->equal(*val()[i])) {
          delete tmp->val()[j]; tmp->val()[j] = 0; break;
        }
      }
      if (j==tmp->lengthAsLong()) {
        delete tmp; return SDLBool::SDLFalse();
      }
    }
    delete tmp;
    return SDLBool::SDLTrue();
  } catch(...) { delete tmp; throw; }
}

const SDLBool&
SDLSetofBase::ge(const SDLSetofBase& b)const
{
  return b.le(*this);
}


void
SDLSetofBase::_and2(const SDLSetofBase& b1,const SDLSetofBase& b2)
{
  b1.check_valid(); b2.check_valid();
  SDLSetofBase *tmp = SITE_STATIC_CAST(SDLSetofBase*,b1.copy());
  try {
    SITE_SDL_INT i,j;
    for(i=0;i<b2.lengthAsLong();i++) {
      for(j=0;j<tmp->lengthAsLong();j++) {
        if (!tmp->val()[j]) continue;
        if (tmp->val()[j]->equal(*b2.val()[i])) {
          resize(lengthAsLong()+1);
          val()[lengthAsLong()-1] = tmp->val()[j];
          tmp->val()[j] = 0;
          break;
        }
      }
    }
    delete tmp;
  } catch (...) { delete tmp; throw; }
}
