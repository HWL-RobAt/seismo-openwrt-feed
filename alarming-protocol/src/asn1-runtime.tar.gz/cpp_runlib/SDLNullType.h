/*******************************************************************************
*   vim:sw=2:ts=2:et
*
*   File    : SDLNullType.h
*   Author  : Ralf Schr�der
*             Humboldt University Berlin
*             Department of Computer Science / System Analysis
*   e-mail  : r.schroeder@informatik.hu-berlin.de
*   Project : @vantage platform
*   $Date: 2005-05-05 17:38:41 +0200 (Thu, 05 May 2005) $
*   $Revision: 1.3 $
*
*******************************************************************************/
#ifndef _SDLNULL_TYPE_H
#define _SDLNULL_TYPE_H

// forward declarations
class SDLBool;
class SDLAny;

#include "SDLType.h"

static const char* SDLNULLTYPE_RCSID FRWUNUSED = "$Id: SDLNullType.h 554 2005-05-05 15:38:41Z tneumann $";

/** SDL Boolean */
class SDL_API SDLNullType : public SDLType
{
  public:

    /* Call of generated macro for code shared by all declarations of SDL types
     */
    declareSDLType(SDLNullType,SDLType)

    /** Constructor for an invalid value */
    SDLNullType() {}

    /** Constructor for a valid value */
    SDLNullType(long) { set_state(validValue); }

    /** Constructor for an omitted (invalid) value */
    SDLNullType(const SDLNull&)  {}

    /** Copy constructor */
    SDLNullType(const SDLNullType& n) :SDLType(n)
    {
#ifdef SITE_LOG
      if (SDLType::_type_debug & SITE_COPY_LOG)
        std::cerr << "(SDLRTE) Null copy of value "
             << n << std::endl;
#endif
    }


    /** Static literal object for NULL */
    static const SDLNullType the_null;
    /** Literal object for NULL */
    static const SDLNullType& Null() { return the_null; }

    /** Valid check.
        @returns true, if the data object is a valid one.
        It can be configured to switch off this test.
    */
    virtual bool valid()const ;


    /** Encoding of tag and length */
    virtual AsnLen bEnc(BUF_TYPE b) const;

    /** Encoding of the boolean value without tag and length */
    virtual AsnLen bEncContent(BUF_TYPE) const;

    /** Decoding of tag and length */
    virtual void bDec(BUF_TYPE b, AsnLen& bytesDecoded);

    /** Decoding of the boolean value without tag and length */
    virtual void bDecContent(BUF_TYPE,AsnTag,AsnLen,AsnLen&);

    /** Access to the kind of the object */
    virtual SDLTypeId sdl_type_id()const;

    /** Prints NULL. */
    virtual void Print(std::ostream&)const;

    /** Returns a hash value */
    virtual unsigned int hash(unsigned int)const { return 0; }

    /** Assignment operator for SDLNull */
    SDLNullType& operator=(const SDLNullType& n)
    {
#ifdef SITE_LOG
      if (SDLType::_type_debug & SITE_ASSIGNMENT_LOG)
        std::cerr << "(SDLRTE) Null assignment of " << n <<
                " to variable with value " << *this << std::endl;
#endif
      n.check_valid(); set_state(validValue); return *this;
    }

    /** SDL equality. */
    //@{
    SDLBool eq(const SDLNullType& n)const ;
    SDLBool ne(const SDLNullType& n)const ;

    /** Compares boolean objects.
        @param b a boolean object
        The dynamic cast failure is not caught because the code is
        generated correctly.
    */
    bool equal(const SDLType& n) const ;
    //@}
};

#endif
