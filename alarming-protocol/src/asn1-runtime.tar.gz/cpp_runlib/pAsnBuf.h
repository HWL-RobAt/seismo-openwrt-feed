/*******************************************************************************
*   vim:sw=2:ts=2:et
*
*   File    : pAsnBuf.h
*   Author  : Konrad Voigt, Glenn Schuetze
*             Humboldt University Berlin
*             Department of Computer Science / System Analysis
*   e-mail  : kvoigt@informatik.hu-berlin.de, schuetze@informatik.hu-berlin.de
*   Project : @vantage platform
*   $Date: 2005-05-05 17:38:41 +0200 (Thu, 05 May 2005) $
*   $Revision: 1.1 $
*
*******************************************************************************/

#ifndef _PASNBUF_H
#define _PASNBUF_H

#include <string>
#include <vector>
#include "SDLBaseImpl.h"

/** type representing a block of bytes (octets) */
typedef std::vector<Byte> ByteArray;

/** type representing a block of bits */
typedef std::vector<bool> BitField;

/**
   Forward writing bit buffer.
   pAsnBuf represents a buffer of bits and provides methods for
   writing and forward reading it all single bits, bitfields,
   single bytes and byte blocks.
   The buffer automatically grows if needed.
   The bytes written and read are counted.
   @author Uwe Knauer, transformed by Konrad Voigt and Glenn Schuetze
 */
class pAsnBuf
{
    /**
     * attributes
     */
public:
    int writeOperations;
    ByteArray buf;

protected:
    /** The position of the write pointer. It points always to the next
        position to write to. The first position is 0.
     */
    int writePos;
    int readPos;
    int byteCounter;

    /**
     * constructors
     */

public:

    //pAsnBuf():pAsnBuf(32){}
    pAsnBuf(int size) :
    writeOperations(0),
    buf(size),
    writePos(0),
    readPos(0)
    {}

    pAsnBuf(ByteArray data) :
	buf(data),
    writePos(data.size()),
    readPos(0),
    byteCounter(0)
    //,writeOperations(1) really necessary?
    {}

    /**
     * encoding methods
     */
public:
    int fill();
    void putBit(bool val);
    void putBits(BitField& vals);
    void putByte(Byte val);
    void putBytes(ByteArray& val);

    /**
     * decoding methods
     */
    void skip();
    BitField getBitField(int bits);
    int getBitsAsInt(int bits);
    bool getBit();
    bool rollBack(int steps);
    bool undoWrite(int steps);
    Byte getByte();
    void getBytes(int number, ByteArray& newbuf);
    void resetByteCounter();
    int getByteCounter();
    void installData(ByteArray& data);
    ByteArray copyBytes(int length);
    void reset();
    int size();
    ByteArray toByteArray();
    int getReadPos();
    int getWritePos();
    std::string subString(int pos, int len);
    void debug_print(int j);
};

#endif
