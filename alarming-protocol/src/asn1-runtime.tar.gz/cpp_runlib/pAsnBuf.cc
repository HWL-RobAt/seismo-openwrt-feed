/*******************************************************************************
*   vim:sw=2:ts=2:et
*
*   File    : pAsnBuf.cc
*   Author  : Konrad Voigt, Glenn Schuetze
*             Humboldt University Berlin
*             Department of Computer Science / System Analysis
*   e-mail  : kvoigt@informatik.hu-berlin.de, schuetze@informatik.hu-berlin.de
*   Project : cinderella-site
*   $Date: 2006-04-04 13:14:09 +0200 (tir, 04 apr 2006) $
*   $Revision: 586 $
*
*******************************************************************************/
#include "pAsnBuf.h"
#include <iostream>
#if defined(_MSC_VER) && _MSC_VER<1300
#include "ostream64.h"
#endif

/*XXX is this needed for padding? */
int
pAsnBuf::fill(){
  writeOperations++;
  int elmtLen=writePos%8;
  if(writePos%8!=0){
    buf[writePos/8] &= 0xff<<(8-writePos%8);
    writePos+=8-writePos%8;
  }
  return elmtLen;
}

/* occasional old bit value at new write position is overwritten by new one */
void
pAsnBuf::putBit(bool val){
  writeOperations++;
  Byte writemask=0xff;
  if (val)
	  buf[writePos/8] |= 1<<(7-(writePos%8));
  else {
	  writemask<<=8-writePos%8;
	  buf[writePos/8] &= writemask;
  }
  ++writePos;
  if (writePos%8==0) --byteCounter;
}

void
pAsnBuf::putBits(BitField& vals){
  for(unsigned int i=0; i<vals.size(); i++){
	  putBit(vals[i]);
  }
}

/* occasional old bit values at new write positions are overwritten by new ones */
void
pAsnBuf::putByte(Byte val){
  writeOperations++;
  if (writePos%8==0)
	  buf[writePos/8]=val;
  else {
    // wipe out unused bits (may be skipped if we assume unused bits to be 0)
    buf[writePos/8] &= 0xff<<(8-writePos%8);
    // write starting bits of value
    buf[writePos/8] |= val>>(writePos%8);
    // write remaining bits of value
    buf[writePos/8+1] = val<<(8-writePos%8);
  }
  writePos+=8;
  byteCounter--;
}

void
pAsnBuf::putBytes(ByteArray& val){
  writeOperations++;
  /*
     if(buf.size()*8-writePos<val.size()*8){
     if (buf.size() << 1 < buf.size()+val.size()) std::vector<char> newbuf = std::vector<char>(buf.size()+val.size());
     else std::vector<char> newbuf = std::vector<char>(buf.size()+val.size());
     System.arraycopy(buf, 0, newbuf, 0, buf.size()); //FIXME
     buf=newbuf;
     }*/

  if(writePos%8==0){
    for (unsigned int i=0; i<val.size(); i++)
	    buf[writePos/8+i] = val[i];
    writePos+=val.size()*8;
    byteCounter-=val.size();
  }
  else{
    // writePos and byteCounter are adjusted inside putByte
    for (unsigned int i=0; i<val.size(); i++)
	    putByte(val[i]);
  }
}

/*XXX is this needed for padding? */
void
pAsnBuf::skip(){
  if(readPos%8!=0) readPos+=8-readPos%8;
}

BitField
pAsnBuf::getBitField(int bits){
  BitField bitmap(bits);
  for(int i=0; i<bits; i++){
	  bitmap[i]= (buf[readPos/8] & 1<<(7-readPos%8))!=0?true:false;
	  readPos++;
  }
  return bitmap;
}

/*XXX this function should return an unsigned type */
int
pAsnBuf::getBitsAsInt(int bits){
  int val =0;
  BitField pending=getBitField(bits%8);
  for(int i=0; i<bits%8; i++)
  {
    val<<=1;
	  val |= pending[i]?1:0;
  }
  bits-=pending.size();
  while(bits>=8){
    val<<=8;
    val |= getByte();
    bits-=8;
  }
  return val;
}

bool
pAsnBuf::getBit(){
  bool temp;
  temp=(buf[readPos/8] & 1<<(7-readPos%8))!=0?true:false;
  readPos++;
  return temp;
}

bool
pAsnBuf::rollBack(int steps){
  if(readPos-steps<0) return false;
  byteCounter-=steps/8;
  readPos-=steps;
  return true;
}

/*XXX wipes out unused bits in the new current byte; pointless since this
 * wiping is only done for one byte and anyway writing routines always
 * overwrite unused bits; steps should be of unsigned type */
bool
pAsnBuf::undoWrite(int steps){
  if(writePos-steps<0) return false;
  byteCounter+=steps/8;
  writePos-=steps;
  buf[writePos/8] &= 0xff<<(8-writePos%8);
  return true;
}

Byte
pAsnBuf::getByte(){
  byteCounter++;
  readPos+=8;
  return readPos%8==0?
    buf[readPos/8-1]:
    buf[readPos/8-1]<<(readPos%8) | buf[readPos/8]>>(8-readPos%8);
}

/*XXX number should be of unsigned type */
void
pAsnBuf::getBytes(int number, ByteArray& newbuf){
  if (readPos%8==0){
    for (int i=0; i<number; i++)
      newbuf[i]=buf[readPos/8+i];
    readPos+=number*8;
    byteCounter+=number;
  }
  else {
    for(int i=0; i<number; i++)
      newbuf[i]=getByte();
  }
}

void pAsnBuf::resetByteCounter(){
  byteCounter=0;
}

int
pAsnBuf::getByteCounter(){
  return byteCounter;
}

/*  existing data is dismissed */
void
pAsnBuf::installData(ByteArray& data){
  buf = data;
  writePos = data.size()*8;
  readPos = 0;
}

/*XXX what is this used for? */
ByteArray
pAsnBuf::copyBytes(int length){
  ByteArray newbuf(length);
  if(readPos%8==0){
    for (int i=0; i<length; i++)
      newbuf[i]=buf[readPos/8+i];
    readPos+=length*8;
    byteCounter+=length;
  }
  else {
    for(int i=0; i<length; i++)
      newbuf[i]=getByte();
  }
  return newbuf;
}

void
pAsnBuf::reset(){
  readPos=0;
  writePos=0;
}

int
pAsnBuf::size(){
  return writePos/8 + writePos%8!=0?1:0;
}

ByteArray
pAsnBuf::toByteArray(){
  return buf;
}

int
pAsnBuf::getReadPos(){return readPos;}

int
pAsnBuf::getWritePos(){return writePos;}

std::string
pAsnBuf::subString(int pos, int len){
  int safe=readPos;
  std::string bits("");
  readPos=pos;
  for(int i=0; i<len;i++)
      bits+=(getBit()?'1':'0');
  readPos=safe;
  return bits;
}

void
pAsnBuf::debug_print(int j) {
  for(int i=0; i<=j; i++)
    std::cout << "buf[" << i  << "] = " << "\n" << std::hex << cast_from_unsigned(buf[i]) << "\n";
}
