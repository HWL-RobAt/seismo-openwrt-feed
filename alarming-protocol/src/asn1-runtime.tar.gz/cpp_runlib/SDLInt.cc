/*******************************************************************************
*   vim:sw=2:ts=2:et
*
*   File    : SDLInt.cxx
*   Author  : Ralf Schr�der
*             Humboldt University Berlin
*             Department of Computer Science / System Analysis
*   e-mail  : r.schroeder@informatik.hu-berlin.de
*   Project : @vantage platform
*   $Date: 2005-05-05 17:38:41 +0200 (Thu, 05 May 2005) $
*   $Revision: 1.2 $
*
*******************************************************************************/
#include "sdlconfig.h"

#ifdef SITE_RCS_IDENT
static const char* RCSID FRWUNUSED = "$Id: SDLInt.cc 554 2005-05-05 15:38:41Z tneumann $";
#else
static const char* SCCSID FRWUNUSED = "@(#) ";
#endif

#include "SDLInt.h"

#define C_INT SITE_SDL_INT
#define SDLNumber SDLInt
#include "SDLNumber.cc"
#undef C_INT
#undef SDLNumber
