/*******************************************************************************
*   vim:sw=2:ts=2:et
*
*   File    : SDLBit.cxx
*   Author  : Ralf Schr�der
*             Humboldt University Berlin
*             Department of Computer Science / System Analysis
*   e-mail  : r.schroeder@informatik.hu-berlin.de
*   Project : @vantage platform
*   $Date: 2005-05-05 17:38:41 +0200 (Thu, 05 May 2005) $
*   $Revision: 1.3 $
*
*******************************************************************************/
#include "SDLBit.h"
#include "SDLBool.h"
#include "SDLAny.h"
#include "BasicEncoding.h"
#include "SITELIB_implementSDLType_macro.h"

#ifdef SITE_RCS_IDENT
static const char* RCSID FRWUNUSED = "$Id: SDLBit.cc 554 2005-05-05 15:38:41Z tneumann $";
#else
static const char* SCCSID FRWUNUSED = "@(#) ";
#endif

SITELIB_implementSDLType(SDLBit,SDLType)

SDLBit::SDLBit(const SDLAny& a, AsnCodingSet rule_set) : _octet(0),_nr(0)
{
   a.decode(this, rule_set);
}

SDLBit::SDLBit(const SDLBit& b) :
  SDLType(b),_octet(b._octet?new char(*b._octet):0),_nr(b._nr)
{
#ifdef SITE_LOG
  if (SDLType::_type_debug & SITE_COPY_LOG)
    std::cerr << "(SDLRTE) bit copy of value " << b << endl;
#endif
}

SDLBit::~SDLBit()
{
  delete _octet; _octet = 0;
  _nr = 0;
}

const SDLBit SDLBit::the_0(false);
const SDLBit SDLBit::the_1(true);

const SDLBit&
SDLBit::LIT_0()
{
  return the_0;
}

const SDLBit&
SDLBit::LIT_1()
{
  return the_1;
}

bool
SDLBit::equal(const SDLType& b) const
{
  return eq(SITE_DYNAMIC_CAST(const SDLBit&,b));
}

bool
SDLBit::valid()const
{ return state(validValue); }


SDLTypeId
SDLBit::sdl_type_id()const
{ return TypeId_SDLBit; }

void
SDLBit::Print(std::ostream& os)const
{
  if (valid()) os << (val()?"1":"0");
  else os << "<invalid Bit value>";
}

AsnLen
SDLBit::bEnc(BUF_TYPE b) const
{
  b.PutByteRvs((val()?0xFF:0x0));
  BEncDefLenTo127(b,1);
  int yes_unused = BEncTag1(b, UNIV, PRIM, BOOLEAN_TAG_CODE);
  return 3;
}

AsnLen
SDLBit::bEncContent(BUF_TYPE b) const
{
  b.PutByteRvs((val()?0xFF:0x0));
  return 1;
}

void
SDLBit::bDec( BUF_TYPE b, AsnLen& bytesDecoded)
{
  AsnTag tagId = BDecTag1(b,bytesDecoded);
  AsnLen elmtLen;
  if (tagId != MAKE_TAG_ID(UNIV,PRIM,BOOLEAN_TAG_CODE)) {
    TagError(MAKE_TAG_ID(UNIV,PRIM,BOOLEAN_TAG_CODE),tagId); return;
  }
  elmtLen = BDecLen(b,bytesDecoded);
  AsnLen localBytesDecoded = 0;
  bDecContent(b,tagId,elmtLen,localBytesDecoded);
  bytesDecoded += localBytesDecoded;
}

void
SDLBit::bDecContent(BUF_TYPE b, AsnTag, AsnLen elmtLen,
                          AsnLen& bytesDecoded)
{
  set_state(invalidValue);
  if (elmtLen != 1)
    throw ASNLengthException(
      "SDLBit::bDecContent: ERROR - bit value too long"
    );
  if (!_octet) _octet = new char;
  *_octet = (b.GetByte() != 0);
  _nr = 0;
  bytesDecoded++;
  set_state(validValue);
}

SDLBit&
SDLBit::operator=(bool b)
{
#ifdef SITE_LOG
  if (SDLType::_type_debug & SITE_ASSIGNMENT_LOG)
    std::cerr << "(SDLRTE) bit assignment of c++ " << b <<
                 " to variable with value " << *this << endl;
#endif
  if (!_octet) new char;
  *_octet= b?0xff:0x0;
  _nr = 0;
  set_state(validValue);
  return *this;
}

SDLBit&
SDLBit::operator=(const SDLBit& b)
{
#ifdef SITE_LOG
  if (SDLType::_type_debug & SITE_ASSIGNMENT_LOG)
    std::cerr << "(SDLRTE) bit assignment of " << b <<
                 " to variable with value " << *this << endl;
#endif
  b.check_valid();
  if (this == &b) return *this;  // ignore var := var
  delete _octet; _octet = b._octet?new char(*b._octet):0;
  _nr = b._nr;
  set_state(validValue);
  return *this;
}

const SDLBool&
SDLBit::eq(bool b)const
{ return (val()==b)?SDLBool::SDLTrue():SDLBool::SDLFalse(); }

const SDLBool&
SDLBit::ne(bool b)const
{ return (val()!=b)?SDLBool::SDLTrue():SDLBool::SDLFalse(); }

SDLBit
SDLBit::_and(bool b)const
{ return val()&&b; }

SDLBit
SDLBit::_or(bool b)const
{ return val()||b; }

SDLBit
SDLBit::_xor(bool b)const
{ return (val()&&!b)||(!val()&&b); }

SDLBit
SDLBit::impl(bool b)const
{ return !val()||b; }

SDLBit
SDLBit::_not()const
{ return !val(); }

void
SDLBit::assign_new()
{
  delete _octet; _octet = 0;
  _nr = 0;
  SDLType::assign_new();
}
