/*******************************************************************************
*   vim:sw=2:ts=2:et
*
*   File    : SDLAny.h
*   Author  : Ralf Schr�der
*             Humboldt University Berlin
*             Department of Computer Science / System Analysis
*   e-mail  : r.schroeder@informatik.hu-berlin.de
*   Project : @vantage platform
*   $Date: 2005-05-05 17:38:41 +0200 (Thu, 05 May 2005) $
*   $Revision: 1.3 $
*
*******************************************************************************/
#ifndef _SDLANY_H
#define _SDLANY_H

// forward declarations
class SDLBool;
class SDLOctetString;

#include "SDLType.h"

#ifdef SITE_RCS_IDENT
static const char* SDLANY_RCSID FRWUNUSED = "$Id: SDLAny.h 554 2005-05-05 15:38:41Z tneumann $";
#else
static const char* SDLANY_SCCSID FRWUNUSED = "@(#) ";
#endif

/** ASN.1 type ANY with SITE semantics.
    An ANY value represents an ASN.1 encoded SDL value. The encoding
    includes the tag and length information of the type of the value.
    There are operations available on SDL level to assign values to/from ANY.
*/
class SDL_API SDLAny : public SDLType {
  protected:
    /** length of any_buf */
    AsnLen        any_length;

    /** buffer for the encoded value */
    char*         any_buf;

  public:
    _declareSDLType(SDLAny,SDLType)

    /** Constructor for an invalid value */
    SDLAny() ;

    /** Constructor for a given BER OctetString.
        @param os bEnc encoded value (with tag and length)
    */
    SDLAny(const SDLOctetString&os) ;

    /** C++ level Constructor for a given ASN.1 buffer.
        It copies len bytes of the given buffer. The copied
        buffer piece has to represent an bEnc encoded value
        (with tag and length).
    */
    SDLAny(AsnBuf&buff, AsnLen len);

    SDLAny(pAsnBuf&buff, AsnLen len);

    /** Constructor for an omitted (invalid) value */
    SDLAny(const SDLNull&);

    /** Copy constructor */
    SDLAny(const SDLAny& a);

    /** Clean up */
    virtual ~SDLAny() ;

    /** Valid check.
        @returns true, if the data object is a valid one.
        It can be configured to switch off this test.
    */
    virtual bool valid()const ;

    /** Returns an AsnBuf object initialized with the Any values.
        The buffer does not own the inner data stream, hence
        it becomes invalid, if this Any is changed or deleted.
        The buffer has to be deleted after usage.
    */
    AsnBuf* initAsnBuf() const ;

    /** Encoding of this ANY with tag and length.
        The internal buffer is directly written to the
        ASN.1 buffer.
    */
    virtual AsnLen bEnc(BUF_TYPE b) const;

    /** Works excacly as bEnc, because ANY has no tag. */
    virtual AsnLen bEncContent(BUF_TYPE b) const { return bEnc(b); };

    /** Decoding of an ANY.
        It takes the next tag and length information from the buffer
        and puts tag+length len bytes into the internal string.
    */
    virtual void bDec(BUF_TYPE b, AsnLen& bytesDecoded);

    //virtual void pDec(BUF_TYPE2 b, AsnLen& bytesDecoded);
    virtual void pDec(BUF_TYPE2 b);

    /** Decoding of an ANY.
        The given tag and length information is also put into the
        encoded string buffer.
    */
    virtual void bDecContent(BUF_TYPE b,AsnTag tag,AsnLen bytesToDecode,
                             AsnLen& bytesDecoded);

    /** Access to the kind of the object */
    virtual SDLTypeId sdl_type_id()const;

    /** Prints the Any. */
    virtual void Print(std::ostream&)const;

    /** Returns a hash value. */
    virtual unsigned int hash(unsigned int)const;

    /** Assignment operator for Any */
    SDLAny& operator=(const SDLAny&) ;

    /** Returns a copy of the octet string of this Any. */
    SDLOctetString octet_string()const;

    /** SDL equality.
        Note, encoded values may have a different byte representation.
    */
    //@{
    SDLBool eq(const SDLAny& a)const ;
    SDLBool ne(const SDLAny& a)const ;

    /** Compares Any objects.
        @param a an Any object
    */
    bool equal(const SDLType& a) const ;
    //@}

    /** Decode the internal ASN.1 buf into the given fresh created
        type object.
        If new_val is not a new value, random side effects are possible.
        Any decode exception can be thrown here.
    */
    //XXX change rule par
    void decode(SDLType*new_val, AsnCodingSet rule_set=asn_ber)const;

    /** Delete the inner value */
    virtual void assign_new();
};

#endif
