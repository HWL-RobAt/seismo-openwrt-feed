/*******************************************************************************
*   vim:sw=2:ts=2:et
*
*   File    : SDLOctet.h
*   Author  : Ralf Schr�der
*             Humboldt University Berlin
*             Department of Computer Science / System Analysis
*   e-mail  : r.schroeder@informatik.hu-berlin.de
*   Project : @vantage platform
*   $Date: 2005-05-05 17:38:41 +0200 (Thu, 05 May 2005) $
*   $Revision: 1.2 $
*
*******************************************************************************/
#ifndef _SDLOCTET_H
#define _SDLOCTET_H

#include "SDLBitString.h"

#ifdef SITE_RCS_IDENT
static const char* SDLOCTET_RCSID FRWUNUSED = "$Id: SDLOctet.h 554 2005-05-05 15:38:41Z tneumann $";
#else
static const char* SDLOCTET_SCCSID FRWUNUSED = "@(#) ";
#endif

/**  SDL (Z105) Octet */
class SDL_API SDLOctet: public SDLBitString {
    /* Call of generated macro for code shared by all declarations of SDL types
     */
    declareSDLType(SDLOctet,SDLBitString)
private:
    /** Static empty literal */
    static const SDLOctet empty;
public:
    /** The empty literal. It has the wrong size (0). */
    static const SDLOctet& LIT_H() { return empty; }

    /** Constructor for octets of kind [01]*B [0-9A-F]*H with correct
        size.
    */
    SDLOctet(const char *str) ;

    /** Constructor for an invalid value. */
    SDLOctet()  {}

    /** Constructor for MkString.  */
    SDLOctet(const SDLBit& b,SITE_SDL_INT size=1)  :
      SDLBitString(b,size) {}

    /** Constructor for an omitted (invalid) value */
    SDLOctet(const SDLNull& n)  :SDLBitString(n) {}

    /** Bitstring conversion for operators... */
    SDLOctet(const SDLBitString& base)  :SDLBitString(base) {}

protected:
    /** Constructor needed for correct String0 handling.
        It copies the given string but uses reserve bytes more then
        needed for internal representation.
    */
    SDLOctet(const SDLOctet& str, SITE_SDL_INT reserve) :
      SDLBitString(str,reserve) {}

public:
    /** Octet is a syntype */
    const SDLBool& check() const ;

    /** Assignment operator for SDLBitString */
    SDLOctet& operator=(const SDLOctet& str);

    /** Returns the char representation of the octet */
    operator char() const { return val(); }

    /** Returns the char representation of the octet */
    char val() const {
      check_valid(); const char* b = *this; return *b;
    }

    /** convert an int value to Octet module 256 */
    static SDLOctet int2octet(SITE_SDL_INT val) ;

    /** return the int value from 0..255 */
    static SDLInt octet2int(const SDLOctet&) ;

    /** return the octet type id */
    SDLTypeId sdl_type_id()const;
};

#endif
