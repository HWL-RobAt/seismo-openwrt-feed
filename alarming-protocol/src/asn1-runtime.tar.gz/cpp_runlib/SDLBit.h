/*******************************************************************************
*   vim:sw=2:ts=2:et
*
*   File    : SDLBit.h
*   Author  : Ralf Schr�der
*             Humboldt University Berlin
*             Department of Computer Science / System Analysis
*   e-mail  : r.schroeder@informatik.hu-berlin.de
*   Project : @vantage platform
*   $Date: 2005-05-05 17:38:41 +0200 (Thu, 05 May 2005) $
*   $Revision: 1.2 $
*
*******************************************************************************/
#ifndef _SDLBIT_H
#define _SDLBIT_H

#include "SDLType.h"

#ifdef SITE_RCS_IDENT
static const char* SDLBIT_RCSID FRWUNUSED = "$Id: SDLBit.h 554 2005-05-05 15:38:41Z tneumann $";
#else
static const char* SDLBIT_SCCSID FRWUNUSED = "@(#) ";
#endif

// forward declaration
class SDLBool;
class SDLAny;

/** SDL Bit; behaviour like a boolean.
    The implementation is an octet with a bit position. This allows
    the implementation of inline Modify for Bitstrings.
*/
class SDL_API SDLBit : public SDLType
{
    /** Hold the bit value. */
    char* _octet;

    /** Bit position of _octet (right is 0) */
    char  _nr;

  public:

    /* Call of generated macro for code shared by all declarations of SDL types
     */
    declareSDLType(SDLBit,SDLType)

    /** Constructor for an invalid value */
    SDLBit()  : _octet(0),_nr(0) {}

    /** Constructor for a given valid value */
    SDLBit(bool b) : _octet(new char(b?0xff:0x0)),_nr(0)
    { set_state(validValue); }

    /** Constructor for a given byte reference.
        The reference is directly used, hence be carefull.
    */
    SDLBit(char *b,int pos) : _octet(b),_nr((char)(pos&0x7))
    { set_state(validValue); }

    /** Constructor for an omitted (invalid) value */
    SDLBit(const SDLNull&)  {}

    /** Copy constructor */
    SDLBit(const SDLBit& b);

    /** Clean up */
    virtual ~SDLBit();

  private:
    /** Static literal representation. It is initialized by using
        C++ startup initialization. Hence, it is thread safe.
    */
    static const SDLBit the_0, the_1;

  public:
    /** Literal object for 0 */
    static const SDLBit& LIT_0();

    /** Literal object for 1 */
    static const SDLBit& LIT_1();

    /** Valid check.
        @returns true, if the data object is a valid one.
        It can be configured to switch off this test.
    */
    virtual bool valid()const ;

    /** Access to the kind of the object */
    virtual SDLTypeId sdl_type_id()const;

    /** (BOOLEAN) Encoding of tag and length */
    virtual AsnLen bEnc(BUF_TYPE b) const;

    /** (BOOLEAN) Encoding of the boolean value without tag and length */
    virtual AsnLen bEncContent(BUF_TYPE) const;

    /** (BOOLEAN) Decoding of tag and length */
    virtual void bDec(BUF_TYPE b, AsnLen& bytesDecoded);

    /** (BOOLEAN) Decoding of the boolean value without tag and length */
    virtual void bDecContent(BUF_TYPE,AsnTag,AsnLen,AsnLen&);

    /** Prints 0 or 1. */
    virtual void Print(std::ostream&)const;

    /** Returns a hash value. */
    virtual unsigned int hash(unsigned int)const { return val()?0:1; }

    /** Assignment operator for simple bits */
    SDLBit& operator=(bool b);

    /** Assignment operator */
    SDLBit& operator=(const SDLBit& b);

    /** Cast operator to C++ inline bool */
    operator bool() const
    { check_valid(); return ((*_octet)&(1<<_nr))?true:false; }

    /** Explicit value access. */
    bool val()const { return bool(*this); }

    /** SDL equality. */
    //@{
    const SDLBool& eq(bool b)const;
    const SDLBool& ne(bool b)const;

    /** Compares boolean objects.
        @param b a boolean object
        The dynamic cast failure is not caught because the code is
        generated correctly.
    */
    bool equal(const SDLType& b) const ;
    //@}

    /** SDL standard operations */
    //@{
    SDLBit _and(bool b)const ;
    SDLBit _or(bool b)const  ;
    SDLBit _xor(bool b)const ;
    SDLBit impl(bool b)const ;
    SDLBit _not()const ;
    //@}

    /** delete the internal bit */
    virtual void assign_new();
};

#endif
