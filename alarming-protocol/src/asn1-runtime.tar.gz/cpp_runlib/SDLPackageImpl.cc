/*******************************************************************************
*
*   File    : SDLPackageImpl.cc
*   Author  : Frank Bielig, Toby Neumann
*             Humboldt University Berlin
*             Department of Computer Science / System Analysis
*   e-mail  : tneumann@informatik.hu-berlin.de
*   Project : SITE4Cinderella
*   $Date: 2005-05-05 17:38:41 +0200 (Thu, 05 May 2005) $
*   $Revision: 1.4 $
*
*******************************************************************************/
#include "SDLPackageImpl.h"

bool
SDLPackageImpl::datainfo(long, SDLIA5String&, SDLIA5String&, SDLType*&)
{
  return false;
}
