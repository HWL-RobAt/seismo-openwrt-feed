/* ===== SITELIB_declareSDLType_macro.h ===== */

#ifndef SITELIB_declareSDLType
#define SITELIB_declareSDLType(M_TYPE,M_BASE) \
    virtual const char* name() const { return ""#M_TYPE""; }\
    virtual SDLType* copy()const;\
    virtual void assign(const SDLType* t);\
    static SDLType* create();\
    virtual const SDLType* create_new() const;\
    static const M_TYPE& convert(const M_TYPE&t) { return t; };
#endif
