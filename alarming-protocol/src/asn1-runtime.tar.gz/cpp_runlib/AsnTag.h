/* $Id: AsnTag.h 554 2005-05-05 15:38:41Z tneumann $ */

/*
 * $Log: AsnTag.h,v $
 * Revision 1.2  2003/05/26 08:11:48  tneumann
 * code clean up; code documentation; adaptions for VC++
 *
 * Revision 1.1  2002/06/20 12:25:52  boehme
 * first running version with new code generation an data types and OB 4.1.0
 *
 * Revision 1.6  2002/04/25 11:53:36  schroed2
 * - Remove the useless ENV_TYPE parameter from encoding implementation
 *   (performance). Virtual ASN.1 coding methods start with small letter now.
 * - Make encoding const (C++ compiler has better chances to optimize).
 * - Tag the old ASN.1 encoding interface as depricated. It works as before,
 *   however (BEnc, BDec, BEncContent, BDecContent).
 *
 * Assumption: Internal coding help methods (De/EncodeTag, De/EncodeLen,...)
 *             are not used in non generated C++.
 *
 * Revision 1.5  2001/12/14 17:01:43  schroed2
 * And the key is Id not ID arrrrrg.....
 *
 * Revision 1.4  2001/12/14 16:56:02  schroed2
 * Ok, change id: by ID. This key is replaced by RCS, Bertram!!!
 *
 * Revision 1.3  2001/12/14 15:44:57  neubauer
 * - version string inserted in *.h;
 * - version string inserted in *.cxx;
 *
 * Revision 1.2  2001/01/12 17:52:12  schroed2
 * cg version 1.15
 *
 * Revision 1.1  2000/12/18 16:51:07  schroed2
 * Start transition runs...
 *
 * Revision 1.4  2000/12/11 17:54:54  schroed2
 * first execution
 *
 * Revision 1.3  2000/12/06 13:07:17  schroed2
 * Resolved conflicts
 *
 * Revision 1.1.1.2  2000/12/06 12:46:27  schroed2
 * Empty implementation from SAG
 *
 * Revision 1.2  2000/11/29 09:36:28  schroed2
 * Vorstellung Konzepte bei SAG
 *
 * Revision 1.1.1.1  2000/11/20 13:55:15  schroed2
 * initial release
 *
 * Revision 1.3  2000/05/31 08:54:34  schroed2
 * Rules of extensibility implemented for Choice
 *
 * Revision 1.2  1999/03/18 15:38:03  loewis
 * Integrated asn1 into runlib
 *
 * Revision 1.1  1999/03/08 20:09:48  loewis
 * Integrated asnlib
 *
 * Revision 1.3  1999/01/30 20:11:10  loewis
 * Add TAG_ID_CODE. Reindent. Fix array delete.
 *
 * Revision 1.2  1998/09/03 13:02:13  loewis
 * Change comment
 *
 * Revision 1.1.1.2  1998/09/03 11:32:57  loewis
 * Update
 *
 * Revision 1.1.1.1  1998/06/04 19:35:13  loewis
 * Import from SIEMENS
 *
 * Revision 1.2  1997/05/14  21:24:32  site
 * *** empty log message ***
 *
 * Revision 1.2  1997/05/14  21:24:32  site
 * *** empty log message ***
 *
 * Revision 1.1  1997/01/16 15:18:46  site
 * Initial revision
 *
 * Revision 1.1  1995/05/15  11:12:52  tvdgaas
 * Initial revision
 *
 * Revision 1.1.1.1  1994/02/25  19:34:35  julie
 * 2/25/94	Original installation of InfoQuest software using the command
 *		cvs import src InfoQuest Original
 *
 */
/*
 * asn_tag.h - stuff for dealing with tags
 *
 * MS 92
 * Copyright (C) 1992 Michael Sample and the University of British Columbia
 *
 * This library is free software; you can redistribute it and/or
 * modify it provided that this copyright/license information is retained
 * in original form.
 *
 * If you modify this file, you must clearly indicate your changes.
 *
 * This source code is distributed in the hope that it will be
 * useful, but WITHOUT ANY WARRANTY; without even the implied warranty
 * of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 *
 */

#ifndef _asn_tag_h_
#define _asn_tag_h_

#include "sdlconfig.h"

static const char* ASNTAG_RCSID FRWUNUSED = "$Id: AsnTag.h 554 2005-05-05 15:38:41Z tneumann $";

/** A tag error raises an SDL exception */
#define TagError(expectedTag,receivedTag) \
  { throw ASNTagMismatchException(expectedTag,receivedTag); }

/** MissingTag() is generated, if a component type does not
    support Basic Encoding.
*/
#define MissingTag() \
  (throw SDLOperationNotImplemented("Basic Encoding - type without tag"),0)


/** Tag Id's byte len */
#define TB sizeof(AsnTag)

/** Provides a 4 byte tag representation as long int.
    The MAKE_TAG_ID macro generates the TAG_ID rep for
    the given class/form/code (rep'd in long integer form)
    if the class/form/code are constants the compiler (should)
    calculate the tag completely --> zero runtime overhead.
    This is good for efficiently comparing tags in switch statements
    (decoding) etc.
*/
#define MAKE_TAG_ID( cl, fm, cd)\
( (((AsnTag)(cl)) << ((TB-1) * 8)) |  \
  (((AsnTag)(fm)) << ((TB-1) * 8)) |  \
   (MAKE_TAG_ID_CODE(((AsnTag)(cd)))) \
)


/** 4 Byte tag id encoding.
    More than 4 bytes requires more sub-macros for the tag ranges.
*/
#define MAKE_TAG_ID_CODE(cd)\
( (cd < 31) ?  (MAKE_TAG_ID_CODE1(cd)):\
      ((cd < 128)?  (MAKE_TAG_ID_CODE2(cd)):\
         ((cd < 16384)?  (MAKE_TAG_ID_CODE3(cd)):\
           (MAKE_TAG_ID_CODE4(cd)))))

#define MAKE_TAG_ID_CODE1(cd)  ((long int)cd << ((TB -1) * 8))
#define MAKE_TAG_ID_CODE2(cd)  ((31l << ((TB -1) * 8)) | (cd << ((TB-2) * 8)))
#define MAKE_TAG_ID_CODE3(cd)  ((31l << ((TB -1) * 8))\
                                | ((cd & 0x3f80) << 9)\
                                | ( 0x0080L << ((TB-2) * 8))\
                                | ((cd & 0x007F) << ((TB-3)* 8)) )

#define MAKE_TAG_ID_CODE4(cd)  ((31l << ((TB -1) * 8))\
                                | ((cd & 0x1fc000) << 2)\
                                | ( 0x0080L << ((TB-2) * 8))\
                                | ((cd & 0x3f80) << 1)\
                                | ( 0x0080L << ((TB-3) * 8))\
                                | ((cd & 0x007F) << ((TB-4)*8)) )


/** tag class is represented by bit 6 and 7 of the first octet */
typedef enum BER_CLASS
{
    UNIV = 0,
    APPL = (1 << 6),
    CNTX = (2 << 6),
    PRIV = (3 << 6)
} BER_CLASS;

/** tag form is represented by bit 5 of the first octet */
typedef enum BER_FORM
{
    PRIM = 0,
    CONS = (1 << 5)
} BER_FORM;


/** tag ids */
typedef enum BER_UNIV_CODE
{
    NO_TAG_CODE = 0,
    BOOLEAN_TAG_CODE = 1,
    INTEGER_TAG_CODE,
    BITSTRING_TAG_CODE,
    OCTETSTRING_TAG_CODE,
    NULLTYPE_TAG_CODE,
    OID_TAG_CODE,
    OD_TAG_CODE,
    EXTERNAL_TAG_CODE,
    REAL_TAG_CODE,
    ENUM_TAG_CODE,
    SEQ_TAG_CODE =  16,
    SET_TAG_CODE,
    NUMERICSTRING_TAG_CODE,
    PRINTABLESTRING_TAG_CODE,
    TELETEXSTRING_TAG_CODE,
    VIDEOTEXSTRING_TAG_CODE,
    IA5STRING_TAG_CODE,
    UTCTIME_TAG_CODE,
    GENERALIZEDTIME_TAG_CODE,
    GRAPHICSTRING_TAG_CODE,
    VISIBLESTRING_TAG_CODE,
    GENERALSTRING_TAG_CODE
} BER_UNIV_CODE;

#define TT61STRING_TAG_CODE TELETEXSTRING_TAG_CODE
#define ISO646STRING_TAG_CODE VISIBLESTRING_TAG_CODE

/** TAG_IS_CONS evaluates to true if the given AsnTag type
    tag has the constructed bit set.
*/
#define TAG_IS_CONS(tag) ((tag) & ((long int)CONS << ((TB-1) *8)))

/** Infinit length end... */
#define EOC_TAG_ID 0



/** Tag coders.  Given constant exprs for class form & code in the
    source, these can be optimized by the compiler (eg.
    do the shifts and bitwise ors etc).
    @precondition has to be called for the correct tag id range.
 */
//@{

/** Universal encoding of the given tag. */
AsnLen BEncTag(BUF_TYPE b, AsnTag tagId);

#define BEncTag1( b, class, form, code)\
    1;\
    b.PutByteRvs((class) | (form) | (code))

#define BEncTag2( b, class, form, code)\
    2;\
    b.PutByteRvs( code);\
    b.PutByteRvs( (class) | (form) | 31)

#define BEncTag3( b, class, form, code)\
    3;\
    b.PutByteRvs( (code) & 0x7F);\
    b.PutByteRvs( 0x80 | ((code) >> 7));\
    b.PutByteRvs( (class) | (form) | 31)

#define BEncTag4( b, class, form, code)\
    4;\
    b.PutByteRvs( (code) & 0x7F);\
    b.PutByteRvs( 0x80 | ((code) >> 7));\
    b.PutByteRvs( 0x80 | ((code) >> 14));\
    b.PutByteRvs( (class) | (form) | 31)

/** Dummy for tag > 4 Byte (sdl-cg) */
#define BEncTag5( b, class, form, code)\
    5;\
    b.PutByteRvs( (code) & 0x7F);\
    b.PutByteRvs( 0x80 | ((code) >> 7));\
    b.PutByteRvs( 0x80 | ((code) >> 14));\
    b.PutByteRvs( 0x80 | ((code) >> 21));\
    b.PutByteRvs( (class) | (form) | 31)

/** Tag decoder. */
SDL_API AsnTag BDecTag( BUF_TYPE b, AsnLen& bytesDecoded);

/** Tag encoders until tag id's <32.
    It performs a "hard read". If the encoding was wrong (tag
    compare after encoding), the byte should be put back.
*/
#define BDecTag1(b,l)  \
   ((AsnTag)b.GetByte())<< ((sizeof(AsnTag)-1) *8);\
   l+=1;

#define BDecTag2(b,l)    BDecTag(b,l)
#define BDecTag3(b,l)    BDecTag(b,l)
#define BDecTag4(b,l)    BDecTag(b,l)
#define BDecTag5(b,l)    BDecTag(b,l)

//@}

class SDLOctetString;
void remember_tag(SDLOctetString* o, AsnTag tagId);
void remember_len(SDLOctetString* o, AsnLen len);
void remember_data(SDLOctetString* o, BUF_TYPE b, AsnLen l);


#endif /* conditional include */
