/*******************************************************************************
*   vim:sw=2:ts=2:et
*
*   File    : SDLChar.cxx
*   Author  : Martin von L�wis, Ralf Schr�der
*             Humboldt University Berlin
*             Department of Computer Science / System Analysis
*   e-mail  : r.schroeder@informatik.hu-berlin.de
*   Project : @vantage platform
*   $Date: 2005-05-05 17:38:41 +0200 (Thu, 05 May 2005) $
*   $Revision: 1.4 $
*
*******************************************************************************/
#include "SDLChar.h"
#include "SDLPredefined.h"
#include "SITELIB_implementSDLType_macro.h"
#include "implementSDLType_macro.h"

#include <ctype.h>

#ifdef SITE_RCS_IDENT
static const char* RCSID FRWUNUSED = "$Id: SDLChar.cc 554 2005-05-05 15:38:41Z tneumann $";
#else
static const char* SCCSID FRWUNUSED = "@(#) ";
#endif

implementSDLType(SDLChar,SDLType)

SDLChar::SDLChar(const SDLChar& c) :SDLType(c),_value(c._value)
{
#ifdef SITE_LOG
  if (SDLType::_type_debug & SITE_COPY_LOG)
    std::cerr << "(SDLRTE) char copy of value "
              << c << std::endl;
#endif
}

SDLChar:: SDLChar(const char* str)
{
  if (!str) { assert(str); return; }
  assert(str[1]==0);
  _value = str[0];
  assert((_value&0x80)==0);
  set_state(validValue);
}

bool
SDLChar::equal(const SDLType& c) const
{
  return val() == SITE_DYNAMIC_CAST(const SDLChar&,c).val();
}

bool
SDLChar::valid()const
{ return state(validValue); }

SDLTypeId
SDLChar::sdl_type_id()const
{ return TypeId_SDLChar; }

void
SDLChar::Print(std::ostream& os)const
{
  if (valid()) {
    if (isprint(val())) os << val();
    else os << "char(" << ((int)val()) << ")";
  }
  else os << "<invalid character>";
}

void
SDLChar::to_string(std::stringstream& buf){
  if (valid()){
    if (isprint(_value)) buf<<_value;
    else buf<<"char("<<(int)_value<<")";
  }
}

AsnLen
SDLChar::bEnc(BUF_TYPE b) const
{
    AsnLen elmtLen = bEncContent(b);
    elmtLen += BEncDefLen(b,elmtLen);
    elmtLen += BEncTag1(b,UNIV,PRIM,22);
    return elmtLen;
} // SDLCharstring::bEnc

void
SDLChar::bDec(BUF_TYPE b,AsnLen& bytesDecoded)
{
    AsnTag tagId = BDecTag1(b,bytesDecoded);
    AsnLen elmtLen;
    if (tagId != MAKE_TAG_ID(UNIV,PRIM,22)) { TagError(MAKE_TAG_ID(UNIV,PRIM,22),tagId); return; }
    elmtLen = BDecLen(b,bytesDecoded);
    AsnLen localBytesDecoded = 0;
    bDecContent(b,tagId,elmtLen,localBytesDecoded);
    bytesDecoded += localBytesDecoded;
}

AsnLen
SDLChar::bEncContent(BUF_TYPE b) const
{
#ifdef SITE_LOG
  if (SDLType::_type_debug & SITE_BER_LOG)
    std::cerr << "encode char value " << *this << std::endl;
#endif
  check_valid();
  b.PutByteRvs(_value);
  return 1;
}

void
SDLChar::bDecContent(BUF_TYPE b,AsnTag tagId,AsnLen elmtLen,
                                 AsnLen& bytesDecoded)
{
  /*
   * tagId is encoded tag shifted into long int.
   * if CONS bit is set then constructed octet string
   */
  assert((tagId&0x20000000)==0);
  if (elmtLen != 1)
    throw ASNLengthException("SDLChar::bDecContent: not 1 byte");
  _value = b.GetByte();
  set_state(validValue);
  bytesDecoded += elmtLen;
#ifdef SITE_LOG
  if (SDLType::_type_debug & SITE_BER_LOG)
    std::cerr << "decoded char value " << *this << std::endl;
#endif
}

SDLChar&
SDLChar::operator=(char c)
{
#ifdef SITE_LOG
  if (SDLType::_type_debug & SITE_ASSIGNMENT_LOG)
    std::cerr << "(SDLRTE) simple char assignment of " << c <<
                 " to variable with value " << *this << std::endl;
#endif
  assert((c&0x80)==0);
  _value = c;
  set_state(validValue);
  return *this;
}

SDLChar&
SDLChar::operator=(const SDLChar& c)
{
#ifdef SITE_LOG
  if (SDLType::_type_debug & SITE_ASSIGNMENT_LOG)
    std::cerr << "(SDLRTE) char assignment of " << c <<
                 " to variable with value " << *this << std::endl;
#endif
  _value = c.val();
  set_state(validValue);
  return *this;
}

const SDLBool&
SDLChar::eq(const char c)const
{ return (val()==c)?SDLBool::SDLTrue():SDLBool::SDLFalse(); }

const SDLBool&
SDLChar::ne(const char c)const
{ return (val()!=c)?SDLBool::SDLTrue():SDLBool::SDLFalse(); }

SDLInt
SDLChar::Num()const
{ return int(val()); }

const SDLBool&
SDLChar::lt(const char c)const
{ return (val()<c)?SDLBool::SDLTrue():SDLBool::SDLFalse(); }

const SDLBool&
SDLChar::gt(const char c)const
{ return (val()>c)?SDLBool::SDLTrue():SDLBool::SDLFalse(); }

const SDLBool&
SDLChar::le(const char c)const
{ return (val()<=c)?SDLBool::SDLTrue():SDLBool::SDLFalse(); }

const SDLBool&
SDLChar::ge(const char c)const
{ return (val()>=c)?SDLBool::SDLTrue():SDLBool::SDLFalse(); }
