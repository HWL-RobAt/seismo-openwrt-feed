/*******************************************************************************
*   vim:sw=2:ts=2:et
*
*   File    : SDLOctetString.h
*   Author  : Ralf Schr�der
*             Humboldt University Berlin
*             Department of Computer Science / System Analysis
*   e-mail  : r.schroeder@informatik.hu-berlin.de
*   Project : @vantage platform
*   $Date: 2005-05-05 17:38:41 +0200 (Thu, 05 May 2005) $
*   $Revision: 1.4 $
*
*******************************************************************************/
#ifndef _SDLOCTETSTRING_H
#define _SDLOCTETSTRING_H

#include "SDLType.h"
#include "SDLBitString.h"
#include <string.h>

#ifdef SITE_RCS_IDENT
static const char* SDLOCTETSTRING_RCSID FRWUNUSED = "$Id: SDLOctetString.h 554 2005-05-05 15:38:41Z tneumann $";
#else
static const char* SDLOCTETSTRING_SCCSID FRWUNUSED = "@(#) ";
#endif

// forward declarations
class SDLChar;
class SDLOctet;
class SDLBool;
class SDLInt;
class SDLAny;

/** Map table for small letter hex digits,
    for example numToHexCharTblG[10] == 'a'.
*/
extern char numToHexCharTblG[16];

/** Returns a hex char for an int value module 16. */
#define INT2HEX(fourBits) (numToHexCharTblG[(fourBits) & 0x0F])

/** Returns an int value for a small or capital hex char.
    @exception SDLUndefinedValue if hexChar is no hex digit.
*/
#define HEX2INT(hexChar)  \
  ((hexChar>='0'&&hexChar<='9')?        \
    (hexChar-'0'):                        \
    ( (hexChar>='a'&&hexChar<='f')?     \
      (hexChar-'a'+10):                   \
      ( (hexChar>='A'&&hexChar<='F')?   \
        (hexChar-'A'+10):                 \
        (throw SDLInvalidIndex("wrong octet string format")),0) \
  ) )



/** Implementation of Octet_String.
*/
class SDL_API SDLOctetString: public SDLType {
  protected: // access needed for (generated) ASN.1 PER coding
    /** Growing char buffer to hold the octet string. */
    char*        _octs;

    /** The size of the object string (and _octs). */
    SITE_SDL_INT _octetLen;

  private:
    /** This realizes bit modify access */
    class SDLOctetRef {
      char *_octet;
    public:
      SDLOctetRef(char * octet):_octet(octet) {}
      void operator=(const SDLOctet& o) ;
      void operator=(char c) { *_octet = c; }
      SDLBitString::SDLBitRef operator()(SITE_SDL_INT index);
    };

  public:
    /* Call of generated macro for code shared by all declarations of SDL types
     */
    declareSDLType(SDLOctetString,SDLType)

    /** Constructor for an invalid value */
    SDLOctetString()  : _octs(0),_octetLen(0){}

    /** Constructor for charstrings of kind [01]*B [0-9A-F]*H with correct
        allignment.
    */
    SDLOctetString(const char *str) ;

    /** Constructor with direct buffer assign.
        @precondition C++ size of str <= len.
        @param str an OctetBuffer, a C literal string.
        @param len size of octet string - not of str.
        The created object replaces the internal buffer on write access.
    */
    SDLOctetString(const char *str,SITE_SDL_INT len);

  private:
    /** Static empty literal */
    static const SDLOctetString empty;

  public:
    /** The empty literal */
    static const SDLOctetString& LIT_H() { return empty; }

    /** Constructor for BitStrings.
    */
    SDLOctetString(const SDLBitString& bs);

    /** Cast of a Charstring to an OctetString.
    */
    SDLOctetString(const SDLCharstring& str);

    /** Constructor for MkString */
    SDLOctetString(const SDLOctet& o);

    /** Constructor for an omitted (invalid) value */
    SDLOctetString(const SDLNull&)  : _octs(0),_octetLen(0){}

    /** Copy constructor */
    SDLOctetString(const SDLOctetString& str);

protected:
    /** Constructor needed for correct String0 handling.
        It copies the given string but uses reserve bytes more then
        needed for internal representation.
    */
    SDLOctetString(const SDLOctetString& str, SITE_SDL_INT reserve);

public:
    /** Clean up */
    virtual ~SDLOctetString();

    /** Initialize the empty octet string */
    virtual void init_type();

    /** Valid check.
        @returns true, if the data object is a valid one.
        It can be configured to switch off this test.
    */
    virtual bool valid()const ;

    /** Encoding of this octet string value with tag and length */
    virtual AsnLen bEnc(BUF_TYPE b) const;

    /** Encoding of this octet string value without tag and length */
    virtual AsnLen bEncContent(BUF_TYPE) const;

    /** Decoding of this octet string value with tag and length */
    virtual void bDec(BUF_TYPE b, AsnLen& bytesDecoded);

    /** Decoding of this octet string value without tag and length */
    virtual void bDecContent(BUF_TYPE,AsnTag,AsnLen,AsnLen&);

    /** PER encoding of the bitstring */
    virtual AsnLen pEnc(BUF_TYPE2 b) const;

    /** PER decode of the given bitstring */
    virtual void pDec(BUF_TYPE2 b);

    /** Access to the kind of the object */
    virtual SDLTypeId sdl_type_id()const;

    /** Prints the string. */
    virtual void Print(std::ostream&)const;

    /** Returns a hash value */
    unsigned int hash(unsigned int)const;

    /** Assignment operator for SDLOctetString */
    SDLOctetString& operator=(const SDLOctetString& str);

    /** Direct read only access to the internal buffer.
        @postcondition: length() valid data only.
        Note, the returned pointer can be a C literal pointer!
    */
    operator const char*() const { return _octs;}

    /** Direct access to the internal buffer.
        @postcondition: length() valid data only.
        If the internal object is const, a copy of the string is implied here.
    */
    operator char*() const;

    /** SDL equality. */
    //@{
    const SDLBool& eq(const SDLOctetString& os)const;
    const SDLBool& ne(const SDLOctetString& os)const;

    /** Compares OctetString objects.
        @param type second parameter of equality.
    */
    virtual bool equal(const SDLType& type)const ;

    //@}

    /** SDL operations for Octet_String */
    //@{
    SDLOctetString cat(const SDLOctetString& os)const ;
    SDLInt length()const ;
    SDLOctet first()const ;
    SDLOctet last()const ;

    /** Extract access operator (starts with 1).
        @exception SDLInvalidIndex if the index is out of range.
    */
    const SDLOctet operator[](SITE_SDL_INT)const;

#if SITE_SDL_INT_SIZE==64
    /** Extract access operator (starts with 1).
        @exception SDLInvalidIndex if the index is out of range.
        Operator introduced because of ambiguous overload
        c[2] resolvable as operator[]((long long)2) or (char*(c))[2].
    */
    const SDLOctet operator[](int)const;
#endif

    /** Modify access operator (starts with 1) */
    SDLOctetRef operator()(SITE_SDL_INT);

    SDLOctetString substr(SITE_SDL_INT start,SITE_SDL_INT length)const ;

    /** Converter OCTET STRING to BIT STRING */
    static SDLBitString bitstring(const SDLOctetString&);

    /** Converter BIT STRING to OCTET STRING */
    static SDLOctetString octetstring(const SDLBitString&);

    /** Non-standard delete operator.
    */
    SDLOctetString cut(SITE_SDL_INT)const ;
    //@}


    /**@name Helper methods for C++ manipulation. */
    //@{

    /** C++ construction to set buffer and length directly.
        @param str a copy of str is used.
        The internal buffer can be reused for the copy.
    */
    void Set(const char *str,SITE_SDL_INT len) ;

    /** return the length of the octet string */
    SITE_SDL_INT Len() const { return _octetLen; }

    /** The method extends the internal buffer and returns
        the start pointer of the extension.
        @postcondition The buffer has to be initialized with len bytes
            after the call.
        This is an internal manipulation function for encoding.
    */
    char* extend(SITE_SDL_INT len) ;
    //@}

    /** Delete the inner string */
    virtual void assign_new();

    /** C++ octet extraction with range check [1..length].
        The operator is not used from the SDL environment.
        @param index value in range [1,lengthAsLong()], exception otherwise.
        @exception SDLInvalidIndex if the index is out of range.
     */
    char octet(int index) const;

    /** Direct, unsave C++ field assignment, starts with 0.
        @param pos set a value in range [0,lengthAsLong()-1], crash else.
        @param c new value
        This method can imply a copy on write for the internal string.
    */
    void Set(SITE_SDL_INT pos,char c);

    /** Direct C++ field access, starts with 0.
        @param pos get a value in range [0,lengthAsLong()-1], random value else.
    */
    char Get(SITE_SDL_INT pos) const;

  private:
    /** Help method for constructed encoding. */
    void BDecConsOcts (BUF_TYPE, AsnLen, AsnLen&);

};

#endif
