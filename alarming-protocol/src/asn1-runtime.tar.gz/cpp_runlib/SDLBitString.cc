/*******************************************************************************
*   vim:sw=2:ts=2:et
*
*   File    : SDLBitString.cxx
*   Author  : Ralf Schr�der
*             Humboldt University Berlin
*             Department of Computer Science / System Analysis
*   e-mail  : r.schroeder@informatik.hu-berlin.de
*   Project : @vantage platform
*   $Date: 2005-05-05 17:38:41 +0200 (Thu, 05 May 2005) $
*   $Revision: 1.5 $
*
*******************************************************************************/
#include "SDLBitString.h"
#include "SDLPredefined.h"
#include "SITELIB_implementSDLType_macro.h"

#ifdef SITE_RCS_IDENT
static const char* RCSID FRWUNUSED = "$Id: SDLBitString.cc 554 2005-05-05 15:38:41Z tneumann $";
#else
static const char* SCCSID FRWUNUSED = "@(#) ";
#endif

SITELIB_implementSDLType(SDLBitString,SDLType)

const SDLBitString SDLBitString::empty("B");

SDLBitString::SDLBitString(const SDLAny &a, AsnCodingSet rule_set)
  :_bits(0),_bitLen(0),_size(0)
{
  a.decode(this, rule_set);
}

SDLBitString::SDLBitString(const char *str)
  :_bits(0),_bitLen(0),_size(0)
{
  if (!str) {
    throw SDLInvalidIndex("null pointer as bit string");
    return;
  }
  SITE_SDL_INT len = strlen(str);
  if (!len) {
    // Ok the empty string (not really)
    set_state(validValue);
    return;
  }

  len--; // exclude extension H/B
  if (str[len]=='H' || str[len]=='h') {
    if (len) { // avoid new[0]
      _size = (len+1)/2;
      _bitLen = len*4;
      _bits = new char[TO_SIZE_T(_size)];
      memset(_bits,0,TO_SIZE_T(_size));
      for(int i=0;i<len;i++) {
        int val = HEX2INT(str[i]);
        if(i%2==0) val <<= 4;
        _bits[i/2]|=val;
      }
    }
  } else if (str[len]=='B' || str[len]=='b') {
    if (len) { // avoid new[0]
      _size = (len+7)/8;
      _bitLen = len;
      _bits = new char[TO_SIZE_T(_size)];
      memset(_bits,0,TO_SIZE_T(_size));
      for(int i=0;i<len;i++) {
        if(str[i]=='1') {
          _bits[i/8]|= (1<<(7-(i%8)));
        } else if (str[i]!='0') {
          // generated code is correct
          assert(0);
        }
      }
    }
  } else {
    // generated code is correct
    assert(0);
    return;
  }
  set_state(validValue);
}

SDLBitString::SDLBitString(const SDLBit& b, SITE_SDL_INT size)  :
  _bits(0),
  _bitLen(size),
  _size((size+7)/8)
{
  b.check_valid();
  if (size<0) {
    throw SDLOutOfRange("MkString(Bit,<negative value>");
  }
  if (size) { // avoid new [0]
    _bits = new char[TO_SIZE_T((size+7)/8)];
    if (b.val()) {
      memset(_bits,0xff,TO_SIZE_T(_size-1));
      _bits[_size-1] = 0;
      // start of bs with 0, hence 8-i not 7-i!
      for(SITE_SDL_INT i=(size)%8; i; i--) {
        _bits[_size-1] |= 1<<(8-i);
      }
    } else {
      memset(_bits,0,TO_SIZE_T(_size));
    }
  }
  set_state(validValue);
}

SDLBitString::SDLBitString(const SDLOctetString& os)  :
  SDLType(os),
  _bits((os.check_valid(),os.Len())?new char[TO_SIZE_T(os.Len())]:0),
  _bitLen(os.Len()*8),
  _size(os.Len())
{
  if (_bitLen) memcpy(_bits,(char*)os,TO_SIZE_T(_size));
}

SDLBitString::SDLBitString(const SDLBitString& str)  :
  SDLType(str),_bits(0),_bitLen(str._bitLen),_size(0)
{
#ifdef SITE_LOG
  if (SDLType::_type_debug & SITE_COPY_LOG)
    std::cerr << "(SDLRTE) bitstring copy of value " << str << endl;
#endif
  if (str._bitLen) {
    assert(str._bits);
    _size = (_bitLen+7)/8;
    _bits = new char[TO_SIZE_T(_size)];
    memcpy(_bits,str._bits,TO_SIZE_T(_size));
  }
}

SDLBitString::SDLBitString(const SDLBitString& str,SITE_SDL_INT reserve) :
  SDLType(str),_bits(0),_bitLen(str._bitLen),
  _size((str._bitLen+7)/8+reserve)
{
#ifdef SITE_LOG
  if (SDLType::_type_debug & SITE_COPY_LOG)
    std::cerr << "(SDLRTE) bitstring copy of value " << str
              << " reserve " << reserve << endl;
#endif
  assert(reserve>=0);
  if (_size) {
    _bits = new char[TO_SIZE_T(_size)];
    memset(_bits,0,TO_SIZE_T(_size));
  }
  if (str._bits) {
    memcpy(_bits,str._bits,TO_SIZE_T((_bitLen+7)/8));
  }
}


SDLBitString::~SDLBitString()
{
  delete [] _bits; _bits = 0;
  _bitLen = _size = 0;
}

bool
SDLBitString::valid()const
{ return state(validValue); }

#include <iostream> // for debug

AsnLen
SDLBitString::pEnc(BUF_TYPE2 b) const {
  int unusedBits=(8-(_bitLen%8))%8;
  AsnLen elmtLen=pEncLen(b, _bitLen);
  AsnLen pos=0;
  AsnLen rem_bits=_bitLen;
  int cur_bits;
  while(rem_bits>0){
    // compute size of next fragment
    cur_bits = (rem_bits<16384?rem_bits:
		   (rem_bits>>14)<=4?(rem_bits>>14)*16384:
		   4*16384);
    for(AsnLen max_pos=pos+cur_bits/8;pos<max_pos;pos++)
      b.putByte(_bits[pos]);
    rem_bits-=cur_bits;
    elmtLen+=cur_bits;

    // this is the last fragment and there are unused bits
    if(!rem_bits && unusedBits){
      b.putByte(_bits[pos]);
      b.undoWrite(unusedBits);
    }
    else if(!(cur_bits%16384))
      elmtLen+=pEncLen(b,rem_bits);
  }
  return elmtLen;
}

void
SDLBitString::pDec(BUF_TYPE2 b) {
  int rem_bits=pDecLen(b);
  delete [] _bits;
  _bits = NULL;
  _size=0;
  _bitLen=0;
  if(!rem_bits){
    set_state(validValue);
    return;
  }
  AsnLen pos=0;
  int inverse_unused=0;
  int next_bits;
  ByteArray tmp, tmp2;
  while(rem_bits){
    int cur_bytes=rem_bits/8;
    AsnLen max_pos=pos+cur_bytes;
    b.getBytes(cur_bytes, tmp2);
    // there will follow another (non empty) fragment
    if(!(rem_bits%16384)&&(next_bits=pDecLen(b))){
      tmp.resize(max_pos);
      // copy bytes from the encode buffer to the temp buffer
      for(int i=0;pos<max_pos;pos++,i++)
	      tmp[pos]=tmp2[i];
      rem_bits=next_bits;
    }
    // this is the last fragment
    else {
      inverse_unused=rem_bits%8;
      _bits=new char[max_pos+(inverse_unused?1:0)];
      if(!tmp.empty())
	      // copy bytes from the temp buffer to the _bits array
	      for(AsnLen i=0;i<pos;i++)
	        _bits[i]=tmp[i];
      // copy bytes from the encode buffer to the _bits array
      for(int i=0;pos<max_pos;pos++,i++)
	      _bits[pos]=tmp2[i];
      _size=max_pos;
      _bitLen=max_pos*8;
      if(inverse_unused){
        int val=b.getBitsAsInt(inverse_unused);
        _bits[max_pos]=(char)(val<<(8-inverse_unused));
        _size++;
        _bitLen+=inverse_unused;
      }
      rem_bits=0;
    }
  }
  set_state(validValue);
}

AsnLen
SDLBitString::bEnc(BUF_TYPE b) const
{
  AsnLen l = bEncContent(b);
  l += BEncDefLen(b,l);
  l += BEncTag1(b, UNIV, PRIM, BITSTRING_TAG_CODE);
  return l;
}

AsnLen
SDLBitString::bEncContent(BUF_TYPE b) const
{
#ifdef SITE_LOG
  if (SDLType::_type_debug & SITE_BER_LOG)
    std::cerr << "encode bitstring value " << *this << endl;
#endif
  check_valid();
  unsigned int unusedBits;
  AsnLen byteLen;

  byteLen = (_bitLen+7)/8;

  if (byteLen) b.PutSegRvs( _bits, TO_SIZE_T(byteLen));
  unusedBits = TO_UINT32(_bitLen % 8);
  if (unusedBits != 0)
    unusedBits = 8 - unusedBits;
  b.PutByteRvs(unusedBits);
  return byteLen+1;
}

void
SDLBitString::bDec( BUF_TYPE b, AsnLen& bytesDecoded)
{
  AsnTag tagId = BDecTag1(b,bytesDecoded);
  if ((tagId != MAKE_TAG_ID(UNIV, PRIM, BITSTRING_TAG_CODE)) &&
      (tagId != MAKE_TAG_ID(UNIV, CONS, BITSTRING_TAG_CODE))) {
    TagError(MAKE_TAG_ID(UNIV,PRIM,BITSTRING_TAG_CODE),tagId); return;
  }
  AsnLen elmtLen = BDecLen(b,bytesDecoded);
  AsnLen localBytesDecoded = 0;
  bDecContent(b,tagId,elmtLen,localBytesDecoded);
  bytesDecoded += localBytesDecoded;
}

void
SDLBitString::bDecContent(BUF_TYPE b,AsnTag tagId,AsnLen elmtLen,
                          AsnLen& bytesDecoded)
{
  /*
   * tagId is encoded tag shifted into long int.
   * if CONS bit is set then constructed bit string
   */
  if (tagId & 0x20000000)
    BDecConsBits(b, elmtLen, bytesDecoded);
  else { /* primitive bit string */
    delete [] _bits; _bits = 0;
    if (!elmtLen) {
      // should not happen, empty bit string is 0x0, but anyway
      _size = _bitLen = 0;
    } else {
      _size = --elmtLen;
      _bitLen = (elmtLen * 8) - (AsnLen)b.GetByte();
      if (_bitLen<0) {
        _bitLen = 0;
        throw ASNLengthException("negative bit string length");
      }
      if (_bitLen) {
        _bits =  new char[TO_SIZE_T(_size)];
        b.Copy(_bits,TO_SIZE_T(elmtLen));
      }
      bytesDecoded += elmtLen+1;
    }
  }
  set_state(validValue);
#ifdef SITE_LOG
  if (SDLType::_type_debug & SITE_BER_LOG)
    std::cerr << "decoded bitstring value " << *this << endl;
#endif
}

SDLTypeId
SDLBitString::sdl_type_id()const
{ return TypeId_SDLBitString; }

void
SDLBitString::Print(std::ostream& os)const
{
  if (!valid()) {
    os << "<invalid bitstring value>";
    return;
  }
  os << "'";
  for(SITE_SDL_INT i=0; i<_bitLen; i++) {
    os << ((_bits[i/8] & (1<<(7-i%8)))?'1':'0');
    //if (!os.good()) SDLType::raise(new SDLLogLimitReached);
  }
  os << "'B";
}

unsigned int
SDLBitString::hash(unsigned int max_hash)const
{
  unsigned int res=0;
  if (!valid()) return 0;
  for(size_t i=0;i<TO_SIZE_T((_bitLen+7)/8);i++) res+=_bits[i];
  return res%max_hash;
}


SDLBitString&
SDLBitString::operator=(const SDLBitString& str)
{
#ifdef SITE_LOG
  if (SDLType::_type_debug & SITE_ASSIGNMENT_LOG)
    std::cerr << "(SDLRTE) bitstring assignment of " << str <<
                 " to variable with value " << *this << endl;
#endif
  str.check_valid();
  if (this == &str) return *this;  // ignore var := var
  delete [] _bits; _bits = 0;
  if (str._bits) {
    _bitLen = str._bitLen;
    _size = (_bitLen+7)/8;
    _bits = new char[TO_SIZE_T(_size)];
    memcpy(_bits,str._bits,TO_SIZE_T(_size));
  } else {
    _bitLen = _size = 0;
  }
  set_state(validValue);
  return *this;
}


const SDLBool&
SDLBitString::eq(const SDLBitString& bs)const
{
  check_valid(); bs.check_valid();
  if (_bitLen != bs._bitLen) return SDLBool::SDLFalse();
  if (!_bitLen) return SDLBool::SDLTrue();
  return (memcmp(_bits,bs._bits,TO_SIZE_T((_bitLen+7)/8))==0)?
         SDLBool::SDLTrue():SDLBool::SDLFalse();
}

const SDLBool&
SDLBitString::ne(const SDLBitString& bs)const
{
  check_valid(); bs.check_valid();
  if (_bitLen != bs._bitLen) return SDLBool::SDLTrue();
  if (!_bitLen) return SDLBool::SDLFalse();
  return (memcmp(_bits,bs._bits,TO_SIZE_T((_bitLen+7)/8))==0)?
         SDLBool::SDLFalse():SDLBool::SDLTrue();
}

bool
SDLBitString::equal(const SDLType& type)const
{
  const SDLBitString& bs = SITE_DYNAMIC_CAST(const SDLBitString&,type);
  if (_bitLen != bs._bitLen) return false;
  if (!_bitLen) return true;
  return (memcmp(_bits,bs._bits,TO_SIZE_T((_bitLen+7)/8))==0);
}

SDLBitString
SDLBitString::cat(const SDLBitString& bs)const
{
  check_valid(); bs.check_valid();
  SDLBitString ret;
  ret._bitLen = _bitLen+bs._bitLen;
  ret._size = (ret._bitLen+7)/8;
  if (ret._size) { // avoid new [0]
    ret._bits = new char[TO_SIZE_T(ret._size)];
    memcpy(ret._bits,_bits,TO_SIZE_T((_bitLen+7)/8));
    memset(ret._bits+(_bitLen+7)/8,0,TO_SIZE_T(ret._size-(_bitLen+7)/8));
    // copy single bits from bs, note 0 start!
    for(SITE_SDL_INT i = 0; i<bs._bitLen; i++) {
      if (bs._bits[i/8]&(1 << (7-i%8)))
        ret._bits[(i+_bitLen)/8] |= (1 << (7-(i+_bitLen)%8));
    }
  }
  ret.set_state(validValue);
  return ret;
}


SDLInt
SDLBitString::length()const
{ return _bitLen; }

SDLBit
SDLBitString::first()const
{ if (!_bitLen) { throw SDLInvalidIndex(); }
  return SDLBit((_bits[0]&0x80)?true:false);
}

SDLBit
SDLBitString::last()const
{
  if (!_bitLen) { throw SDLInvalidIndex(); }
  return (*this)[_bitLen-1];
}

const SDLBit
SDLBitString::operator[](SITE_SDL_INT index) const
{
  if (index<0 || index>=length()) { throw SDLInvalidIndex(); }
  return SDLBit((_bits[index/8] & (1 << (7-index%8)))?true:false);
}

#if SITE_SDL_INT_SIZE==64
const SDLBit
SDLBitString::operator[](int index) const
{
  return (*this)[static_cast<SITE_SDL_INT>(index)];
}
#endif

SDLBitString::SDLBitRef
SDLBitString::operator()(SITE_SDL_INT index)
{
  //if (index<0 || index>=length()) { raise(new SDLInvalidIndex); }
  check_valid();
  if (index<0) { throw SDLInvalidIndex(); }
  // non SDL String expansion
  if (index>=_bitLen) { resize(index+1); }
  set_state(validValue); // changes default value
  return SDLBitRef(_bits,index);
}

SDLBitString
SDLBitString::substr(SITE_SDL_INT from, SITE_SDL_INT len)const
{
  check_valid();
  if (from<0 || _bitLen-1<from || len<0)
  { throw SDLInvalidIndex(); }
  // non SDL-2000
  if (from+len>_bitLen) {
    len = _bitLen-from;
  }
  SDLBitString ret(SDLBit::LIT_0(),len);
  for(SITE_SDL_INT i = 0; i<len; i++) {
    ret(i) = (*this)[i+from];
  }
  return ret;
}


SDLBitString
SDLBitString::_and(const SDLBitString& bs)const
{
  check_valid(); bs.check_valid();
  SITE_SDL_INT b_min = (_bitLen<bs._bitLen)?_bitLen:bs._bitLen;
  SITE_SDL_INT b_max = (_bitLen<bs._bitLen)?bs._bitLen:_bitLen;
  SDLBitString ret(SDLBit::LIT_0(),b_max);
  SITE_SDL_INT i;
  for(i=0;i<(b_min+7)/8;i++) ret._bits[i] = _bits[i] & bs._bits[i];
  return ret;
}

SDLBitString
SDLBitString::_or(const SDLBitString& bs)const
{
  check_valid(); bs.check_valid();
  SITE_SDL_INT b_min = (_bitLen<bs._bitLen)?_bitLen:bs._bitLen;
  const SDLBitString& the_max = (_bitLen<bs._bitLen)? bs : *this;
  SDLBitString ret(the_max);
  SITE_SDL_INT i;
  for(i=0;i<(b_min+7)/8;i++) ret._bits[i] = _bits[i] | bs._bits[i];
  return ret;
}

SDLBitString
SDLBitString::_xor(const SDLBitString& bs)const
{
  check_valid(); bs.check_valid();
  SITE_SDL_INT b_min = (_bitLen<bs._bitLen)?_bitLen:bs._bitLen;
  const SDLBitString& the_max = (_bitLen<bs._bitLen)? bs : *this;
  SDLBitString ret(the_max);
  SITE_SDL_INT i;
  for(i=0;i<(b_min+7)/8;i++) ret._bits[i] = _bits[i] ^ bs._bits[i];
  return ret;
}

SDLBitString
SDLBitString::impl(const SDLBitString& bs)const
{
  check_valid(); bs.check_valid();
  SITE_SDL_INT b_min = (_bitLen<bs._bitLen)?_bitLen:bs._bitLen;
  SITE_SDL_INT b_max = (_bitLen<bs._bitLen)?bs._bitLen:_bitLen;
  SDLBitString ret(SDLBit::LIT_0(),b_max);
  SITE_SDL_INT i;
  for(i=0;i<(b_min+7)/8;i++) ret._bits[i] = ~(_bits[i] & ~bs._bits[i]);
  ret._bits[i-1] &= ~(0x00ff >> b_min%8);
  if (_bitLen<bs._bitLen) {
    for(i=b_min;i<b_max;i++) ret._bits[i/8] |= (1 << (7-i%8));
  } else {
    for(i=b_min;i<b_max;i++)
      if (!(_bits[i/8] & (1 << (7-i%8))))
        ret._bits[i/8] |= (1 << (7-i%8));
  }
  return ret;
}

SDLBitString
SDLBitString::_not()const
{
  check_valid();
  SDLBitString ret(SDLBit::LIT_0(),_bitLen);
  SITE_SDL_INT i;
  SITE_SDL_INT size = (_bitLen+7)/8;;
  for(i=0;i<size-1;i++) ret._bits[i] = ~_bits[i];
  ret._bits[size-1] = ~ret._bits[size-1] & ~(0x00ff >> _bitLen%8);
  return ret;
}

SDLBitString
SDLBitString::appendElem(SITE_SDL_INT atIndex)
{
  if (atIndex<0) return *this;
  // resize the byte array if necessary
  if (atIndex/8+1 > _size) resize(atIndex+1);
  _bits[atIndex/8]|=(1<<(7-atIndex%8));
  if (atIndex+1>_bitLen)  _bitLen = atIndex+1;
  return *this;
}

void
SDLBitString::assign_new()
{
  delete [] _bits; _bits = 0;
  _bitLen = _size = 0;
  SDLType::assign_new();
}

void
SDLBitString::Set(char *str,SITE_SDL_INT len)
{
  _size = (len+7)/8;
  _bitLen = len;
  delete [] _bits; _bits = 0;
  if (len) {
    _bits = new char[TO_SIZE_T(_size)];
    assert(str);
    memcpy(_bits,str,TO_SIZE_T(_size));
  }
  set_state(validValue);
}

void
SDLBitString::resize(SITE_SDL_INT new_len)
{
  if ((new_len+7)/8 > _size) {
    size_t len = TO_SIZE_T((new_len+7)/8);
    char* tmp = new char[len];
    if (_bits) {
      memcpy(tmp,_bits,TO_SIZE_T(_size));
      memset(tmp+_size,0,TO_SIZE_T(len-_size));
      delete []_bits; _bits = 0;
    } else memset(tmp,0,TO_SIZE_T(len));
    _bits = tmp;
    _size = len;
  }
  _bitLen = new_len;
  set_state(validValue);
}

void
SDLBitString::BDecConsBits (BUF_TYPE, AsnLen, AsnLen&)

{ throw SDLOperationNotImplemented("SDLBitString::BDecConsBits"); }
