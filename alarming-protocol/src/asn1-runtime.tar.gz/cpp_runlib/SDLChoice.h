/*******************************************************************************
*   vim:sw=2:ts=2:et
*
*   File    : SDLChoice.h
*   Author  : Ralf Schr�der and Martin von L�wis
*             Humboldt University Berlin
*             Department of Computer Science / System Analysis
*   e-mail  : r.schroeder@informatik.hu-berlin.de
*   Project : @vantage platform
*   $Date: 2005-05-05 17:38:41 +0200 (Thu, 05 May 2005) $
*   $Revision: 1.2 $
*
*******************************************************************************/
#ifndef _SDLCHOICE_H
#define _SDLCHOICE_H

#include "SDLType.h"

#ifdef SITE_RCS_IDENT
static const char* SDLCHOICE_RCSID FRWUNUSED = "$Id: SDLChoice.h 554 2005-05-05 15:38:41Z tneumann $";
#else
static const char* SDLCHOICE_SCCSID FRWUNUSED = "@(#) ";
#endif

// forward declarations
class SDLBool;
class SDLInt;
class SDLIA5String;
class SDLAny;

/** Abstract CHOICE implementation.
    Each generated choice class provides access methods for fields and
    a secure field assignment based on SDLType.
*/
class SDL_API SDLChoice: public SDLType {

  protected:
    /** Hold the assigned field */
    mutable SDLType* _u;

    /** Hold the enum information, which field.
        Has to correspond with SDLInt.
    */
    mutable SITE_SDL_INT _present;
  public:

    /** Constructor for an invalid value */
    SDLChoice() ;

    /** Constructor for a certain variant.
        Warning, there is no consistency check behind the val
        assignment. If the dynamic cast to the correct variant
        type failes during the field access, an SDLASSERT is
        called. Note, the same constructor of any derived class
        uses a type check for the variants. Hence, this constructor
        is only be used to create abstract choice objects (no usage
        in generated data classes).
    */
    SDLChoice(SITE_SDL_INT variant, const SDLType& val) ;

    /** Constructor for an omitted (invalid) value */
    SDLChoice(const SDLNull&) ;


    /** Copy constructor */
    SDLChoice(const SDLChoice& c) ;

    /** Clean up */
    virtual ~SDLChoice();

    /** Valid check.
        @returns true, if the data object is a valid one.
        The check ignores the status flag of the type and uses
        the presence/absence of the internal choice field _u.
        Nevertheless, the status flag of a choice value should be valid,
        otherwise the encoding of enclosing types can fail.
    */
    virtual bool valid()const ;

    // Choice coding methods are generated

    /** Access to the kind of the object */
    virtual SDLTypeId sdl_type_id()const;

    /** Prints the string. */
    virtual void Print(std::ostream&)const;

    /** return the hash value of the component or 0 */
    unsigned int hash(unsigned int)const;

    /** Direct access to the value */
    SDLType* content()const  { return _u; }

    /** Assignment operator for SDLChoice */
    SDLChoice& operator=(const SDLChoice& c);

  protected:
    /** Generic field assignment with type check.
        Note, the method is not abstract to allow the construction of
        SDLChoice objects. For these objects, there is no type check.
        Here, the field type check is implemented in derived (generated)
        classes.
    */
    virtual void assign_field(unsigned int variant,const SDLType& elem);

  public:
    /** SDL equality. */
    //@{
    const SDLBool& eq(const SDLChoice& c)const ;
    const SDLBool& ne(const SDLChoice& c)const ;

    /** Compares Choice objects.
        @param type second parameter of equality.
    */
    virtual bool equal(const SDLType& type)const ;

    //@}


    /** SDL operations for CHOCIE */
    //@{

    /** Returns the number of the present enumeration. */
    SDLInt present()const ;

    /** Returns true, if the given variant is present. */
    const SDLBool& present(SITE_SDL_INT v) ;
    //@}

    /**@name Helper methods for C++ manipulation. */
    //@{

    virtual bool datainfo(long,SDLIA5String&,SDLIA5String&,
                          SDLType*&,infotype);

    /** Delete the inner choice value */
    virtual void assign_new();

  protected:
    /** Help method for unknown fields (extensibility). */
    void BDecRememberField(BUF_TYPE b, AsnLen &local, AsnTag tagId, AsnLen len);

  private:
    /** Help method for infinit length decoding (not used in advantage). */
    void remember_infinit_data(BUF_TYPE b, AsnLen &local);

    //@}
};

#endif
