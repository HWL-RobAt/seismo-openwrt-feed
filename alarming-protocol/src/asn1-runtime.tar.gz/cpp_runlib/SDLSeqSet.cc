/*******************************************************************************
*   vim:sw=2:ts=2:et
*
*   File    : SDLSeqSet.cxx
*   Author  : Ralf Schr�der and Martin von L�wis
*             Humboldt University Berlin
*             Department of Computer Science / System Analysis
*   e-mail  : r.schroeder@informatik.hu-berlin.de
*   Project : @vantage platform
*   $Date: 2006-04-04 13:14:09 +0200 (tir, 04 apr 2006) $
*   $Revision: 586 $
*
*******************************************************************************/
#include "SDLSeqSet.h"
#include "SDLPredefined.h"

#ifdef SITE_RCS_IDENT
static const char* RCSID FRWUNUSED = "$Id: SDLSeqSet.cc 586 2006-04-04 11:14:09Z tneumann $";
#else
static const char* SCCSID FRWUNUSED = "@(#) ";
#endif

/** Private field description layout
    It describes the optional and default property,
    the name of the field and a function to create
    a value of the field type.
*/
struct SDLSeqSetDescription::Field
{
  bool _optional;
  bool _default;
  bool _trace;
  const char *_name;
  SDLSeqSetDescription::newfunc    _newval;
  SDLSeqSetDescription::newctxaddr _newctxval;
  Field():_name(0), _newval(0), _newctxval(0) {}
};

// SDLSeqSetDescription implementation
SDLSeqSetDescription::SDLSeqSetDescription(int count):
  _len(count), _fields(new Field[count])
{}

SDLSeqSetDescription::Field*
SDLSeqSetDescription::add (int i, const char*name, newctxaddr newval,bool trace)
{
  if (i>=_len) return 0;
  _fields[i]._optional = false;
  _fields[i]._default = false;
  _fields[i]._trace = trace;
  _fields[i]._name = name;
  _fields[i]._newctxval = newval;
  return _fields+i;
}

SDLSeqSetDescription::Field*
SDLSeqSetDescription::add (int i, const char*name, newfunc newval,bool trace)
{
  if (i>=_len) return 0;
  _fields[i]._optional = false;
  _fields[i]._default = false;
  _fields[i]._trace = trace;
  _fields[i]._name = name;
  _fields[i]._newval = newval;
  return _fields+i;
}

SDLSeqSetDescription::Field*
SDLSeqSetDescription::add_optional (int i, const char* name, newfunc newval,bool trace)
{
  if (i>=_len) return 0;
  _fields[i]._optional = true;
  _fields[i]._default = false;
  _fields[i]._trace = trace;
  _fields[i]._name = name;
  _fields[i]._newval = newval;
  return _fields+i;
}

SDLSeqSetDescription::Field*
SDLSeqSetDescription::add_default (int i, const char* name, newfunc newval,bool trace)
{
  if (i>=_len) return 0;
  _fields[i]._optional = true;
  _fields[i]._default = true;
  _fields[i]._trace = trace;
  _fields[i]._name = name;
  _fields[i]._newval = newval;
  return _fields+i;
}

bool
SDLSeqSetDescription::optional_p (int index) const
{
  return _fields[index]._optional;
}

bool
SDLSeqSetDescription::default_p (int index) const
{
  return _fields[index]._default;
}

bool
SDLSeqSetDescription::trace_p (int index) const
{
  return _fields[index]._trace;
}

const char*
SDLSeqSetDescription::name (int index) const
{
  return _fields[index]._name;
}

SDLType*
SDLSeqSetDescription::at (int index,const SDLType* me)const
{
  return (_fields[index]._newval)?
                    _fields[index]._newval() : me->*(_fields[index]._newctxval);
}



// Abstract base class for SDL and ASN.1 structure types implementation

SDLSeqSet::SDLSeqSet(SDLType **field_list, unsigned long size) :
  _extra_fields(0)
{
  for(unsigned long i=0; i<size; i++)
    field_list[i]=0;
  set_state(validValue);
}

SDLSeqSet::SDLSeqSet(const SDLSeqSet& seq) :
  SDLType(seq),
  _extra_fields(seq._extra_fields?
    new SDLOctetString(*seq._extra_fields):
    0)
{}


SDLSeqSet::~SDLSeqSet()
{
  delete _extra_fields; _extra_fields = 0;
}


// valid, if the fields are valid; otherwise I run into problems
// with context save
bool
SDLSeqSet::valid()const
{
  // the state is not valid for omitted values (SDLNull construction)
  if (!state(validValue)) return false;
  SDLSeqSetDescription *desc;
  SDLType *const* fields;
  get_fields(desc, fields);

  for (int i=0; i<desc->len(); i++) {
    if (fields[i]) {
#if 0
      if (!fields[i]->valid()) {
        //if set, it should be valid
        return false;
      }
#else
      if (!fields[i]->state(validValue)) {
        //if set, it should be valid
        return false;
      }
#endif
    } else if (!desc->optional_p(i)) {
      //if not set, it should be optional
      return false;
    }
  }
  return true;
}

void
SDLSeqSet::Print(std::ostream& out)const
{
  if (!state(validValue)) {
    out << "<invalid SEQUENCE/SET " << name() << " value>\n";
    return;
  }
  SDLSeqSetDescription *desc;
  SDLType *const*fields;
  get_fields(desc, fields);
  bool invalid = false;
  out << "-- SEQUENCE/SET " << name() << " -- {\n";
  for (int i=0; i<desc->len(); i++)
  {
    out << "\t\t" << desc->name (i) << ": ";
    if (!desc->trace_p(i)) {
      out << "<no trace>";
    }
    else if (fields[i]) {
      if (desc->default_p(i) && fields[i]->equal(*desc->at(i,this)))
        out << "-- default value -- ";
      fields[i]->Print (out);
    }
    else if (desc->optional_p (i)) {
      if(desc->default_p(i))
          out << "default value ";
      out << "not present";
    }
    else {
      out << "<invalid>";
      invalid = true;
    }
    out << "\n";
  }
  if (_extra_fields) {
    out << "\t\t... : " << *_extra_fields << "\n";
  }
  out << "}";
  if (invalid) out << " -- <invalid SDL structure value> --";
}


// SDLSeqSet static methods

SDLType *
SDLSeqSet::field_access(
  SDLSeqSetDescription& d,SDLType **field_list,int index,bool with_default)
  const
{
  SITEASSERT(index<d.len(),"SDLSeqSet::field_access: index out of range");
  if(!field_list[index]) {
    field_list[index] = with_default?
      d.at(index,this)->copy():d.at(index,this)->create_new()->copy();
  }
  // accessing any fields initializes an invalid structure
  // const cast because of stable interface...
  SITE_CONST_CAST(SDLSeqSet*,this)->set_state(validValue);
  return field_list[index];
}

void
SDLSeqSet::sequence_copyinit(SDLType **dest, SDLType*const* source, int size)
{
#ifdef SITE_LOG
    if (SDLType::_type_debug & SITE_COPY_LOG)
      std::cerr << "(SDLRTE) struct copy of fields " << std::endl;
#endif
  for(int i=0; i<size; i++) {
#ifdef SITE_LOG
    if (SDLType::_type_debug & SITE_COPY_LOG) {
      std::cerr << "  field " << i+1 <<  ": ";
      if (source[i]) std::cerr << *source[i] << std::endl;
      else std::cerr << "<not present>" << std::endl;
    }
#endif
    dest[i] = (source[i]&&source[i]->state(validValue))
               ? source[i]->copy() : 0;
  }
}

const SDLBool&
SDLSeqSet::field_present (
  SDLSeqSetDescription& desc, SDLType*const* field_list, int index) const
{
  if (!state(validValue)) return SDLBool::SDLFalse();
  if (field_list[index] == 0) return SDLBool::SDLFalse();
  if (desc.default_p(index)){
    // defval is a proto object, no delete
    SDLType *defval = desc.at(index,this);
    if(field_list[index]->equal(*defval))
      return SDLBool::SDLFalse();
    return SDLBool::SDLTrue();
  }
  return (field_list[index]->valid()) ?
           SDLBool::SDLTrue() :
           SDLBool::SDLFalse();
}

void
SDLSeqSet::field_omit(SDLSeqSetDescription&, SDLType **field_list, int index)
{
  delete field_list[index];
  field_list[index]=0;
}

unsigned int
SDLSeqSet::sequence_hash(
  SDLType*const* field_list, int size, unsigned int max_hash)
{
  unsigned int result = 0;
  for (int i=0; i<size; i++) {
    if (field_list[i])
      result += field_list[i]->hash(max_hash);
  }
  return result%max_hash;
}

void
SDLSeqSet::clear_fields(SDLType** field_list, int size)
{
  for (int i=0; i<size; i++) {
    delete field_list[i]; field_list[i] = 0;
  }
}

// SDLSeqSet (dynamic) methods
void
SDLSeqSet::sequence_assign(const SDLSeqSet& src)
{
  bool is_tmp = src.state(SITEtemporaryValue);
#ifdef SITE_LOG
  if (SDLType::_type_debug & SITE_ASSIGNMENT_LOG)
    std::cerr << "(SDLRTE) struct " << (is_tmp?"reference ":"") <<
            "assignment of " << src <<
            " to variable with value " << *this << std::endl;
#endif
  SDLType **myfields;
  SDLType *const* ofields;
  SDLSeqSetDescription *mydesc, *odesc;
  get_fields(mydesc,myfields);
  src.get_fields(odesc,ofields);
  assert(mydesc == odesc);
  int l = mydesc->len();
  set_state(~SITEtemporaryValue);
  if (is_tmp) {
    for(int i=0;i<l;i++) {
      delete myfields[i]; myfields[i] = ofields[i];
      SITE_CONST_CAST(SDLType**,ofields)[i] = 0;
    }
    delete _extra_fields;
    _extra_fields = src._extra_fields;
    if (_extra_fields)
      SITE_CONST_CAST(SDLSeqSet&,src)._extra_fields = 0;
  } else {
    for(int i=0;i<l;i++) {
      SDLType *f_left = myfields[i],
      *f_right = ofields[i];
      if (f_left) {
        if (f_right) {
          f_left->assign(f_right);
        } else {
          delete f_left; myfields[i]=0;
        }
      } else {
        myfields[i] = f_right ? f_right->copy() : 0;
      }
    }

    delete _extra_fields;
    _extra_fields = src._extra_fields?
      new SDLOctetString(*src._extra_fields):
      0;
  }
  set_state(validValue);
}


const SDLBool&
SDLSeqSet::eq(const SDLSeqSet&o)const
{
  check_valid(), o.check_valid();

  SDLType *const*myfields, *const*ofields;
  SDLSeqSetDescription *mydesc, *odesc;
  SDLType *p1,*p2;

  get_fields(mydesc, myfields);
  o.get_fields(odesc, ofields);

  for(int i=0;i<mydesc->len();i++) {
    p1 = myfields[i];
    p2 = ofields [i];
    // two optional fields
    if(!p1 && !p2) {
       // because of the valid check...
       if  (!mydesc->optional_p(i))
         assert(0);
       continue;
    }
    // both fields present
    if (p1 && p2) {
      if (!p1->equal(*p2)) return SDLBool::SDLFalse();
      continue;
    }
    // one of the fields is not present

    // if we do not have default values, then there is a difference
    if(!mydesc->default_p(i)) return SDLBool::SDLFalse();

    // otherwise we have to check against the default value
    if(!p1) p1 = mydesc->at(i,this);
    if(!p2) p2 = mydesc->at(i,this);
    if (!p1->equal(*p2)) return SDLBool::SDLFalse();
  }
  return SDLBool::SDLTrue();
}

const SDLBool&
SDLSeqSet::ne(const SDLSeqSet& s)const
{ return eq(s)._not(); }


bool
SDLSeqSet::equal(const SDLType& s)const
{
  return eq(dynamic_cast<const SDLSeqSet&>(s));
}


AsnLen
SDLSeqSet::bEnc(BUF_TYPE b) const
{
    AsnLen elmtLen = bEncContent(b);
    elmtLen += BEncDefLen(b,elmtLen);
    elmtLen += BEncTag1(b,UNIV,CONS,16);
    return elmtLen;
}

AsnLen
SDLSeqSet::bEncContent(BUF_TYPE b) const
{
#ifdef SITE_LOG
  if (SDLType::_type_debug & SITE_BER_LOG)
    std::cerr << "encode struct value " << *this << std::endl;
#endif
  SDLSeqSetDescription *desc;
  SDLType *const*fields;
  get_fields(desc, fields);
  AsnLen bytesDecoded = 0;
  for (int i=desc->len()-1; i>=0; i--) {
    if (fields[i]) bytesDecoded += fields[i]->bEnc(b);
    else throw SDLUndefinedField(desc->name(i));
  }
  return bytesDecoded;
} // TYPE_B_4d13::bEncContent

void
SDLSeqSet::bDec(BUF_TYPE b,AsnLen& bytesDecoded)
{
    AsnTag tagId = BDecTag1(b,bytesDecoded);
    AsnLen elmtLen;
    if (tagId != MAKE_TAG_ID(UNIV,CONS,16))
    { TagError(MAKE_TAG_ID(UNIV,CONS,16),tagId); return; }
    elmtLen = BDecLen(b,bytesDecoded);
    AsnLen localBytesDecoded = 0;
    bDecContent(b,tagId,elmtLen,localBytesDecoded);
    bytesDecoded += localBytesDecoded;
} // TYPE_B_4d13::bDec

void
SDLSeqSet::bDecContent(BUF_TYPE b,AsnTag,
        AsnLen len, AsnLen& bytesDecoded)
{
  SDLSeqSetDescription *desc;
  SDLType **field_list;
  get_fields(desc, field_list);
  AsnLen localBytesDecoded = 0;
  for (int i=0; i<desc->len(); i++) {
    if(!field_list[i]) {
      field_list[i] = desc->at(i,this)->copy();
    }
    field_list[i]->bDec(b,localBytesDecoded);
  }
  bytesDecoded += localBytesDecoded;
  if (len!=localBytesDecoded)
    throw ASNLengthException("SDL struct - bDecContent: wrong byte number");
  set_state(validValue);
#ifdef SITE_LOG
  if (SDLType::_type_debug & SITE_BER_LOG)
    std::cerr << "decoded struct value " << *this << std::endl;
#endif
}

void
SDLSeqSet::complete_sequence_decoding(BUF_TYPE b, AsnLen len, AsnLen &local, AsnTag tagId)
{
   bool done = (len!=INDEFINITE_LEN) && (local==len);
   if (local>len)
      LengthError();
   if ((len==INDEFINITE_LEN) && (tagId==EOC_TAG_ID)) {
      BDEC_2ND_EOC_OCTET(b,local);
      done = true;
   }
   if (!done)
      LengthError();
}

AsnLen
SDLSeqSet::BEncExtraFields(BUF_TYPE b) const
{
  return _extra_fields ? _extra_fields->bEncContent(b) : 0;
}

void
SDLSeqSet::BDecSkipField(BUF_TYPE b, AsnLen &local, AsnTag tagId)
{
   AsnLen len = BDecLen(b, local);
   VAR_ellipsis(); // init
   remember_tag(_extra_fields,tagId);
   remember_len(_extra_fields,len);
   if (len != INDEFINITE_LEN)
   {
      /* A field that has a definite length.
         the next field, which might be EOC. */
      remember_data(_extra_fields, b, len);
      local += len;
      return;
   }
   /* The field is with indefinite length (SEQUENCE, SET, or OCTET STRING).
      It better is constructed, so we can read a tag next. */
   if (!TAG_IS_CONS (tagId))
      TagError (MAKE_TAG_ID (UNIV, CONS, 16), tagId); /* any constructed field would have done. */

   AsnTag t1 = BDecTag (b, local);
   /* We will recursively fall into the indefinite case right away. */
   complete_open_sequence_decoding(b, len, local, t1);
}


void
SDLSeqSet::complete_open_sequence_decoding(BUF_TYPE b, AsnLen len, AsnLen &local, AsnTag tagId)
{
   if (len != INDEFINITE_LEN)
   {
      /* The entire sequence has a definite length, skip the rest of it. */
      if (len == local)
         return;
      VAR_ellipsis(); // init
      remember_tag(_extra_fields,tagId);        //First tag of remaining fields
      remember_data(_extra_fields,b, len-local);//remaining fields, starting with len
      local = len;
      return;
   }

   /* The sequence has a indefinite length, skip it field-by-field until EOC. */

   while (tagId != EOC_TAG_ID)
   {
      /* Read one field, then get the next tag. */
      BDecSkipField(b, local, tagId);
      tagId = BDecTag (b, local);
   }

   /* Now we eventually found the EOC. */
   BDEC_2ND_EOC_OCTET (b, local);
   // SITE sends finite even if the received value was inifinite.
   // Hence we have to discard the two EOC tags.
   // remember_tag(_extra_fields,EOC_TAG_ID);
   // remember_len(_extra_fields,0);
}

SDLOctetString&
SDLSeqSet::VAR_ellipsis() const
{
   if (!_extra_fields)
     _extra_fields = new SDLOctetString("");
   return *_extra_fields;
}

bool SDLSeqSet::datainfo(long index,
                         SDLIA5String& fieldname,
                         SDLType*& value,
                         infotype dir)
{
   SDLSeqSetDescription *d;
   SDLType **f;
   /* Index starts at 1. */
   if(index<=0)
       return false;
   index--;
   get_fields (d, f);
   if (index >= d->len())
      /* end of structure */
      return false;
   fieldname = d->name (index);
   value = f[index];
   if (value)
      /* Field present */
      return true;
   if (dir == info_get)
      /* Not present, reading */
      return true;
   /* Writing, modify */
   field_access (*d, f, index);
   value = f[index];
   return true;
}

void
SDLSeqSet::assign_new()
{
  delete _extra_fields; _extra_fields = 0;
  SDLSeqSetDescription *desc;
  SDLType ** fields;
  get_fields(desc, fields);
  clear_fields(fields,desc->len());
  SDLType::assign_new();
}

void
SDLSeqSet::init_type()
{
  SDLType::init_type();
  SDLSeqSetDescription *desc;
  SDLType ** fields;
  get_fields(desc, fields);
  for(int i = 0; i<desc->len();++i) {
    if (desc->default_p(i)) desc->at(i,this);
  }
}
