/* ===== implementSDLType_macro.h ===== */

#ifndef implementSDLType
#define implementSDLType(M_TYPE,M_BASE) \
    M_TYPE::M_TYPE(const SDLAny& a, AsnCodingSet rule_set){                                      a.decode(this,rule_set); }\
    \
    SITELIB_implementSDLType(M_TYPE,M_BASE)
#endif
