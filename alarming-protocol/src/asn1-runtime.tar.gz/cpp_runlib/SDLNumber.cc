/*******************************************************************************
*   vim:sw=2:ts=2:et
*
*   File    : SDLNumber.cxx
*   Author  : Ralf Schr�der
*             Humboldt University Berlin
*             Department of Computer Science / System Analysis
*   e-mail  : r.schroeder@informatik.hu-berlin.de
*   Project : @vantage platform
*   $Date: 2006-04-04 13:14:09 +0200 (tir, 04 apr 2006) $
*   $Revision: 586 $
*
*******************************************************************************/
#include "SDLChar.h"
#include "SDLAny.h"
#include "SDLReal.h"
#include "BasicEncoding.h"
#include "SITELIB_implementSDLType_macro.h"
#include "implementSDLType_macro.h"
#include "sdlconfig.h"
#if defined(_MSC_VER) && _MSC_VER<1300
#include "ostream64.h"
#endif
#if !defined(_MSC_VER)
#include <stdlib.h>
#endif

#ifdef SITE_RCS_IDENT
static const char* SDLNumber_RCSID FRWUNUSED = "$Id: SDLNumber.cc 586 2006-04-04 11:14:09Z tneumann $";
#else
static const char* SDLNumber_SCCSID FRWUNUSED = "@(#) ";
#endif

implementSDLType(SDLNumber,SDLType)

void
SDLNumber::init_type()
{
  const SDLNumber *ival;
  C_INT val;
  for(int i=1;get_literal(i,&ival,&val);i++);
  SDLType::init_type();
}


bool
SDLNumber::valid()const
{ return state(validValue); }

AsnLen
SDLNumber::pEnc(pAsnBuf& octBuf)const {
#if SITE_SDL_INT_SIZE==64
    #if defined(_MSC_VER) && _MSC_VER<1300
      SITE_SDL_UINT bitMask= 0x7f80000000000000L;
    #else
      SITE_SDL_UINT bitMask= 0x7f80000000000000LL;
    #endif
#else
    SITE_SDL_UINT bitMask= 0x7f800000;
#endif
    int valCpy=_value;
    int numLen, j;

    if(_value<0){
      for(numLen=SITE_SDL_INT_SIZE/8; numLen>1; bitMask>>=8,numLen--)
	if((bitMask & _value)!=bitMask) break;
    }
    else{
      for(numLen=SITE_SDL_INT_SIZE/8; numLen>1; bitMask>>=8,numLen--)
	if(bitMask & _value) break;
    }
    // since the numLen is always 8 or less, it is alway encoded into 1 byte
    pEncLen(octBuf, numLen);

    for(j=numLen-1;j>=0;j--){
	octBuf.putByte((char)((valCpy & (0xff<<j*8))>>(j*8)));
    }
    // add the one byte of the numLen coding
    return (numLen+1)*8;
}

//XXX what is the length of type of _value? probably 64 bit == 8 byte!
void
SDLNumber::pDec(pAsnBuf& octBuf) {

  //int start,end;
  int elmtLen=pDecLen(octBuf);
  char aByte;

  //start=octBuf.getReadPos();
  if (elmtLen>SITE_SDL_INT_SIZE/8);
      //an exception should be thrown
  aByte=octBuf.getByte();
  if ((aByte & 0x80) != 0)
      _value=(-1 << 8) | aByte;
  else
      _value = aByte;
  for(;elmtLen>1;elmtLen--) {
      aByte = octBuf.getByte();
      _value=(_value << 8) | ((aByte&0x7f) & 0xFF);
      if (aByte&0x80) _value |= 0x80;
  }
  set_state(validValue);
  //end=octBuf.getReadPos();
  //markup.addRow(start,end-start,octBuf.subString(start,end-start),"unconstrained Integer ("+_value+")");
}



AsnLen
SDLNumber::bEnc(BUF_TYPE b) const
{
  AsnLen l = bEncContent(b);
  BEncDefLenTo127(b,l);
  l++;
  l += BEncTag1(b, UNIV, PRIM, INTEGER_TAG_CODE);
  return l;
}

void
SDLNumber::bDec( BUF_TYPE b, AsnLen& bytesDecoded)
{
  AsnTag tagId = BDecTag1(b,bytesDecoded);
  AsnLen elmtLen;
  if (tagId != MAKE_TAG_ID(UNIV,PRIM,INTEGER_TAG_CODE)) {
    TagError(MAKE_TAG_ID(UNIV,PRIM,INTEGER_TAG_CODE),tagId); return;
  }
  elmtLen = BDecLen(b,bytesDecoded);
  AsnLen localBytesDecoded = 0;
  bDecContent(b,tagId,elmtLen,localBytesDecoded);
  bytesDecoded += localBytesDecoded;
}
#ifndef _MSC_VER
typedef unsigned long long ulonglong;
#else
typedef unsigned __int64 ulonglong;
#endif
AsnLen
SDLNumber::bEncContent(BUF_TYPE b) const
{
#ifdef SITE_LOG
  if (SDLType::_type_debug & SITE_BER_LOG)
    std::cerr << "encode integer value " << *this << std::endl;
#endif
  if (!state(validValue)) check_valid();
  ulonglong mask;
  // correct for 2-complement hardware, needed to guarant left 0 for >>
  ulonglong dataCpy = (ulonglong)_value;
  AsnLen len;
  if (_value < 0) {
    // calculate encoded length of the integer (content) */
    mask = ((ulonglong)0x7f80 << ((sizeof(_value) - 2) * 8));
    for (len = sizeof(_value) ; len > 1 ; --len) {
      if ( (dataCpy & mask) == mask)
        mask >>= 8;
      else
        break;
    }
  } else {
    // cut out enums and small numbers
    if (_value<127) {
      b.PutByteRvs(TO_UCHAR(dataCpy));
      return 1;
    }
    mask = ((ulonglong)0x7f80 << ((sizeof(_value) - 2) * 8));
    for (len = sizeof(_value) ; len > 1 ; --len) {
      if ( (dataCpy & mask) == 0)
        mask >>= 8;
      else
        break;
    }
  }

  // write the BER integer
  for (AsnLen i = 0; i < len; i++) {
    b.PutByteRvs(TO_UCHAR(dataCpy));
    dataCpy >>= 8;
  }

  return len;
}

void
SDLNumber::bDecContent(
  BUF_TYPE b, AsnTag, AsnLen elmtLen,AsnLen& bytesDecoded)
{
  AsnLen   i;
  unsigned char byte;

  set_state(invalidValue);
  if (TO_SIZE_T(elmtLen) > sizeof(_value)) {
    throw ASNTooBigToDecodeException(
      "SDLNumber::bDecContent: ERROR - integer is too big to decode"
    );
  }

  // determine the sign and the first byte
  byte = b.GetByte();
  if (byte & 0x80) {  /* top bit of first byte is sign bit */
    _value = -1;
    _value = (_value << 8) | byte;
  } else
    _value = byte;

  // write from buffer into _value
  for (i = 1; i < elmtLen; i++)
    _value = (_value << 8) | b.GetByte();

  bytesDecoded += elmtLen;
  set_state(validValue);
#ifdef SITE_LOG
  if (SDLType::_type_debug & SITE_BER_LOG)
    std::cerr << "decoded integer value " << *this << std::endl;
#endif
}

unsigned int
SDLNumber::hash(unsigned int max)const
{ C_INT i = val()&0xffffffff; return TO_UINT32((i>=0)?i:-i)%max; }

void
SDLNumber::Print(std::ostream& os)const
{
  if (valid()) os << _value;
  else os << "<invalid Integer value>";
}

bool
SDLNumber::equal(const SDLType& b) const
{ return val()==SITE_DYNAMIC_CAST(const SDLNumber&,b).val(); }

SDLNumber
SDLNumber::add(C_INT l)const
{ return val()+l; }

SDLNumber
SDLNumber::sub(C_INT l)const
{ return val()-l; }

SDLNumber
SDLNumber::mul(C_INT l)const
{ return val()*l; }

SDLNumber
SDLNumber::div(C_INT l)const
{
  if (l) return val()/l;
  else { throw SDLDivisionByZero(); return 0; }
}

SDLNumber
SDLNumber::mod(C_INT l)const
{
  if (!l) { throw SDLDivisionByZero(); return 0; }
  C_INT v = val();
  if (l<0) l=-l;
  if (v>=0) { return v-(l*(v/l)); }
  else {
    C_INT rem_val = v-(l*(v/l));
    return (rem_val==0)?0:rem_val+l;
  }
}

SDLNumber
SDLNumber::rem(C_INT l)const
{
  if (l) { C_INT v = val(); return v-(l*(v/l)); }
  else { throw SDLDivisionByZero(); return 0; }
}

SDLNumber
SDLNumber::neg()const
{ return -val(); }

SDLNumber
SDLNumber::Any(C_INT min, C_INT max)
{
  // just in case the result exceeds SITE_INT_MAX
  assert(max>0?max - min + 1 >0:1);
#ifdef WIN32
  return min + ( rand() % (max - min +1));
#else
  return min + ( random() % (max - min +1));
#endif
}

SDLNumber
SDLNumber::Any()
{
  return
#ifdef WIN32
    rand();
#else
    random();
#endif
}

SDLReal
SDLNumber::op_float()const
{ return (double)val(); }

SDLChar
SDLNumber::chr()const
{ return SDLChar(TO_CHAR(val()&0x7f)); }

SDLTypeId
SDLNumber::sdl_type_id()const
{ return TypeId_SDLInt; }

bool
SDLNumber::get_literal(int,const SDLNumber**,C_INT*) const
{ return false; }

int
SDLNumber::nr_literals()const
{ return 0; }

bool
SDLNumber::datainfo(long,SDLIA5String&,const SDLType*&)const
{ return false; }

void
SDLNumber::to_string(std::stringstream& buf){
  if (valid()) buf<<_value;
}
