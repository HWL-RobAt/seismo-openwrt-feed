/*******************************************************************************
*   vim:sw=2:ts=2:et
*
*   File    : SDLBool.h
*   Author  : Ralf Schr�der
*             Humboldt University Berlin
*             Department of Computer Science / System Analysis
*   e-mail  : r.schroeder@informatik.hu-berlin.de
*   Project : @vantage platform
*   $Date: 2005-05-05 17:38:41 +0200 (Thu, 05 May 2005) $
*   $Revision: 1.6 $
*
*******************************************************************************/
#ifndef _SDLBOOL_H
#define _SDLBOOL_H

#include "SDLType.h"

#ifdef SITE_RCS_IDENT
static const char* SDLBOOL_RCSID FRWUNUSED = "$Id: SDLBool.h 554 2005-05-05 15:38:41Z tneumann $";
#else
static const char* SDLBOOL_SCCSID FRWUNUSED = "@(#) ";
#endif

// forward declaration
class SDLAny;

/** SDL Boolean.
    This is one of the most used data types, hence the implementation
    has to be highly efficient. Therefore, most non virtual methods
    are inlined, it would be better to have more of them.
*/
class SDL_API SDLBool : public SDLType
{
  protected:
    /** Hold the boolean value. */
    bool _value;

  public:

    /* Call of generated macro for code shared by all declarations of SDL types
     */
    declareSDLType(SDLBool,SDLType)

    /** Constructor for an invalid value.
        Initialize _value for access checks.
    */
    SDLBool()  : _value(false) {}

    /** Constructor for a given valid value */
    SDLBool(bool b) :_value(b) { set_state(validValue); }

    /** Constructor for an omitted (invalid) value.
        Initialize _value for access checks.
    */
    SDLBool(const SDLNull&)  : _value(false) {}

    /** Copy constructor.
        Can be used for invalid values.
    */
    SDLBool(const SDLBool& b) :SDLType(b),_value(b._value)
    {
#ifdef SITE_LOG
      if (SDLType::_type_debug & SITE_COPY_LOG)
        std::cerr << "(SDLRTE) boolean copy of value "
             << b << std::endl;
#endif
    }

  private:
    /** Static literal representation. It is initialized by using
        C++ startup initialization. Hence, it is thread safe.
    */
    static const SDLBool the_true, the_false;

  public:
    /** Literal object for TRUE */
    static const SDLBool& SDLTrue() { return the_true; }

    /** Literal object for FALSE */
    static const SDLBool& SDLFalse() { return the_false; }

    /** Valid check.
        @return true, if the data object is a valid one.
        It can be configured to switch off this test.
    */
    virtual bool valid()const;

    /** Encoding of tag and length */
    virtual AsnLen bEnc(BUF_TYPE b) const;
/**
   * Encodes this Bool according to PER to the given buffer.
   *
   * @param b the buffer to write the encoding to
   * @return the number of bits written to the buffer; always 1.
   */

    virtual AsnLen pEnc(BUF_TYPE2 b) const; //XXX

    /** Encoding of the boolean value without tag and length */
    virtual AsnLen bEncContent(BUF_TYPE) const;

    /** Decoding of tag and length */
    virtual void bDec(BUF_TYPE b, AsnLen& bytesDecoded);
  /**
   * Decodes a PER BOOLEAN from the given buffer.
   *
   * @param b the buffer to read from
   * @exception ASNDecodeException if decoding failed.
   */

    virtual void pDec(BUF_TYPE2 b);

    /** Decoding of the boolean value without tag and length */
    virtual void bDecContent(BUF_TYPE,AsnTag,AsnLen,AsnLen&);

    /** Access to the kind of the object */
    virtual SDLTypeId sdl_type_id()const;

    /** Prints TRUE or FALSE. */
    virtual void Print(std::ostream&)const;

    /** Returns a hash value */
    virtual unsigned int hash(unsigned int)const { return val()?0:1; }

    /** Assignment operator for SDLBool */
    SDLBool& operator=(bool b)
    {
#ifdef SITE_LOG
      if (SDLType::_type_debug & SITE_ASSIGNMENT_LOG)
        std::cerr << "(SDLRTE) primitive boolean assignment of " << b <<
                " to variable with value " << *this << std::endl;
#endif
      _value=b; set_state(validValue); return *this;
    }

    /** Assignment operator for SDLBool */
    SDLBool& operator=(const SDLBool& b)
    {
#ifdef SITE_LOG
      if (SDLType::_type_debug & SITE_ASSIGNMENT_LOG)
        std::cerr << "(SDLRTE) boolean assignment of " << b <<
                " to variable with value " << *this << std::endl;
#endif
      _value=b.val(); set_state(validValue); return *this;
    }

    /** Cast operator (with valid check) to C++ inline bool */
    operator bool() const
    { if (!state(validValue)) check_valid(); return _value; }

    /** Explicit value access with valid check. */
    bool val()const { return bool(*this); }

    /** Writes the represented value to the string stream. Does nothing if
	invalid. */
    void to_string(std::stringstream& buf);

    /** SDL equality. */
    //@{
    const SDLBool& eq(bool b)const
    { return (val()==b)?SDLTrue():SDLFalse(); }

    const SDLBool& ne(bool b)const
    { return (val()!=b)?SDLTrue():SDLFalse(); }

    /** Compares boolean objects.
        @param b a boolean object
        The dynamic cast failure is not caught because the code is
        generated correctly.
    */
    bool equal(const SDLType& b) const ;
    //@}

    /** SDL standard operations */
    //@{
    const SDLBool& _and(bool b)const ;
    const SDLBool& _or(bool b)const  ;
    const SDLBool& _xor(bool b)const ;
    const SDLBool& impl(bool b)const ;
    const SDLBool& _not()const ;
    //@}

};

#endif
