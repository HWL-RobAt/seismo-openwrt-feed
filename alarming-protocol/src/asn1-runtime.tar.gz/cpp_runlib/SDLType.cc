/*******************************************************************************
*   vim:sw=2:ts=2:et
*
*   File    : SDLType.cxx
*   Author  : Ralf Schr�der
*             Humboldt University Berlin
*             Department of Computer Science / System Analysis
*   e-mail  : r.schroeder@informatik.hu-berlin.de
*   Project : @vantage platform
*   $Date: 2006-04-04 13:14:09 +0200 (tir, 04 apr 2006) $
*   $Revision: 586 $
*
*******************************************************************************/
#include "SDLPredefined.h"
#include "SDLType.h"

#include "SITELIB_implementSDLType_macro.h"
#include "implementSDLType_macro.h"

#ifdef SITE_RCS_IDENT
static const char* RCSID FRWUNUSED = "$Id: SDLType.cc 586 2006-04-04 11:14:09Z tneumann $";
#else
static const char* SCCSID FRWUNUSED = "@(#) ";
#endif

//XXX is that still supported?
/* Use these constants to activate additional debug logging.
    It is sufficiant to recompile SDLTypes.cxx and to rebuild
    the shared SDL library.

    SITE_BER_LOG_ON : Log ASN buffer content and coding of library types.
    SITE_ASSIGNMENT_LOG_ON : Log all assignments (operator =).
    SITE_COPY_LOG_ON : Log copy constructor calls
    SITE_METHOD_LOG_ON : Log entry/exit of selected methods
    SITE_EXC_THROW_LOG_ON : Log the SDL exception handling
    SITE_TRACE2CERR_ON : redirect all SITE logs to cerr (no platform limit)
    SITE_EXCEPTION_LOOP_ON : run an infinite loop for any SDL exception calls
    SITE_ASSERT_LOOP_ON : run an infinite loop for SDLAssert calls
    SITE_ADDR_LOG_ON : print also address information
*/
#if 0
#define SITE_BER_LOG_ON
#define SITE_ASSIGNMENT_LOG_ON
#define SITE_COPY_LOG_ON
#define SITE_METHOD_LOG_ON
#define SITE_EXC_THROW_LOG_ON
#define SITE_TRACE2CERR_ON
#define SITE_EXCEPTION_LOOP_ON
#define SITE_ASSERT_LOOP_ON
#define SITE_ADDR_LOG_ON
#endif

/* do not change nor use these macros */
#ifdef SITE_BER_LOG_ON
#define SITE_BER_INIT SITE_BER_LOG
#else
#define SITE_BER_INIT 0x0
#endif

#ifdef SITE_ASSIGNMENT_LOG_ON
#define SITE_ASSIGNMENT_INIT SITE_ASSIGNMENT_LOG
#else
#define SITE_ASSIGNMENT_INIT 0x0
#endif

#ifdef SITE_COPY_LOG_ON
#define SITE_COPY_INIT SITE_COPY_LOG
#else
#define SITE_COPY_INIT 0x0
#endif

#ifdef SITE_EXC_THROW_LOG_ON
#define SITE_EXC_THROW_INIT SITE_EXC_THROW_LOG
#else
#define SITE_EXC_THROW_INIT 0x0
#endif

#ifdef SITE_TRACE2CERR_ON
#define SITE_TRACE2CERR_INIT SITE_TRACE2CERR_LOG
#else
#define SITE_TRACE2CERR_INIT 0x0
#endif

#ifdef SITE_METHOD_LOG_ON
#define SITE_METHOD_LOG_INIT SITE_METHOD_LOG
#else
#define SITE_METHOD_LOG_INIT 0x0
#endif

#ifdef SITE_EXCEPTION_LOOP_ON
#define SITE_EXCEPTION_LOOP_INIT SITE_EXCEPTION_LOOP
#else
#define SITE_EXCEPTION_LOOP_INIT 0x0
#endif

#ifdef SITE_ASSERT_LOOP_ON
#define SITE_ASSERT_LOOP_INIT SITE_ASSERT_LOOP
#else
#define SITE_ASSERT_LOOP_INIT 0x0
#endif

#ifdef SITE_ADDR_LOG_ON
#define SITE_ADDR_LOG_INIT SITE_ADDR_LOG
#else
#define SITE_ADDR_LOG_INIT 0x0
#endif

#ifdef SITE_LOG
void SITE_LOG_defined() {}
#else
void SITE_LOG_undefined() {}
#endif

int SDLType::_type_debug =
  SITE_BER_INIT|
  SITE_ASSIGNMENT_INIT|
  SITE_COPY_INIT|
  SITE_EXC_THROW_INIT|
  SITE_TRACE2CERR_INIT|
  SITE_METHOD_LOG_INIT|
  SITE_ASSERT_LOOP_INIT|
  SITE_EXCEPTION_LOOP_INIT|
  SITE_ADDR_LOG_INIT;


#define _STATE_DELETED SITEreservedState5

SDLType::~SDLType()
{
#ifdef SITE_LOG
  if ((SDLType::_type_debug)&SITE_ADDR_LOG)
    std::cerr << "(SDLRTE): SDLType destructor for " << this << std::endl;
#endif
  assert((_status&_STATE_DELETED)==0);
  _status = _STATE_DELETED;
}

void
SDLType::init_type()
{
  create_new(); // initialize the static proto object, if not done yet
}

void
SDLType::set_state(ValueState s)
{
  // note, switch is int, attend conversion problems...
  switch(s) {
    case invalidValue:
      _status &= ~validValue; return;
    case validValue:
      _status |= validValue; return;
    case SITEconstValue:
      _status |= validValue|SITEconstValue; return;
    case SITEtemporaryValue:
      _status |=  SITEtemporaryValue; return;
    case (ValueState)(~SITEtemporaryValue):
      _status &=  ~SITEtemporaryValue; return;
    case (ValueState)(~SITEconstValue):
      _status &=  ~SITEconstValue; return;
    default:
      throw SDLOperationNotImplemented("SDLType::set_state unknown state");
  }
}

void
SDLType::assign(const SDLType*t)
{
  assert((_status&_STATE_DELETED)==0);

#ifdef SITE_LOG
  if (SDLType::_type_debug & SITE_ASSIGNMENT_LOG)
    std::cerr << "(SDLRTE) incompatible assignment of " << t
         << " (" << t->name()
         << ") to variable with value " << *this
         << " (" << name() << ") => SDLAssert!" << std::endl;
#endif
  assert(0);
}

bool
SDLType::valid()const
{return true;}

const SDLBool&
SDLType::SDLValid()const
{
  return valid()?SDLBool::SDLTrue():SDLBool::SDLFalse();
}


const SDLBool&
SDLType::check()const
{
  check_valid(); return SDLBool::SDLTrue();
}

#ifndef NO_VALID
void
SDLType::check_valid() const
{
  assert((_status&_STATE_DELETED)==0);
  if (!valid()) throw SDLUndefinedVariable(name());
}
#endif

AsnLen
SDLType::bEnc(BUF_TYPE) const
{ throw SDLCodingError("bEnc not implemented"); return 0; }

AsnLen
SDLType::pEnc(BUF_TYPE2) const
{ throw SDLCodingError("pEnc not implemented"); return 0; }

AsnLen
SDLType::BEnc(BUF_TYPE b)
{ return bEnc(b); }

AsnLen
SDLType::bEncContent(BUF_TYPE) const
{ throw SDLCodingError("bEncContent not implemented"); return 0; }

AsnLen
SDLType::BEncContent(BUF_TYPE b)
{ return bEncContent(b); }

void
SDLType::bDec(BUF_TYPE, AsnLen&)
{ throw SDLCodingError("bDec not implemented"); }

void
SDLType::pDec(BUF_TYPE2)
{ throw SDLCodingError("pDec not implemented"); }

void
SDLType::BDec(BUF_TYPE b, AsnLen& len)
{ bDec(b,len); }

void
SDLType::bDecContent(BUF_TYPE,AsnTag,AsnLen,AsnLen&)
{ throw SDLCodingError("bDecContent not implemented"); }

void
SDLType::BDecContent(BUF_TYPE b ,AsnTag tag,AsnLen len,AsnLen& encLen)
{ bDecContent(b,tag,len,encLen); }

SDLAny
SDLType::encode(AsnCodingSet rule_set) const
{
  check_valid();
  AsnLen l;
  switch(rule_set){
    case asn_ber: {
	char data[ASN_BUF_SIZE];
	AsnBuf buf(data,ASN_BUF_SIZE);
	// what does it do?
	buf.reset_encode();
	l = bEnc(buf);
	return SDLAny(buf,l);
    }
    case asn_per: {
	pAsnBuf buf(ASN_BUF_SIZE);
	l = pEnc(buf);
	return SDLAny(buf,(l+7)/8);
    }
    default: {
      throw SDLCodingError("unknown encoding rule set requested for encoding");
    }
  }
  // just for the compiler
  return SDLAny();
}


SDLCharstring
SDLType::charstring() const
{
  std::ostringstream out;
  Print(out);
  out << '\0';
  SDLIA5String res(out.str().c_str());
  return res;
}


const char*
SDLType::name() const
{
  assert((_status&_STATE_DELETED)==0);
  return "method name() not implemented";
}

void
SDLType::assign_new()
{ _status = invalidValue; }

const SDLType*
SDLType::create_new() const
{
  assert((_status&_STATE_DELETED)==0);
  throw SDLOperationNotImplemented("SDLType::create_new");
  return 0;
}

void
SDLType::Print(std::ostream& os)const
{
  assert((_status&_STATE_DELETED)==0);
  os<<"<no output function defined for the current value>\n";
}

bool
SDLType::equal(const SDLType&)const
{
  assert((_status&_STATE_DELETED)==0);
  throw SDLOperationNotImplemented("equal not implemented");
  return false;
}


implementSDLType(SDLNull,SDLType)

SDLTypeId
SDLNull::sdl_type_id() const
{ return TypeId_Invalid; }

void
SDLNull::Print(std::ostream& out)const
{
  out << "<omitted value>";
};

SDLNull theSDLNull;

std::ostream&
operator<<(std::ostream& os, const SDLType& t)
{
#ifdef SITE_LOG
  if ((SDLType::_type_debug)&SITE_ADDR_LOG) os << "(" << &t << ")";
#endif
  t.Print(os);
  return os;
}

const SDLBool&
SDLType::destroy() const
{
  SITE_CONST_CAST(SDLType*,this)->assign_new();
  return SDLBool::SDLTrue();
}

void
SDLType::raise(SDLError* e) const
{
  throw *e;
}

