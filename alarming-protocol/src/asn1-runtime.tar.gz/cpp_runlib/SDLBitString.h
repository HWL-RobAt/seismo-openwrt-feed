/*******************************************************************************
*   vim:sw=2:ts=2:et
*
*   File    : SDLBitString.h
*   Author  : Ralf Schr�der
*             Humboldt University Berlin
*             Department of Computer Science / System Analysis
*   e-mail  : r.schroeder@informatik.hu-berlin.de
*   Project : @vantage platform
*   $Date: 2005-05-05 17:38:41 +0200 (Thu, 05 May 2005) $
*   $Revision: 1.4 $
*
*******************************************************************************/
#ifndef _SDLBITSTRING_H
#define _SDLBITSTRING_H

#include "SDLType.h"

#ifdef SITE_RCS_IDENT
static const char* SDLBITSTRING_RCSID FRWUNUSED = "$Id: SDLBitString.h 554 2005-05-05 15:38:41Z tneumann $";
#else
static const char* SDLBITSTRING_SCCSID FRWUNUSED = "@(#) ";
#endif

// forward declarations
class SDLBit;
class SDLBool;
class SDLInt;
class SDLOctetString;
class SDLAny;


/** Implementation of Bit_String.
    Warning: use of bit string as integer value is not intuitive!
    The following things hold:
    least significant bit = left bit = bit at index 0;
    most significant bit = right bit = bit at index length-1;
    That's why bits are filled with 0-bits to the rigth, if it becomes
    necessary.
*/
class SDL_API SDLBitString: public SDLType {
  protected:
    /** Growing bit field to hold the bit string.
        The field can be 0 for empty strings.
    */
	char* _bits;
  //TBY access needed in derived classes for decoding; private:
    /** SDL size of the bit string.
        Unused bits (right) are filled with 0.
    */
    SITE_SDL_INT _bitLen;

    /** C++ size of _bits.
        @postcondition Unused bits of an incomplete octet have to be 0.
    */
    SITE_SDL_INT _size;

  public:
    /** Internal class to realize bit modify access */
    class SDLBitRef {
      char        *_bits;
      SITE_SDL_INT _index;
    public:
      SDLBitRef(char * bits, SITE_SDL_INT index):_bits(bits),_index(index) {}
      void operator=(bool b)  {
        if (b)
          _bits[_index/8] |= 1 << (7-_index%8);
        else
          _bits[_index/8] &= ~(1 << (7-_index%8));
      }
    };

    declareSDLType(SDLBitString,SDLType)

  private:
    /** Static empty literal. It is initialized with C++
        startup initialization, hence thread safe.
    */
    static const SDLBitString empty;

  public:
    /** Static empty literal */
    static const SDLBitString& LIT_B() { return empty; }

    /** Constructor for an invalid value. */
    SDLBitString()  : _bits(0),_bitLen(0),_size(0) {}

    /** Constructor for bitstrings of kind [01]*B [0-9A-F]*H.
        Do not forget the final H/B in the string!
    */
    SDLBitString(const char *str) ;

    /** Constructor for MkString.
    */
    SDLBitString(const SDLBit& b,SITE_SDL_INT size=1) ;

    /** Constructor for OctetStrings.
    */
    SDLBitString(const SDLOctetString& os) ;

    /** Constructor for an omitted (invalid) value */
    SDLBitString(const SDLNull&)  : _bits(0),_bitLen(0),_size(0) {}

    /** Copy constructor; cuts the internal bit field. */
    SDLBitString(const SDLBitString& str) ;

protected:
    /** Constructor needed for correct String0 handling.
        It copies the given string but uses reserve bytes more then
        needed for internal representation.
    */
    SDLBitString(const SDLBitString& str, SITE_SDL_INT reserve);

public:
    /** Clean up */
    virtual ~SDLBitString();

    /** Valid check.
        @returns true, if the data object is a valid one.
        It can be configured to switch off this test.
    */
    virtual bool valid()const ;

    /** PER encoding of the bitstring */
    virtual AsnLen pEnc(BUF_TYPE2 b) const;

    /** PER decode of the given bitstring */
    virtual void pDec(BUF_TYPE2 b);

    /** Encoding of tag and length */
    virtual AsnLen bEnc(BUF_TYPE b) const;

    /** Encoding of the boolean value without tag and length */
    virtual AsnLen bEncContent(BUF_TYPE) const;

    /** Decoding of tag and length */
    virtual void bDec(BUF_TYPE b, AsnLen& bytesDecoded) ;

    /** Decoding of the boolean value without tag and length */
    virtual void bDecContent(BUF_TYPE,AsnTag,AsnLen,AsnLen&) ;

    /** Access to the kind of the object */
    virtual SDLTypeId sdl_type_id()const;

    /** Prints the string in '...'B format. */
    virtual void Print(std::ostream&)const;

    /** Returns a hash value */
    unsigned int hash(unsigned int)const;


    /** Assignment operator for SDLBitString */
    SDLBitString& operator=(const SDLBitString& str);

    /** Direct access to the internal buffer.
        @postcondition: length() valid bits only.
    */
    operator char*() const { return _bits;}

    /** return the C++ length of the bit string */
    SITE_SDL_INT Len() const { return _bitLen; }

    /** SDL equality. */
    //@{
    const SDLBool& eq(const SDLBitString& bs)const ;
    const SDLBool& ne(const SDLBitString& bs)const ;

    /** Compares BitString objects.
        @param type second parameter of equality.
    */
    virtual bool equal(const SDLType& type)const ;

    //@}

    /** SDL operations for Bit_String */
    //@{
    SDLBitString cat(const SDLBitString& bs)const ;
    SDLInt length()const ;
    SDLBit first()const ;
    SDLBit last()const ;

    /** Extract access operator (starts with 0 = left bit in literals).
        @exception SDLInvalidIndex if the index is out of range.
    */
    const SDLBit operator[](SITE_SDL_INT) const;

#if SITE_SDL_INT_SIZE==64
    /** Extract access operator (starts with 0 = left bit in literals).
        Operator introduced because of ambiguous overload
        c[2] resolvable as operator[]((long long)2) or (char*(c))[2].
    */
    const SDLBit operator[](int)const;
#endif

    /** Modify access operator (starts with 0 = left bit in literals);
        SITE expansion semantics
    */
    SDLBitRef operator()(SITE_SDL_INT);

    SDLBitString substr(SITE_SDL_INT start,SITE_SDL_INT length)const ;

    SDLBitString _and(const SDLBitString& bs)const ;

    /** Bit or, not conform to Z.105 axioms (Z.105 bug) */
    SDLBitString _or(const SDLBitString& bs)const  ;
    /** Bit xor, not conform to Z.105 axioms (Z.105 bug) */
    SDLBitString _xor(const SDLBitString& bs)const ;
    /** Bit implication, not conform to Z.105 axioms (2 Z.105 bugs) */
    SDLBitString impl(const SDLBitString& bs)const ;

    SDLBitString _not()const ;

    /** Realization of ASN.1 structured value notation */
    SDLBitString appendElem(SITE_SDL_INT atIndex);
    //@}

    /** delete the internal bitstring */
    virtual void assign_new();

    /**@name Helper methods for C++ manipulation. */
    //@{

    /** Set the bistring directly.
        @param str the bit field (will be copied)
        @param len the number of valid bits
    */
    void Set(char* str, SITE_SDL_INT len) ;

    /** Resize the bitstring (add 0 right) */
    void resize(SITE_SDL_INT new_len) ;

  private:
    /** Help method for constructed encoding. */
    void BDecConsBits (BUF_TYPE, AsnLen, AsnLen&) ;

    //@}
};

#endif
