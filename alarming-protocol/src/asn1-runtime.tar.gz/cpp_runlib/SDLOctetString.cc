/*******************************************************************************
*   vim:sw=2:ts=2:et
*
*   File    : SDLOctetString.cxx
*   Author  : Ralf Schr�der
*             Humboldt University Berlin
*             Department of Computer Science / System Analysis
*   e-mail  : r.schroeder@informatik.hu-berlin.de
*   Project : @vantage platform
*   $Date: 2005-05-05 17:38:41 +0200 (Thu, 05 May 2005) $
*   $Revision: 1.5 $
*
*******************************************************************************/
#include "SDLPredefined.h"
#include "SITELIB_implementSDLType_macro.h"

#include <ctype.h>

#ifdef SITE_RCS_IDENT
static const char* RCSID FRWUNUSED = "$Id: SDLOctetString.cc 554 2005-05-05 15:38:41Z tneumann $";
#else
static const char* SCCSID FRWUNUSED = "@(#) ";
#endif

char numToHexCharTblG[16] = {
  '0', '1', '2', '3', '4', '5', '6', '7',
  '8', '9', 'a', 'b', 'c', 'd' ,'e', 'f'
};


void
SDLOctetString::SDLOctetRef::operator=(const SDLOctet& o)
{
#ifdef SITE_LOG
  if (SDLType::_type_debug & SITE_ASSIGNMENT_LOG)
    std::cerr << "(SDLRTE) inline assignment of octet" << o <<
                 " to octetstring field" << endl;
#endif
  assert(_octet);
  *_octet = o.val();
}

SDLBitString::SDLBitRef
SDLOctetString::SDLOctetRef::operator()(SITE_SDL_INT index)
{
  if (index<0 || index>7) { throw SDLInvalidIndex(); }
  return SDLBitString::SDLBitRef(_octet,index);
}

SITELIB_implementSDLType(SDLOctetString,SDLType)

const SDLOctetString SDLOctetString::empty("H");

SDLOctetString::SDLOctetString(const SDLAny &a, AsnCodingSet rule_set) :
    _octs(0),_octetLen(0)
{
  a.decode(this, rule_set);
}

SDLOctetString::SDLOctetString(const char *str)
  :_octs(0),_octetLen(0)
{
  if (!str) {
    assert(0);
    return;
  }
  int len = strlen(str);
  if (!len) {
    // Ok the empty string (not really)
    _octs = new char[1];
    set_state(validValue);
    return;
  }

  len--;
  if (str[len]=='H' || str[len]=='h') {
    _octetLen = (len+1)/2;
    _octs = new char[TO_SIZE_T(_octetLen)];
    memset(_octs,0,TO_SIZE_T(_octetLen));
    for(int i=0;i<len;i++) {
      int val = HEX2INT(str[i]);
      if(i%2==0) val <<= 4;
      _octs[i/2]|=val;
    }
  } else if (str[len]=='B' || str[len]=='b') {
    _octetLen = (len+7)/8;
    _octs = new char[TO_SIZE_T(_octetLen)];
    memset(_octs,0,TO_SIZE_T(_octetLen));
    for(int i=0;i<len;i++) {
      if(str[i]=='1')
        _octs[i/8]|= (1<<(7-(i%8)));
      else if (str[i]!='0')
        assert(0);
    }
  } else {
    assert(0);
    return;
  }
  set_state(validValue);
}

SDLOctetString::SDLOctetString(const char *str,SITE_SDL_INT len):
  _octs((char*)str),_octetLen(len)
{
  set_state(SITEconstValue);
}

SDLOctetString::SDLOctetString(const SDLBitString& bs) :
  SDLType(bs),
  _octs(0),
  _octetLen((bs.Len()+7)/8)
{
  if (_octetLen) {
    _octs = new char[TO_SIZE_T(_octetLen)];
    char* bs_val = bs;
    memcpy(_octs,bs_val,TO_SIZE_T(_octetLen));
  }
}

SDLOctetString::SDLOctetString(const SDLCharstring& str) :
  SDLType(),
  _octs(0),
  _octetLen(str.lengthAsLong())
{
  if (_octetLen) {
    _octs = new char[TO_SIZE_T(str.lengthAsLong())];
    memcpy(_octs,(const char*)str,TO_SIZE_T(_octetLen));
  }
  set_state(validValue);
}

SDLOctetString::SDLOctetString(const SDLOctet& o) :
  SDLType(),
  _octs(new char[1]),
  _octetLen(1)
{
  char *byte = o;  // use SDLBitString::operator char*() const
  _octs[0] = o.Len()?byte[0]:0;
  set_state(validValue);
}

SDLOctetString::SDLOctetString(const SDLOctetString& str) :
  SDLType(str),_octs(0),_octetLen(str._octetLen)
{
#ifdef SITE_LOG
  if (SDLType::_type_debug & SITE_COPY_LOG)
    std::cerr << "(SDLRTE) octetstring " <<
            (state(SITEconstValue)?" reference ":"") <<
            "copy of value " << str << endl;
#endif
  if (str._octs) {
    if (state(SITEconstValue)) {
       _octs = str._octs;
    } else {
      _octs = new char[TO_SIZE_T(_octetLen)];
      memcpy(_octs,str._octs,TO_SIZE_T(_octetLen));
    }
  }
}

SDLOctetString::SDLOctetString(const SDLOctetString& str, SITE_SDL_INT reserve):
  _octs(0),_octetLen(str._octetLen)
{
#ifdef SITE_LOG
  if (SDLType::_type_debug & SITE_COPY_LOG)
    std::cerr << "(SDLRTE) octetstring copy of value "
              << str << " reserve " << reserve << endl;
#endif
  assert(reserve>=0);
  _octs = new char[TO_SIZE_T(_octetLen+reserve)];
  if (str._octs) {
    memcpy(_octs,str._octs,TO_SIZE_T(_octetLen));
  }
  memset(_octs+_octetLen,0,TO_SIZE_T(reserve));
  if (str.state(validValue)) set_state(validValue);
}

SDLOctetString::~SDLOctetString()
{
  if (!state(SITEconstValue)) delete [] _octs;
  _octs = 0;
  _octetLen = 0;
}

void
SDLOctetString::init_type()
{ LIT_H(); }

bool
SDLOctetString::valid()const
{ return state(validValue); }


AsnLen
SDLOctetString::bEnc(BUF_TYPE b) const
{
  AsnLen l = bEncContent(b);
  l += BEncDefLen(b,l);
  l += BEncTag1(b, UNIV, PRIM, OCTETSTRING_TAG_CODE);
  return l;
}

AsnLen
SDLOctetString::bEncContent(BUF_TYPE b) const
{
#ifdef SITE_LOG
  if (SDLType::_type_debug & SITE_BER_LOG)
    std::cerr << "encode octetstring value " << *this << endl;
#endif
  if (_octetLen) b.PutSegRvs(_octs, TO_SIZE_T(_octetLen));
  return(_octetLen);
}

void
SDLOctetString::bDec( BUF_TYPE b, AsnLen& bytesDecoded)
{
  AsnTag tagId = BDecTag1(b,bytesDecoded);
  if ((tagId != MAKE_TAG_ID(UNIV, PRIM, OCTETSTRING_TAG_CODE)) &&
      (tagId != MAKE_TAG_ID(UNIV, CONS, OCTETSTRING_TAG_CODE))) {
    TagError(MAKE_TAG_ID(UNIV,PRIM,OCTETSTRING_TAG_CODE),tagId); return;
  }
  AsnLen elmtLen = BDecLen(b,bytesDecoded);
  AsnLen localBytesDecoded = 0;
  bDecContent(b,tagId,elmtLen,localBytesDecoded);
  bytesDecoded += localBytesDecoded;
}

void SDLOctetString::bDecContent(BUF_TYPE b,AsnTag tagId,AsnLen elmtLen,
                                 AsnLen& bytesDecoded)
{
  if (state(SITEconstValue)) {
    _octs = 0; _octetLen = 0;
    set_state(~SITEconstValue);
    set_state(invalidValue);
  }
  /*
   * tagId is encoded tag shifted into long int.
   * if CONS bit is set then constructed octet string
   */
  if (tagId & 0x20000000)
    BDecConsOcts(b, elmtLen, bytesDecoded);

  else { /* primitive octet string */
    if (_octetLen<elmtLen || _octetLen > 2*elmtLen) {
      delete [] _octs;
      _octs =  new char[TO_SIZE_T(elmtLen)];
    }
    _octetLen = elmtLen;
    if (elmtLen) b.Copy(_octs, TO_SIZE_T(elmtLen));
    bytesDecoded += elmtLen;
  }
  set_state(validValue);
#ifdef SITE_LOG
  if (SDLType::_type_debug & SITE_BER_LOG)
    std::cerr << "decoded octetstring value " << *this << endl;
#endif
}

AsnLen
SDLOctetString::pEnc(BUF_TYPE2 b) const
{
  AsnLen elmtLen=pEncLen(b, _octetLen);
  AsnLen rem=_octetLen;
  AsnLen pos=0;
  int cur;
  while(rem>0){
    // compute size of next fragment
    cur = (rem<16384?rem: (rem>>14)<=4?(rem>>14)*16384: 4*16384);
    for(AsnLen max_pos=pos+cur;pos<max_pos;pos++)
      b.putByte(_octs[pos]);
    rem-=cur;
    elmtLen+=cur*8;
    // this is not the last fragment
    if(!(cur%16384))
      elmtLen+=pEncLen(b,rem);
  }
  return elmtLen;
}

void
SDLOctetString::pDec(BUF_TYPE2 b)
{
  int rem=pDecLen(b);
  delete [] _octs;
  _octs = NULL;
  _octetLen=0;
  if(!rem){
    set_state(validValue);
    return;
  }
  AsnLen pos=0;
  int next;
  ByteArray tmp, tmp2;
  while(rem>0){
    AsnLen max_pos=pos+rem;
    b.getBytes(rem, tmp2);
    // there will follow another (non empty) fragment
    if(!(rem%16384)&&(next=pDecLen(b))){
      tmp.resize(max_pos);
      // copy bytes from the encode buffer to the temp buffer
      for(int i=0;pos<max_pos;pos++,i++)
	      tmp[pos]=tmp2[i];
      rem=next;
    }
    // this is the last fragment
    else {
      _octs=new char[max_pos];
      if(!tmp.empty())
	      // copy bytes from the temp buffer to the _octs array
	      for(AsnLen i=0;i<pos;i++)
	        _octs[i]=tmp[i];
      // copy bytes from the encode buffer to the _octs array
      for(int i=0;pos<max_pos;pos++,i++)
	      _octs[pos]=tmp2[i];
      _octetLen=max_pos;
      rem=0;
    }
  }
  set_state(validValue);
}

SDLTypeId
SDLOctetString::sdl_type_id()const
{ return TypeId_SDLOctetString; }

void
SDLOctetString::Print(std::ostream& os)const
{
  if (!valid()){  os << "<invalid octetstring value>"; return; }
  SITE_SDL_INT i;
  os << "'";
  for(i=0; i<_octetLen; i++) {
    os << INT2HEX(_octs[i] >> 4) << (INT2HEX(_octs[i]));
    //if (!os.good()) SDLType::raise(new SDLLogLimitReached);
    // SunCC-bug, optimized code crashes the vtbl of the second
    // SDLLogLimitReached... see assembler output!
    if (!os.good()) break;
  }
  os << "'H  -- \"";

  // put printable parts in ASN.1 comment
  for(i=0; i<_octetLen; i++) {
    if (isspace(_octs[i]))
      os << " ";  // newlines->space (so don't screw up ASN.1 comment)
    else if (isprint(_octs[i]))
      os <<_octs[i];
    else
      os << ".";
    //if (!os.good()) SDLType::raise(new SDLLogLimitReached);
  }
  os << "\" --";
}

unsigned int
SDLOctetString::hash(unsigned int max_hash)const {
  unsigned int res=0;
  for(SITE_SDL_INT i=0;i<_octetLen;i++) res+=_octs[i];
  return res%max_hash;
}


SDLOctetString&
SDLOctetString::operator=(const SDLOctetString& str)
{
#ifdef SITE_LOG
  if (SDLType::_type_debug & SITE_ASSIGNMENT_LOG)
    std::cerr << "(SDLRTE) octetstring " <<
            (state(SITEconstValue)?" reference ":"") <<
            "assignment of " << str <<
            " to variable with value " << *this << endl;
#endif
  str.check_valid();
  if (this == &str) return *this;
  if (state(SITEconstValue)) set_state(~SITEconstValue);
  else delete [] _octs;
  _octs = 0;
  if (str._octs) {
    _octetLen = str._octetLen;
    if (str.state(SITEconstValue)) {
      _octs = str._octs;
      set_state(SITEconstValue);
      return *this;
    }
    _octs = new char[TO_SIZE_T(_octetLen)];
    memcpy(_octs,str._octs,TO_SIZE_T(_octetLen));
  } else {
    _octetLen = 0; _octs = 0;
  }
  set_state(validValue);
  return *this;
}

SDLOctetString::operator char*() const
{
  if (!_octs) return 0;
  if (state(SITEconstValue)) {
    SDLOctetString &t = SITE_CONST_CAST(SDLOctetString&,*this);
    char* tmp = new char[TO_SIZE_T(_octetLen)];
    memcpy(tmp,_octs,TO_SIZE_T(_octetLen));
    t._octs = tmp;
    t.set_state(~SITEconstValue);
  }
  return _octs;
}

const SDLBool&
SDLOctetString::eq(const SDLOctetString& os)const
{
  check_valid(); os.check_valid();
  if (_octetLen != os._octetLen) return SDLBool::SDLFalse();
  return (_octetLen==0 || memcmp(_octs,os._octs,TO_SIZE_T(_octetLen))==0) ?
         SDLBool::SDLTrue() : SDLBool::SDLFalse();
}

const SDLBool&
SDLOctetString::ne(const SDLOctetString& os)const
{
  check_valid(); os.check_valid();
  if (_octetLen != os._octetLen) return SDLBool::SDLTrue();
  return (_octetLen!=0 && memcmp(_octs,os._octs,TO_SIZE_T(_octetLen))!=0) ?
         SDLBool::SDLTrue() : SDLBool::SDLFalse();
}

bool
SDLOctetString::equal(const SDLType& type)const
{
  SDLOctetString os = SITE_DYNAMIC_CAST(const SDLOctetString&,type);
  if (_octetLen != os._octetLen) return false;
  return _octetLen==0 || memcmp(_octs,os._octs,TO_SIZE_T(_octetLen))==0;
}


SDLOctetString
SDLOctetString::cat(const SDLOctetString& os)const
{
  check_valid(); os.check_valid();
  SDLOctetString ret;
  ret._octetLen = _octetLen + os._octetLen;
  ret._octs = new char[TO_SIZE_T(ret._octetLen)];
  if (_octetLen)    memcpy(ret._octs,_octs,TO_SIZE_T(_octetLen));
  if (os._octetLen) memcpy(ret._octs+_octetLen,os._octs,TO_SIZE_T(os._octetLen));
  ret.set_state(validValue);
  return ret;
}

SDLInt
SDLOctetString::length()const
{ check_valid(); return _octetLen; }

SDLOctet
SDLOctetString::first()const
{
  check_valid();
  if (!_octetLen) { throw SDLInvalidIndex(); }
  return SDLOctet::int2octet(_octs[0]);
}

SDLOctet
SDLOctetString::last()const
{
  check_valid();
  if (!_octetLen) { throw SDLInvalidIndex(); }
  return SDLOctet::int2octet(_octs[_octetLen-1]);
}

const SDLOctet
SDLOctetString::operator[](SITE_SDL_INT index)const
{
  check_valid();
  if (index<1 || index>Len()) { throw SDLInvalidIndex(); }
  SDLOctet ret;
  ret.Set(_octs+index-1,8);
  return ret;
}

#if SITE_SDL_INT_SIZE==64
const SDLOctet
SDLOctetString::operator[](int index)const
{
  return (*this)[static_cast<SITE_SDL_INT>(index)];
}
#endif

SDLOctetString::SDLOctetRef
SDLOctetString::operator()(SITE_SDL_INT index)
{
  check_valid();
  if (index<1 || index>Len()) { throw SDLInvalidIndex(); }
  if (state(SITEconstValue)) {
    char* tmp = new char[TO_SIZE_T(_octetLen)];
    memcpy(tmp,_octs,TO_SIZE_T(_octetLen));
    _octs = tmp;
    set_state(~SITEconstValue);
  }
  set_state(validValue); // changes default value
  return SDLOctetRef(_octs+index-1);
}

SDLOctetString
SDLOctetString::substr(SITE_SDL_INT from,SITE_SDL_INT len)const
{
  check_valid();
  if (from<1 || _octetLen<from || len<0)
  { throw SDLInvalidIndex(); }
  // non SDL-2000
  if (from+len-1>_octetLen) {
    len = _octetLen-from+1;
  }
  if (!len) return SDLOctetString("",0);
  SDLOctetString ret;
  ret._octetLen = len;
  ret._octs = new char[TO_SIZE_T(len)];
  ret.set_state(validValue);
  memcpy(ret._octs,_octs+from-1,TO_SIZE_T(len));
  return ret;
}


SDLBitString
SDLOctetString::bitstring(const SDLOctetString& str)
{
  return SDLBitString(str);
}

SDLOctetString
SDLOctetString::octetstring(const SDLBitString& str)
{
  return SDLOctetString(str);
}

SDLOctetString
SDLOctetString::cut(SITE_SDL_INT index)const
{
  if (index<1 || index > _octetLen) { return *this; }
  if (_octetLen==1) return SDLOctetString("",0);
  SDLOctetString ret;
  ret._octetLen = _octetLen-1;
  ret._octs = new char[TO_SIZE_T(_octetLen)-1];
  ret.set_state(validValue);
  // index <= 0 implies return, if _octetLen==0 implies
  // _octetLen < index with return, consequently _octs is not 0
  memcpy(ret._octs,_octs,TO_SIZE_T(index-1));
  memcpy(ret._octs+index-1,_octs+index,TO_SIZE_T(_octetLen-index));
  return ret;
}

void
SDLOctetString::Set(const char *str,SITE_SDL_INT len)
{
  if (state(SITEconstValue)) set_state(~SITEconstValue);
  else delete [] _octs;
  _octs = 0;
  _octetLen = len;
  if (len) {
    _octs = new char[TO_SIZE_T(_octetLen)];
    assert(str);
    memcpy(_octs,str,TO_SIZE_T(_octetLen));
  }
  set_state(validValue);
}

char*
SDLOctetString::extend(SITE_SDL_INT len)
{
  char* new_octs = new char[TO_SIZE_T(_octetLen+len)];
  if (_octetLen) memcpy(new_octs,_octs,TO_SIZE_T(_octetLen));
  if (state(SITEconstValue)) set_state(~SITEconstValue);
  else delete[]_octs;
  _octs = new_octs;
  new_octs = _octs+_octetLen;
  _octetLen += len;
  return new_octs;
}

void
SDLOctetString::assign_new()
{
  if (state(SITEconstValue)) set_state(~SITEconstValue);
  else delete [] _octs;
  _octs = 0;
  _octetLen = 0;
  SDLType::assign_new();
}

char
SDLOctetString::octet(int index)const
{
  check_valid();
  if (index<1 || index>TO_INT32(Len())) { throw SDLInvalidIndex(); }
  return _octs[index-1];
}

void
SDLOctetString::Set(SITE_SDL_INT index, char c)
{
  // check for copy on write for octet string constants
  if (state(SITEconstValue)) {
    char *tmp = new char[TO_SIZE_T(_octetLen)];
    memcpy(tmp,_octs,TO_SIZE_T(_octetLen));
    _octs = tmp;
    set_state(~SITEconstValue);
  }
  _octs[index] = c;
}

char
SDLOctetString::Get(SITE_SDL_INT index) const
{
  return _octs[index];
}


void
SDLOctetString::BDecConsOcts (BUF_TYPE, AsnLen, AsnLen&)

{ throw SDLOperationNotImplemented("SDLOctetString::BDecConsOcts"); }
