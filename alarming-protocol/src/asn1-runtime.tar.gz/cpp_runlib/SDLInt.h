/*******************************************************************************
*   vim:sw=2:ts=2:et
*
*   File    : SDLInt.h
*   Author  : Ralf Schr�der
*             Humboldt University Berlin
*             Department of Computer Science / System Analysis
*   e-mail  : r.schroeder@informatik.hu-berlin.de
*   Project : @vantage platform
*   $Date: 2005-05-05 17:38:41 +0200 (Thu, 05 May 2005) $
*   $Revision: 1.2 $
*
*******************************************************************************/
#ifndef _SDLINT_H
#define _SDLINT_H

#include "sdlconfig.h"

#ifdef SITE_RCS_IDENT
static const char* SDLINT_RCSID FRWUNUSED = "$Id: SDLInt.h 554 2005-05-05 15:38:41Z tneumann $";
#else
static const char* SDLINT_SCCSID FRWUNUSED = "@(#) ";
#endif

#define C_INT SITE_SDL_INT
#define SDLNumber SDLInt
#define ID SDLIntNumber_ID
#include "SDLNumber.h"
#undef ID
#undef C_INT
#undef SDLNumber

#endif
