/*******************************************************************************
*   vim:sw=2:ts=2:et
*
*   File    : SDLReal.h
*   Author  : Ralf Schr�der and Martin von L�wis
*   Author  : Ralf Schr�der
*             Humboldt University Berlin
*             Department of Computer Science / System Analysis
*   e-mail  : r.schroeder@informatik.hu-berlin.de
*   Project : @vantage platform
*   $Date: 2005-05-05 17:38:41 +0200 (Thu, 05 May 2005) $
*   $Revision: 1.6 $
*
*******************************************************************************/
#ifndef _SDLREAL_H
#define _SDLREAL_H

#include "SDLType.h"

#ifdef SITE_RCS_IDENT
static const char* SDLREAL_RCSID FRWUNUSED = "$Id: SDLReal.h 554 2005-05-05 15:38:41Z tneumann $";
#else
static const char* SDLREAL_SCCSID FRWUNUSED = "@(#) ";
#endif

// forward declarations
class SDLBool;
class SDLInt;


/** SDL real numbers.
    The data type does not realize the exact rational numbers semantics of
    SDL. Instead the C++ type double with double operations is used. Hence
    there are rounding effects, which are not defined for SDL Real.
*/
class SDL_API SDLReal: public SDLType {

  protected:
    /** Hold the real value. */
    double _value;

  public:
    /* Call of generated macro for code shared by all declarations of SDL types
     */
    declareSDLType(SDLReal,SDLType)

    /** Constructor for an invalid value */
    SDLReal() :_value(0.0) {}

    /** Constructor for a given valid value */
    SDLReal(double r) :_value(r)
    { set_state(validValue); }

    /** Constructor for an ASN.1 value notation */
    SDLReal(SITE_SDL_INT mantissa,SITE_SDL_INT base,SITE_SDL_INT exp)
      ;

    /** Constructor for an omitted (invalid) value */
    SDLReal(const SDLNull&)  : SDLType(),_value(0.0) {}

    /** Copy constructor */
    SDLReal(const SDLReal& r) :SDLType(r),_value(r._value)
    {
#ifdef SITE_LOG
      if (SDLType::_type_debug & SITE_COPY_LOG)
        std::cerr << "(SDLRTE) real copy of value "
             << r << std::endl;
#endif
    }

    /** Clean up */
    virtual ~SDLReal();

    /** Valid check.
        @returns true, if the data object is a valid one.
        It can be configured to switch off this test.
    */
    virtual bool valid()const ;

    /** Encoding of a number with tag and length */
    virtual AsnLen bEnc(BUF_TYPE b) const;

    /** Encoding of a number without tag and length */
    virtual AsnLen bEncContent(BUF_TYPE) const;

    /** Decoding of a number with tag and length */
    virtual void bDec(BUF_TYPE b, AsnLen& bytesDecoded);

    /** Decoding of a number without tag and length */
    virtual void bDecContent(BUF_TYPE,AsnTag,AsnLen,AsnLen&);

    virtual AsnLen pEnc(BUF_TYPE2 b) const;
    virtual void pDec(BUF_TYPE2 b);

    /** Access to the kind of the object */
    virtual SDLTypeId sdl_type_id()const;

    /** Prints the number. */
    virtual void Print(std::ostream&)const;

    /** Returns a hash value. */
    virtual unsigned int hash(unsigned int max)const;

    /** Assignment operator for SDLReal */
    SDLReal& operator=(double r)
    {
#ifdef SITE_LOG
      if (SDLType::_type_debug & SITE_ASSIGNMENT_LOG)
        std::cerr << "(SDLRTE) primitive real assignment of " << r <<
                " to variable with value " << *this << std::endl;
#endif
      _value=r; set_state(validValue); return *this;
    }

    /** Assignment operator for SDLReal.
        avoids access check failure
    */
    SDLReal& operator=(const SDLReal& r)
    {
#ifdef SITE_LOG
      if (SDLType::_type_debug & SITE_ASSIGNMENT_LOG)
        std::cerr << "(SDLRTE) real assignment of " << r <<
                " to variable with value " << *this << std::endl;
#endif
      _value=r.val(); set_state(validValue); return *this;
    }

    /** Cast operator to C++ inline double */
    operator double() const
    { check_valid(); return _value; }

    /** Explicit value access. */
    double val()const { check_valid(); return _value; }

    /** Writes the represented value to the string stream. Does nothing if
	invalid. */
    void to_string(std::stringstream& buf);

    /** SDL equality. */
    //@{
    SDLBool eq(double r)const ;
    SDLBool ne(double r)const ;

    /** Compares real objects.
        @param r a real object
        The dynamic cast failure is not caught because the code is
        generated correctly.
    */
    bool equal(const SDLType& r) const ;

    //@}

    /** SDL standard operations */
    //@{
    SDLReal add(double r)const ;
    SDLReal sub(double r)const  ;
    SDLReal mul(double r)const ;
    SDLReal div(double r)const ;
    SDLReal rem(double r)const ;
    SDLReal mod(double r)const ;
    SDLReal neg()const ;

    void inc(double l) ;

    SDLBool lt(double l)const ;
    SDLBool gt(double l)const ;
    SDLBool le(double l)const ;
    SDLBool ge(double l)const ;

    static SDLReal power(SITE_SDL_INT base, SITE_SDL_INT expo);
    SDLInt fix()const ;

    //@}
};

extern const SDLReal PLUS_INFINITY;
extern const SDLReal MINUS_INFINITY;

#endif
