/* ===== SDLPredefined.cxx ===== */

#include "SDLPredefined.h"

//#include "version.h"
//
//#include "SDLPredefined.h"
//#define OPTIONS_RANGE_SHIFT 0LL
//int SDLPredefined147597_has_been_changed=0;
//
//static void check_package_versions()
//{
//}
//
//SDLPredefined::SDLPredefined (const char * myname) :
//SDLPackage(myname)
//{
//    SDL_LIB_3_28=1;
//    SITE_CONSISTENCY_CHECK;
//    _non_standard_compilation_option = " --case-sensitive";
//} /* SDLPredefined::SDLPredefined */
//
//void SDLPredefined::init()
//{
//    SDLPackage::init();
//    SDLNat::create()->init_type();
//    SDLIA5String::create()->init_type();
//    SDLNumericString::create()->init_type();
//    SDLPrintableString::create()->init_type();
//    SDLTeletexString::create()->init_type();
//    SDLT61String::create()->init_type();
//    SDLVideotexString::create()->init_type();
//    SDLVisibleString::create()->init_type();
//    SDLISO646String::create()->init_type();
//    SDLGraphicString::create()->init_type();
//    SDLGeneralString::create()->init_type();
//    SDLGeneralizedTime::create()->init_type();
//    SDLUTCTime::create()->init_type();
//    SDLObjectDescriptor::create()->init_type();
//}/* SDLPredefined:: init */
//
//SDLPredefined::~SDLPredefined()
//{
//} /* SDLPredefined::~SDLPredefined */
//
//SDLPredefined*
//SDLPredefined::Instance()
//{
//    static SDLPredefined * _instance = new SDLPredefined("SDLPredefined");
//    return _instance;
//} /* SDLPredefined::Instance */
//
//bool SDLPredefined::datainfo(long index,
//        SDLIA5String& var_name,SDLIA5String& var_type,SDLType*& var){
//
//    switch(index) {
//        default: return SDLPackage::datainfo(index-0,var_name,var_type,var);
//    }
//    return true;
//} /* SDLPredefined::datainfo */
