/*******************************************************************************
*
*   File    : SDLBaseImpl.h
*   Author  : Frank Bielig, Toby Neumann
*             Humboldt University Berlin
*             Department of Computer Science / System Analysis
*   e-mail  : tneumann@informatik.hu-berlin.de
*   Project : SITE4Cinderella
*   $Date: 2005-06-29 10:23:35 +0200 (ons, 29 jun 2005) $
*   $Revision: 584 $
*
*******************************************************************************/
#ifndef _SDL_BASE_IMPL_H
#define _SDL_BASE_IMPL_H

#include <stdio.h>
#include <iostream>
#include <iosfwd>
#include <list>
#include <limits>
#include <assert.h>
#include "sdlconfig.h"


//XXX change 1: BER 2:PER_UNALIGNED_BASIC
enum AsnCodingSet {asn_ber, asn_per};

//XXX give detailed description of this byte definition part!
typedef SITE_SDL_UINT Bytes;
typedef unsigned char Byte;

/* to avoid the warning we assume Byte to be unsigned and use the shortcut */
#ifdef SIGNED_BYTE
// Byte is a conceptionally unsigned type
template <bool is_signed>
class BitAssign;

template<>
class BitAssign<false>
{
public:
  Bytes operator()(Byte b) { return b; }
};


template<>
class BitAssign<true>
{
public:
  Bytes operator()(Byte b)
  {
    if (b < 0) {
      return b + (- std::numeric_limits<Byte>::min()
	      + std::numeric_limits<Byte>::max() +1);
    }
    else
      return b;
  }
};

extern BitAssign<std::numeric_limits<Byte>::is_signed> cast_from_unsigned;
#else
Bytes cast_from_unsigned(Byte b);
#endif

/** Length of temporary message buffer used in case of errors */
#define SDL_MSG_LENGTH	1024

/* the coding to be used for signals when communicating with the environment */
extern AsnCodingSet		       asn_coding;

struct SDLError
{
  std::string message;

  SDLError();
  SDLError(std::string msg);
  virtual ~SDLError();
};

#define SDLCodingError    SDLError
#define SDLInvalidIndex   SDLError
#define SDLOperationNotImplemented SDLError
#define SDLUndefinedVariable SDLError
#define SDLDivisionByZero SDLError
#define SDLOutOfRange SDLError
#define SDLUndefinedField SDLError
#define SDLAssert         SDLError

#define package_init(package)

#endif /* _SDL_BASE_IMPL_H */
