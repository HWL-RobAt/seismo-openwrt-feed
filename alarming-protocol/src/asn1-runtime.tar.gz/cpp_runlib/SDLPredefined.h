/* ===== SDLPredefined.h ===== */

#ifndef SDLPredefined_H
#define SDLPredefined_H
#include "sdlconfig.h"
#include "predefined.h"
#include "SDLType.h"
//#include <sdltimer.h>

class SDLNat;
class SDLIA5String;
class SDLNumericString;
class SDLPrintableString;
class SDLTeletexString;
class SDLT61String;
class SDLVideotexString;
class SDLVisibleString;
class SDLISO646String;
class SDLGraphicString;
class SDLGeneralString;
class SDLGeneralizedTime;
class SDLUTCTime;
class SDLObjectDescriptor;

class SDLNat: public SDLInt {
public:
    SDLNat(const SDLAny&, AsnCodingSet rule_set=asn_ber);
    virtual const char* name() const { return "SDLNat"; }
    virtual SDLType* copy()const;
    virtual void assign(const SDLType* t);
    static SDLType* create();
    virtual const SDLType* create_new() const;
    static const SDLNat& convert(const SDLNat&t) { return t; };
    
public:
    SDLNat(SITE_SDL_INT l):SDLInt(l){}
    SDLNat(){}
    SDLNat(const SDLNull& n):SDLInt(n){}
    SDLNat(const SDLInt& base):SDLInt(base){}
    const SDLBool& check() const;
};

class SDLIA5String: public SDLCharstring {
public:
    SDLIA5String(const SDLAny&, AsnCodingSet rule_set=asn_ber);
    virtual const char* name() const { return "SDLIA5String"; }
    virtual SDLType* copy()const;
    virtual void assign(const SDLType* t);
    static SDLType* create();
    virtual const SDLType* create_new() const;
    static const SDLIA5String& convert(const SDLIA5String&t) { return t; };
    
public:
    SDLIA5String(const char *str,SITE_SDL_INT size = -1,bool no_copy=false):SDLCharstring(str,size,no_copy){}
    SDLIA5String(){}
    SDLIA5String(const SDLNull& n):SDLCharstring(n){}
    SDLIA5String(const SDLCharstring& base):SDLCharstring(base){}
    AsnLen bEnc(BUF_TYPE) const;
    void bDec(BUF_TYPE,AsnLen&);
};

class SDLNumericString: public SDLCharstring {
public:
    SDLNumericString(const SDLAny&, AsnCodingSet rule_set=asn_ber);
    virtual const char* name() const { return "SDLNumericString"; }
    virtual SDLType* copy()const;
    virtual void assign(const SDLType* t);
    static SDLType* create();
    virtual const SDLType* create_new() const;
    static const SDLNumericString& convert(const SDLNumericString&t) { return t; };
    
public:
    SDLNumericString(const char *str,SITE_SDL_INT size = -1,bool no_copy=false):SDLCharstring(str,size,no_copy){}
    SDLNumericString(){}
    SDLNumericString(const SDLNull& n):SDLCharstring(n){}
    SDLNumericString(const SDLCharstring& base):SDLCharstring(base){}
    AsnLen bEnc(BUF_TYPE) const;
    void bDec(BUF_TYPE,AsnLen&);
};

class SDLPrintableString: public SDLCharstring {
public:
    SDLPrintableString(const SDLAny&, AsnCodingSet rule_set=asn_ber);
    virtual const char* name() const { return "SDLPrintableString"; }
    virtual SDLType* copy()const;
    virtual void assign(const SDLType* t);
    static SDLType* create();
    virtual const SDLType* create_new() const;
    static const SDLPrintableString& convert(const SDLPrintableString&t) { return t; };
    
public:
    SDLPrintableString(const char *str,SITE_SDL_INT size = -1,bool no_copy=false):SDLCharstring(str,size,no_copy){}
    SDLPrintableString(){}
    SDLPrintableString(const SDLNull& n):SDLCharstring(n){}
    SDLPrintableString(const SDLCharstring& base):SDLCharstring(base){}
    AsnLen bEnc(BUF_TYPE) const;
    void bDec(BUF_TYPE,AsnLen&);
};

class SDLTeletexString: public SDLCharstring {
public:
    SDLTeletexString(const SDLAny&, AsnCodingSet rule_set=asn_ber);
    virtual const char* name() const { return "SDLTeletexString"; }
    virtual SDLType* copy()const;
    virtual void assign(const SDLType* t);
    static SDLType* create();
    virtual const SDLType* create_new() const;
    static const SDLTeletexString& convert(const SDLTeletexString&t) { return t; };
    
public:
    SDLTeletexString(const char *str,SITE_SDL_INT size = -1,bool no_copy=false):SDLCharstring(str,size,no_copy){}
    SDLTeletexString(){}
    SDLTeletexString(const SDLNull& n):SDLCharstring(n){}
    SDLTeletexString(const SDLCharstring& base):SDLCharstring(base){}
    AsnLen bEnc(BUF_TYPE) const;
    void bDec(BUF_TYPE,AsnLen&);
};

class SDLT61String: public SDLCharstring {
public:
    SDLT61String(const SDLAny&, AsnCodingSet rule_set=asn_ber);
    virtual const char* name() const { return "SDLT61String"; }
    virtual SDLType* copy()const;
    virtual void assign(const SDLType* t);
    static SDLType* create();
    virtual const SDLType* create_new() const;
    static const SDLT61String& convert(const SDLT61String&t) { return t; };
    
public:
    SDLT61String(const char *str,SITE_SDL_INT size = -1,bool no_copy=false):SDLCharstring(str,size,no_copy){}
    SDLT61String(){}
    SDLT61String(const SDLNull& n):SDLCharstring(n){}
    SDLT61String(const SDLCharstring& base):SDLCharstring(base){}
    AsnLen bEnc(BUF_TYPE) const;
    void bDec(BUF_TYPE,AsnLen&);
};

class SDLVideotexString: public SDLCharstring {
public:
    SDLVideotexString(const SDLAny&, AsnCodingSet rule_set=asn_ber);
    virtual const char* name() const { return "SDLVideotexString"; }
    virtual SDLType* copy()const;
    virtual void assign(const SDLType* t);
    static SDLType* create();
    virtual const SDLType* create_new() const;
    static const SDLVideotexString& convert(const SDLVideotexString&t) { return t; };
    
public:
    SDLVideotexString(const char *str,SITE_SDL_INT size = -1,bool no_copy=false):SDLCharstring(str,size,no_copy){}
    SDLVideotexString(){}
    SDLVideotexString(const SDLNull& n):SDLCharstring(n){}
    SDLVideotexString(const SDLCharstring& base):SDLCharstring(base){}
    AsnLen bEnc(BUF_TYPE) const;
    void bDec(BUF_TYPE,AsnLen&);
};

class SDLVisibleString: public SDLCharstring {
public:
    SDLVisibleString(const SDLAny&, AsnCodingSet rule_set=asn_ber);
    virtual const char* name() const { return "SDLVisibleString"; }
    virtual SDLType* copy()const;
    virtual void assign(const SDLType* t);
    static SDLType* create();
    virtual const SDLType* create_new() const;
    static const SDLVisibleString& convert(const SDLVisibleString&t) { return t; };
    
public:
    SDLVisibleString(const char *str,SITE_SDL_INT size = -1,bool no_copy=false):SDLCharstring(str,size,no_copy){}
    SDLVisibleString(){}
    SDLVisibleString(const SDLNull& n):SDLCharstring(n){}
    SDLVisibleString(const SDLCharstring& base):SDLCharstring(base){}
    AsnLen bEnc(BUF_TYPE) const;
    void bDec(BUF_TYPE,AsnLen&);
};

class SDLISO646String: public SDLCharstring {
public:
    SDLISO646String(const SDLAny&, AsnCodingSet rule_set=asn_ber);
    virtual const char* name() const { return "SDLISO646String"; }
    virtual SDLType* copy()const;
    virtual void assign(const SDLType* t);
    static SDLType* create();
    virtual const SDLType* create_new() const;
    static const SDLISO646String& convert(const SDLISO646String&t) { return t; };
    
public:
    SDLISO646String(const char *str,SITE_SDL_INT size = -1,bool no_copy=false):SDLCharstring(str,size,no_copy){}
    SDLISO646String(){}
    SDLISO646String(const SDLNull& n):SDLCharstring(n){}
    SDLISO646String(const SDLCharstring& base):SDLCharstring(base){}
    AsnLen bEnc(BUF_TYPE) const;
    void bDec(BUF_TYPE,AsnLen&);
};

class SDLGraphicString: public SDLCharstring {
public:
    SDLGraphicString(const SDLAny&, AsnCodingSet rule_set=asn_ber);
    virtual const char* name() const { return "SDLGraphicString"; }
    virtual SDLType* copy()const;
    virtual void assign(const SDLType* t);
    static SDLType* create();
    virtual const SDLType* create_new() const;
    static const SDLGraphicString& convert(const SDLGraphicString&t) { return t; };
    
public:
    SDLGraphicString(const char *str,SITE_SDL_INT size = -1,bool no_copy=false):SDLCharstring(str,size,no_copy){}
    SDLGraphicString(){}
    SDLGraphicString(const SDLNull& n):SDLCharstring(n){}
    SDLGraphicString(const SDLCharstring& base):SDLCharstring(base){}
    AsnLen bEnc(BUF_TYPE) const;
    void bDec(BUF_TYPE,AsnLen&);
};

class SDLGeneralString: public SDLCharstring {
public:
    SDLGeneralString(const SDLAny&, AsnCodingSet rule_set=asn_ber);
    virtual const char* name() const { return "SDLGeneralString"; }
    virtual SDLType* copy()const;
    virtual void assign(const SDLType* t);
    static SDLType* create();
    virtual const SDLType* create_new() const;
    static const SDLGeneralString& convert(const SDLGeneralString&t) { return t; };
    
public:
    SDLGeneralString(const char *str,SITE_SDL_INT size = -1,bool no_copy=false):SDLCharstring(str,size,no_copy){}
    SDLGeneralString(){}
    SDLGeneralString(const SDLNull& n):SDLCharstring(n){}
    SDLGeneralString(const SDLCharstring& base):SDLCharstring(base){}
    AsnLen bEnc(BUF_TYPE) const;
    void bDec(BUF_TYPE,AsnLen&);
};

class SDLGeneralizedTime: public SDLVisibleString {
public:
    SDLGeneralizedTime(const SDLAny&, AsnCodingSet rule_set=asn_ber);
    virtual const char* name() const { return "SDLGeneralizedTime"; }
    virtual SDLType* copy()const;
    virtual void assign(const SDLType* t);
    static SDLType* create();
    virtual const SDLType* create_new() const;
    static const SDLGeneralizedTime& convert(const SDLGeneralizedTime&t) { return t; };
    
public:
    SDLGeneralizedTime(const char *str,SITE_SDL_INT size = -1,bool no_copy=false):SDLVisibleString(str,size,no_copy){}
    SDLGeneralizedTime(){}
    SDLGeneralizedTime(const SDLNull& n):SDLVisibleString(n){}
    SDLGeneralizedTime(const SDLCharstring& base):SDLVisibleString(base){}
    AsnLen bEnc(BUF_TYPE) const;
    void bDec(BUF_TYPE,AsnLen&);
};

class SDLUTCTime: public SDLVisibleString {
public:
    SDLUTCTime(const SDLAny&, AsnCodingSet rule_set=asn_ber);
    virtual const char* name() const { return "SDLUTCTime"; }
    virtual SDLType* copy()const;
    virtual void assign(const SDLType* t);
    static SDLType* create();
    virtual const SDLType* create_new() const;
    static const SDLUTCTime& convert(const SDLUTCTime&t) { return t; };
    
public:
    SDLUTCTime(const char *str,SITE_SDL_INT size = -1,bool no_copy=false):SDLVisibleString(str,size,no_copy){}
    SDLUTCTime(){}
    SDLUTCTime(const SDLNull& n):SDLVisibleString(n){}
    SDLUTCTime(const SDLCharstring& base):SDLVisibleString(base){}
    AsnLen bEnc(BUF_TYPE) const;
    void bDec(BUF_TYPE,AsnLen&);
};

class SDLObjectDescriptor: public SDLGraphicString {
public:
    SDLObjectDescriptor(const SDLAny&, AsnCodingSet rule_set=asn_ber);
    virtual const char* name() const { return "SDLObjectDescriptor"; }
    virtual SDLType* copy()const;
    virtual void assign(const SDLType* t);
    static SDLType* create();
    virtual const SDLType* create_new() const;
    static const SDLObjectDescriptor& convert(const SDLObjectDescriptor&t) { return t; };
    
public:
    SDLObjectDescriptor(const char *str,SITE_SDL_INT size = -1,bool no_copy=false):SDLGraphicString(str,size,no_copy){}
    SDLObjectDescriptor(){}
    SDLObjectDescriptor(const SDLNull& n):SDLGraphicString(n){}
    SDLObjectDescriptor(const SDLCharstring& base):SDLGraphicString(base){}
    AsnLen bEnc(BUF_TYPE) const;
    void bDec(BUF_TYPE,AsnLen&);
};

//#include <sdlpackage.h>
//#include <sdlblock.h>
//#include <sdlchannel.h>
//#include <sdlshell.h>
//
//extern int SDLPredefined147597_has_been_changed;
//
//class SDLPredefined : public SDLPackage 
//{
//    declareSDLPackage(SDLPredefined)
//    SDLPredefined(const char *);
//public:
//    void init();
//    ~SDLPredefined();
//    static SDLPredefined* Instance();
//    bool datainfo(long,class SDLIA5String&,SDLIA5String&,SDLType*&);
//}; /* SDLPredefined */

//#define MY_SDLPredefined (SDLPredefined::Instance())

#endif
