/*******************************************************************************
*   vim:sw=2:ts=2:et
*
*   File    : SDLNullType.cxx
*   Author  : Ralf Schr�der
*             Humboldt University Berlin
*             Department of Computer Science / System Analysis
*   e-mail  : r.schroeder@informatik.hu-berlin.de
*   Project : @vantage platform
*   $Date: 2005-05-05 17:38:41 +0200 (Thu, 05 May 2005) $
*   $Revision: 1.3 $
*
*******************************************************************************/
#include "SDLNullType.h"
#include "SDLBool.h"
#include "SDLAny.h"
#include "BasicEncoding.h"
#include "SITELIB_implementSDLType_macro.h"
#include "implementSDLType_macro.h"

#ifdef SITE_RCS_IDENT
static const char* RCSID FRWUNUSED = "$Id: SDLNullType.cc 554 2005-05-05 15:38:41Z tneumann $";
#else
static const char* SCCSID FRWUNUSED = "@(#) ";
#endif

implementSDLType(SDLNullType,SDLType)

const SDLNullType SDLNullType::the_null(0);

bool
SDLNullType::equal(const SDLType& b) const
{
  return true;
}

bool
SDLNullType::valid()const
{ return state(validValue); }


AsnLen
SDLNullType::bEnc(BUF_TYPE b) const
{
#ifdef SITE_LOG
  if (SDLType::_type_debug & SITE_BER_LOG)
    std::cerr << "encode Null value " << *this << std::endl;
#endif
  // after C++ optimization this are 2 put byte ops
  BEncDefLenTo127(b,0);
  AsnLen len = BEncTag1(b, UNIV, PRIM, NULLTYPE_TAG_CODE);
  return len+1;
}

AsnLen
SDLNullType::bEncContent(BUF_TYPE) const
{
#ifdef SITE_LOG
  if (SDLType::_type_debug & SITE_BER_LOG)
    std::cerr << "encode Null value " << *this << std::endl;
#endif
  return 0;
}

void
SDLNullType::bDec( BUF_TYPE b, AsnLen& bytesDecoded)

{
    AsnTag tagId = BDecTag1(b,bytesDecoded);
    if (tagId != MAKE_TAG_ID(UNIV,PRIM,NULLTYPE_TAG_CODE)) {
      TagError(MAKE_TAG_ID(UNIV,PRIM,NULLTYPE_TAG_CODE),tagId); return;
    }
    if (b.GetByte()) {
      throw ASNLengthException("SDLNullType::bDec NULL decoding with length");
    }
    bytesDecoded += 1;
    set_state(validValue);
#ifdef SITE_LOG
  if (SDLType::_type_debug & SITE_BER_LOG)
    std::cerr << "decoded Null value " << *this << std::endl;
#endif
}

void SDLNullType::bDecContent(BUF_TYPE, AsnTag, AsnLen elmtLen,AsnLen&)
{
  if (elmtLen != 0) {
    set_state(invalidValue);
    throw ASNLengthException("SDLNullType::bDecContent NULL decoding with length");
  }
  set_state(validValue);
#ifdef SITE_LOG
  if (SDLType::_type_debug & SITE_BER_LOG)
    std::cerr << "decoded Null value " << *this << std::endl;
#endif
}

SDLTypeId
SDLNullType::sdl_type_id()const
{ return TypeId_SDLNull; }

void
SDLNullType::Print(std::ostream& os)const
{
  if (valid()) os << "NULL";
  else os << "<invalid NULL value>";
}


SDLBool
SDLNullType::eq(const SDLNullType& n)const
{ check_valid(); n.check_valid(); return true; }

SDLBool
SDLNullType::ne(const SDLNullType& n)const
{ check_valid(); n.check_valid(); return false; }
