/*******************************************************************************
*   vim:sw=2:ts=2:et
*
*   File    : SDLSetof.h
*   Author  : Ralf Schr�der and Martin von L�wis
*             Humboldt University Berlin
*             Department of Computer Science / System Analysis
*   e-mail  : r.schroeder@informatik.hu-berlin.de
*   Project : @vantage platform
*   $Date: 2005-05-05 17:38:41 +0200 (Thu, 05 May 2005) $
*   $Revision: 1.2 $
*
*******************************************************************************/
#ifndef _SDLBAG_H
#define _SDLBAG_H

#include "SDLString.h"

#ifdef SITE_RCS_IDENT
static const char* SDLSETOF_RCSID FRWUNUSED = "$Id: SDLSetof.h 554 2005-05-05 15:38:41Z tneumann $";
#else
static const char* SDLSETOF_SCCSID FRWUNUSED = "@(#) ";
#endif


/** Generic Bag implementation for SET OF.
    @param BAG the name of the first derived class (better performance)
    @param ELEM the name of the set element class
*/
class SDLSetofBase: public SDLStringBase
{

  public:
    /** Constructor for an empty set */
    SDLSetofBase() {}

    /** Constructor for an omitted (invalid) value */
    SDLSetofBase(const SDLNull& n) :
      SDLStringBase(n) {}

    /** Base constructor */
    SDLSetofBase(const SDLStringBase&s)  :
      SDLStringBase(s) {}

    /** Copy constructor */
    SDLSetofBase(const SDLSetofBase& str) : SDLStringBase(str) {}

    /** ELEM constructor */
    SDLSetofBase(const SDLType& elem, SITE_SDL_INT size = 1) :
      SDLStringBase(elem,size) {}

  protected:
    /** Copy constructor with resize*/
    SDLSetofBase(const SDLSetofBase& str,SITE_SDL_INT reserve) :
      SDLStringBase(str,reserve) {}

  public:
    /** Encode for SET OF ELEM */
    virtual AsnLen bEnc(BUF_TYPE b) const;

    /** Decoding for SET OF ELEM */
    virtual void bDec(BUF_TYPE b, AsnLen& bytesDecoded);

    /** Access to the kind of the object */
    virtual SDLTypeId sdl_type_id()const;

    /** Prints the string. */
    virtual void Print(std::ostream&)const;

    /** SDL equality. */
    //@{
    /** SDL equality. Non covariant signature avoids warnings */
    const SDLBool& eq(const SDLStringBase& bag)const;
    /** SDL non-equality. Non covariant signature avoids warnings */
    const SDLBool& ne(const SDLStringBase& bag)const;

    /** Compares string objects.
        @param str a set object
        The dynamic cast failure is not caught because the code is
        generated correctly.
    */
    bool equal(const SDLType& b) const;
    //@}

    /** SDL operations */
    //@{
    /** method Incl */
    void _incl(const SDLType& e);

    /** method Del */
    void _del(const SDLType& e);

    /** operator Take */
    const SDLType& _take();

    /** operator "in" */
    const SDLBool& in(const SDLType& str) const;

    const SDLBool& lt(const SDLSetofBase& b)const;
    const SDLBool& gt(const SDLSetofBase& b)const;
    const SDLBool& le(const SDLSetofBase& b)const;
    const SDLBool& ge(const SDLSetofBase& b)const;

    /** method "and" (intersection) */
    void _and2(const SDLSetofBase& b1,const SDLSetofBase& b2);
    //@}
};

#include "SDLSetofTemplate.h"

/**@name Bag macros */
//@{

/** Base class name for Bag */
#define BagTemplate(BAG,ELEM) \
  SDLSetof<BAG,ELEM>

/** Constructors for Bags */
#define BagTemplateConstruction(BAG,ELEM,ELEM_PROTO) \
public:\
  BAG(){ set_state(validValue); }\
  BAG(const super& base):super(base){}\
  BAG(const BAG& base,SITE_SDL_INT reserve):super(base,reserve){}\
  BAG(const SDLNull& n):super(n){}\
  BAG(const ELEM& elem):super(elem){}\
  static const BAG& LIT_Empty() { static BAG b; return b; } \
  BAG& operator=(const BAG&bag) {\
    return SITE_STATIC_CAST(BAG&,super::operator=(bag));\
  }\
  void init_type() { super::init_type(); LIT_Empty(); delete create_elem(); }

/** Constructors for Bags with init call */
#define BagTemplateConstructionInit(BAG,ELEM,ELEM_PROTO) \
public:\
  BAG(){ init(); set_state(validValue); }\
  BAG(const super& base):super(base){ init(); }\
  BAG(const BAG& base,SITE_SDL_INT reserve):super(base,reserve){}\
  BAG(const SDLNull& n):super(n){ init(); }\
  BAG(const ELEM& elem):super(elem){ init(); }\

/** no special implementations for Bags */
#define BagTemplateDeclaration(BAG,ELEM,ELEM_PROTO) \
  declareSDLType(BAG,super)\
  ELEM* create_elem() const;

#include "SITELIB_implementSDLType_macro.h"
#include "implementSDLType_macro.h"
#define BagTemplateImplementation(BAG,ELEM,ELEM_PROTO) \
 implementSDLType(BAG,BAG::super)\
 ELEM* BAG::create_elem() const{\
   static ELEM *e = ELEM_PROTO;\
   return SITE_STATIC_CAST(ELEM*,e->copy());\
 }

//@}

#endif
