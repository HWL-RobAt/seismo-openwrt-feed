/*******************************************************************************
*   File    : SDLChar.h
*   Author  : Martin von L�wis, Ralf Schr�der
*             Humboldt University Berlin
*             Department of Computer Science / System Analysis
*   e-mail  : loewis@informatik.hu-berlin.de
*   Projekt : VESUV
*   Date    : Mon Feb 10 18:40:22 1997
*   Version : 1.0
*   Remark  :
*   History :
*
*******************************************************************************/
#ifndef _SDLCHAR_H
#define _SDLCHAR_H

#include "SDLType.h"

#ifdef SITE_RCS_IDENT
static const char* SDLCHAR_RCSID FRWUNUSED = "$Id: SDLChar.h,v 1.4 2003/08/22 16:07:01 tneumann Exp $";
#else
static const char* SDLCHAR_SCCSID FRWUNUSED = "@(#) ";
#endif

//forward declarations
class SDLBool;
class SDLInt;
class SDLAny;

/** SDL Characters (range 0..127, the 8th bit will be cutted).
    The provided encoding should only be used for context safe/restore.
*/
class SDL_API SDLChar: public SDLType {
    /** holds a character less than 128 */
    char _value;

  public:
    /* Call of generated macro for code shared by all declarations of SDL types
     */
    declareSDLType(SDLChar,SDLType)

    /** Constructor for an invalid character */
    SDLChar() :_value(0){}

    /** Constructor for an omitted (invalid) value */
    SDLChar(const SDLNull&) :_value(0){}

    /** Copy constructor */
    SDLChar(const SDLChar& c);

    /** Constructor for a given valid value */
    SDLChar(char c) :_value(c&0x7f)
    { set_state(validValue); }

    /** Constructor for a given valid value
        @param str must be string of length 1
        @exception SDLUndefinedValue if str is 0 or str[1]!=0
    */
    SDLChar(const char* str) ;

    /** Encoding as IA5String */
    AsnLen bEnc(BUF_TYPE) const;

    /** Encoding of the string value without tag and length */
    virtual AsnLen bEncContent(BUF_TYPE) const;

    /** Decoding as IA5String */
    void bDec(BUF_TYPE,AsnLen&);

    /** Decoding of the string value without tag and length */
    virtual void bDecContent(BUF_TYPE,AsnTag,AsnLen,AsnLen&);


    /** Valid check.
        @return true, if the data object is a valid one.
        It can be configured to switch off this test.
    */
    virtual bool valid()const ;

    /** Access to the kind of the object */
    virtual SDLTypeId sdl_type_id()const ;

    /** Prints the character. */
    virtual void Print(std::ostream&)const ;

    /** Writes the represented value to the string stream. Does nothing if
	invalid. */
    void to_string(std::stringstream& buf);

    /** Returns a hash value */
    virtual unsigned int hash(unsigned int max_hash)const
    { return _value%max_hash; }

    /** Assignment operator for SDL characters */
    SDLChar& operator=(char c) ;

    /** Assignment operator for SDL characters */
    SDLChar& operator=(const SDLChar& c);

    /** Cast operator to C++ inline char */
    operator char() const
    { return val(); }

    /** Explicit value access. */
    char val()const
    { check_valid(); return _value; }

    /** SDL equality. */
    //@{
    const SDLBool& eq(const char c)const ;
    const SDLBool& ne(const char c)const ;

    /** Compares char objects.
        @param b a char object
        The dynamic cast failure is not caught because the code is
        generated correctly.
    */
    bool equal(const SDLType& c) const ;
    //@}


    /** SDL standard operations */
    //@{
    SDLInt Num()const ;

    const SDLBool& lt(const char c)const ;
    const SDLBool& gt(const char c)const ;
    const SDLBool& le(const char c)const ;
    const SDLBool& ge(const char c)const ;
    //@}

    /** Character literals.
        The literals are created on access because of rare usage.
    */
    //@{
#define CLIT(x,v)  static SDLChar LIT_##x(){return SDLChar((char)v);}
      CLIT(NUL,0);
      CLIT(SOH,1);
      CLIT(STX,2);
      CLIT(ETX,3);
      CLIT(EOT,3);
      CLIT(ENQ,5);
      CLIT(ACK,6);
      CLIT(BEL,7);
      CLIT(BS,8);
      CLIT(HT,9);
      CLIT(LF,10);
      CLIT(VT,11);
      CLIT(FF,12);
      CLIT(CR,13);
      CLIT(SO,14);
      CLIT(SI,15);
      CLIT(DLE,16);
      CLIT(DC1,17);
      CLIT(DC2,18);
      CLIT(DC3,19);
      CLIT(DC4,20);
      CLIT(NAK,21);
      CLIT(SYN,22);
      CLIT(ETB,23);
      CLIT(CAN,24);
      CLIT(EM,25);
      CLIT(SUB,26);
      CLIT(ESC,27);
      CLIT(IS4,28);
      CLIT(IS3,29);
      CLIT(IS2,30);
      CLIT(IS1,31);
      CLIT(DEL,127);
#undef CLIT
};

#endif
