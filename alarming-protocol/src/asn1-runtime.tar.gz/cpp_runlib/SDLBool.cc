/*******************************************************************************
*   vim:sw=2:ts=2:et
*
*   File    : SDLBool.cxx
*   Author  : Ralf Schr�der
*             Humboldt University Berlin
*             Department of Computer Science / System Analysis
*   e-mail  : r.schroeder@informatik.hu-berlin.de
*   Project : @vantage platform
*   $Date: 2005-05-05 17:38:41 +0200 (Thu, 05 May 2005) $
*   $Revision: 1.5 $
*
*******************************************************************************/
#include "SDLPredefined.h"
#include "SITELIB_implementSDLType_macro.h"
#include "implementSDLType_macro.h"

#ifdef SITE_RCS_IDENT
static const char* RCSID FRWUNUSED = "$Id: SDLBool.cc 554 2005-05-05 15:38:41Z tneumann $";
#else
static const char* SCCSID FRWUNUSED = "@(#) ";
#endif

implementSDLType(SDLBool,SDLType)


const SDLBool SDLBool::the_true(true);
const SDLBool SDLBool::the_false(false);


bool
SDLBool::valid()const
{ return state(validValue); }


AsnLen
SDLBool::pEnc(BUF_TYPE2 b) const
{
    b.putBit(val());
    return 1;
}

void SDLBool::pDec(BUF_TYPE2 b) {
    _value = b.getBit();
    set_state(validValue);
}

AsnLen
SDLBool::bEnc(BUF_TYPE b) const
{
#ifdef SITE_LOG
  if (SDLType::_type_debug & SITE_BER_LOG)
    std::cerr << "encode boolean value " << *this << std::endl;
#endif
  b.PutByteRvs((val()?0xFF:0x0));
  BEncDefLenTo127(b,1);
  int yes_unused = BEncTag1(b, UNIV, PRIM, BOOLEAN_TAG_CODE);
  return 3;
}

AsnLen
SDLBool::bEncContent(BUF_TYPE b) const
{
#ifdef SITE_LOG
  if (SDLType::_type_debug & SITE_BER_LOG)
    std::cerr << "encode boolean value " << *this << std::endl;
#endif
  b.PutByteRvs((val()?0xFF:0x0));
  return 1;
}

void
SDLBool::bDec( BUF_TYPE b, AsnLen& bytesDecoded)
{
  AsnTag tagId = BDecTag1(b,bytesDecoded);
  AsnLen elmtLen;
  if (tagId != MAKE_TAG_ID(UNIV,PRIM,BOOLEAN_TAG_CODE)) {
    TagError(MAKE_TAG_ID(UNIV,PRIM,BOOLEAN_TAG_CODE),tagId); return;
  }
  elmtLen = BDecLen(b,bytesDecoded);
  AsnLen localBytesDecoded = 0;
  bDecContent(b,tagId,elmtLen,localBytesDecoded);
  bytesDecoded += localBytesDecoded;
}

void
SDLBool::bDecContent(BUF_TYPE b, AsnTag, AsnLen elmtLen,
                          AsnLen& bytesDecoded)
{
  set_state(invalidValue);
  if (elmtLen != 1)
    throw ASNLengthException(
      "SDLBool::bDecContent: ERROR - boolean value too long"
    );
  _value = (b.GetByte() != 0);
  bytesDecoded++;
  set_state(validValue);
#ifdef SITE_LOG
  if (SDLType::_type_debug & SITE_BER_LOG)
    std::cerr << "decoded boolean value " << *this << std::endl;
#endif
}

SDLTypeId
SDLBool::sdl_type_id()const
{ return TypeId_SDLBool; }

void
SDLBool::Print(std::ostream& os)const
{
  if (valid()) os << (val()?"TRUE":"FALSE");
  else os << "<invalid Boolean value>";
}

bool
SDLBool::equal(const SDLType& b) const
{
  return _value == SITE_DYNAMIC_CAST(const SDLBool&,b)._value;
}

void
SDLBool::to_string(std::stringstream& buf){
  if (valid()) buf<<(_value?"TRUE":"FALSE");
}

const SDLBool&
SDLBool::_and(bool b)const
{ return (val()&&b)?SDLTrue():SDLFalse(); }

const SDLBool&
SDLBool::_or(bool b)const
{ return (val()||b)?SDLTrue():SDLFalse(); }

const SDLBool&
SDLBool::_xor(bool b)const
{ return ((val()&&!b)||(!val()&&b))?SDLTrue():SDLFalse(); }

const SDLBool&
SDLBool::impl(bool b)const
{ return (!val()||b)?SDLTrue():SDLFalse(); }

const SDLBool&
SDLBool::_not()const
{ return (!val())?SDLTrue():SDLFalse(); }
