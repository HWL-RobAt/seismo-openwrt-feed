/*******************************************************************************
*   vim:sw=2:ts=2:et
*
*   File    : SDLCharstring.cxx
*   Author  : Ralf Schr�der
*             Humboldt University Berlin
*             Department of Computer Science / System Analysis
*   e-mail  : r.schroeder@informatik.hu-berlin.de
*   Project : @vantage platform
*   $Date: 2005-05-05 17:38:41 +0200 (Thu, 05 May 2005) $
*   $Revision: 1.7 $
*
*******************************************************************************/
#include "SDLPredefined.h"
#include "SDLCharstring.h"
#include "SITELIB_implementSDLType_macro.h"

#include <ctype.h>

#ifdef SITE_RCS_IDENT
static const char* RCSID FRWUNUSED = "$Id: SDLCharstring.cc 554 2005-05-05 15:38:41Z tneumann $";
#else
static const char* SCCSID FRWUNUSED = "@(#) ";
#endif

#define _CONST_OPTIMIZE
SITELIB_implementSDLType(SDLCharstring,SDLType)

SDLCharstring::SDLCharstring(const SDLAny &a, AsnCodingSet rule_set) :
  _length(0),_string(0),_string_size(0)
{
  a.decode(this, rule_set);
  // decode will automatically null-terminate the string
}

SDLCharstring::SDLCharstring() :
  _length(0),_string(0),_string_size(0)
{}

SDLCharstring::SDLCharstring(char c, SITE_SDL_INT size)
  :
  _length(size),
  _string(new char[TO_SIZE_T(size)+1]),
  _string_size(size+1)
{
  memset(_string,c,TO_SIZE_T(size));
  _string[size] = 0; // 0 termination
  set_state(validValue);
}

SDLCharstring::SDLCharstring(const char* str, SITE_SDL_INT size,bool no_copy) :
  SDLType()
{
  // allow str == 0
  if (!str) {
    if (size<0) size=0;
    _length = size;
    _string_size = size+1;
    _string = new char[TO_SIZE_T(size)+1];
    memset(_string,0,TO_SIZE_T(size)+1);
  } else {
    _length = (size<0)?strlen(str):size;
#ifdef _CONST_OPTIMIZE
    if (no_copy) {
      _string_size = -1;
      _string = (char*)str;
    } else
#endif
    {
      _string_size = _length+1;
      _string = new char[TO_SIZE_T(_string_size)];
      memcpy(_string,str,TO_SIZE_T(_length));
      _string[TO_SIZE_T(_length)] = 0;  // 0 termination
    }
  }
  set_state(validValue);
}

SDLCharstring::SDLCharstring(
           const SDLCharstring& str,SITE_SDL_INT reserve) :
  SDLType(str),
  _length(str._length),
  _string(new char[TO_SIZE_T(str._length+reserve+1)]),
  _string_size(str._length+reserve+1)
{
  if (_length) memcpy(_string,str._string,TO_SIZE_T(_length));
  memset(_string+_length,0,TO_SIZE_T(_string_size-_length));
}

void
SDLCharstring::resize(SITE_SDL_INT new_len)
{
#ifdef _CONST_OPTIMIZE
  if (_string_size==-1) {
    _string_size = new_len+1;
    char* newlist = new char[TO_SIZE_T(_string_size)];
    if (_length > new_len) {
      memcpy(newlist,_string,TO_SIZE_T(new_len));
    } else {
      if (_length) memcpy(newlist,_string,TO_SIZE_T(_length));
    }
    memset(newlist+_length,0,TO_SIZE_T(_string_size-_length));
    _string = newlist;
  } else
#endif
  if (new_len+1>_string_size) {
    // good value for the internal buffer, probably!
    SITE_SDL_INT newsize = 2*new_len-_string_size+_length+1;
    char* newlist = new char[TO_SIZE_T(newsize)];
    if (_length) memcpy(newlist,_string,TO_SIZE_T(_length));
    memset(newlist+_length,0,TO_SIZE_T(newsize-_string_size));
    delete[]_string;
    _string=newlist;
    _string_size = newsize;
  }
  _length=new_len;
  _string[TO_SIZE_T(_length)] = 0;  // 0 termination
}

SDLCharstring::SDLCharstring(const SDLCharstring& str) :
  SDLType(str),
  _length(str._length),
  _string(0),
  _string_size(0)
{
#ifdef _CONST_OPTIMIZE
  if (str._string_size==-1) {
#ifdef SITE_LOG
    if (SDLType::_type_debug & SITE_COPY_LOG)
      std::cerr << "(SDLRTE) charstring const reference copy of value "
           << str << std::endl;
#endif
    _string_size = -1;
    _string = str._string;
    return;
  }
#endif
#ifdef SITE_LOG
  if (SDLType::_type_debug & SITE_COPY_LOG)
    std::cerr << "(SDLRTE) charstring " <<
             (str.state(SITEtemporaryValue)?"reference ":"") <<
            "copy of value " << str << std::endl;
#endif
  if (!_length) return;
  if (str.state(SITEtemporaryValue)) {
    SDLCharstring &s = SITE_CONST_CAST(SDLCharstring&,str);
    _string_size = str._string_size; s._string_size = 0;
    _string =  str._string; s._string = 0;
    s._length = 0;
    return;
  }
  _string_size = _length+1;
  _string = new char[TO_SIZE_T(_string_size)];
  memcpy(_string,str._string,TO_SIZE_T(_length+1));
}

SDLCharstring::~SDLCharstring()
{
  if (_string_size!=-1) delete[]_string;
  _string = 0;
  _string_size = _length = 0;
}


bool
SDLCharstring::valid()const
{
  if (!state(validValue)) return false;
  // include a 0 termination check, just in case...
  SITEASSERT(!_string||((_string_size>_length || _string_size==-1) && _string[_length]==0),
            "0 termination of character string missing");
  return true;
}

AsnLen
SDLCharstring::bEnc(BUF_TYPE b) const
{
    AsnLen elmtLen = bEncContent(b);
    elmtLen += BEncDefLen(b,elmtLen);
    elmtLen += BEncTag1(b,UNIV,PRIM,22);
    return elmtLen;
} // SDLCharstring::BEnc

void
SDLCharstring::bDec(BUF_TYPE b,AsnLen& bytesDecoded)
{
    AsnTag tagId = BDecTag1(b,bytesDecoded);
    AsnLen elmtLen;
    if (tagId != MAKE_TAG_ID(UNIV,PRIM,22)) { TagError(MAKE_TAG_ID(UNIV,PRIM,22),tagId); return; }
    elmtLen = BDecLen(b,bytesDecoded);
    int pending_eoc = 0;
    if (elmtLen == INDEFINITE_LEN) ++pending_eoc;
    AsnLen localBytesDecoded = 0;
    bDecContent(b,tagId,elmtLen,localBytesDecoded);
    for(;pending_eoc>0;--pending_eoc) { BDecEoc(b,localBytesDecoded); }
    bytesDecoded += localBytesDecoded;
} // SDLCharstring::BDec

AsnLen
SDLCharstring::bEncContent(BUF_TYPE b) const
{
#ifdef SITE_LOG
  if (SDLType::_type_debug & SITE_BER_LOG)
    std::cerr << "encode charstring value " << *this << std::endl;
#endif
  if (!state(validValue)) check_valid();
  if (_length) b.PutSegRvs(_string, TO_SIZE_T(_length));
  return(_length);
}

void
SDLCharstring::bDecContent(BUF_TYPE b,AsnTag tagId,AsnLen elmtLen,
                                 AsnLen& bytesDecoded)
{
  /*
   * tagId is encoded tag shifted into long int.
   * if CONS bit is set then constructed octet string
   */
  if (tagId & 0x20000000)
    BDecConsString(b, elmtLen, bytesDecoded);

  else { /* primitive string */
#ifdef _CONST_OPTIMIZE
    if (_string_size==-1) {
      _string_size = _length = 0; _string = 0;
    }
#endif
    if (!_string_size) {
      _string =  new char[TO_SIZE_T(elmtLen)+1];
      _string_size = elmtLen+1;
    } else if (_string_size<elmtLen+1 || _string_size>8*elmtLen) {
      delete [] _string;
      _string =  new char[TO_SIZE_T(elmtLen)+1];
      _string_size = elmtLen+1;
    }
    _length = elmtLen;
    b.Copy(_string, TO_SIZE_T(elmtLen));
    memset(_string+_length,0,TO_SIZE_T(_string_size-_length));
    bytesDecoded += elmtLen;
  }
  set_state(validValue);
#ifdef SITE_LOG
  if (SDLType::_type_debug & SITE_BER_LOG)
    std::cerr << "decoded charstring value " << *this << std::endl;
#endif
}

AsnLen
SDLCharstring::pEnc(BUF_TYPE2 b) const
{
  AsnLen elmtLen=pEncLen(b, _length);
  AsnLen rem=_length;
  AsnLen pos=0;
  int cur;
  while(rem>0){
    // compute size of next fragment
    cur = (rem<16384?rem: (rem>>14)<=4?(rem>>14)*16384: 4*16384);
    for(AsnLen max_pos=pos+cur;pos<max_pos;pos++)
      b.putByte(_string[pos]);
    rem-=cur;
    elmtLen+=cur*8;
    // this is not the last fragment
    if(!(cur%16384))
      elmtLen+=pEncLen(b,rem);
  }
  return elmtLen;
}

void
SDLCharstring::pDec(BUF_TYPE2 b)
{
  int rem=pDecLen(b);
  delete [] _string;
  _string = NULL;
  _length=0;
  _string_size=0;
  if(!rem){
    set_state(validValue);
    return;
  }
  AsnLen pos=0;
  int next;
  ByteArray tmp, tmp2;
  while(rem>0){
    AsnLen max_pos=pos+rem;
    b.getBytes(rem, tmp2);
    // there will follow another (non empty) fragment
    if(!(rem%16384)&&(next=pDecLen(b))){
      tmp.resize(max_pos);
      // copy bytes from the encode buffer to the temp buffer
      for(int i=0;pos<max_pos;pos++,i++)
	      tmp[pos]=tmp2[i];
      rem=next;
    }
    // this is the last fragment
    else {
      // an additional field holds the c-string zero
      _string=new char[max_pos+1];
      if(!tmp.empty())
	      // copy bytes from the temp buffer to the _octs array
	      for(AsnLen i=0;i<pos;i++)
	        _string[i]=tmp[i];
      // copy bytes from the encode buffer to the _octs array
      for(int i=0;pos<max_pos;pos++,i++)
	      _string[pos]=tmp2[i];
      _string[max_pos]='\0';
      _length=max_pos;
      _string_size= _length;
      rem=0;
    }
  }
  set_state(validValue);
}

SDLTypeId
SDLCharstring::sdl_type_id()const
{ return TypeId_SDLIA5String; }


void
SDLCharstring::Print(std::ostream& out)const
{
  if (!valid()) { out << "<invalid charstring value>"; return; }
  out << "'";
  for(SITE_SDL_INT i=0;i<_length;i++) {
    if (isprint(_string[i])) {
      out << _string[i];
      if (_string[i] == '\'') out << "'";
    } else {
      out << ' '; // Cntl -> space
    }
    //if (!out.good()) SDLType::raise(new SDLLogLimitReached);
  }
  out << "'";
}

void
SDLCharstring::to_string(std::stringstream& buf){
  if (valid()){
    buf << "'";
    for(SITE_SDL_INT i=0;i<_length;i++) {
      if (isprint(_string[i])) {
	buf << _string[i];
	if (_string[i] == '\'') buf << "'";
      }
      else buf << ' ';
    }
    buf << "'";
  }
}


unsigned int
SDLCharstring::hash(unsigned int max_hash)const
{
  if (!_length) return 0;
  return TO_UINT32(_length+_string[0]+_string[_length-1])%max_hash;
}

SDLCharstring&
SDLCharstring::operator=(const SDLCharstring& str)
{
#ifdef SITE_LOG
  if (SDLType::_type_debug & SITE_ASSIGNMENT_LOG)
    std::cerr << "(SDLRTE) charstring" <<
            (str.state(SITEtemporaryValue)?"reference ":"") <<
            "assignment of " << str <<
            " to variable with value " << *this << std::endl;
#endif
  str.check_valid();
  if (this == &str) return *this;
#ifdef _CONST_OPTIMIZE
  if (_string_size==-1) {
      _string_size = 0; _string = 0;
  }
  _length = str._length;
  if (str._string_size==-1) {
    _string_size = -1;
    delete[]_string;
    _string = str._string;
    set_state(validValue);
    return *this;
  }
#endif
  set_state(~SITEtemporaryValue);
  if (str.state(SITEtemporaryValue)) {
    SDLCharstring &s = SITE_CONST_CAST(SDLCharstring&,str);
    _string_size = str._string_size; s._string_size = 0;
    delete[]_string; _string =  str._string; s._string = 0;
    s._length = 0;
    set_state(validValue);
    return *this;
  }

  if (_length) {
    if (_string_size < _length+1) {
      // set up a new string item
      delete[]_string; _string = 0;
      _string_size = str._length+1;
      _string = new char[TO_SIZE_T(_string_size)+1];
      if (_length) memcpy(_string,str._string,TO_SIZE_T(_length));
    } else {
      memcpy(_string,str._string,TO_SIZE_T(_length));
    }
    _string[TO_SIZE_T(_length)] = 0;  // 0 termination
  } else {
   if (_string_size)
     _string[TO_SIZE_T(_length)] = 0;  // 0 termination
  }
  set_state(validValue);
  return *this;
}

const SDLBool&
SDLCharstring::eq(
    const SDLCharstring& str)const
{
  check_valid(); str.check_valid();
  if (_length !=str._length) return SDLBool::SDLFalse();
  if (!_length) return SDLBool::SDLTrue();
  return (memcmp(_string,str._string,TO_SIZE_T(_length))==0) ?
         SDLBool::SDLTrue() : SDLBool::SDLFalse();
}

const SDLBool&
SDLCharstring::ne(
    const SDLCharstring& str)const
{
  check_valid(); str.check_valid();
  if (_length !=str._length) return SDLBool::SDLTrue();
  if (!_length) return SDLBool::SDLFalse();
  return (memcmp(_string,str._string,TO_SIZE_T(_length))!=0) ?
         SDLBool::SDLTrue() : SDLBool::SDLFalse();
}

bool
SDLCharstring::equal(
    const SDLType& str)const
{
  return eq(SITE_DYNAMIC_CAST(const SDLCharstring&,str));
}


SDLInt
SDLCharstring::length()const
{
  check_valid(); return _length;
}

SDLChar
SDLCharstring::first()const
{
  check_valid();
  if(!_length) { throw SDLInvalidIndex(); }
  return _string[0];
}

SDLChar
SDLCharstring::last()const
{
  check_valid();
  if(!_length) { throw SDLInvalidIndex(); }
  return _string[_length-1];
}

SDLCharstring
SDLCharstring::cat(const SDLCharstring& str) const
{
  SDLCharstring ret(*this,str.lengthAsLong());
  ret._cat(str);
  ret.set_state(SITEtemporaryValue);
  return ret;
}

void
SDLCharstring::_cat(const SDLCharstring& str)
{
  check_valid(); str.check_valid();
#ifdef _CONST_OPTIMIZE
  if (_string_size==-1) {
    // set up a new string item
    char* new_string = new char[TO_SIZE_T(_length+str._length+1)];
    if (_length) memcpy(new_string,_string,TO_SIZE_T(_length));
    _string = new_string;
    _string_size = _length+str._length+1;
  } else
#endif
  if (_string_size<_length+str._length+1) {
    // set up a new string item
    char* new_string = new char[TO_SIZE_T(_length+str._length+1)];
    if (_length) memcpy(new_string,_string,TO_SIZE_T(_length));
    delete[] _string; _string = new_string;
    _string_size = _length+str._length+1;
  }
  if (str._length)
    memcpy(_string+_length,str._string,TO_SIZE_T(str._length));
  _length += str._length;
  _string[TO_SIZE_T(_length)] = 0;  // 0 termination
}


SDLCharstring::SDLCharRef
SDLCharstring::operator()(SITE_SDL_INT index)
{
  check_valid();
  if (index<1) { throw SDLInvalidIndex(); }
  if (index>_length) { resize(index); }
  set_state(validValue); // changes default value
#ifdef _CONST_OPTIMIZE
  if (_string_size==-1) {
    // set up a new string item
    char* new_string = new char[TO_SIZE_T(_length+1)];
    if (_length) memcpy(new_string,_string,TO_SIZE_T(_length)+1);
    _string = new_string;
    _string_size = _length+1;
  }
#endif
  return SDLCharRef(_string+index-1);
}

const SDLChar
SDLCharstring::operator[](SITE_SDL_INT index)const
{
  if (index<1 || _length<index) { throw SDLInvalidIndex(); }
  return _string[index-1];
}

#if SITE_SDL_INT_SIZE==64
const SDLChar
SDLCharstring::operator[](int index)const
{
  return (*this)[static_cast<SITE_SDL_INT>(index)];
}
#endif

SDLCharstring
SDLCharstring::substr(SITE_SDL_INT from,SITE_SDL_INT len) const
{
  check_valid();
  if (from<1 || _length<from || len<0)
  { throw SDLInvalidIndex(); }
  // non SDL-2000
  if (from+len-1>_length) {
    len = _length-from+1;
  }
  char *buf = new char[TO_SIZE_T(len)+1];
  if (len) memcpy(buf,_string+from-1,TO_SIZE_T(len));
  buf[len] = 0; // 0 termination
  SDLCharstring ret(buf,len);
  ret.set_state(SITEtemporaryValue);
  return ret;
}

SDLCharstring
SDLCharstring::cut(SITE_SDL_INT index) const
{
  check_valid();
  if (index<1 || _length<index) return *this;
  char *buff  = new char[TO_SIZE_T(_length)];
  memcpy(buff,_string,TO_SIZE_T(index-1));
  memcpy(buff+index-1,_string+index,TO_SIZE_T(_length-index));
  buff[_length-1] = 0;
  SDLCharstring ret(buff,_length-1);
  ret.set_state(SITEtemporaryValue);
  return ret;
}

void
SDLCharstring::Set(SITE_SDL_INT index, char c)
{
  // check for copy on write for string constants
  if (_string_size == -1) {
    _string_size = _length+1;
    char *tmp = new char[TO_SIZE_T(_string_size)];
    memcpy(tmp,_string,TO_SIZE_T(_string_size));
    _string = tmp;
  }
  _string[index] = c;
}

char
SDLCharstring::Get(SITE_SDL_INT index) const
{
  return _string[index];
}

void
SDLCharstring::assign_new()
{
  if (_string_size!=-1) delete[]_string;
  _string = 0;
  _string_size = _length = 0;
  SDLType::assign_new();
}

void
SDLCharstring::BDecConsString(BUF_TYPE, AsnLen, AsnLen&)
{ throw SDLOperationNotImplemented("SDLCharstring::BDecConsString"); }
