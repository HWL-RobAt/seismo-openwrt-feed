/*******************************************************************************
*   vim:sw=2:ts=2:et
*
*   File    : SDLArray.cxx
*   Author  : Ralf Schr�der
*             Humboldt University Berlin
*             Department of Computer Science / System Analysis
*   e-mail  : r.schroeder@informatik.hu-berlin.de
*   Project : @vantage platform
*   $Date: 2005-05-05 17:38:41 +0200 (Thu, 05 May 2005) $
*   $Revision: 1.3 $
*
*******************************************************************************/
#include "SDLArray.h"
#include "BasicEncoding.h"
#include "SDLBool.h"
#include "SDLInt.h"
#include "SDLAny.h"
#include "SITELIB_implementSDLType_macro.h"
#include "implementSDLType_macro.h"

#ifdef SITE_RCS_IDENT
static const char* SDLARRAY_IMPL_RCSID FRWUNUSED = "$Id: SDLArray.cc 554 2005-05-05 15:38:41Z tneumann $";
#else
static const char* SDLARRAY_IMPL_SCCSID FRWUNUSED = "@(#) ";
#endif

/// hash size function
inline long
hash_size(long index)
{ return (1<<(index+7))+1; }

/** This hash table is directly designed for SDL Array. The main problem is,
    that the key type of the Array can be without order, so that std::map
    does not work. Using std::multimap with hash as key is also complex
    and propably more slow.
*/
class SITEHashTable
{
    /** number of Array entries */
    long   _length;

    /** index to hash size */
    long   _size;


    /** count unused hash slots */
    long   _free_slots;

    /** type of the hash slots */
    struct EntryList {
      const SDLType *_key;
      SDLType       *_value;
      EntryList     *_next;
      EntryList(const EntryList& entry):
        _key(entry._key->copy()),
        _value(entry._value->copy()),
        _next(entry._next?new EntryList(*entry._next):0)
      {}
      EntryList(SDLType*key,SDLType*value, EntryList* next=0):
        _key(key), _value(value), _next(next)
      {}
      ~EntryList() {
        delete _key; _key=0;
        delete _value; _value=0;
        delete _next; _next = 0;
      }
    };

    /** Hash slots */
    EntryList **_table;

    /**@name state based, non thread save hash iterator */
    //@{
    long            _iter_slot;
    EntryList*      _iter_entry;

    /** insert/replace the value for key */
    void insert(EntryList* entry);

  public:
    /** Reset the state of the hash iterator */
    void iterator_reset() { _iter_slot=-1; _iter_entry=0; }

    /** Set the iterator state to the next element.
        @returns False, if there is no element
    */
    bool iterator_next() {
      if (_iter_entry) {
        if (_iter_entry->_next) {
          _iter_entry = _iter_entry->_next;
          return true;
        }
        _iter_entry = 0;
      }
      while(++_iter_slot<hash_size(_size)) {
        if (_table[_iter_slot]) {
          _iter_entry = _table[_iter_slot];
          return true;
        }
      }
      return false;
    }

    /** @returns the key of the iterator state */
    const SDLType* iterator_key() { return _iter_entry?_iter_entry->_key:0; }
    /** @returns the value of the iterator state */
    SDLType* iterator_value() { return _iter_entry?_iter_entry->_value:0; }
  //@}

  public:

    /** initial construction */
    SITEHashTable(long initial) :
      _length(0),
      _size(initial),
      _free_slots(hash_size(_size)),
      _table(new EntryList*[hash_size(_size)]),
      _iter_slot(-1),
      _iter_entry(0)
    { memset(_table,0,hash_size(_size)*sizeof(EntryList*)); }

    /** copy the content */
    SITEHashTable(const SITEHashTable& table);

    /** delete the table */
    ~SITEHashTable();

    /** insert/replace the value for key */
    void insert(SDLType*key, SDLType*value);

    /** delete the entry of key, return false if there was no entry */
    bool del(const SDLType&);

    /** get the value of key */
    SDLType* get(const SDLType&);

    long hash_slots(){ return hash_size(_size); }
    long length()      { return _length; }
    long free_slots(){ return _free_slots; }
  protected:
    void rebuild();
};


SITEHashTable::SITEHashTable(const SITEHashTable& table) :
  _length(table._length),
  _size(table._size),
  _free_slots(table._free_slots),
  _table(new EntryList*[hash_size(_size)]),
  _iter_slot(-1),
  _iter_entry(0)
{
  for (long i=0; i<hash_size(_size); i++) {
     _table[i] =  table._table[i]?new EntryList(*table._table[i]):0;
  }
}

SITEHashTable::~SITEHashTable()
{
  for(long i=0;i<hash_size(_size);i++) {
    delete _table[i]; _table[i] = 0;
  }
  delete []_table; _table = 0;
  _length = 0;
  _size = 0;
  _free_slots = 0;
  _table = 0;
}

void
SITEHashTable::insert(SDLType* key, SDLType* value)
{
  long slot = key->hash(hash_size(_size));
  if (!_table[slot]) {
    _table[slot] = new EntryList(key,value);
    _length++;
    if (--_free_slots < hash_size(_size)/8) rebuild();
    return;
  }
  for(EntryList *entry=_table[slot]; entry; entry = entry->_next) {
    if (entry->_key->equal(*key)) {
      entry->_value->assign(value);
      return;
    }
  }
#ifdef SITE_LOG
  if (SDLType::_type_debug & SITE_COPY_LOG)
    std::cerr << "(SDLRTE) array insertion, slot " << slot << " hash clash"
         << std::endl;
#endif
  _table[slot] = new EntryList(key,value,_table[slot]);
  _length++;
}


void
SITEHashTable::insert(EntryList*e)
{
  long slot = e->_key->hash(hash_size(_size));
  if (!_table[slot]) {
    e->_next = 0;
    --_free_slots;
  } else {
    e->_next = _table[slot];
  }
  _table[slot] = e;
  _length++;
}


bool
SITEHashTable::del(const SDLType& key)
{
  long slot = key.hash(hash_size(_size));
  EntryList *last = 0;
  for(EntryList *entry=_table[slot]; entry; entry = entry->_next) {
    if (entry->_key->equal(key)) {
      if (last) { last->_next = entry->_next; }
      else {
        _table[slot] = entry->_next;
        if (!_table[slot]) _free_slots++;
      }
      entry->_next = 0; delete entry;
      iterator_reset();
      _length--;
      return true;
    }
    last = entry;
  }
  return false;
}


SDLType*
SITEHashTable::get(const SDLType& key)
{
  long slot = key.hash(hash_size(_size));
  for(EntryList *entry=_table[slot]; entry; entry = entry->_next) {
    if (entry->_key->equal(key)) {
      return entry->_value;
    }
  }
  return 0;
}

void
SITEHashTable::rebuild()
{
#ifdef SITE_LOG
  if (SDLType::_type_debug & SITE_COPY_LOG)
    std::cerr << "(SDLRTE) array hash rebuild, new size: "
         << hash_slots() << " SDL length: " << length()
         << "free slots:" << free_slots();
#endif
  EntryList **t = _table;
  _size += 1;
  _free_slots = hash_size(_size);
  _length = 0;
  _table = new EntryList*[hash_size(_size+1)];
  memset(_table,0,hash_size(_size)*sizeof(EntryList*));
  _iter_slot = -1;
  _iter_entry = 0;

  for(long slot=0;slot<hash_size(_size-1);slot++) {
    for(EntryList *entry=t[slot]; entry;) {
      EntryList *next = entry->_next;
      insert(entry);
      entry = next;
    }
    t[slot] = 0;
  }
  delete [] t;
#ifdef SITE_LOG
  if (SDLType::_type_debug & SITE_COPY_LOG)
    std::cerr << ", now " << free_slots() << "free slots" << std::endl;
#endif
}

// implementation of SDLArray
SDLArrayBase::SDLArrayBase() :
  _hashTable(new SITEHashTable(0)),
  _default(0)
{ set_state(validValue); }

SDLArrayBase::SDLArrayBase(const SDLType& val) :
  _hashTable(new SITEHashTable(0)),
  _default(val.copy())
{ set_state(validValue); }

SDLArrayBase::SDLArrayBase(const SDLNull&):
  _hashTable(new SITEHashTable(0)),
  _default(0)
{}

SDLArrayBase::SDLArrayBase(const SDLArrayBase& a) :
  SDLType(a),
  _hashTable(0),
  _default(0)
{
#ifdef SITE_LOG
  if (SDLType::_type_debug & SITE_COPY_LOG)
    std::cerr << "(SDLRTE) array " << (a.state(SITEtemporaryValue)?"reference ":"")
         << "copy of value " << a << std::endl;
#endif
  if (a.state(SITEtemporaryValue)) {
    SDLArrayBase &aa = SITE_CONST_CAST(SDLArrayBase&,a);
    _hashTable = a._hashTable; aa._hashTable = 0;
    _default = a._default; aa._default = 0;
    return;
  }
  if (a._hashTable) _hashTable = new SITEHashTable(*a._hashTable);
  if (a._default) _default = a._default->copy();
}

SDLArrayBase::~SDLArrayBase()
{
  delete _hashTable; _hashTable = 0;
  delete _default; _default = 0;
}


bool
SDLArrayBase::valid() const
{ return state(validValue); }


AsnLen
SDLArrayBase::bEnc(BUF_TYPE b) const
{
  AsnLen elmtLen = bEncContent(b);
  elmtLen += BEncDefLen(b,elmtLen);
  elmtLen += BEncTag1(b,PRIV,CONS,16);
  return elmtLen;
}

AsnLen
SDLArrayBase::bEncContent(BUF_TYPE b) const
{
#ifdef SITE_LOG
  if (SDLType::_type_debug & SITE_BER_LOG)
    std::cerr << "encode array value " << *this << std::endl;
#endif
  check_valid();
  AsnLen elmtLen = 0, bytesEncoded = 0;
  _hashTable->iterator_reset();
  // encode tag len KEY tag len VALUE as iteration
  while(_hashTable->iterator_next()) {
    // encoding the content implies some bad side effects for decoding
    // of non constructed variants and choices, use BEnc
    elmtLen = _hashTable->iterator_value()->bEnc(b);
    bytesEncoded += BEncDefLen(b,elmtLen);
    bytesEncoded += BEncTag1(b,CNTX,CONS,4);
    bytesEncoded += elmtLen;

    elmtLen = SITE_CONST_CAST(SDLType*,_hashTable->iterator_key())->bEnc(b);
    bytesEncoded += BEncDefLen(b,elmtLen);
    bytesEncoded += BEncTag1(b,CNTX,CONS,3);
    bytesEncoded += elmtLen;
  }
  bytesEncoded += BEncDefLen(b,bytesEncoded);
  bytesEncoded += BEncTag1(b,CNTX,CONS,2);
  if (_default) {
    elmtLen = _default->bEnc(b);
    elmtLen += BEncDefLen(b,elmtLen);
    elmtLen += BEncTag1(b,CNTX,CONS,1);
    bytesEncoded += elmtLen;
  }
  return bytesEncoded;
}

void
SDLArrayBase::bDec(BUF_TYPE b, AsnLen& bytesDecoded)
{
  AsnTag tagId = BDecTag1(b,bytesDecoded);
  AsnLen elmtLen;
  if (tagId != MAKE_TAG_ID(PRIV,CONS,16)) {
    TagError(MAKE_TAG_ID(PRIV,CONS,16),tagId); return;
  }
  elmtLen = BDecLen(b,bytesDecoded);
  int pending_eoc = 0;
  if (elmtLen == INDEFINITE_LEN) ++pending_eoc;
  AsnLen localBytesDecoded = 0;
  bDecContent(b,tagId,elmtLen,localBytesDecoded);
  for(;pending_eoc>0;--pending_eoc) { BDecEoc(b,localBytesDecoded); }
  bytesDecoded += localBytesDecoded;
}

void
SDLArrayBase::bDecContent(BUF_TYPE b,AsnTag,AsnLen bytesToDecode,
                         AsnLen& bytesDecoded)
{
  delete _default; _default = 0;
  delete _hashTable;
  _hashTable = new SITEHashTable(0);

  bool structDone = false;
  AsnLen elmtLen, localBytesDecoded = 0;
  AsnTag tagId;
  delete _default; _default = 0;
  if (bytesToDecode == 0) { tagId = 0; structDone = true; }
  else tagId = BDecTag(b,localBytesDecoded);
  if (!structDone && (tagId==MAKE_TAG_ID(CNTX,CONS,1))) {
    elmtLen = BDecLen(b,localBytesDecoded);
    _default = create_elem();
    AsnLen defaultBytesDecoded = 0;
    _default->bDec(b,defaultBytesDecoded);
    if (defaultBytesDecoded != elmtLen) {
      throw ASNLengthException(
        "Array/BDecContent: wrong default value byte number");
    }
    localBytesDecoded += defaultBytesDecoded;
    if (localBytesDecoded>=bytesToDecode) structDone = true;
    else tagId = BDecTag(b,localBytesDecoded);
  }
  if (!structDone && (tagId==MAKE_TAG_ID(CNTX,CONS,2))) {
    elmtLen = BDecLen(b,localBytesDecoded);
    AsnLen keyvalEncoded = 0, keyvalLen;
    while (keyvalEncoded<elmtLen) {
      SDLType *key = create_key();
      SDLType *val = create_elem();
      AsnLen keyvalBytesDecoded = 0;
      try {
        tagId = BDecTag(b,keyvalEncoded);
        if (tagId!=MAKE_TAG_ID(CNTX,CONS,3)) {
          TagError(MAKE_TAG_ID(CNTX,CONS,3),tagId); return;
        }
        keyvalLen = BDecLen(b,keyvalEncoded);
        key->bDec(b,keyvalBytesDecoded);
        if (keyvalBytesDecoded != keyvalLen) {
          throw ASNLengthException(
                "Array/BDecContent: wrong key byte number");
        }
        keyvalEncoded += keyvalBytesDecoded;

        tagId = BDecTag(b,keyvalEncoded);
        if (tagId!=MAKE_TAG_ID(CNTX,CONS,4)) {
          TagError(MAKE_TAG_ID(CNTX,CONS,4),tagId);
        }
        keyvalLen = BDecLen(b,keyvalEncoded);
        keyvalBytesDecoded = 0;
        val->bDec(b,keyvalBytesDecoded);
        if (keyvalBytesDecoded != keyvalLen) {
          throw ASNLengthException(
                "Array/BDecContent: wrong key byte number");
        }
        keyvalEncoded += keyvalBytesDecoded;
        _hashTable->insert(key,val);
      } catch (...) { delete key; delete val; throw; }
    }

    localBytesDecoded += keyvalEncoded;
  }
  if (localBytesDecoded<bytesToDecode) {
    throw ASNLengthException("remaining bytes by array encoding");
  }
  bytesDecoded += localBytesDecoded;
  set_state(validValue);
#ifdef SITE_LOG
  if (SDLType::_type_debug & SITE_BER_LOG)
    std::cerr << "decoded array value " << *this << std::endl;
#endif
}


SDLTypeId
SDLArrayBase::sdl_type_id() const
{ return TypeId_SDLArray; }

void
SDLArrayBase::Print(std::ostream& out)const
{
  if (!valid()) {
    out << "-- invalid SDLArray --";
    return;
  }
  out << "-- SDLArray " << " -- {\n";
#ifdef SITE_LOG
  if (SDLType::_type_debug & SITE_COPY_LOG)
    out << "-- hash size: " << _hashTable->hash_slots()
        << " / free " << _hashTable->free_slots() << "\n";
#endif
  if(_default) {
      out << "  default value: ";
      _default->Print(out);
      out << std::endl;
  }
  _hashTable->iterator_reset();
  int i=1;
  while(_hashTable->iterator_next()) {
    out << "   [" << i++ << "]  key ";
    _hashTable->iterator_key()->Print(out);
    out << "  value " << ":  ";
    _hashTable->iterator_value()->Print(out);
    out << std::endl;
  }
  if (i==1) {
    out << "  no entries" << std::endl;
  }
  out << "}";
}

unsigned int
SDLArrayBase:: hash(unsigned int max)const
{ return _hashTable->length()%max; }


SDLArrayBase&
SDLArrayBase::operator=(const SDLArrayBase& a)
{
#ifdef SITE_LOG
  if (SDLType::_type_debug & SITE_ASSIGNMENT_LOG)
    std::cerr << "(SDLRTE) array" <<
            (a.state(SITEtemporaryValue)?"reference ":"") <<
            "assignment of " << a <<
            " to variable with value " << *this << std::endl;
#endif
  a.check_valid();
  if (this==&a) return *this;
  set_state(~SITEtemporaryValue);
  if (a.state(SITEtemporaryValue)) {
    a.check_valid();
    SDLArrayBase &aa = SITE_CONST_CAST(SDLArrayBase&,a);
    _hashTable = a._hashTable; aa._hashTable = 0;
    _default = a._default; aa._default = 0;
    set_state(validValue);
    return *this;
  }
  set_state(invalidValue);
  delete _hashTable;
  _hashTable = new SITEHashTable(*a._hashTable);
  delete _default;
  _default = a._default?a._default->copy():0;
  set_state(validValue);
  return *this;
}


const SDLBool&
SDLArrayBase::eq(const SDLArrayBase& a)const
{
  check_valid(); a.check_valid();
  if (_hashTable->length()!=a._hashTable->length()) return SDLBool::SDLFalse();
  if (_default) {
    if (!a._default || !_default->equal(*a._default)) return SDLBool::SDLFalse();
  } else {
    if (a._default) return SDLBool::SDLFalse();
  }
  _hashTable->iterator_reset();
  a._hashTable->iterator_reset();
  while(_hashTable->iterator_next() && a._hashTable->iterator_next()) {
    if (!_hashTable->iterator_key()->equal(*a._hashTable->iterator_key()) ||
        !_hashTable->iterator_value()->equal(*a._hashTable->iterator_value()))
      return SDLBool::SDLFalse();
  }
  return SDLBool::SDLTrue();
}

const SDLBool&
SDLArrayBase::ne(const SDLArrayBase& a)const

{
  return eq(a)._not();
}

bool
SDLArrayBase::equal(const SDLType& a)const

{
  return eq(SITE_DYNAMIC_CAST(const SDLArrayBase&,a));
}


SDLType&
SDLArrayBase::modify(const SDLType& key)
{
  if (!state(validValue)) check_valid(); key.check_valid();
  SDLType* ret = _hashTable->get(key);
  if (ret) { return *ret; }
  ret = _default?_default->copy():create_elem();
  _hashTable->insert(key.copy(),ret);
  set_state(validValue); // changes default value
  return *ret;
}

const SDLType&
SDLArrayBase::extract(const SDLType& key)const
{
  if (!state(validValue)) check_valid(); key.check_valid();
  SDLType* ret = _hashTable->get(key);
  if (ret) return *ret;
  if (_default) return *_default;
  throw SDLInvalidIndex();
  return *ret;
}


SDLInt
SDLArrayBase::length() const
{ if (!state(validValue)) check_valid(); return _hashTable->length(); }

const SDLBool&
SDLArrayBase::_del(const SDLType& key)
{
  if (!state(validValue)) check_valid();
  return _hashTable->del(key)?SDLBool::SDLTrue():SDLBool::SDLFalse();
}

const SDLType&
SDLArrayBase::_firstkey() const
{
  if (!state(validValue)) check_valid();
  _hashTable->iterator_reset();
  if (!_hashTable->iterator_next()) throw SDLInvalidIndex();
  return *_hashTable->iterator_key();
}

const SDLType&
SDLArrayBase::_nextkey() const
{
  if (!state(validValue)) check_valid();
  if (!_hashTable->iterator_next()) throw SDLInvalidIndex();
  return *_hashTable->iterator_key();
}

bool
SDLArrayBase::in(const SDLType& key) const
{
  if (!valid()) return false;
  SDLType* val = _hashTable->get(key);
  if (val==0 || !val->valid()) return false;
  return true;
}

void
SDLArrayBase::assign_new()
{
  delete _hashTable; _hashTable = 0;
  delete _default; _default = 0;
  SDLType::assign_new();
}

SDLType*
SDLArrayBase::copy() const
{
  SDLArrayBase* ret = SITE_STATIC_CAST(SDLArrayBase*,create_new()->copy());
  ret->_hashTable = _hashTable?new SITEHashTable(*_hashTable):0;
  ret->_default = _default?_default->copy():0;
  return ret;
}

void
SDLArrayBase::init_type()
{
  SDLType::init_type();
  delete create_elem();
  delete create_key();
}
