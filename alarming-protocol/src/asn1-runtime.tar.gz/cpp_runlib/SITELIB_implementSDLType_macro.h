/* ===== SITELIB_implementSDLType_macro.h ===== */

#ifndef SITELIB_implementSDLType
#define SITELIB_implementSDLType(M_TYPE,M_BASE) \
    SDLType* M_TYPE::copy()const { return new M_TYPE(*this); }\
    \
    void M_TYPE::assign(const SDLType* t)\
    {\
      const M_TYPE *arg = SITE_DYNAMIC_CAST(const M_TYPE*,t);\
      if (!arg) M_BASE::assign(t);\
      else *this = *arg;\
    }\
    \
    SDLType* M_TYPE::create()\
    {\
      static M_TYPE* tmpl = new M_TYPE;\
      return tmpl;\
    }\
    \
    const SDLType* M_TYPE::create_new() const { return create(); }
#endif
