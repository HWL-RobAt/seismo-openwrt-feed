/*******************************************************************************
*   vim:sw=2:ts=2:et
*
*   File    : BasicEncoding.h
*   Author  : Ralf Schr�der
*             Humboldt University Berlin
*             Department of Computer Science / System Analysis
*   e-mail  : r.schroeder@informatik.hu-berlin.de
*   Project : @vantage platform
*   $Date: 2005-05-05 17:38:41 +0200 (Thu, 05 May 2005) $
*   $Revision: 1.3 $
*
*******************************************************************************/
#ifndef _BASICENCODING_H
#define _BASICENCODING_H

#include "sdlconfig.h"
#include "SDLBaseImpl.h"

static const char* BASICENCODING_RCSID FRWUNUSED = "$Id: BasicEncoding.h 554 2005-05-05 15:38:41Z tneumann $";

/**@name BasicEncoding low level interface.
   The BasicEncoding supports the decoding functionality
   for indefinite length, too. However, it is never used
   in context of SDL, hence not implemented for encoding.
*/

//@{

/** Value which represents the indefinite encoding length */
#define INDEFINITE_LEN  (~(AsnLen)0)

/** Decode a length information.
    @param b buffer for the encoded string
    @param bytesDecoded counter for encoded bytes.
*/
SDL_API AsnLen BDecLen( BUF_TYPE b, AsnLen& bytesDecoded);


/** Encode a length information.
    @param b buffer for the encoded string
    @param len the length value to encode
    @returns the number of octets written to the buffer.
*/
SDL_API AsnLen BEncDefLen ( BUF_TYPE b, AsnLen len);

/** Encode a length information with 0 >= len <= 127 (no check!).
    Eg for booleans, nulls, any resonable integers and reals
    NOTE: this particular Encode Routine does NOT return the length
    encoded (1).  The length counter must be explicity incremented
*/
#define BEncDefLenTo127(b, len)\
    b.PutByteRvs(TO_UCHAR(len))


/** Encode a EndOfContent.
    @param b buffer for the encoded string
    Not used, because infinit encoding never happens.
*/
#define BEncEoc(b) \
    (b.PutByteRvs(0),b.PutByteRvs(0),2)

/** Decode the second EndOfContent byte
    @param b buffer for the encoded string
    @param bytesDecoded the byte counter
*/
#define BDEC_2ND_EOC_OCTET(b, bytesDecoded)\
{\
    if ((b.GetByte() != 0)) {\
        throw ASNLengthException("Warning - second octet of EOC not zero\n");}\
    bytesDecoded++;\
}

/** Decode EndOfContent.
    @param b buffer for the encoded string
    @param bytesDecoded counter for encoded bytes.
*/
#define BDecEoc(buff, bytesDecoded) \
  { if ((b.GetByte() != 0) || (b.GetByte() != 0)) \
      throw ASNCorruptedEocException( \
        "BDecEoc: ERROR - non zero byte in EOC or end of data reached\n"); \
    bytesDecoded += 2; \
  }

//$}

#include "AsnTag.h"

/**@name ASN.1 exception handling.
   ASN.1 coding exceptions are SDLCodingError exceptions.
   Otherwise we have the ID problem.
*/
//@{
#define ASNCorruptedEocException   SDLCodingError
#define ASNLengthException         SDLCodingError
#define ASNTooBigToDecodeException SDLCodingError
#define ASNWrongTagException       SDLCodingError
#define ASNChoiceError             SDLCodingError

/** A detailed tag problem exception. If the exception is restored
    within a saved signal, the details disappear and the exception
    is an SDLCodingError only.
*/
struct ASNTagMismatchException:public ASNWrongTagException{
    AsnTag _expected, _received;
  public:
    ASNTagMismatchException(AsnTag e, AsnTag r);
    AsnTag expected() const;
    AsnTag received() const;
    virtual void Print(std::ostream&)const;
};

#define LengthError() \
  throw ASNLengthException("BDecContent: wrong byte number")
#define SetError() throw SDLCodingError("static ASN.1 coding problem")
#define ChoiceError(msg) throw SDLCodingError(msg)
//@}

#include "AsnBuf.h"
#include "pAsnBuf.h"

AsnLen pEncLen(pAsnBuf& octBuf, int number);
AsnLen pDecLen(pAsnBuf& octBuf);
AsnLen pEncSmallNumber(pAsnBuf& octBuf, int number);
AsnLen pDecSmallNumber(pAsnBuf& octBuf);

#endif
