/*******************************************************************************
*   vim:sw=2:ts=2:et
*
*   File    : SDLOctet.cxx
*   Author  : Ralf Schr�der
*             Humboldt University Berlin
*             Department of Computer Science / System Analysis
*   e-mail  : r.schroeder@informatik.hu-berlin.de
*   Project : @vantage platform
*   $Date: 2005-05-05 17:38:41 +0200 (Thu, 05 May 2005) $
*   $Revision: 1.3 $
*
*******************************************************************************/
#include "SDLOctet.h"
#include "SDLPredefined.h"
#include "SITELIB_implementSDLType_macro.h"

#ifdef SITE_RCS_IDENT
static const char* RCSID FRWUNUSED = "$Id: SDLOctet.cc 554 2005-05-05 15:38:41Z tneumann $";
#else
static const char* SCCSID FRWUNUSED = "@(#) ";
#endif

SITELIB_implementSDLType(SDLOctet,SDLBitString)

const SDLOctet SDLOctet::empty(SDLBitString("B"));

SDLOctet::SDLOctet(const SDLAny &a, AsnCodingSet rule_set) :
    SDLBitString(a, rule_set) {}

SDLOctet::SDLOctet(const char *str)  :
  SDLBitString(str)
{
  // generated code is correct
  assert(Len()==8);
}


const SDLBool&
SDLOctet::check() const
{
    check_valid();
    return (Len()==8)?SDLBool::SDLTrue():SDLBool::SDLFalse();
}

SDLOctet&
SDLOctet::operator=(const SDLOctet& str)

{
#ifdef SITE_LOG
  if (SDLType::_type_debug & SITE_ASSIGNMENT_LOG)
    std::cerr << "(SDLRTE) octet assignment of " << str <<
                 " to variable with value " << *this << endl;
#endif
  str.check_valid();
  if (this==&str) return *this;
  char* o = str;
  if (o) Set(o,8);
  set_state(validValue);
  return *this;
}


SDLOctet SDLOctet::int2octet(SITE_SDL_INT val)
{
  char c = TO_CHAR(val&0xff);
  SDLOctet ret;
  ret.Set(&c,8);
  ret.set_state(validValue);
  return ret;
}

SDLInt SDLOctet::octet2int(const SDLOctet& o)
{
  o.check_valid();
  unsigned char c = (unsigned char)*((char*)o);
  return SDLInt(c);
}

SDLTypeId
SDLOctet::sdl_type_id()const
{ return TypeId_SDLOctet; }
