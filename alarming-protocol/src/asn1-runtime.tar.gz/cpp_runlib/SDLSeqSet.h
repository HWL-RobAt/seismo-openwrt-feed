/*******************************************************************************
*   vim:sw=2:ts=2:et
*
*   File    : SDLSeqSet.h
*   Author  : Ralf Schr�der and Martin von L�wis
*             Humboldt University Berlin
*             Department of Computer Science / System Analysis
*   e-mail  : r.schroeder@informatik.hu-berlin.de
*   Project : @vantage platform
*   $Date: 2005-05-05 17:38:41 +0200 (Thu, 05 May 2005) $
*   $Revision: 1.2 $
*
*******************************************************************************/
#ifndef _SDLSEQSET_H
#define _SDLSEQSET_H

#include "SDLType.h"

#ifdef SITE_RCS_IDENT
static const char* SDLSEQSET_RCSID FRWUNUSED = "$Id: SDLSeqSet.h 554 2005-05-05 15:38:41Z tneumann $";
#else
static const char* SDLSEQSET_SCCSID FRWUNUSED = "@(#) ";
#endif

// forward declarations
class SDLIA5String;
class SDLOctetString;

/** Field description of an abstract structure class.
    Each structure class has a static member
    <I>static SDLSeqSetDescription _fdesc;</I> to
    allow the generic field access implementation.
*/
class SDL_API SDLSeqSetDescription{
  public:
    /** Field is a field description structure with private layout. */
    struct Field;

  private:
    /** The number of described fields */
    int _len;

    /** The list (size _len) of field descriptions */
    Field* _fields;

  public:
    /** Type definition for a static create function for SDLType objects. */
    typedef SDLType* (*newfunc)();

    /** Type definition for a dynamic create function for SDLType objects
        if context parameters are used.
    */
    typedef SDLType* SDLType::*newctxaddr;

    /** Constructor, which is called for the initialization of
        the static description object in structures.
        @param count the number of info fields.
    */
    SDLSeqSetDescription(int count);

    /**@name add methods
        Add a field to the field description.
        @param index position in the field description.
        @param fname the name of the field (never deleted).
        @param newfunc a fuction to create an object for the field.
        @returns the pointer to the initialized description.
    */
    //@{
    Field* add(int index,const char *fname,newfunc, bool trace=true);
    Field* add(int index,const char *fname,newctxaddr, bool trace=true);
    Field* add_optional(int index,const char*fname, newfunc, bool trace=true);
    Field* add_default(int index,const char*fname, newfunc, bool trace=true);
    //@}

    /** Return the number of fields */
    int len()const{return _len;}

    /** True, if field index is optional (or default) - no index check */
    bool optional_p(int index) const;

    /** True, if field index has a defaul value - no index check */
    bool default_p(int index) const;

    /** True, if field index can be traced (default on) */
    bool trace_p(int index) const;

    /** Return the name of field index. */
    const char *name(int index) const;

    /** Return the prototype object of field index. */
    SDLType* at(int  index, const SDLType* me)const;
};

/** Abstract base class for SDL and ASN.1 structure types.
    This is a generic structure implementation.
    Any structure value is valid by default (SAG assignment semantics).
*/
class SDL_API SDLSeqSet: public SDLType {
    /** Hold an ellipsis field (ASN.1 extensibility).
        Additional fields are represented in encoded form.
        The best way is to use an SDLOctetString.
    */
    mutable SDLOctetString *_extra_fields;

  protected:


    /** Constructor with a value field 0 initialization.
        @param field_list a list of SDL value objects initialized with 0
        @param size the size of field_list
    */
    SDLSeqSet(SDLType** field_list,unsigned long size);

    /** Constructor, which requires a hand setting of field.
        It is used for generated constructors with field parameters.
    */
    SDLSeqSet() : _extra_fields(0) { set_state(validValue); }

    /** Copy constructor */
    SDLSeqSet(const SDLSeqSet& seq) ;

    /** clean up */
    virtual ~SDLSeqSet() ;

  public:
    /** Valid check.
        @returns true, if the data object is a valid one.
        It can be configured to switch off this test.
    */
    virtual bool valid()const ;

    /** Prints the number. */
    virtual void Print(std::ostream&)const;


    /**@name Static structure support.
       The methods are used used to improve readability, test
       behaviour and allow test configurations.
    */
    //@{

    /** Initializing access to the n-th field.
        @param descr dynamic Description of the structure.
        @param field_list the value field of the structure.
        @index the field number to access.
        The value is created on-the-fly if not available.
    */
    SDLType* field_access(
      SDLSeqSetDescription& descr,SDLType**field_list,int index,
      bool with_default=true) const;

    /** Generic (deep) field copy.
        @param dest SDL type field destination.
        @param source SDL type field source.
        @param size length of both fields.
        The internal help method copies fields without any checks.
        Therefore, this function should never be called from hand written code!
    */
    static void sequence_copyinit(
      SDLType**dest,SDLType* const* source, int size);

    /** Generic present implementation for all fields.
        @param descr dynamic description of the structure.
        @param field_list the value field of the structure.
        @index the field number to access.
        No index checks!
    */
    const SDLBool& field_present(
      SDLSeqSetDescription& descr,SDLType* const* field_list,int index) const;

    /** Delete a field entry.
        @param descr dynamic description of the structure.
        @param field_list the value field of the structure.
        @index the field number to access.
        No index checks!
    */
    static void field_omit(
      SDLSeqSetDescription& descr, SDLType**field_list, int index);

    /** Generic hash function (for array keys).
        @param field_list the value field of the structure.
        @param size length of both fields.
        @param max_hash the hash maximum.
        Method ignores fields without values.
    */
    static unsigned int sequence_hash(
      SDLType* const* field_list, int size, unsigned int max_hash);

    /** Delete all field entries.
        @param field_list the value field of the structure.
        @param size length of both fields.
    */
    static void clear_fields(SDLType**, int) ;
    //@}

  protected:
    /**@name Dynamic structure support.
       The methods are used used to improve readability, test
       behaviour and allow test configurations.
    */
    //@{

    /** Return the field description and field list as
        parameter arguments from the actual structure object.
    */
    virtual void
    get_fields(class SDLSeqSetDescription*&, SDLType**&) = 0;

    /** Return the field description and field list as
        parameter arguments from the actual structure object.
    */
    virtual void
    get_fields(class SDLSeqSetDescription*&, SDLType*const*&) const = 0;

    /** Generic field assignment for = operator with SDL exception.
        @param src assign field from src.
        This and src has to be of the same structure!
    */
    void sequence_assign(const SDLSeqSet& src) ;

  public:
    //common access
    const SDLBool& eq(const SDLSeqSet&)const ;
    const SDLBool& ne(const SDLSeqSet&)const ;

    /** Compares structure objects.
        @param b a structure object compatible to this
        The dynamic cast failures are not caught because the code is
        generated correctly.
    */
    bool equal(const SDLType& b) const ;

    bool datainfo(long index, SDLIA5String& fieldname,
                  SDLType*& value, infotype dir);

    //extra fields support
    SDLOctetString& VAR_ellipsis() const;


    /** Encode for SDL struct  */
    virtual AsnLen bEnc(BUF_TYPE b) const;

    /** Encode the SDL struct content */
    virtual AsnLen bEncContent(BUF_TYPE) const;

    /** Decoding for SDL struct */
    virtual void bDec(BUF_TYPE b, AsnLen& bytesDecoded);

    /** Decode the SDL struct content */
    virtual void bDecContent(BUF_TYPE b,AsnTag tag,AsnLen bytesToDecode,
                             AsnLen& bytesDecoded);

    /** Delete all inner fields */
    virtual void assign_new();

    /** Initialize the default values */
    virtual void init_type();

  protected:
    //BER support
    AsnLen BEncExtraFields(BUF_TYPE) const;
    void BDecSkipField(BUF_TYPE b, AsnLen &local, AsnTag tagId);
    void complete_sequence_decoding(BUF_TYPE,AsnLen expected, AsnLen &local, AsnTag next);
    void complete_open_sequence_decoding(BUF_TYPE,AsnLen expected, AsnLen &local, AsnTag next);
};


/** Base class for ASN.1 SET { ... } constructions. */
class SDL_API SDLSet: public SDLSeqSet {
   public:
    SDLSet() : SDLSeqSet() {}
    SDLSet(SDLType** field_list,unsigned long size) :
      SDLSeqSet(field_list,size){}

    SDLTypeId sdl_type_id()const { return TypeId_SDLSet; }
};


/** Base class for ASN.1 SET { ... } constructions. */
class SDL_API SDLSequence: public SDLSeqSet {
  public:
    SDLSequence() : SDLSeqSet() {}
    SDLSequence(SDLType** field_list,unsigned long size) :
      SDLSeqSet(field_list,size){}

    SDLTypeId sdl_type_id()const { return TypeId_SDLSequence; }
};

#endif
