/*******************************************************************************
*   vim:sw=2:ts=2:et
*
*   File    : BasicEncoding.cxx
*   Author  : Ralf Schr�der
*             Humboldt University Berlin
*             Department of Computer Science / System Analysis
*   e-mail  : r.schroeder@informatik.hu-berlin.de
*   Project : @vantage platform
*   $Date: 2005-05-05 17:38:41 +0200 (Thu, 05 May 2005) $
*   $Revision: 1.3 $
*
*******************************************************************************/
#include "BasicEncoding.h"

static const char* RCSID FRWUNUSED = "$Id: BasicEncoding.cc 554 2005-05-05 15:38:41Z tneumann $";

ASNTagMismatchException::ASNTagMismatchException(AsnTag e, AsnTag r):
  ASNWrongTagException("Tag missmatch"), _expected(e),_received(r)
{}

AsnTag ASNTagMismatchException::expected()const{return _expected;}
AsnTag ASNTagMismatchException::received()const{return _received;}

#include <iomanip>

#define HEX std::hex
#define DEC std::dec

void
ASNTagMismatchException::Print(std::ostream& os)const
{
  os << "exception TagMismatch ("
     << "expected: 0x" << HEX << expected()
     << " received: 0x" << received() << DEC << ")" << std::endl;
}

AsnLen
BEncDefLen ( BUF_TYPE  b, AsnLen len)
{
    /* unrolled for efficiency
     * (check each possibility of the 4 byte integer) */
    if (len < 128)
    {
        b.PutByteRvs(TO_UCHAR(len));
        return (1);
    }
    else if (len < 256)
    {
        b.PutByteRvs(TO_UCHAR(len));
        b.PutByteRvs( 0x81);
        return(2);
    }
    else if (len < 65536)
    {
        b.PutByteRvs(TO_UCHAR(len));
        b.PutByteRvs(TO_UCHAR(len >> 8));
        b.PutByteRvs(0x82);
        return (3);
    }
    else if (len < 16777126)
    {
        b.PutByteRvs(TO_UCHAR(len));
        b.PutByteRvs(TO_UCHAR(len >> 8));
        b.PutByteRvs(TO_UCHAR(len >> 16));
        b.PutByteRvs(0x83);
        return (4);
    }
    else
    {
        b.PutByteRvs(TO_UCHAR(len));
        b.PutByteRvs(TO_UCHAR(len >> 8));
        b.PutByteRvs(TO_UCHAR(len >> 16));
        b.PutByteRvs(TO_UCHAR(len >> 24));
        b.PutByteRvs( 0x84);
        return (5);
    }
} /*  EncodeDefLen */


/* Decode a BER length from the given buffer. Increments bytesDecoded
 * by the number of octets of the encoded length.  Flags an
 * error if the length is too large or a read error occurs
 */
AsnLen
BDecLen( BUF_TYPE b, AsnLen& bytesDecoded)
{
  AsnLen  len;
  unsigned char  byte;
  AsnLen  lenBytes;

  byte = b.GetByte();

  bytesDecoded++;
  if (byte < 128)   /* short length */
    return(byte);

  else if (byte == (unsigned char) 0x80)  /* indef len indicator */
    return(INDEFINITE_LEN);

  else  /* long len form */
  {
    /*
     * strip high bit to get # bytes left in len
     */
    lenBytes = byte & (unsigned char) 0x7f;

    if (TO_SIZE_T(lenBytes) > sizeof(AsnLen))
      throw ASNLengthException("BDecLen: ERROR - length overflow\n");

    bytesDecoded += lenBytes;

    for (len = 0; lenBytes > 0; lenBytes--)
      len = (len << 8) | (unsigned long int) b.GetByte();

    return(len);
  }
  /* not reached */
}

/*********** PER coding ****************************/

AsnLen
pEncLen(pAsnBuf& octBuf, int number){
  assert(number>=0);
  // X.961 case a)
  if(number<128)
    octBuf.putByte((char) number);
  // X.961 case b)
  //	<16k
  else if(number<16384){
    octBuf.putByte((char) (0x80|(number>>8)));
    octBuf.putByte((char) number);
    return 16;
  }
  // X.961 case c)
  //	<32k
  else if(number<2*16384)
    octBuf.putByte((char)0xC1);
  //	<48k
  else if(number<3*16384)
    octBuf.putByte((char)0xC2);
  //	<64k
  else if(number<4*16384)
    octBuf.putByte((char)0xC3);
  //	>= 64k
  else
    octBuf.putByte((char)0xC4);
  return 8;
}

AsnLen
pDecLen(pAsnBuf& octBuf){
  // X.691 case a)
  if (!octBuf.getBit())
    return octBuf.getBitsAsInt(7);
  // X.691 case b)
  if (!octBuf.getBit())
    return octBuf.getBitsAsInt(14);
  // X.691 case c)
  else
    return octBuf.getBitsAsInt(6)*16384;
}

AsnLen
pEncSmallNumber(pAsnBuf& octBuf, int number){
  if(number<=0x3f){
    octBuf.putBit(false);
    int mask=0x20;
    for(int i=0; i<6; mask>>=1,i++)
      octBuf.putBit((number&mask)!=0);
    return 7;
  }
  else{
    octBuf.putBit(true);
    return pEncLen(octBuf, number);
  }
}

AsnLen
pDecSmallNumber(pAsnBuf& octBuf){
    //int start=octBuf.getReadPos();
    //int end;
    int number;
    if(octBuf.getBit()==false){
	number=octBuf.getBitsAsInt(6);
	//end=octBuf.getReadPos();
	//markup.addRow(start,ende-start,octBuf.subString(start,ende-start),"normally small number ("+number+")");
	return number;
    }
    else{
	//end=octBuf.getReadPos();
	//markup.addRow(start,ende-start,octBuf.subString(start,ende-start),"normally small number >63 ");
	return pDecLen(octBuf);
    }
}
