/*******************************************************************************
*   vim:sw=2:ts=2:et
*
*   File    : SDLEnum.h
*   Author  : Ralf Schr�der
*             Humboldt University Berlin
*             Department of Computer Science / System Analysis
*   e-mail  : r.schroeder@informatik.hu-berlin.de
*   Project : @vantage platform
*   $Date: 2005-05-05 17:38:41 +0200 (Thu, 05 May 2005) $
*   $Revision: 1.3 $
*
*******************************************************************************/
#ifndef _SDLENUM_H
#define _SDLENUM_H

#include "sdlconfig.h"

#ifdef SITE_RCS_IDENT
static const char* SDLENUM_RCSID FRWUNUSED = "$Id: SDLEnum.h 554 2005-05-05 15:38:41Z tneumann $";
#else
static const char* SDLENUM_SCCSID FRWUNUSED = "@(#) ";
#endif

#define C_INT long
#define SDLNumber SDLEnumBase
#define ID SDLEnumBase_ID
#define get_literal _get_literal
#include "SDLNumber.h"
#undef get_literal
#undef ID
#undef C_INT
#undef SDLNumber

// forward declarations
class SDLInt;

/** SDL ENUM */
class SDL_API SDLEnum : public SDLEnumBase
{
  public:
    /* Call of generated macro for code shared by all declarations of SDL types
     */
    declareSDLType(SDLEnum,SDLEnumBase)

    /** Constructor for an invalid value */
    SDLEnum() : SDLEnumBase() {}

    /** Constructor for a given valid value */
    SDLEnum(long l) :SDLEnumBase(l) {}

    /** Constructor for an omitted (invalid) value */
    SDLEnum(const SDLNull&n) : SDLEnumBase(n) {}

    /** Copy constructor */
    SDLEnum(const SDLEnum& e) : SDLEnumBase(e) {}

    /** Encoding of this enum with tag and length */
    virtual AsnLen bEnc(BUF_TYPE b) const;

    /** Encodes this enum using PER.
        This method is always generated anew by the code generator.
	@param b the buffer which into the encoding is written
	@return the number of bits written to the buffer
     */
    virtual AsnLen pEnc(BUF_TYPE2 b) const;

    /** Decodes an enum from the given buffer using PER.
        This method is always generated anew by the code generator.
	@param b the buffer which from the bits to decode are read
     */
    virtual void pDec(BUF_TYPE2 b);

    /** Decoding of this enum with tag and length */
    virtual void bDec(BUF_TYPE b, AsnLen& bytesDecoded);

    /** SDL ENUM operations */
    //@{

    /** Determine the (value) predecessor.
        The implementation has to iterate all literals
    */
    const SDLEnum& pred()const;

    /** Determine the (value) successor.
        The implementation has to iterate all literals
    */
    const SDLEnum& succ()const;

    /** Determine the literal with lowest value.
        The implementation has to iterate all literals
    */
    const SDLEnum& first()const;

    /** Determine the literal with highest value.
        The implementation has to iterate all literals
    */
    const SDLEnum& last()const;

    SDLInt num()const;

    /** Assignment operator for simple values.
        Has to be present as best match.
    */
    SDLEnum& operator=(long l)
    { SDLEnumBase::operator=(l); return *this; }

    /** Assignment operator.
        If not present, uninitialized access errors for allignment space.
    */
    SDLEnum& operator=(const SDLEnum& e)
    { SDLEnumBase::operator=(e); return *this; }

    /** Return ANY Enum (simulation construct ANY(...)).
        It is a correct implementation to return the first element.
        No usefull application for non simulation environments!
    */
    static SDLEnum Any(const SDLEnum& e) { return e.first(); }
    //@}

    /** Access to the kind of the object */
    virtual SDLTypeId sdl_type_id()const;

    /** Generic literal access */
    virtual bool get_literal(int,const SDLEnum**,long*)const;
};

#endif
