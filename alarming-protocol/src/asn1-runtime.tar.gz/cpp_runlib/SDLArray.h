/*******************************************************************************
*   vim:sw=2:ts=2:et
*
*   File    : SDLArray.h
*   Author  : Ralf Schr�der
*             Humboldt University Berlin
*             Department of Computer Science / System Analysis
*   e-mail  : r.schroeder@informatik.hu-berlin.de
*   Project : @vantage platform
*   $Date: 2005-05-05 17:38:41 +0200 (Thu, 05 May 2005) $
*   $Revision: 1.2 $
*
*******************************************************************************/
#ifndef _SDLARRAY_H
#define _SDLARRAY_H

#include "SDLType.h"

#ifdef SITE_RCS_IDENT
static const char* SDLARRAY_RCSID FRWUNUSED = "$Id: SDLArray.h 554 2005-05-05 15:38:41Z tneumann $";
#else
static const char* SDLARRAY_SCCSID FRWUNUSED = "@(#) ";
#endif

// forward declarations
class SDLInt;
class SDLBool;
class SDLAny;
class SITEHashTable;


/** SITE abstract implementation of SDL Array generator.
    SDL Arrays are never invalid, there is a default initialization
    as empty array without default value (SDL requires an initial
    array assignment). The realization of SDL arrays works with a
    dynamically growing hash table. If the key type is not able
    to produce good hash values, the access to an array corresponds
    to a linear search operation. <br>
    The implementation is not able to deal with context parameters
    als index or element type (yet). It is an option to implement
    an SDL Array for SDL types with ordering based on std::(multi)map.
*/
class SDLArrayBase : public SDLType
{
    /** hash table of the array */
    SITEHashTable* _hashTable;

    /** default element initialization of the array */
    SDLType*       _default;

  protected:
    /** Array element factory */
    virtual SDLType* create_elem() const = 0;
    /** Array key factory */
    virtual SDLType* create_key() const = 0;

  public:
    /** Constructor for empty array without default value (non SDL) */
    SDLArrayBase();

    /** Constructor for empty array with default value */
    SDLArrayBase(const SDLType& val);

    /** Constructor for an omitted (invalid) value */
    SDLArrayBase(const SDLNull&);

    /** Copy constructor */
    SDLArrayBase(const SDLArrayBase&);

    /** Clean up */
    virtual ~SDLArrayBase();

    /** Valid check.
        @returns true, if the data object is a valid one; in SITE allways true.
    */
    virtual bool valid()const ;

    /** Encode for array  */
    virtual AsnLen bEnc(BUF_TYPE b) const;

    /** Encode the array content */
    virtual AsnLen bEncContent(BUF_TYPE) const;

    /** Decoding for array */
    virtual void bDec(BUF_TYPE b, AsnLen& bytesDecoded);

    /** Decode the array content */
    virtual void bDecContent(BUF_TYPE b,AsnTag tag,AsnLen bytesToDecode,
                             AsnLen& bytesDecoded);

    /** Access to the kind of the object */
    virtual SDLTypeId sdl_type_id()const;

    /** Prints the array. */
    virtual void Print(std::ostream&)const;

    /** Returns a hash value (use length). */
    virtual unsigned int hash(unsigned int max)const;

    /** Assignment operator for arrays. */
    SDLArrayBase& operator=(const SDLArrayBase& a);

    /** SDL equality.
        It is rather expensive to verify equality (linear iteration
        for all values (worst case o(length(x)*length(y)).
    */
    //@{
    const SDLBool& eq(const SDLArrayBase& a)const ;
    const SDLBool& ne(const SDLArrayBase& a)const ;

    /** Compares array objects.
        @param b an array object
        The dynamic cast failure is not caught because the code is
        generated correctly.
    */
    bool equal(const SDLType& a) const ;
    //@}

    /** SDL operations */
    //@{
    /** operator Modify (SITE semantics)
        @exception SDLException for invalid values.
        The modify operation does not attend default value assignments.
        It is not possible to reduce the size of an SDL array by using
        such an assignment. This is not a contradiction to SDL but could
        be changed with a small price of efficiancy.
        Note, that this operator inserts a (default) value in
        the requested position implicitly.
    */
    SDLType& modify(const SDLType&key);

    /** operator Extract (SITE semantics)
        @exception SDLException for invalid values or, if no default value
                   is given, for access of unassigned fields.
    */
    const SDLType& extract(const SDLType&key)const ;

    /** Returns the size of the array (non SDL operator).
        It represents the number of assigned fields.
    */
    SDLInt length() const;

    /** Deletes an array entry.
        It is a non SDL operation with side effects for the array argument.
        The generated code can be wrong, because in/out parameters for
        operators are not checked by the SITE design.
    */
    const SDLBool& _del(const SDLType&);

    /** Resets the iterator state and returns the first key. */
    const SDLType& _firstkey() const ;

    /** Returns the next key. If any operation except [] is used,
        then the result of nextkey() is undefined.
    */
    const SDLType& _nextkey() const ;

    //@}

    /** Check, that a valid value for a key is present.
        Not used in SDL, C++ extension only.
    */
    bool in(const SDLType&) const;

    /** Delete all array entries */
    virtual void assign_new();

    /** Copy an Array */
    SDLType* copy() const;

    /** Initialize the array type */
    virtual void init_type();
};

#include "SDLArrayTemplate.h"

/**@name Array template macros.
*/
//@{
#define ArrayTemplate(ARRAY,KEY,ELEM) \
  SDLArray<KEY,ELEM>

#define ArrayTemplateConstruction(ARRAY,KEY,KEY_CREATE,ELEM,ELEM_CREATE) \
public:\
  ARRAY() {} \
  ARRAY(const ARRAY& a):super(a){}\
  ARRAY(const super& base):super(base){}\
  ARRAY(const SDLNull& n):super(n){}\

#define ArrayTemplateConstructionInit(ARRAY,KEY,KEY_CREATE,ELEM,ELEM_CREATE) \
public:\
  ARRAY() { init(); } \
  ARRAY(const ARRAY& a):super(a){ init(); }\
  ARRAY(const super& base):super(base){ init(); }\
  ARRAY(const SDLNull& n):super(n){ init(); }\


#define ArrayTemplateDeclaration(ARRAY,KEY,KEY_CREATE,ELEM,ELEM_CREATE) \
  declareSDLType(ARRAY,SDLArray)\
  ARRAY(const ELEM& elem):super(elem){}\
  SDLType* create_elem() const;\
  SDLType* create_key() const;

#define ArrayTemplateImplementation(ARRAY,KEY,KEY_CREATE,ELEM,ELEM_CREATE) \
 implementSDLType(ARRAY,super)\
 SDLType* ARRAY::create_elem() const{\
   static ELEM *e = ELEM_CREATE;\
   return SITE_STATIC_CAST(ELEM*,e->copy());\
 }\
 SDLType* ARRAY::create_key() const{\
   static KEY *e = KEY_CREATE;\
   return SITE_STATIC_CAST(KEY*,e->copy());\
 }


//@}

#endif

