/*******************************************************************************
*
*   File    : SDLBaseImpl.cc
*   Author  : Frank Bielig, Toby Neumann
*             Humboldt University Berlin
*             Department of Computer Science / System Analysis
*   e-mail  : tneumann@informatik.hu-berlin.de
*   Project : SITE4Cinderella
*   $Date: 2005-06-29 10:23:35 +0200 (ons, 29 jun 2005) $
*   $Revision: 584 $
*
*******************************************************************************/
#include <iostream>

#include "SDLBaseImpl.h"

#ifdef SIGNED_BYTE
BitAssign<std::numeric_limits<Byte>::is_signed> cast_from_unsigned;
#else
Bytes cast_from_unsigned(Byte b){return b;}
#endif

AsnCodingSet	     asn_coding=asn_ber;

SDLError::SDLError() { }

SDLError::SDLError(std::string msg) : message(msg) { }

SDLError::~SDLError() { }
