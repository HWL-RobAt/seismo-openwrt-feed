/*******************************************************************************
*   vim:sw=2:ts=2:et
*
*   File    : SDLStringTemplate.h
*   Author  : Ralf Schr�der
*             Humboldt University Berlin
*             Department of Computer Science / System Analysis
*   e-mail  : r.schroeder@informatik.hu-berlin.de
*   Project : @vantage platform
*   $Date: 2005-05-05 17:38:41 +0200 (Thu, 05 May 2005) $
*   $Revision: 1.2 $
*
*******************************************************************************/
#ifndef _SDLSTRINGTEMPLATE_H
#define _SDLSTRINGTEMPLATE_H

// in case the user did not use SDLArray.h
#include "SDLString.h"

/** String and String0 generator of SDL.
    The template abstraction is used for correct signatures
    of operators on C++ level. Bigger implementations are part
    of SDLStringBase.
    An extra file is used because Reliant CC includes
    an existing cxx file implicitly.
*/
template <typename STRING, typename ELEM, SITE_SDL_INT start>
class SDL_API SDLStringTemplate : public SDLStringBase
{

    typedef SDLStringTemplate<STRING,ELEM,start> self;

    /** Create an elem object */
    virtual ELEM* create_elem() const = 0;

    /** Create an elem object as SDLType* */
    virtual SDLType* _create_elem() const { return create_elem(); }

  public:
    /** Constructor for an empty string */
    SDLStringTemplate() {}

    /** Constructor for a given valid value
        @param e initialization value
        @param size number of elements to initialize
    */
    SDLStringTemplate(const ELEM& e, SITE_SDL_INT size = 1) :
      SDLStringBase(e,size) {}

    /** Constructor for an omitted (invalid) value */
    SDLStringTemplate(const SDLNull&n)  :
      SDLStringBase(n) {}

  protected:
    /** Copy constructor with resize. */
    SDLStringTemplate(const SDLStringTemplate& str,SITE_SDL_INT reserve) :
      SDLStringBase(str,reserve) {}

  public:
    /** Copy constructor.
        The constructor utilizes the temporary value flag.
    */
    SDLStringTemplate(const SDLStringTemplate& str) :
      SDLStringBase(str) {}

    /** Assignment operator (deep) for Strings.
        If (length of the target object >= length of source,
        then the target items may be reused (no new..., assign only)
        otherwise all target items will be deleted and the
        string is deep copied.
        The operator utilizes the temporary value flag.
        @precodition all elements are valid, string holes are ignored.
    */
    self& operator=(const self& str)
    { return SITE_STATIC_CAST(self&,SDLStringBase::operator=(str)); }

    /** Return the elem array for direct manipulation.
        @postcondition the size cannot be changed.
        It is not recommended to use this internal representation
        to allow implementation changes.
        @depricated: use SDLType** val() const because of invalid C++
        ELEM** val() const
        { return SITE_STATIC_CAST(ELEM**,SDLStringBase::val()); }
    */

    /** SDL operations */
    //@{
    /** operator First.
        @exception SDLInvalidIndex if there is no first value.
    */
    const ELEM& first() const
    { return SITE_STATIC_CAST(const ELEM&,SDLStringBase::first()); }

    /** operator last
        @exception SDLInvalidIndex if there is no last value.
    */
    const ELEM& last() const
    { return SITE_STATIC_CAST(const ELEM&,SDLStringBase::last()); }

    /** operator "//"
        @returns this//str
    */
    STRING cat(const STRING& str) const
    {
      STRING ret(SITE_STATIC_CAST(const STRING&,*this),str.lengthAsLong());
      ret._cat(str);
      ret.set_state(SITEtemporaryValue);
      return ret;
    }

    /** SDL operator Modify with SITE expansion semantics.
        @exception SDLIndexError for negative index
        Missing elements are created on the fly. The string can be
        resized by that action. This semantics allows an initialization
        loop for strings (not allowed in standard SDL).
    */
    ELEM& operator()(SITE_SDL_INT i)
    { return SITE_STATIC_CAST(ELEM&,SDLStringBase::operator()(i-start)); }

    /** SDL operator Extract.
        @exception SDLIndexError for wrong access or the access to a hole.
    */
    const ELEM& operator[](SITE_SDL_INT i)const
    { return SITE_STATIC_CAST(const ELEM&,SDLStringBase::operator[](i-start)); }

  protected:
    /** Internal operator elem (for coding).
        The implementation resizes the internal buffer if necessary.
    */
    ELEM* elem(SITE_SDL_INT i)
    { return SITE_STATIC_CAST(ELEM*,_elem(i-start)); }

    /** Internal operator elem (for coding).
        The implementation resizes the internal buffer if necessary.
    */
    const ELEM* elem(SITE_SDL_INT i) const
    { return SITE_STATIC_CAST(
        ELEM*,SITE_CONST_CAST(self*,this)->_elem(i-start));
    }

  public:
    /** operator SubString.
      @param from start index.
      @param len  size of the substring.
      @exception SDLIndexError if from or from+len are out of range
          or if len is negative (conforms with SDL, change from VESUV).
      @exception SDLException any other errors.
    */
    STRING substr(SITE_SDL_INT from,SITE_SDL_INT len) const
    { STRING ret;
      ret._substr(*this,from-start,len);
      ret.set_state(SITEtemporaryValue);
      return ret;
    }

    /** Cut one element.
        @returns a new string
    */
    STRING cut(SITE_SDL_INT index) const
    {
      check_valid();
      STRING ret = *this;
      ret._cut(index-start);
      ret.set_state(SITEtemporaryValue);
      return ret;
    }

    //@}

    /** Prints the string. */
    void Print(std::ostream& out)const { _Print(out,start); }
};

#endif
