/* ===== declareSDLType_macro.h ===== */

#ifndef declareSDLType
#define declareSDLType(M_TYPE,M_BASE) \
    public:\
    M_TYPE(const SDLAny&, AsnCodingSet rule_set=asn_ber);\
    SITELIB_declareSDLType(M_TYPE,M_BASE)\

#endif
