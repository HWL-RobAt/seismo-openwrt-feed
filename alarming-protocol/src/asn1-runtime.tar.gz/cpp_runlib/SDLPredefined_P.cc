/* ===== SDLPredefined_P.cxx ===== */

#include "SDLPredefined.h"
#include "version.h"

SDLNat::SDLNat(const SDLAny& a, AsnCodingSet rule_set){                                      a.decode(this,rule_set); }

SDLType* SDLNat::copy()const { return new SDLNat(*this); }

void SDLNat::assign(const SDLType* t)
{
  const SDLNat *arg = SITE_DYNAMIC_CAST(const SDLNat*,t);
  if (!arg) SDLInt::assign(t);
  else *this = *arg;
}

SDLType* SDLNat::create()
{
  static SDLNat* tmpl = new SDLNat;
  return tmpl;
}

const SDLType* SDLNat::create_new() const { return create(); }

const SDLBool& SDLNat::check() const{
    if(((ge(0))&&true /* half open intervall */)) return SDLBool::SDLTrue();
    return SDLBool::SDLFalse();
}

SDLIA5String::SDLIA5String(const SDLAny& a, AsnCodingSet rule_set){                                      a.decode(this,rule_set); }

SDLType* SDLIA5String::copy()const { return new SDLIA5String(*this); }

void SDLIA5String::assign(const SDLType* t)
{
  const SDLIA5String *arg = SITE_DYNAMIC_CAST(const SDLIA5String*,t);
  if (!arg) SDLCharstring::assign(t);
  else *this = *arg;
}

SDLType* SDLIA5String::create()
{
  static SDLIA5String* tmpl = new SDLIA5String;
  return tmpl;
}

const SDLType* SDLIA5String::create_new() const { return create(); }

AsnLen SDLIA5String::bEnc(BUF_TYPE b) const {
    AsnLen elmtLen = bEncContent(b);
    elmtLen += BEncDefLen(b,elmtLen);
    elmtLen += BEncTag1(b,UNIV,PRIM,22);
    return elmtLen;
} // SDLIA5String::bEnc

void SDLIA5String::bDec(BUF_TYPE b,AsnLen& bytesDecoded) {
    AsnTag tagId = BDecTag1(b,bytesDecoded);
    AsnLen elmtLen;
    if (tagId != MAKE_TAG_ID(UNIV,PRIM,22)) { TagError(MAKE_TAG_ID(UNIV,PRIM,22),tagId); return; }
    elmtLen = BDecLen(b,bytesDecoded);
    AsnLen localBytesDecoded = 0;
    bDecContent(b,tagId,elmtLen,localBytesDecoded);
    bytesDecoded += localBytesDecoded;
} // SDLIA5String::bDec

SDLNumericString::SDLNumericString(const SDLAny& a, AsnCodingSet rule_set){                                      a.decode(this,rule_set); }

SDLType* SDLNumericString::copy()const { return new SDLNumericString(*this); }

void SDLNumericString::assign(const SDLType* t)
{
  const SDLNumericString *arg = SITE_DYNAMIC_CAST(const SDLNumericString*,t);
  if (!arg) SDLCharstring::assign(t);
  else *this = *arg;
}

SDLType* SDLNumericString::create()
{
  static SDLNumericString* tmpl = new SDLNumericString;
  return tmpl;
}

const SDLType* SDLNumericString::create_new() const { return create(); }

AsnLen SDLNumericString::bEnc(BUF_TYPE b) const {
    AsnLen elmtLen = bEncContent(b);
    elmtLen += BEncDefLen(b,elmtLen);
    elmtLen += BEncTag1(b,UNIV,PRIM,18);
    return elmtLen;
} // SDLNumericString::bEnc

void SDLNumericString::bDec(BUF_TYPE b,AsnLen& bytesDecoded) {
    AsnTag tagId = BDecTag1(b,bytesDecoded);
    AsnLen elmtLen;
    if (tagId != MAKE_TAG_ID(UNIV,PRIM,18)) { TagError(MAKE_TAG_ID(UNIV,PRIM,18),tagId); return; }
    elmtLen = BDecLen(b,bytesDecoded);
    AsnLen localBytesDecoded = 0;
    bDecContent(b,tagId,elmtLen,localBytesDecoded);
    bytesDecoded += localBytesDecoded;
} // SDLNumericString::bDec

SDLPrintableString::SDLPrintableString(const SDLAny& a, AsnCodingSet rule_set){                                      a.decode(this,rule_set); }

SDLType* SDLPrintableString::copy()const { return new SDLPrintableString(*this); }

void SDLPrintableString::assign(const SDLType* t)
{
  const SDLPrintableString *arg = SITE_DYNAMIC_CAST(const SDLPrintableString*,t);
  if (!arg) SDLCharstring::assign(t);
  else *this = *arg;
}

SDLType* SDLPrintableString::create()
{
  static SDLPrintableString* tmpl = new SDLPrintableString;
  return tmpl;
}

const SDLType* SDLPrintableString::create_new() const { return create(); }

AsnLen SDLPrintableString::bEnc(BUF_TYPE b) const {
    AsnLen elmtLen = bEncContent(b);
    elmtLen += BEncDefLen(b,elmtLen);
    elmtLen += BEncTag1(b,UNIV,PRIM,19);
    return elmtLen;
} // SDLPrintableString::bEnc

void SDLPrintableString::bDec(BUF_TYPE b,AsnLen& bytesDecoded) {
    AsnTag tagId = BDecTag1(b,bytesDecoded);
    AsnLen elmtLen;
    if (tagId != MAKE_TAG_ID(UNIV,PRIM,19)) { TagError(MAKE_TAG_ID(UNIV,PRIM,19),tagId); return; }
    elmtLen = BDecLen(b,bytesDecoded);
    AsnLen localBytesDecoded = 0;
    bDecContent(b,tagId,elmtLen,localBytesDecoded);
    bytesDecoded += localBytesDecoded;
} // SDLPrintableString::bDec

SDLTeletexString::SDLTeletexString(const SDLAny& a, AsnCodingSet rule_set){                                      a.decode(this,rule_set); }

SDLType* SDLTeletexString::copy()const { return new SDLTeletexString(*this); }

void SDLTeletexString::assign(const SDLType* t)
{
  const SDLTeletexString *arg = SITE_DYNAMIC_CAST(const SDLTeletexString*,t);
  if (!arg) SDLCharstring::assign(t);
  else *this = *arg;
}

SDLType* SDLTeletexString::create()
{
  static SDLTeletexString* tmpl = new SDLTeletexString;
  return tmpl;
}

const SDLType* SDLTeletexString::create_new() const { return create(); }

AsnLen SDLTeletexString::bEnc(BUF_TYPE b) const {
    AsnLen elmtLen = bEncContent(b);
    elmtLen += BEncDefLen(b,elmtLen);
    elmtLen += BEncTag1(b,UNIV,PRIM,20);
    return elmtLen;
} // SDLTeletexString::bEnc

void SDLTeletexString::bDec(BUF_TYPE b,AsnLen& bytesDecoded) {
    AsnTag tagId = BDecTag1(b,bytesDecoded);
    AsnLen elmtLen;
    if (tagId != MAKE_TAG_ID(UNIV,PRIM,20)) { TagError(MAKE_TAG_ID(UNIV,PRIM,20),tagId); return; }
    elmtLen = BDecLen(b,bytesDecoded);
    AsnLen localBytesDecoded = 0;
    bDecContent(b,tagId,elmtLen,localBytesDecoded);
    bytesDecoded += localBytesDecoded;
} // SDLTeletexString::bDec

SDLT61String::SDLT61String(const SDLAny& a, AsnCodingSet rule_set){                                      a.decode(this,rule_set); }

SDLType* SDLT61String::copy()const { return new SDLT61String(*this); }

void SDLT61String::assign(const SDLType* t)
{
  const SDLT61String *arg = SITE_DYNAMIC_CAST(const SDLT61String*,t);
  if (!arg) SDLCharstring::assign(t);
  else *this = *arg;
}

SDLType* SDLT61String::create()
{
  static SDLT61String* tmpl = new SDLT61String;
  return tmpl;
}

const SDLType* SDLT61String::create_new() const { return create(); }

AsnLen SDLT61String::bEnc(BUF_TYPE b) const {
    AsnLen elmtLen = bEncContent(b);
    elmtLen += BEncDefLen(b,elmtLen);
    elmtLen += BEncTag1(b,UNIV,PRIM,20);
    return elmtLen;
} // SDLT61String::bEnc

void SDLT61String::bDec(BUF_TYPE b,AsnLen& bytesDecoded) {
    AsnTag tagId = BDecTag1(b,bytesDecoded);
    AsnLen elmtLen;
    if (tagId != MAKE_TAG_ID(UNIV,PRIM,20)) { TagError(MAKE_TAG_ID(UNIV,PRIM,20),tagId); return; }
    elmtLen = BDecLen(b,bytesDecoded);
    AsnLen localBytesDecoded = 0;
    bDecContent(b,tagId,elmtLen,localBytesDecoded);
    bytesDecoded += localBytesDecoded;
} // SDLT61String::bDec

SDLVideotexString::SDLVideotexString(const SDLAny& a, AsnCodingSet rule_set){                                      a.decode(this,rule_set); }

SDLType* SDLVideotexString::copy()const { return new SDLVideotexString(*this); }

void SDLVideotexString::assign(const SDLType* t)
{
  const SDLVideotexString *arg = SITE_DYNAMIC_CAST(const SDLVideotexString*,t);
  if (!arg) SDLCharstring::assign(t);
  else *this = *arg;
}

SDLType* SDLVideotexString::create()
{
  static SDLVideotexString* tmpl = new SDLVideotexString;
  return tmpl;
}

const SDLType* SDLVideotexString::create_new() const { return create(); }

AsnLen SDLVideotexString::bEnc(BUF_TYPE b) const {
    AsnLen elmtLen = bEncContent(b);
    elmtLen += BEncDefLen(b,elmtLen);
    elmtLen += BEncTag1(b,UNIV,PRIM,21);
    return elmtLen;
} // SDLVideotexString::bEnc

void SDLVideotexString::bDec(BUF_TYPE b,AsnLen& bytesDecoded) {
    AsnTag tagId = BDecTag1(b,bytesDecoded);
    AsnLen elmtLen;
    if (tagId != MAKE_TAG_ID(UNIV,PRIM,21)) { TagError(MAKE_TAG_ID(UNIV,PRIM,21),tagId); return; }
    elmtLen = BDecLen(b,bytesDecoded);
    AsnLen localBytesDecoded = 0;
    bDecContent(b,tagId,elmtLen,localBytesDecoded);
    bytesDecoded += localBytesDecoded;
} // SDLVideotexString::bDec

SDLVisibleString::SDLVisibleString(const SDLAny& a, AsnCodingSet rule_set){                                      a.decode(this,rule_set); }

SDLType* SDLVisibleString::copy()const { return new SDLVisibleString(*this); }

void SDLVisibleString::assign(const SDLType* t)
{
  const SDLVisibleString *arg = SITE_DYNAMIC_CAST(const SDLVisibleString*,t);
  if (!arg) SDLCharstring::assign(t);
  else *this = *arg;
}

SDLType* SDLVisibleString::create()
{
  static SDLVisibleString* tmpl = new SDLVisibleString;
  return tmpl;
}

const SDLType* SDLVisibleString::create_new() const { return create(); }

AsnLen SDLVisibleString::bEnc(BUF_TYPE b) const {
    AsnLen elmtLen = bEncContent(b);
    elmtLen += BEncDefLen(b,elmtLen);
    elmtLen += BEncTag1(b,UNIV,PRIM,26);
    return elmtLen;
} // SDLVisibleString::bEnc

void SDLVisibleString::bDec(BUF_TYPE b,AsnLen& bytesDecoded) {
    AsnTag tagId = BDecTag1(b,bytesDecoded);
    AsnLen elmtLen;
    if (tagId != MAKE_TAG_ID(UNIV,PRIM,26)) { TagError(MAKE_TAG_ID(UNIV,PRIM,26),tagId); return; }
    elmtLen = BDecLen(b,bytesDecoded);
    AsnLen localBytesDecoded = 0;
    bDecContent(b,tagId,elmtLen,localBytesDecoded);
    bytesDecoded += localBytesDecoded;
} // SDLVisibleString::bDec

SDLISO646String::SDLISO646String(const SDLAny& a, AsnCodingSet rule_set){                                      a.decode(this,rule_set); }

SDLType* SDLISO646String::copy()const { return new SDLISO646String(*this); }

void SDLISO646String::assign(const SDLType* t)
{
  const SDLISO646String *arg = SITE_DYNAMIC_CAST(const SDLISO646String*,t);
  if (!arg) SDLCharstring::assign(t);
  else *this = *arg;
}

SDLType* SDLISO646String::create()
{
  static SDLISO646String* tmpl = new SDLISO646String;
  return tmpl;
}

const SDLType* SDLISO646String::create_new() const { return create(); }

AsnLen SDLISO646String::bEnc(BUF_TYPE b) const {
    AsnLen elmtLen = bEncContent(b);
    elmtLen += BEncDefLen(b,elmtLen);
    elmtLen += BEncTag1(b,UNIV,PRIM,26);
    return elmtLen;
} // SDLISO646String::bEnc

void SDLISO646String::bDec(BUF_TYPE b,AsnLen& bytesDecoded) {
    AsnTag tagId = BDecTag1(b,bytesDecoded);
    AsnLen elmtLen;
    if (tagId != MAKE_TAG_ID(UNIV,PRIM,26)) { TagError(MAKE_TAG_ID(UNIV,PRIM,26),tagId); return; }
    elmtLen = BDecLen(b,bytesDecoded);
    AsnLen localBytesDecoded = 0;
    bDecContent(b,tagId,elmtLen,localBytesDecoded);
    bytesDecoded += localBytesDecoded;
} // SDLISO646String::bDec

SDLGraphicString::SDLGraphicString(const SDLAny& a, AsnCodingSet rule_set){                                      a.decode(this,rule_set); }

SDLType* SDLGraphicString::copy()const { return new SDLGraphicString(*this); }

void SDLGraphicString::assign(const SDLType* t)
{
  const SDLGraphicString *arg = SITE_DYNAMIC_CAST(const SDLGraphicString*,t);
  if (!arg) SDLCharstring::assign(t);
  else *this = *arg;
}

SDLType* SDLGraphicString::create()
{
  static SDLGraphicString* tmpl = new SDLGraphicString;
  return tmpl;
}

const SDLType* SDLGraphicString::create_new() const { return create(); }

AsnLen SDLGraphicString::bEnc(BUF_TYPE b) const {
    AsnLen elmtLen = bEncContent(b);
    elmtLen += BEncDefLen(b,elmtLen);
    elmtLen += BEncTag1(b,UNIV,PRIM,25);
    return elmtLen;
} // SDLGraphicString::bEnc

void SDLGraphicString::bDec(BUF_TYPE b,AsnLen& bytesDecoded) {
    AsnTag tagId = BDecTag1(b,bytesDecoded);
    AsnLen elmtLen;
    if (tagId != MAKE_TAG_ID(UNIV,PRIM,25)) { TagError(MAKE_TAG_ID(UNIV,PRIM,25),tagId); return; }
    elmtLen = BDecLen(b,bytesDecoded);
    AsnLen localBytesDecoded = 0;
    bDecContent(b,tagId,elmtLen,localBytesDecoded);
    bytesDecoded += localBytesDecoded;
} // SDLGraphicString::bDec

SDLGeneralString::SDLGeneralString(const SDLAny& a, AsnCodingSet rule_set){                                      a.decode(this,rule_set); }

SDLType* SDLGeneralString::copy()const { return new SDLGeneralString(*this); }

void SDLGeneralString::assign(const SDLType* t)
{
  const SDLGeneralString *arg = SITE_DYNAMIC_CAST(const SDLGeneralString*,t);
  if (!arg) SDLCharstring::assign(t);
  else *this = *arg;
}

SDLType* SDLGeneralString::create()
{
  static SDLGeneralString* tmpl = new SDLGeneralString;
  return tmpl;
}

const SDLType* SDLGeneralString::create_new() const { return create(); }

AsnLen SDLGeneralString::bEnc(BUF_TYPE b) const {
    AsnLen elmtLen = bEncContent(b);
    elmtLen += BEncDefLen(b,elmtLen);
    elmtLen += BEncTag1(b,UNIV,PRIM,27);
    return elmtLen;
} // SDLGeneralString::bEnc

void SDLGeneralString::bDec(BUF_TYPE b,AsnLen& bytesDecoded) {
    AsnTag tagId = BDecTag1(b,bytesDecoded);
    AsnLen elmtLen;
    if (tagId != MAKE_TAG_ID(UNIV,PRIM,27)) { TagError(MAKE_TAG_ID(UNIV,PRIM,27),tagId); return; }
    elmtLen = BDecLen(b,bytesDecoded);
    AsnLen localBytesDecoded = 0;
    bDecContent(b,tagId,elmtLen,localBytesDecoded);
    bytesDecoded += localBytesDecoded;
} // SDLGeneralString::bDec

SDLGeneralizedTime::SDLGeneralizedTime(const SDLAny& a, AsnCodingSet rule_set){                                      a.decode(this,rule_set); }

SDLType* SDLGeneralizedTime::copy()const { return new SDLGeneralizedTime(*this); }

void SDLGeneralizedTime::assign(const SDLType* t)
{
  const SDLGeneralizedTime *arg = SITE_DYNAMIC_CAST(const SDLGeneralizedTime*,t);
  if (!arg) SDLVisibleString::assign(t);
  else *this = *arg;
}

SDLType* SDLGeneralizedTime::create()
{
  static SDLGeneralizedTime* tmpl = new SDLGeneralizedTime;
  return tmpl;
}

const SDLType* SDLGeneralizedTime::create_new() const { return create(); }

AsnLen SDLGeneralizedTime::bEnc(BUF_TYPE b) const {
    AsnLen elmtLen = bEncContent(b);
    elmtLen += BEncDefLen(b,elmtLen);
    elmtLen += BEncTag1(b,UNIV,PRIM,24);
    return elmtLen;
} // SDLGeneralizedTime::bEnc

void SDLGeneralizedTime::bDec(BUF_TYPE b,AsnLen& bytesDecoded) {
    AsnTag tagId = BDecTag1(b,bytesDecoded);
    AsnLen elmtLen;
    if (tagId != MAKE_TAG_ID(UNIV,PRIM,24)) { TagError(MAKE_TAG_ID(UNIV,PRIM,24),tagId); return; }
    elmtLen = BDecLen(b,bytesDecoded);
    AsnLen localBytesDecoded = 0;
    bDecContent(b,tagId,elmtLen,localBytesDecoded);
    bytesDecoded += localBytesDecoded;
} // SDLGeneralizedTime::bDec

SDLUTCTime::SDLUTCTime(const SDLAny& a, AsnCodingSet rule_set){                                      a.decode(this,rule_set); }

SDLType* SDLUTCTime::copy()const { return new SDLUTCTime(*this); }

void SDLUTCTime::assign(const SDLType* t)
{
  const SDLUTCTime *arg = SITE_DYNAMIC_CAST(const SDLUTCTime*,t);
  if (!arg) SDLVisibleString::assign(t);
  else *this = *arg;
}

SDLType* SDLUTCTime::create()
{
  static SDLUTCTime* tmpl = new SDLUTCTime;
  return tmpl;
}

const SDLType* SDLUTCTime::create_new() const { return create(); }

AsnLen SDLUTCTime::bEnc(BUF_TYPE b) const {
    AsnLen elmtLen = bEncContent(b);
    elmtLen += BEncDefLen(b,elmtLen);
    elmtLen += BEncTag1(b,UNIV,PRIM,23);
    return elmtLen;
} // SDLUTCTime::bEnc

void SDLUTCTime::bDec(BUF_TYPE b,AsnLen& bytesDecoded) {
    AsnTag tagId = BDecTag1(b,bytesDecoded);
    AsnLen elmtLen;
    if (tagId != MAKE_TAG_ID(UNIV,PRIM,23)) { TagError(MAKE_TAG_ID(UNIV,PRIM,23),tagId); return; }
    elmtLen = BDecLen(b,bytesDecoded);
    AsnLen localBytesDecoded = 0;
    bDecContent(b,tagId,elmtLen,localBytesDecoded);
    bytesDecoded += localBytesDecoded;
} // SDLUTCTime::bDec

SDLObjectDescriptor::SDLObjectDescriptor(const SDLAny& a, AsnCodingSet rule_set){                                      a.decode(this,rule_set); }

SDLType* SDLObjectDescriptor::copy()const { return new SDLObjectDescriptor(*this); }

void SDLObjectDescriptor::assign(const SDLType* t)
{
  const SDLObjectDescriptor *arg = SITE_DYNAMIC_CAST(const SDLObjectDescriptor*,t);
  if (!arg) SDLGraphicString::assign(t);
  else *this = *arg;
}

SDLType* SDLObjectDescriptor::create()
{
  static SDLObjectDescriptor* tmpl = new SDLObjectDescriptor;
  return tmpl;
}

const SDLType* SDLObjectDescriptor::create_new() const { return create(); }

AsnLen SDLObjectDescriptor::bEnc(BUF_TYPE b) const {
    AsnLen elmtLen = bEncContent(b);
    elmtLen += BEncDefLen(b,elmtLen);
    elmtLen += BEncTag1(b,UNIV,PRIM,7);
    return elmtLen;
} // SDLObjectDescriptor::bEnc

void SDLObjectDescriptor::bDec(BUF_TYPE b,AsnLen& bytesDecoded) {
    AsnTag tagId = BDecTag1(b,bytesDecoded);
    AsnLen elmtLen;
    if (tagId != MAKE_TAG_ID(UNIV,PRIM,7)) { TagError(MAKE_TAG_ID(UNIV,PRIM,7),tagId); return; }
    elmtLen = BDecLen(b,bytesDecoded);
    AsnLen localBytesDecoded = 0;
    bDecContent(b,tagId,elmtLen,localBytesDecoded);
    bytesDecoded += localBytesDecoded;
} // SDLObjectDescriptor::bDec

