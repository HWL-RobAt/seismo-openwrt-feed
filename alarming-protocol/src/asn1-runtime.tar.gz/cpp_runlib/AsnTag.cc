/*******************************************************************************
*   vim:sw=2:ts=2:et
*
*   File    : AsnTag.cxx
*   Author  : Ralf Schr�der
*             Humboldt University Berlin
*             Department of Computer Science / System Analysis
*   e-mail  : r.schroeder@informatik.hu-berlin.de
*   Project : @vantage platform
*   $Date: 2005-05-05 17:38:41 +0200 (Thu, 05 May 2005) $
*   $Revision: 1.2 $
*
*******************************************************************************/
#include "BasicEncoding.h"
#include "SDLOctetString.h"

static const char* RCSID FRWUNUSED = "$Id: AsnTag.cc 554 2005-05-05 15:38:41Z tneumann $";

/*
 * Decode a BER Tag from the given buffer.  Error is
 * flagged if the tag is too long or if a read error occors.
 */
AsnTag
BDecTag ( BUF_TYPE  b, AsnLen& bytesDecoded)
{
    AsnTag tagId;
    AsnTag tmpTagId;
    size_t i;

    tagId = ((AsnTag) b.GetByte()) << ((sizeof(AsnTag)-1) *8);
    bytesDecoded++;

    /* check if long tag format (ie code > 31) */
    if ( (tagId & (((AsnTag) 0x1f) << ((sizeof(AsnTag)-1)*8))) ==
          (((AsnTag)0x1f) << ((sizeof(AsnTag)-1)*8)))
    {
        i = 2;
        do
        {
            tmpTagId = (AsnTag) b.GetByte();
            tagId |= (tmpTagId << ((sizeof(AsnTag)-i)*8));
            bytesDecoded++;
            i++;
        }
        while ((tmpTagId & (AsnTag)0x80) && (i < sizeof(AsnTag)));

        /*
         * check for too long a tag
         */
        if (i > (sizeof(AsnTag)+1))
          throw ASNTooBigToDecodeException("BDecTag: ERROR - tag value overflow\n");
    }

    return(tagId);

} /* BDecTag */

AsnLen
BEncTag(BUF_TYPE b, AsnTag tagId)
{
   if ((tagId & (((AsnTag) 0x1f) << ((sizeof(AsnTag)-1)*8)))
       != (((AsnTag)0x1f) << ((sizeof(AsnTag)-1)*8))){
      /* single byte tag */
      unsigned int byte = tagId >> ((sizeof(AsnTag)-1)*8);
      b.PutByteRvs((unsigned char)byte);
      return 1;
   }

   /* multibyte tag, MSB contains class and form,
      rest contains 7 bits per byte, terminated with byte that
      has high bit not set. */

   AsnTag len = 1;
   int shift;
   for(shift = (sizeof(AsnTag)-2)*8; shift>=0; shift-=8){
      unsigned int byte = (tagId>>shift) & 0x80;
      len++;
      if (!byte) break;
   }
   AsnTag ret = len;
   for(shift = (sizeof(AsnTag)-1)*8; len--; shift-=8){
      unsigned int byte = (tagId>>shift) & 0xFF;
      b.PutByteRvs((unsigned char)byte);
   }
   return ret;
}


void
remember_tag(SDLOctetString* o, AsnTag tagId)
{
   if ((tagId & (((AsnTag) 0x1f) << ((sizeof(AsnTag)-1)*8)))
       != (((AsnTag)0x1f) << ((sizeof(AsnTag)-1)*8))){
      /* single byte tag */
      unsigned int byte = tagId >> ((sizeof(AsnTag)-1)*8);
      /* XXX check out test case for -120 */
      *(o->extend(1)) = byte;
      return;
   }

   /* multibyte tag, MSB contains class and form,
      rest contains 7 bits per byte, terminated with byte that
      has high bit not set. */

   int len = 1;
   int shift;
   for(shift = (sizeof(AsnTag)-2)*8; shift>=0; shift-=8){
      unsigned int byte = (tagId>>shift) & 0x80;
      len++;
      if (!byte) break;
   }
   char *buf = o->extend(len);
   for(shift = (sizeof(AsnTag)-1)*8; len--; shift-=8){
      unsigned int byte = (tagId>>shift) & 0xFF;
      *buf = byte;
      buf++;
   }
}


void
remember_len(SDLOctetString* o, AsnLen len)
{
  unsigned char b[5];
  int l;
  // Modelled after BEncDefLen
  if (len == INDEFINITE_LEN){
    b[0] = 0x80;
    l = 1;
  }else if (len <= 128){
    b[0] = TO_UCHAR(len);
    l = 1;
  }else if (len < 256){
    b[0] = 0x81;
    b[1] = TO_UCHAR(len);
    l = 2;
  }else if (len < 65536){
    b[0] = 0x82;
    b[1] = TO_UCHAR(len >> 8);
    b[2] = TO_UCHAR(len);
    l = 3;
  }else if (len < 16777126){
    b[0] = 0x83;
    b[1] = TO_UCHAR(len >> 16);
    b[2] = TO_UCHAR(len >> 8);
    b[3] = TO_UCHAR(len);
    l = 4;
  }else{
    b[0] = 0x84;
    b[1] = TO_UCHAR(len>>24);
    b[2] = TO_UCHAR(len>>16);
    b[3] = TO_UCHAR(len>>8);
    b[4] = TO_UCHAR(len);
    l = 5;
  }
  char *dest = o->extend(l);
  memcpy(dest, b, l);
}

void
remember_data(SDLOctetString* o, BUF_TYPE b, AsnLen l)
{
   char *dest = o->extend(l);
   b.Copy(dest,TO_SIZE_T(l));
}
