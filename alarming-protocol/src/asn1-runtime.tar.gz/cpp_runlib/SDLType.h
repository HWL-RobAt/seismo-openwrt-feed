/*******************************************************************************
*   vim:sw=2:ts=2:et
*
*   File    : SDLType.h
*   Author  : Ralf Schr�der
*             Humboldt University Berlin
*             Department of Computer Science / System Analysis
*   e-mail  : r.schroeder@informatik.hu-berlin.de
*   Project : @vantage platform
*   $Date: 2006-04-04 13:14:09 +0200 (tir, 04 apr 2006) $
*   $Revision: 586 $
*
*******************************************************************************/
#ifndef _SDLTYPE_H
#define _SDLTYPE_H

#include <sstream>
#include "sdlconfig.h"
#include "SDLBaseImpl.h"

static const char* SDLTYPE_RCSID UNUSED = "$Id: SDLType.h 586 2006-04-04 11:14:09Z tneumann $";

/**@name State of a data object.
    The implementation for data states has been changed from Enums to
    bit patterns. Note, there are also internal patterns.
 */
//@{
typedef unsigned char ValueState;

/// default state
#define invalidValue     0x0

/// the value is a temporary C++ object, which ist deleted without other access
#define SITEtemporaryValue   0x1

/// the value was assigned
#define validValue       0x2

/// the value is read only
#define SITEconstValue   0x4

/// internally reserved, do never use this value
#define SITEreservedState1   0x8
/// internally reserved, do never use this value
#define SITEreservedState2   0x10
/// internally reserved, do never use this value
#define SITEreservedState3   0x20
/// internally reserved, do never use this value
#define SITEreservedState4   0x40
/// internally reserved, do never use this value
#define SITEreservedState5   0x80
//@}

/**@name Logging of a data object.
    The implementation for data logging is neither thread safe nor
    platform based. All information is printed to cerr.
    The logging assumes, that SITE_LOG is defined. The log interface is
    designed such that the SDLrunlib can be replaced without new C++ code
    generation and compilation. The log activation requires the
    setting of the bit mask SDLType::_type_debug. There is some code
    to do that in SDLType.cxx, if the runlib has to be changed temporary.
*/
//@{

/** Log low level BER activities. */
#define SITE_BER_LOG        0x01

/** Log all non dummy runlib operators "=". */
#define SITE_ASSIGNMENT_LOG 0x02

/** Log all non dummy copy constructors. */
#define SITE_COPY_LOG       0x04

/** Log exceptions raised with C++ throw. */
#define SITE_EXC_THROW_LOG  0x08

/** Activate platform tracing to cerr.
    Full switch activation only on system startup.
*/
#define SITE_TRACE2CERR_LOG 0x10

/** Log method calls. */
#define SITE_METHOD_LOG     0x20

/** Run a loop, if any SDL exception is raised. */
#define SITE_EXCEPTION_LOOP 0x40

/** Run a loop, only if an SDL assert is raised. */
#define SITE_ASSERT_LOOP    0x80

/** Activate address logging. */
#define SITE_ADDR_LOG       0x100


#ifdef SITE_LOG
// verify consistent flag usage
void SITE_LOG_defined();
#else
void SITE_LOG_undefined();
#endif
//@}

/** Kinds of SDL data objects */
enum SDLTypeId {
  TypeId_Unknown = -1,
  TypeId_Invalid,
  TypeId_SDLAny,
  TypeId_SDLNull,
  TypeId_SDLInt,
  TypeId_SDLBool,
  TypeId_SDLEnum,
  TypeId_SDLSequence,
  TypeId_SDLSequenceof,
  TypeId_SDLSet,
  TypeId_SDLSetof,
  TypeId_SDLChoice,
  TypeId_SDLReal,
  TypeId_SDLPId,
  TypeId_SDLBit,
  TypeId_SDLBitString,
  TypeId_SDLOctetString,
  TypeId_SDLIA5String,
  TypeId_SDLTime,
  TypeId_SDLDuration,
  TypeId_SDLOctet,
  TypeId_SDLChar,
  TypeId_SDLArray,
  TypeId_SDLObjectid,
  TypeId_SDLPowerset
};


// forward declarations
class SDLBool;
class SDLCharstring;
class SDLAny;


/** Abstract base class of all SDL data.
    Data types with primitive C++ type variants supports a val()
    method and a cast operation. The functionality of both methods
    is the same, in both cases a valid check is
    executed.

    General assumptions:<br>
    The init_type() method has to be called exclusivly for one object
    if the data type has to be used in a thread environment.
*/
class SDL_API SDLType
{
    /** Hold the state of the object.
        Supported states are implementation dependent.
    */
    ValueState _status;

  public:
    /** Static field to control debugging of types.
        SDL type logging and its control is not thread safe
        and it works only, if SITE_LOG is defined.
        SITE internal use only!
    */
    static int _type_debug;

    /** Raise an C++ based SDL exception.
        It should be used, if the raise method of SDLActiveObject is
        not available, e.g. within operators. Note, the SDLException
        is thrown as part of SDLPendingException.
        @param e SDL exception object, whereas the data parameters will be
                 copied internally before throw is called.
        @exception SDLPendingException
    */

    /** Access to the SDLType address of a data object.
        @return The adress of the data object.
        It is a compatibility method for multiple inheritance.
        SITE internal use only!
    */
    const SDLType* addr() const  { return this; }

    /** Verify the state of the data object.
        @param s the state (or bit mask) to verify.
        SITE internal use only!
    */
    bool state(ValueState s) const { return (s&_status)?true:false; }


    /** Basic initialization to invalid value */
    SDLType() : _status(invalidValue) {}

    /** Copy constructor.
        Copies the state.
    */
    SDLType(const SDLType& t) : _status(t._status) {}

    virtual ~SDLType();


    /** Initialize all static elements of the data type for running
        in a multi-thread environment.
        The generated code realizes a call chain with base type call
        at the end of the static method. If the method is not called,
        any access to static elements is realized with on-the-fly
        initialization.
    */
    virtual void init_type();

    /** Sets the state of a data object.
        @param s the new state.
        @exception SDLOperationNotImplemented for unknown state setting.
    */
    void set_state(ValueState s);

    /** Returns the state in an enum like way.
        @deprecated Use bool state(ValueState s) const, it is for
        backward compatibility of the code generator to RTE.
        SITE internal use only!
    */
    ValueState state() const {
      if (SDLType::state(validValue)) {
        return validValue;
      }
      return invalidValue;
    }

    /** Polymorphic deep copy.
        @return a new deep copied SDL object
    */
    virtual SDLType* copy()const =0;

    /** Polymorphic assignment.
        @precondition t not 0, compatible to this.
        @param t the value which has to be assigned to.
        @exception SDLException for assignment of invalid values.
    */
    virtual void assign(const SDLType* t);

    /** Non recursive valid check mainly for variables.
        It is not a range check, the value can be used for operations
        (especially encoding) without access errors. Only a valid
        variable with valid subcomponents, i.e. a valid SDL value,
        can be saved in the  platform context.
        @return true, if the data object is a valid one.
    */
    virtual bool valid()const ;

    /** SDL Valid operator.
        SDL access to bool valid()const.
    */
    const SDLBool& SDLValid()const;

    /** Range check.
        The range check realizes the range condition for a certain
        type. It does not work recursivly. A range check can only be
        used with valid SDL values.
    */
    virtual const SDLBool& check()const ;

    /** Exception based valid check.
        It is a compile time option to switch off the check.
        @exception SDLException if this is invalid.
        With compile time option -DNO_VALID the check is deactivated
        and the corresponding SDL exception is never thrown.
        Errors can crash the system in that case.
    */
    void check_valid() const
#ifdef NO_VALID
    {}
#else
    ;
#endif


    /** Encoding with tag and length
        @precondition b not 0.
        @param b The buffer object for encoding.
        @return The length of the encoded string.
        @exception SDLException for encoding errors (not implemented,
                   invalid values,...).
        @precondition b not 0, this is a valid SDL value.
        The method will be redefined, if the tag has been changed against
        the base type definition. It is a complete redefinition until the value
        content is reached (nested tagging!) to avoid complex nested calls
        and problems with implicit tagging.<br><br>

        The method has to be implemented to realize context save/restore
        of variables or value components of this type.
    */
    virtual AsnLen bEnc(BUF_TYPE b) const;

    virtual AsnLen pEnc(BUF_TYPE2 b) const;

    /** @depricated use bEnc */
    AsnLen BEnc(BUF_TYPE b);

    /** Encoding of the value without tag and length of this type.
        @precondition b not 0, this is valid.
        @param b The buffer object for encoding.
        @return The length of the encoded string.
        @exception SDLException for encoding errors (not implemented,
                   invalid values,...).
        The method has to be implemented to realize context save/restore
        of variables or value components of this type.
    */
    virtual AsnLen bEncContent(BUF_TYPE) const;

    /** @depricated use bEncContent */
    AsnLen BEncContent(BUF_TYPE);

    /** Decoding with tag and length.
        @precondition b not 0, this is a fresh created value.
        @param b The buffer object for the decoded value.
        @param bytesDecoded Reference to a byte counter.
        @exception SDLException for any kind of decode error.
        @postcondition bytesDecoded is increased by the number bytes,
          which was used for decoding.
        The method will be redefined, if the tag has been changed against
        the base type definition. It is a complete redefinition until the value
        content is reached (nested tagging!) to avoid complex nested calls
        and problems with implicit tagging.
        It is important, that there is no inner structure (as after a new).
        Otherwise the decoding has random side effects.
        <br><br>

        The method has to be implemented to realize context save/restore
        of variables or value components of this type.
    */
    virtual void bDec(BUF_TYPE b, AsnLen& bytesDecoded);

    virtual void pDec(BUF_TYPE2 b);

    /** @depricated use bDec */
    void BDec(BUF_TYPE b, AsnLen& bytesDecoded);

    /** Decoding of the value without tag and length of this type.
        @precondition b not 0, this is a fresh created value.
        @param b The buffer object for the decoded value.
        @param tag The last tag read; sometimes needed to identify the correct
		   content (choice).
        @param bytesToDecode The length of the value to decode; can be infinite.
        @param bytesDecoded Reference to a byte counter.
        @exception SDLException for any kind of decode error.
        @postcondition bytesDecoded is increased by the number of bytes,
                       which was used for decoding.
        It is important, that there is no inner structure (as after a new).
        Otherwise the decoding has random side effects.
        The method has to be implemented to realize context save/restore
        of variables or value components of this type.
    */
    virtual void bDecContent(BUF_TYPE b,AsnTag tag,AsnLen bytesToDecode,
                             AsnLen& bytesDecoded);

    /** @depricated use bDecContent */
    void BDecContent(BUF_TYPE b,AsnTag tag,AsnLen bytesToDecode,
                     AsnLen& bytesDecoded);


    /** Encoding on SDL level defined for all types.
        @exception SDLException for any kind of decode error.
    */
    SDLAny encode(AsnCodingSet rule_set=asn_ber) const;

    /** Creates an SDL Charstring with a printable version of the
        current object using Print.
        The support of that method depends on platform limitations.
        There is no guaranty for a certain format of the output.
    */
    SDLCharstring charstring() const ;

    /** Return the name of the data class definition. */
    virtual const char* name() const ;

    /** Reassign a fresh constructed value (empty construction).
        It may not work as expected for user defined data!
    */
    virtual void assign_new();

    /** Virtual object creation.
        The static method create is called on the corresponding
        level. SDLType::create_new can be seen as pure virtual
        method call, an SDL exception SDLOperationNotImplemented
        will be thrown.
    */
    virtual const SDLType* create_new() const;

    /** Parameter type to determine read and write for generic access methods.
    */
    enum infotype{info_get,info_put};

    /** Access to the kind of the object */
    virtual SDLTypeId sdl_type_id()const { return TypeId_Unknown; }

    /** Create a char string representation of the value object.
        It is an ASN.1 like value representation, whereas  a
        suitable indentation for complex values is realized on top level
        only. It is implemented for debugging purpose and can be changed
        without notification.
    */
    virtual void Print(std::ostream&)const;

    /** Hash function, used for Array keys.
        A data type, which is used as Array key should implement
        this method. Otherwise the Array access is a linear search.
        @param unsigned maximum of the hash value
    */
    virtual unsigned int hash(unsigned int)const { return 0; }

    /** Compares SDL objects of compatible types virtually.
        @precondition type compatibility, valid SDL values.
        @param type second to this compatible parameter.
        Test versions can support a type check.
    */
    virtual bool equal(const SDLType& type)const;

    /** Transfer the components from the given value into a
        temporary object, whereas the given argument becomes invalid.
        @val   content is moved to the return value.
        @return a new temporary object with content of val.
    */
    template<typename T>
    static  T transfer(const T& val)
    {
      T&v = SITE_CONST_CAST(T&,val);
      v.set_state(SITEtemporaryValue);
      T ret = v;
      v.assign_new();
      ret.set_state(SITEtemporaryValue);
      return ret;
    }

    /** SDL procedure to destroy the inner components of a value */
    const SDLBool& destroy() const;

    /** Writes the value of the type to a string stream. If a derived type
	doesn't implement this method, "NA" is written instead of the value.
	Invalid values are simply skipped.
	@param buf the string stream to write to
     */
    virtual void to_string(std::stringstream& buf) {buf<<"NA";}
  protected:
    void raise(SDLError* e) const;
};

/** Allows the use of ostream << operator for all SDL types */
SDL_API std::ostream& operator<<(std::ostream& os, const SDLType& a);

#include "SITELIB_declareSDLType_macro.h"
#include "declareSDLType_macro.h"
/** Backward macro compatibility for internal use only */

#define _declareSDLType SITELIB_declareSDLType

/** Empty value initialization.
    The implementation replaces the (mis)use of ASN.1 NULL.
    ASN.1 NULL will be changed to SDLNullType.
 */
class SDL_API SDLNull : public SDLType {
  public:
    declareSDLType(SDLNull,SDLType)
    SDLNull() {}
    virtual bool valid()const  {return false;}
    virtual SDLTypeId sdl_type_id()const;

    /** Prints <invalid value>. */
    virtual void Print(std::ostream&)const;
};

extern SDLNull theSDLNull;


#endif
