/*******************************************************************************
*   vim:sw=2:ts=2:et
*
*   File    : SDLSetofTemplate.h
*   Author  : Ralf Schr�der
*             Humboldt University Berlin
*             Department of Computer Science / System Analysis
*   e-mail  : r.schroeder@informatik.hu-berlin.de
*   Project : @vantage platform
*   $Date: 2005-05-05 17:38:41 +0200 (Thu, 05 May 2005) $
*   $Revision: 1.2 $
*
*******************************************************************************/
#ifndef _SDLSETOFTEMPLATE_H
#define _SDLSETOFTEMPLATE_H

// in case the user did not use SDLArray.h
#include "SDLSetof.h"

/** Template for SET OF.
    @param BAG the name of the first derived class (better performance)
    @param ELEM the name of the set element class
    An extra file is used because Reliant CC includes
    an existing cxx file implicitly.
*/
template <typename BAG, typename ELEM>
class SDL_API SDLSetof: public SDLSetofBase
{
    typedef SDLSetof<BAG,ELEM> self;

  protected:
    /* proto elem creation for context parementers (later) */
    ELEM* create_elem() const { return new ELEM; }

  private:
   /** Create an elem object as SDLType* */
    virtual SDLType* _create_elem() const { return create_elem(); }

  public:

    /** Constructor for an empty set */
    SDLSetof() {}

    /** Constructor for an omitted (invalid) value */
    SDLSetof(const SDLNull& n) :
      SDLSetofBase(n) {}

    /** Base constructor */
    SDLSetof(const SDLSetofBase&s)  :
      SDLSetofBase(s) {}

    /** Copy constructor */
    SDLSetof(const self& str) : SDLSetofBase(str) {}

    /** ELEM constructor */
    SDLSetof(const ELEM& elem, SITE_SDL_INT size = 1) :
      SDLSetofBase(elem,size) {}

  protected:
    /** Copy constructor with resize*/
    SDLSetof(const SDLSetof& str,SITE_SDL_INT reserve) :
      SDLSetofBase(str,reserve) {}

  public:
    /** SDL operations */
    //@{
    /** operator Incl */
    BAG incl(const ELEM& e) const
    {
      BAG ret(*this,1);
      ret._incl(e);
      ret.set_state(SITEtemporaryValue);
      return ret;
    }

    /** operator Del */
    BAG del(const ELEM& e) const
    {
      BAG ret = *this;
      ret._del(e);
      ret.set_state(SITEtemporaryValue);
      return ret;
    }

    /** operator Take */
    const ELEM& take()
    { return SITE_STATIC_CAST(const ELEM&,_take()); }

    /** operator "and" (intersection) */
    BAG _and(const BAG& b) const
    { BAG ret;
      ret._and2(*this,b);
      ret.set_state(SITEtemporaryValue);
      return ret;
    }

    /** operator "or" (unification) */
    BAG _or(const BAG& b) const
    { BAG ret(*this,b.lengthAsLong());
      ret._cat(b);
      ret.set_state(SITEtemporaryValue);
      return ret;
    }
    //@}

    /** Non standard SDL operator Modify with SITE expansion semantics.
        @exception SDLIndexError for negative index
        Missing elements are created on the fly. The string can be
        resized by that action. This semantics allows an initialization
        loop for strings (not allowed in standard SDL).
    */
    ELEM& operator()(SITE_SDL_INT i)
    { return SITE_STATIC_CAST(ELEM&,SDLStringBase::operator()(i-1)); }

    /** Non standard SDL operator Extract.
        @exception SDLIndexError for wrong access or the access to a hole.
    */
    const ELEM& operator[](SITE_SDL_INT i)const
    { return SITE_STATIC_CAST(const ELEM&,SDLStringBase::operator[](i-1)); }

  protected:
    /** Internal operator elem (for coding).
        The implementations resizes the internal buffer if necessary.
    */
    ELEM* elem(SITE_SDL_INT i)
    { return SITE_STATIC_CAST(ELEM*,_elem(i-1)); }

    /** Internal operator elem (for coding).
        The implementations resizes the internal buffer if necessary.
    */
    const ELEM* elem(SITE_SDL_INT i) const
    { return SITE_STATIC_CAST(
        ELEM*,SITE_CONST_CAST(self*,this)->_elem(i-1));
    }

};

#endif
