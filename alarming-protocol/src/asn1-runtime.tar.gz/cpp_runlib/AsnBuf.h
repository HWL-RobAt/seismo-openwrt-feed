/*******************************************************************************
*   vim:sw=2:ts=2:et
*
*   File    : AsnBuf.h
*   Author  : Ralf Schr�der
*             Humboldt University Berlin
*             Department of Computer Science / System Analysis
*   e-mail  : r.schroeder@informatik.hu-berlin.de
*   Project : @vantage platform
*   $Date: 2005-05-05 17:38:41 +0200 (Thu, 05 May 2005) $
*   $Revision: 1.3 $
*
*******************************************************************************/
#ifndef _ASNBUF_H
#define _ASNBUF_H

#include "BasicEncoding.h"
#include "SDLType.h"
#include <memory.h>

static const char* ASNBUF_RCSID FRWUNUSED = "$Id: AsnBuf.h 554 2005-05-05 15:38:41Z tneumann $";

typedef char* AsnBufCursor;

/** The ASN.1 buffer class.
    All methods are inline because of hight speed requirements.
    The encoding default size is ASN_BUF_SIZE. After that size,
    a realocation takes place with factor 4.
*/
class SDL_API AsnBuf
{
    /** my memory for encoded data */
    char*       data;

    /** size of data */
    size_t      len;

    /** True, if AsnBuf owns the data buffer */
    bool        own;

    /** pointer to the start of data */
    char       *cursor;

  public:

    /** Initialize for decoding from given buffer. */
    AsnBuf(char* buff, size_t l) :
      data(buff),len(l),own(false),cursor(data)
    {}

    /** Initialize for encoding */
    AsnBuf():
      data(new char[ASN_BUF_SIZE]),
      len(ASN_BUF_SIZE),
      own(true),
      cursor(data+len)
    {}

    ~AsnBuf() { if (own) delete[]data; }

    /** Return the buffer cursor position */
    AsnBufCursor get_cursor() const { return cursor; }

    /** Set back the cursor to c.
        @precondition The value of c must come from a previous cursor() call.
        @return the cursor movement (for simple checks)
        There are no consistency checks, be carefully!
    */
    int set_cursor(AsnBufCursor c) {
      int ret = cursor-c;
      cursor = c;
      return ret;
    }

    /** Set the bufer in encode mode, i.e. place the cursor at
        the end of the data buffer.
        It is possible to use the AsnBuf(char* buff, size_t l) constructor
        in combination with reset_encode() to avoid object creation.
        Note, after a resize, the internal buffer changes.
    */
    void reset_encode() { cursor = data+len; }

    /** Read a Byte from Buffer */
    unsigned char GetByte() {
      if (cursor == data+len) throw ASNLengthException("End of data");
      return *cursor++;
    }

    /** Returns true, if there is no more data */
    bool EndOfData() {
      return cursor == data+len;
    }

    /** Read copyLen Bytes from Buffer into dst.
        @exception ASNLengthException not enought bytes available
    */
    void Copy(char* dst, size_t copyLen);

    /** Write segLen bytes backwards.
        @exception ASNLengthException no more buffer
    */
    void PutSegRvs(char* c_seg, size_t segLen)
    {
      if (cursor-segLen+1 <= data) {
        increase_buffer();
        PutSegRvs(c_seg,segLen);
        return;
      }
      cursor -= segLen;
      memcpy(cursor,c_seg,segLen);
    }

    /** Write a byte backwards.
        @exception ASNLengthException no more buffer
    */
    void PutByteRvs(unsigned char c) {
      if (cursor == data) { increase_buffer(); }
      *(--cursor) = c;
    }

    /** If used as read-buffer it returns the remaining data bytes */
    size_t data_len() const { return len - (cursor-data); }

    /** for debugging only, prints the buff to cerr */
    void Print(size_t from=0, size_t to = 0) const;

    /** dynamic buffer increasement */
    void increase_buffer();
};

#endif

