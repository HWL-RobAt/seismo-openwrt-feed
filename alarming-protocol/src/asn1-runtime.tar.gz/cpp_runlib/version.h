/* ===== version.h ===== */

/* expected library version is hard coded */

#include "sdlversion.h"
#ifndef SDL_LIB_3_28
#error wrong SDL library version (3.28 expected)
#endif

#define SITE_CONSISTENCY_CHECK

