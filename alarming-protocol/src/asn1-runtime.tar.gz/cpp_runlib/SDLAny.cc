/*******************************************************************************
*   vim:sw=2:ts=2:et
*
*   File    : SDLAny.cxx
*   Author  : Ralf Schr�der
*             Humboldt University Berlin
*             Department of Computer Science / System Analysis
*   e-mail  : r.schroeder@informatik.hu-berlin.de
*   Project : @vantage platform
*   $Date: 2006-04-04 13:14:09 +0200 (tir, 04 apr 2006) $
*   $Revision: 586 $
*
*******************************************************************************/
#include "SDLAny.h"
#include "SDLOctetString.h"
#include "SDLBool.h"
#include "BasicEncoding.h"
#include "SITELIB_implementSDLType_macro.h"

#ifdef SITE_RCS_IDENT
static const char* RCSID FRWUNUSED = "$Id: SDLAny.cc 586 2006-04-04 11:14:09Z tneumann $";
#else
static const char* SCCSID FRWUNUSED = "@(#) ";
#endif

SITELIB_implementSDLType(SDLAny,SDLType)

SDLAny::SDLAny() :
  SDLType(),any_length(0),any_buf(0)
{}

SDLAny::SDLAny(const SDLOctetString& octs)  :
  SDLType(octs),
  any_length(octs.Len()),
  any_buf(any_length?(new char[TO_SIZE_T(any_length)]):0)
{
  if (any_length) memcpy (any_buf, (const char*)octs, TO_SIZE_T(any_length));
}

SDLAny::SDLAny(AsnBuf& b, AsnLen l) :
  SDLType(),
  any_length(l),
  any_buf(l?(new char[TO_SIZE_T(l)]):0)
{
  if (l) {
    b.Copy(any_buf, TO_SIZE_T(l));
  }
  set_state(validValue);
}

// l is the number of bits, not bytes!
SDLAny::SDLAny(pAsnBuf& p, AsnLen l) :
    SDLType(),
    any_length(l),
    any_buf(l?(new char[TO_SIZE_T(l)]):0)
{
    for (int i=0; i<l; i++)
      any_buf[i] = p.buf[i];
    set_state(validValue);
}

SDLAny::SDLAny(const SDLNull&) :
  SDLType(),any_length(0),any_buf(0)
{}

SDLAny::SDLAny(const SDLAny& a) :
  SDLType(a),
  any_length(a.any_length)
{
#ifdef SITE_LOG
  if (SDLType::_type_debug & SITE_COPY_LOG)
    std::cerr << "(SDLRTE) any copy of value "
              << a << std::endl;
#endif
  if(any_length){
    any_buf = new char[TO_SIZE_T(any_length)];
    memcpy(any_buf,a.any_buf,TO_SIZE_T(any_length));
  }
  else
    any_buf=0;
}


SDLAny::~SDLAny()
{
  delete [] any_buf; any_buf = 0;
  any_length = 0;
}


bool
SDLAny::valid()const
{ return state(validValue); }


AsnBuf*
SDLAny::initAsnBuf() const
{ return new AsnBuf(any_buf,TO_SIZE_T(any_length)); }

AsnLen
SDLAny::bEnc(BUF_TYPE b) const
{
#ifdef SITE_LOG
  if (SDLType::_type_debug & SITE_BER_LOG)
    std::cerr << "encode any value " << *this << std::endl;
#endif
  check_valid();
  b.PutSegRvs(any_buf, TO_SIZE_T(any_length));
  return  any_length;
}

void
//SDLAny::pDec(BUF_TYPE b, AsnLen& bytesDecoded)
SDLAny::pDec(BUF_TYPE2 b)
{
  std::cerr<<"pDec of Any not implemented"<<std::endl;
}
void
SDLAny::bDec(BUF_TYPE b, AsnLen& bytesDecoded)
{
    AsnBufCursor pos = b.get_cursor();  // hold my position
    AsnLen decoded=0;
    BDecTag(b,decoded);
    AsnLen len=BDecLen(b,decoded);
    len+=decoded;                       // len of tag+len+value
    b.set_cursor(pos);                  // reset the cursor
    delete [] any_buf;
    any_buf= new char[TO_SIZE_T(len)];
    any_length=len;
    b.Copy(any_buf, TO_SIZE_T(any_length));
    bytesDecoded+=len;
    set_state(validValue);
}

void
SDLAny::bDecContent(BUF_TYPE b,AsnTag tag,AsnLen bytesToDecode,
            AsnLen& bytesDecoded)
{
    AsnLen decoded = bytesToDecode;
    decoded += BEncDefLen(b,bytesToDecode);
    decoded += BEncTag(b,tag);
    delete [] any_buf;
    any_buf= new char[TO_SIZE_T(decoded)];
    any_length=decoded;
    b.Copy(any_buf, TO_SIZE_T(any_length));
    bytesDecoded+=bytesToDecode;
    set_state(validValue);
#ifdef SITE_LOG
  if (SDLType::_type_debug & SITE_BER_LOG)
    std::cerr << "decoded any value " << *this << std::endl;
#endif
}

SDLTypeId
SDLAny::sdl_type_id()const
{ return TypeId_SDLAny; }


void
SDLAny::Print(std::ostream& out)const
{
  if(!valid()) out << "<invalid value>";
  else {
    out << "-- ANY type with length: " << TO_SIZE_T(any_length) << " (";
    for(AsnLen i = 0; i < any_length; i++)
      out << INT2HEX(any_buf[i] >> 4) << (INT2HEX(any_buf[i]));
    out << ") -- ";
  }
}

unsigned int
SDLAny::hash(unsigned int max_hash)const
{
  unsigned int res=TO_UINT32(any_length);
  if(any_length) {
    res=(res+(unsigned int)any_buf[0]);
    res=(res+(unsigned int)any_buf[any_length/2]);
    res=(res+(unsigned int)any_buf[any_length-1]);
  }
  return res%max_hash;
}

SDLAny&
SDLAny::operator=(const SDLAny& a)
{
#ifdef SITE_LOG
  if (SDLType::_type_debug & SITE_ASSIGNMENT_LOG)
    std::cerr << "(SDLRTE) any assignment of " << a <<
            " to variable with value " << *this << std::endl;
#endif
  a.check_valid();
  if (this==&a) return *this;
  delete [] any_buf; any_buf = 0;
  any_length = a.any_length;
  if (a.any_buf) { // should be true
    any_buf = new char[TO_SIZE_T(any_length)];
    memcpy (any_buf, a.any_buf, TO_SIZE_T(any_length));
  }
  set_state(validValue);
  return *this;
}


SDLOctetString
SDLAny::octet_string()const
{
  check_valid();
  SDLOctetString res;
  res.Set(any_buf, any_length);
  return res;
}


SDLBool
SDLAny::eq(const SDLAny& a)const
{
  check_valid(); a.check_valid();
  return any_length==a.any_length &&
         (!any_length || memcmp(any_buf,a.any_buf,TO_SIZE_T(any_length))==0);
}


SDLBool
SDLAny::ne(const SDLAny& a)const
{
  check_valid(); a.check_valid();
  return any_length!=a.any_length ||
         (any_length && memcmp(any_buf,a.any_buf,TO_SIZE_T(any_length))!=0);
}

bool
SDLAny::equal(const SDLType& a) const
{
  return eq(SITE_DYNAMIC_CAST(const SDLAny&,a));
}

void
SDLAny::decode(SDLType* t, AsnCodingSet rule_set)const
{
//  std::cout<<"decoding"<<std::endl;
  check_valid();
  switch(rule_set){
    case asn_ber: {
      AsnLen bytesDecoded = 0;
      AsnBuf buf(any_buf,TO_SIZE_T(any_length));
      t->bDec(buf, bytesDecoded);
      if (bytesDecoded != any_length)
      {
	throw ASNLengthException("SDLAny::decode: length error");}
      break;
    }
    case asn_per: {
      pAsnBuf buffer(any_length);
      for(int i=0;i<any_length;i++) buffer.buf[i]=any_buf[i];
      t->pDec(buffer);
      break;
    }
    default: {
      throw SDLCodingError("unknown coding rule set requested for decoding");}
  }
//  std::cout<<"decoding finished"<<std::endl;
  t->set_state(validValue);
}

void
SDLAny::assign_new()
{
  delete [] any_buf; any_buf = 0;
  any_length = 0;
  SDLType::assign_new();
}
