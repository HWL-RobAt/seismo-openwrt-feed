/*******************************************************************************
*   vim:sw=2:ts=2:et
*
*   File    : SDLString.h
*   Author  : Ralf Schr�der
*             Humboldt University Berlin
*             Department of Computer Science / System Analysis
*   e-mail  : r.schroeder@informatik.hu-berlin.de
*   Project : @vantage platform
*   $Date: 2006-04-04 13:14:09 +0200 (tir, 04 apr 2006) $
*   $Revision: 586 $
*
*******************************************************************************/
#ifndef _SDLSTRING_H
#define _SDLSTRING_H

#include "SDLType.h"

#ifdef SITE_RCS_IDENT
static const char* SDLSTRING_RCSID FRWUNUSED = "$Id: SDLString.h 586 2006-04-04 11:14:09Z tneumann $";
#else
static const char* SDLSTRING_SCCSID FRWUNUSED = "@(#) ";
#endif

// forward declarations
class SDLBool;
class SDLInt;

/** Base class for SDL string template implementation.
    It contains implementations which have been moved from the template string
    class. It is the base of all ASN.1 SEQUENCE OF types and String, String0
    SDL generator applications.
*/
class SDLStringBase : public SDLType
{
    /** SDL length of the string */
    SITE_SDL_INT   _length;

    /** String elements */
    SDLType** _string;

    /** C++ size of _string */
    SITE_SDL_INT  _string_size;

  private:
    /** delete _string items */
    void del_elems() ;

    /** Abstract creation of an elem object */
    virtual SDLType* _create_elem() const = 0;

  public:
    /** Constructor for an empty string */
    SDLStringBase() ;

    /** Constructor for a given valid element value.
        @param e initialization value
        @param size number of elements to initialize
    */
    SDLStringBase(const SDLType& e, SITE_SDL_INT size = 1);

    /** Constructor for an omitted (invalid) value */
    SDLStringBase(const SDLNull&)  :
      _length(0),_string(0),_string_size(0)
	  {}

  protected:
    /** Copy constructor with resize */
    SDLStringBase(const SDLStringBase& str,SITE_SDL_INT reserve);

    /** Force a resize to new_len.
        This action can change the SDL length of the internal buffer
        to a suitable upper limit. In case of a cut, assigned elements
        may not be deleted!
        @param new_len the new length of the string.
    */
    void resize(SITE_SDL_INT new_len) ;

  public:
    /** Copy constructor.
        The constructor utilizes the temporary value flag.
     */
    SDLStringBase(const SDLStringBase& str) ;

    /** Clean up */
    virtual ~SDLStringBase() ;

    /** Non recursive valid check.
        @returns true, if the string object is a valid one.
    */
    virtual bool valid()const ;

    /** Encode for SEQUENCE OF ELEM */
    virtual AsnLen bEnc(BUF_TYPE b) const;

    /** Encode the string content */
    virtual AsnLen bEncContent(BUF_TYPE) const;

    /** Decode for SEQUENCE OF ELEM */
    virtual void bDec(BUF_TYPE b, AsnLen& bytesDecoded);

    /** Decode the string content */
    virtual void bDecContent(BUF_TYPE b,AsnTag tag,AsnLen bytesToDecode,
                             AsnLen& bytesDecoded);

    /** PER encoding of the bitstring */
    virtual AsnLen pEnc(BUF_TYPE2 b) const;

    /** PER decode of the given bitstring */
    virtual void pDec(BUF_TYPE2 b);

    /** Access to the kind of the object */
    virtual SDLTypeId sdl_type_id()const ;

  protected:
    /** Prints the string. */
    void _Print(std::ostream& out,SITE_SDL_INT start)const;

  public:
    /** Returns a hash value */
    virtual unsigned int hash(unsigned int)const ;

    /** Assignment operator (deep) for Strings.
        If (length of the target object >= length of source,
        then the target items may be reused (no new..., assign only)
        otherwise all target items will be deleted and the
        string is deep copied.
        @precondition all elements are valid, string holes are ignored.
    */
    SDLStringBase& operator=(const SDLStringBase& str);

    /** Return the elem array for direct manipulation.
        @postcondition the size cannot be changed.
    */
    SDLType** val() const { return _string; }

    /** SDL equality. */
    //@{
    const SDLBool& eq(const SDLStringBase& str)const;
    const SDLBool& ne(const SDLStringBase& str)const;

    /** Compares string objects.
        @param str a string object
        The dynamic cast failure is not caught because the code is
        generated correctly.
    */
    bool equal(const SDLType& str) const ;
    //@}

    /** SDL operations */
    //@{
    /** operator Length */
    SDLInt length()const;

    SITE_SDL_INT lengthAsLong() const { return _length; }

  protected:
    /** operator First.
        @exception SDLInvalidIndex if there is no first value.
    */
    const SDLType& first() const;

    /** operator last
        @exception SDLInvalidIndex if there is no last value.
    */
    const SDLType& last() const;

    /** method: this = this // str */
    void _cat(const SDLStringBase& str);

    /** operator Modify with SITE expansion semantics starting with 0.
        @exception SDLIndexError for negative index
        Missing elements are created on the fly. The string can be
        resized by that action. This semantics allows an initialization
        loop for strings (not allowed in standard SDL).
    */
    SDLType& operator()(SITE_SDL_INT);

    /** operator Extract starting with 0.
        @exception SDLIndexError for wrong access or the access to a hole.
    */
    const SDLType& operator[](SITE_SDL_INT)const ;

    /** Internal operator elem starting with 0.
        The implementation resizes the internal buffer if necessary.
    */
    SDLType* _elem(SITE_SDL_INT) ;

  public:
    SDLType* elem_as_type_starting_from_0(SITE_SDL_INT i)
    { return _elem(i); }

  protected:
    /** method SubString from src to this object.
      @param from start index from 0.
      @param len  size of the substring.
      @exception SDLIndexError if from or from+len are out of range
          or if len is negative (conforms with SDL, change from VESUV).
      @exception SDLException any other errors.
    */
    void _substr(const SDLStringBase&src, SITE_SDL_INT from,SITE_SDL_INT len);

    /** method cut */
    void _cut(SITE_SDL_INT index);
    //@}

  public:
    /** Delete the inner string */
    virtual void assign_new();

    /** Initialize the string type */
    virtual void init_type();
};

#include "SDLStringTemplate.h"

/**@name String generator application macros. */
//@{
/** alternative size evaluation of the code generator, not used */
#define declareSizeCheck()

/** alternative size evaluation of the code generator, not used */
#define implementSizeCheck(TYPE,CONSTRAINT)


/** Base class name for String */
#define StringTemplate(STRING,ELEM,EMPTY_LIT) \
  SDLStringTemplate<STRING,ELEM,1>

/** Base class name for String0 */
#define String0Template(STRING,ELEM,EMPTY_LIT) \
  SDLStringTemplate<STRING,ELEM,0>

/** Constructors for Strings */
#define StringTemplateConstruction(STRING,ELEM,ELEM_PROTO,EMPTY_LIT) \
public:\
  STRING(){ set_state(validValue); }\
  STRING(const char*){ set_state(validValue); }\
  STRING(const super& base):super(base){}\
  STRING(const STRING& base,SITE_SDL_INT reserve):super(base,reserve){}\
  STRING(const SDLNull& n):super(n){}\
  STRING(const ELEM& elem):super(elem){}\
  STRING& operator=(const STRING&str) {\
    return SITE_STATIC_CAST(STRING&,super::operator=(str));\
  }

/** Constructors for Strings with init call */
#define StringTemplateConstructionInit(STRING,ELEM,ELEM_PROTO,EMPTY_LIT) \
public:\
  STRING(){ init(); set_state(validValue); }\
  STRING(const char*){ init(); set_state(validValue); }\
  STRING(const super& base):super(base){ init(); }\
  STRING(const STRING& base,SITE_SDL_INT reserve):super(base,reserve){}\
  STRING(const SDLNull& n):super(n){ init(); }\
  STRING(const ELEM& elem):super(elem){ init(); }\

/* implied C++
  STRING& operator=(const STRING&str) {\
    return SITE_STATIC_CAST(STRING&,super::operator=(str));\
  }
*/

#define String0TemplateConstruction(STRING,ELEM,ELEM_PROTO,EMPTY_LIT) \
  StringTemplateConstruction(STRING,ELEM,ELEM_PROTO,EMPTY_LIT) \

#define String0TemplateConstructionInit(STRING,ELEM,ELEM_PROTO,EMPTY_LIT) \
  String0TemplateConstruction(STRING,ELEM,ELEM_PROTO,EMPTY_LIT) \

/** no special implementations for Strings */
#define StringTemplateDeclaration(STRING,ELEM,ELEM_PROTO,EMPTY_LIT) \
  declareSDLType(STRING,super)\
  static STRING EMPTY_LIT();\
  ELEM* create_elem() const;

#define String0TemplateDeclaration(STRING,ELEM,ELEM_PROTO,EMPTY_LIT) \
  declareSDLType(STRING,super)\
  static STRING EMPTY_LIT();\
  ELEM* create_elem() const;

#define StringTemplateImplementation(STRING,ELEM,ELEM_PROTO,EMPTY_LIT) \
 implementSDLType(STRING,STRING::super)\
 STRING STRING::EMPTY_LIT(){\
   return STRING();\
 }\
 ELEM* STRING::create_elem() const{\
   static ELEM *e = ELEM_PROTO;\
   return SITE_STATIC_CAST(ELEM*,e->copy());\
 }

#define String0TemplateImplementation(STRING,ELEM,ELEM_PROTO,EMPTY_LIT) \
 implementSDLType(STRING,STRING::super) \
 STRING STRING::EMPTY_LIT(){\
   return String();\
 }\
 ELEM* STRING::create_elem() const{\
   static ELEM *e = ELEM_PROTO;\
   return SITE_STATIC_CAST(ELEM*,e->copy());\
 }

//@}

#endif
