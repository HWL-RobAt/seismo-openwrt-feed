/*******************************************************************************
*   vim:sw=2:ts=2:et
*
*   File    : SDLCharstring.h
*   Author  : Ralf Schr�der
*             Humboldt University Berlin
*             Department of Computer Science / System Analysis
*   e-mail  : r.schroeder@informatik.hu-berlin.de
*   Project : @vantage platform
*   $Date: 2005-05-05 17:38:41 +0200 (Thu, 05 May 2005) $
*   $Revision: 1.6 $
*
*******************************************************************************/
#ifndef _SDLCHARSTRING_H
#define _SDLCHARSTRING_H

#include "SDLType.h"

#ifdef SITE_RCS_IDENT
static const char* SDLCHARSTRING_RCSID FRWUNUSED = "$Id: SDLCharstring.h 554 2005-05-05 15:38:41Z tneumann $";
#else
static const char* SDLCHARSTRING_SCCSID FRWUNUSED = "@(#) ";
#endif

// forward declarations
class SDLBool;
class SDLInt;
class SDLChar;
class SDLAny;

/** SDL Charstring.
    Implementation uses a growing buffer with intelligence.
    Warning, each implementation has to attend the 0 termination -
    this is a non SDL feature with high bug propability!
*/
class SDL_API SDLCharstring : public SDLType
{
  protected: // this is needed for generated asn per coding
    /** SDL length of the string.
        It is important to hold this value because 0 can be part of the
        string.
    */
    SITE_SDL_INT   _length;

    /** C++ string (position _length+1 is a 0) */
    char* _string;

    /** C++ size of _string; _string_size > _length is true */
    SITE_SDL_INT  _string_size;

  private:
    /** This realizes char modify access */
    class SDLCharRef {
      char *_string;
    public:
      SDLCharRef(char* string):_string(string) {}
      void operator=(char c)  {
        _string[0] = c;
      }
    };


  public:
    /* Call of generated macro for code shared by all declarations of SDL types
     */
    declareSDLType(SDLCharstring,SDLType)

    /** Constructor for an invalid value */
    SDLCharstring() ;

    /** Constructor for MkString variants.
        @param c initialization value
        @param size number of elements to initialize with c
    */
    SDLCharstring(char c, SITE_SDL_INT size = 1) ;

    /** Constructor for a given string.
        @param str initialization value (will be copied), if str is 0
               then the elems are initializied with 0.
        @param size optional SDL size of str; if negative,
               C++ strlen(str) is used.
        @param no_copy str is used without copy (C literal).
        @precondition size is inbound of str.
        @precondition if no_copy==true then size==sizeof(str)
    */
    SDLCharstring(const char* str, SITE_SDL_INT size = -1,bool no_copy=false);

    /** Constructor for an omitted (invalid) value */
    SDLCharstring(const SDLNull&) :
      _length(0),_string(0),_string_size(0)
    {}

  private:
    /** Direct string construction.
        @param str, created with new char[], now owned.
        @param size of the string (= C++ size -1 because of terminating 0)
        @precondition str!=0, C++ length == size+1, 0 terminated
    */
    SDLCharstring(char* str,SITE_SDL_INT size) :
      _length(size),_string(str),_string_size(size+1)
    { set_state(validValue); }

    /** Copy constructor with resize. */
    SDLCharstring(const SDLCharstring& str,SITE_SDL_INT reserve) ;

    /** Force a resize to new_len.
        This action can change the length of the internal buffer
        to a suitable upper limit.
    */
    void resize(SITE_SDL_INT new_len) ;

  public:
    /** Copy constructor */
    SDLCharstring(const SDLCharstring& str) ;

    /** Clean up */
    virtual ~SDLCharstring() ;


    /** Valid check.
        @return true, if the string object is a valid one.
        It can be configured to switch off this test.
    */
    virtual bool valid()const ;

    /** Encoding as IA5String */
    AsnLen bEnc(BUF_TYPE) const;

    /** Encoding of the string value without tag and length */
    virtual AsnLen bEncContent(BUF_TYPE) const;

    /** Decoding as IA5String */
    void bDec(BUF_TYPE,AsnLen&);

    /** Decoding of the string value without tag and length */
    virtual void bDecContent(BUF_TYPE,AsnTag,AsnLen,AsnLen&);

    /** PER encoding as IA5String */
    virtual AsnLen pEnc(BUF_TYPE2 b) const;

    /** PER decode as IA5String */
    virtual void pDec(BUF_TYPE2 b);

    /** Access to the kind of the object */
    virtual SDLTypeId sdl_type_id()const ;

    /** Prints the string. */
    virtual void Print(std::ostream&)const;

    /** Writes the represented value to the string stream. Does nothing if
	invalid. */
    void to_string(std::stringstream& buf);

    /** Returns a hash value */
    virtual unsigned int hash(unsigned int)const;

    /** Assignment operator (deep) for Strings.
        If (length of the target object >= length of source,
        then the target items will be reused (no new..., assign only)
        otherwise all target items will be deleted and the
        string is deep copied.
    */
    SDLCharstring& operator=(const SDLCharstring& str);

    /** Cast operator for const char*.
        @return the pointer of the inner buffer
    */
    operator const char*() const
    { check_valid(); return _string?_string:""; }

    /** Explicit value access.
        @return the pointer of the inner buffer
    */
    const char* val() const { return _string?_string:""; }

    /** SDL equality. */
    //@{
    const SDLBool& eq(const SDLCharstring& str)const;
    const SDLBool& ne(const SDLCharstring& str)const;

    /** Compares string objects.
        @param str a string object
        The dynamic cast failure is not caught because the code is
        generated correctly.
    */
    bool equal(const SDLType& str) const ;
    //@}

    /** SDL operations */
    //@{
    /** operator Length */
    SDLInt length()const ;

    /** operator Length without int object */
    SITE_SDL_INT lengthAsLong() const { return _length; }

    /** operator First */
    SDLChar first() const;

    /** operator last */
    SDLChar last() const;

    /** operator "//" */
    SDLCharstring cat(const SDLCharstring& str) const;

    /** method "//" */
    void _cat(const SDLCharstring& str);

    /** operator Modify; (SITE expansion semantics)
        @exception SDLIndexError for negative index errors
        If the index is larger than the length, the string is expanded.
        Missing chars are filled with char 0.
    */
    SDLCharRef operator()(SITE_SDL_INT);

    /** operator Extract (returns a copy of the char element).
        @exception SDLInvalidIndex if the index is out of range.
    */
    const SDLChar operator[](SITE_SDL_INT)const;

#if SITE_SDL_INT_SIZE==64
    /** operator Extract (returns a copy of the char element).
        @exception SDLInvalidIndex if the index is out of range.
        Operator introduced because of ambiguous overload
        c[2] resolvable as operator[]((long long)2) or (char*(c))[2].
    */
    const SDLChar operator[](int)const;
#endif

    /** operator SubString.
      @param from start index.
      @param len  size of the substring.
      @exception SDLIndexError if from or from+len are out of range
          or if len is negative (SDL conform, change from VESUV).
      @exception SDLException any other errors.
    */
    SDLCharstring substr(SITE_SDL_INT from,SITE_SDL_INT len) const;


    /** Cut out the specified index for the new returned string */
    SDLCharstring cut(SITE_SDL_INT index) const;
    //@}

    /** Direct, unsave C++ field assignment, starts with 0.
        @param pos set a value in range [0,lengthAsLong()-1], crash else.
        @param c new value
        This method can imply a copy on write for the internal string.
    */
    void Set(SITE_SDL_INT pos,char c);

    /** Direct C++ field access, starts with 0.
        @param pos get a value in range [0,lengthAsLong()-1], random value else.
    */
    char Get(SITE_SDL_INT pos) const;

    /** Delete the internal charstring */
    virtual void assign_new();

  private:
    /** Help method for constructed encoding. */
    void BDecConsString (BUF_TYPE, AsnLen, AsnLen&);

};

#endif
