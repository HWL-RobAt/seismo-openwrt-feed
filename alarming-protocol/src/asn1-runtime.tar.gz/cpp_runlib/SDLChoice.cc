/*******************************************************************************
*   vim:sw=2:ts=2:et
*
*   File    : SDLChoice.cxx
*   Author  : Ralf Schr�der and Martin von L�wis
*             Humboldt University Berlin
*             Department of Computer Science / System Analysis
*   e-mail  : r.schroeder@informatik.hu-berlin.de
*   Project : @vantage platform
*   $Date: 2005-05-05 17:38:41 +0200 (Thu, 05 May 2005) $
*   $Revision: 1.3 $
*
*******************************************************************************/
#include "SDLPredefined.h"
#include "SDLChoice.h"

#ifdef SITE_RCS_IDENT
static const char* RCSID FRWUNUSED = "$Id: SDLChoice.cc 554 2005-05-05 15:38:41Z tneumann $";
#else
static const char* SCCSID FRWUNUSED = "@(#) ";
#endif

SDLChoice::SDLChoice()  :
  _u(0),_present(0)
{ set_state(validValue); }

SDLChoice::SDLChoice(SITE_SDL_INT variant, const SDLType& val)  :
  _present(variant)
{
  val.check_valid();
  _u = val.copy();
  set_state(validValue);
}

SDLChoice::SDLChoice(const SDLNull&)  :
  _u(0),_present(0)
{ set_state(validValue); }

SDLChoice::SDLChoice(const SDLChoice& c)  :
  SDLType(c),_present(c._present)
{
  if(c.state(SITEtemporaryValue)){
#ifdef SITE_LOG
    if (SDLType::_type_debug & SITE_COPY_LOG)
      std::cerr << "(SDLRTE) choice reference copy of value "
                << c << std::endl;
#endif
    _u=c._u;
    ((SDLChoice&)c)._u=0;
  } else {
#ifdef SITE_LOG
    if (SDLType::_type_debug & SITE_COPY_LOG)
      std::cerr << "(SDLRTE) choice copy of value "
                << c << std::endl;
#endif
    _u=c._u?c._u->copy():0;
  }
}

SDLChoice::~SDLChoice()
{
  delete _u; _u = 0;
}


bool SDLChoice::valid()const
{
  return _u!=0;
}

SDLTypeId
SDLChoice::sdl_type_id()const
{ return TypeId_SDLChoice; }


void
SDLChoice::Print(std::ostream& out)const
{
  out << "-- CHOICE ";
  if(!_u)
    out << "<invalid value>";
  else {
    SDLType *field;
    SDLIA5String field_type, field_name;
    SDLChoice *me = SITE_CONST_CAST(SDLChoice*,this);
    me->datainfo(TO_LONG(_present),field_name,field_type,field,SDLType::info_get);
    out << field_name << " of type " << field_type << "-- ";
    _u->Print(out);
  }
}

unsigned int
SDLChoice::hash(unsigned int max_hash)const
{
  if(_u) return _u->hash(max_hash);
  return 0;
}


SDLChoice&
SDLChoice::operator=(const SDLChoice& c)
{
#ifdef SITE_LOG
  if (SDLType::_type_debug & SITE_ASSIGNMENT_LOG)
    std::cerr << "(SDLRTE) choice assignment of " << c <<
                 " to variable with value " << *this << std::endl;
#endif
  c.check_valid();
  if (this==&c) return *this;
  if (c._u) {
    if(c.state(SITEtemporaryValue)){
      _u=c._u;
      ((SDLChoice&)c)._u=0;
      _present = c._present;
    } else {
      assign_field(TO_UINT32(c._present),*c._u);
    }
  } else {
    delete _u; _u=0;
  }
  set_state(validValue); set_state(~SITEtemporaryValue);
  return *this;
}

void
SDLChoice::assign_field(unsigned int variant,const SDLType& elem)
{
  elem.check_valid();
  _present = variant;
  delete _u; _u = elem.copy();
}

const SDLBool&
SDLChoice::eq(const SDLChoice& c)const
{
  check_valid(); c.check_valid();
  if (_present == c._present && _u->equal(*c._u))
    return SDLBool::SDLTrue();
  return SDLBool::SDLFalse();
}

const SDLBool&
SDLChoice::ne(const SDLChoice& c)const
{
  check_valid(); c.check_valid();
  if (_present == c._present && _u->equal(*c._u))
    return SDLBool::SDLFalse();
  return SDLBool::SDLTrue();
}

bool
SDLChoice::equal(const SDLType& c)const
{
  check_valid(); c.check_valid();
  const SDLChoice& my_c = SITE_DYNAMIC_CAST(const SDLChoice&,c);
  if (_present == my_c._present && _u->equal(*my_c._u))
    return true;
  return false;
}

SDLInt
SDLChoice::present()const
{
  check_valid();
  return _present;
}

const SDLBool&
SDLChoice::present(SITE_SDL_INT v)
{
  check_valid();
  return (v == _present)?SDLBool::SDLTrue():SDLBool::SDLFalse();
}


bool
SDLChoice::datainfo(long,SDLIA5String&,SDLIA5String&,SDLType*&,infotype)
{ return false; }

void
SDLChoice::assign_new()
{
  delete _u; _u = 0;
  // no call for SDLType, status remains valid!
}

void
SDLChoice::BDecRememberField(BUF_TYPE b, AsnLen &local, AsnTag tagId,
                             AsnLen len)
{
   delete _u;
   _u = new SDLOctetString();
   _u->set_state(validValue);
   remember_tag(SITE_STATIC_CAST(SDLOctetString*,_u),tagId);
   remember_len(SITE_STATIC_CAST(SDLOctetString*,_u),len);
   if (len != INDEFINITE_LEN)
   {
      /* A field that has a definite length.
         the next field, which might be EOC. */
      remember_data(SITE_STATIC_CAST(SDLOctetString*,_u),b,len);
      local += len;
      return;
   }
   /* For infinite len, the variant must be constructed, check that! */
   if (!TAG_IS_CONS (tagId))
      TagError (MAKE_TAG_ID (UNIV, CONS, 16), tagId); /* any constructed field would have done. */
   remember_infinit_data(b,local);
}

// Encode {tag len value}* until EOC is found
void
SDLChoice::remember_infinit_data(BUF_TYPE b, AsnLen &local)
{
   AsnTag tagId = BDecTag (b, local);
   while (tagId != EOC_TAG_ID) {
      AsnLen len = BDecLen(b, local);
      remember_tag(SITE_STATIC_CAST(SDLOctetString*,_u),tagId);
      remember_len(SITE_STATIC_CAST(SDLOctetString*,_u),len);
      if (len != INDEFINITE_LEN) {
        remember_data(SITE_STATIC_CAST(SDLOctetString*,_u),b,len);
        local += len;
      } else {
        // a recursive infinit coding, check that it is constructed!
        if (!TAG_IS_CONS (tagId))
          TagError (MAKE_TAG_ID (UNIV, CONS, 16), tagId);
         // any constructed field would have done.
        remember_infinit_data(b,local);
      }
      tagId = BDecTag (b,local);
   }

   /* Now we eventually found the EOC. */
   BDEC_2ND_EOC_OCTET (b, local);
   remember_tag(SITE_STATIC_CAST(SDLOctetString*,_u),EOC_TAG_ID);
   remember_len(SITE_STATIC_CAST(SDLOctetString*,_u),0);
}
