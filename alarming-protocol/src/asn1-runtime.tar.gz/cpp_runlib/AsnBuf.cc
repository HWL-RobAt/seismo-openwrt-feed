/*******************************************************************************
*   vim:sw=2:ts=2:et
*
*   File    : AsnBuf.cxx
*   Author  : Ralf Schr�der
*             Humboldt University Berlin
*             Department of Computer Science / System Analysis
*   e-mail  : r.schroeder@informatik.hu-berlin.de
*   Project : @vantage platform
*   $Date: 2005-05-05 17:38:41 +0200 (Thu, 05 May 2005) $
*   $Revision: 1.3 $
*
*******************************************************************************/
#include "AsnBuf.h"

static const char* RCSID FRWUNUSED = "$Id: AsnBuf.cc 554 2005-05-05 15:38:41Z tneumann $";


void
AsnBuf::Copy(char* dst, size_t copyLen)
{
  while (cursor+copyLen > data+len) {
    if (cursor == data+len) throw ASNLengthException("End of data");
    else {
      unsigned long partial_len = data+len-cursor;
      memcpy(dst,cursor,partial_len);
      cursor += partial_len;
      dst += partial_len;
      copyLen -= partial_len;
      throw ASNLengthException("End of data");
    }
  }
  memcpy(dst,cursor,copyLen);
  cursor += copyLen;
}


void
AsnBuf::increase_buffer()
{
  size_t new_len = 4*len;
  char* new_buf = new char[new_len];
  if (!new_buf)
    throw ASNLengthException("message buffer overflow");
  memcpy(new_buf+new_len-data_len(),cursor,data_len());
  cursor = new_buf + new_len - data_len();
  if (own) delete data; data = new_buf;
#ifdef SITE_LOG
  if (SDLType::_type_debug & SITE_BER_LOG) {
    std::cerr << "ASN.1 buffer reallocation from " << len
         << " to " << new_len << " bytes" << std::endl;
  }
#endif
  len = new_len;
  own = true;
}

#include <iomanip>

#define HEX std::hex
#define SETW(W) std::setw(W)
#define SETFILL(F) std::setfill(F)
#define DEC std::dec

void
AsnBuf::Print(size_t from, size_t to) const
{
  std::cerr
    << "own data   : " << (own?"yes":"no") << "\n"
    << "buffer len : " << len << "\n"
    << "data len   : " << data_len() << "\n"
    << "data cursor: " << (cursor-data) << std::endl;

  if (from == 0 && to == 0) {
    from = cursor-data; to = len;
  }
  if (from >= to) return;
  for(int i=1; from <= to; i++,from++) {
    if (from>=len) break;
    std::cerr << HEX << SETW(2) << SETFILL('0')
              << ((int)((unsigned char)data[from])) << " ";
    if (i==16) { i=0; std::cerr << "\n"; }
  }
  std::cerr << DEC << std::endl;
}
