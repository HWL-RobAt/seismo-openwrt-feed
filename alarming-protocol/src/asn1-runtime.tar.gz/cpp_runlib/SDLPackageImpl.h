/*******************************************************************************
*
*   File    : SDLPackageImpl.h
*   Author  : Frank Bielig, Toby Neumann
*             Humboldt University Berlin
*             Department of Computer Science / System Analysis
*   e-mail  : tneumann@informatik.hu-berlin.de
*   Project : SITE4Cinderella
*   $Date: 2005-05-05 17:38:41 +0200 (Thu, 05 May 2005) $
*   $Revision: 1.6 $
*
*******************************************************************************/
#ifndef _SDL_PACKAGE_IMPL_H
#define _SDL_PACKAGE_IMPL_H

//#include "SDLScopeImpl.h"
#include "SDLType.h"
#include "SDLPredefined.h"


#define declareSDLPackage(Pkg)

#define implementSDLPackage(Pkg)

#define implementSDLPackageLib(Pkg)

#define implementASNPackageLib(Pkg)

/** The abstract base class for SDL packages.
 */
class SDLPackageImpl
{
 public:

  /** Constructs a new SDL package.
      @param name the package name
   */
  SDLPackageImpl(const char* name)
    //:SDLScopeImpl(name,(SDLScopeImpl*)0)
    {}

  /** Virtual clean up. Empty. */
  virtual ~SDLPackageImpl(){}

  /** Initializes the package contents. The init function of packages in
      the generated code implements the actual initialization.
   */
  virtual void init(){};

  /** Gives access to contained data objects. These objects are sorted by
      index. This function could be used for simulation purposes.
      The actual access will be generated code in derived classes.
      @param index the index of the data object to access
      @param var_name the memory to hold the SDL name of the variable at the
		      specified index
      @param var_type the memory to hold the SDL type name of the variable at
		      the specified index
      @param var the memory to hold a pointer to the data object at the
		 specified index
      @returns false if the index is invalid; true otherwise
   */
  virtual bool			    datainfo(long index, SDLIA5String& var_name,
					SDLIA5String& var_type, SDLType*& var);

 protected:
  /** A string containing the code generator options which have been used for
        the generation of this component but only if they differ from the
        default. The value is set by the code generator in generated code. */
  const char* _non_standard_compilation_option;
};

typedef SDLPackageImpl		  SDLPackage;

#endif /*_SDL_PACKAGE_IMPL_H */
