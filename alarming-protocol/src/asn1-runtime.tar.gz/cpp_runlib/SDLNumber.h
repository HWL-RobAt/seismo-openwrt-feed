/*******************************************************************************
*   vim:sw=2:ts=2:et
*
*   File    : SDLNumber.h
*   Author  : Ralf Schr�der
*             Humboldt University Berlin
*             Department of Computer Science / System Analysis
*   e-mail  : r.schroeder@informatik.hu-berlin.de
*   Project : @vantage platform
*   $Date: 2006-04-04 13:14:09 +0200 (tir, 04 apr 2006) $
*   $Revision: 586 $
*
*******************************************************************************/

#ifndef SDLNumber
#error "do never include SDLNumber stand alone"
#endif

#ifdef SITE_RCS_IDENT
static const char* ID FRWUNUSED = "$Id: SDLNumber.h 586 2006-04-04 11:14:09Z tneumann $";
#else
static const char* ID FRWUNUSED = "@(#) ";
#endif

#include "SDLType.h"
#include "SDLBool.h"

// forward declarations
class SDLChar;
class SDLAny;
class SDLReal;
class SDLIA5String;

/** SDL Integer class.
    The size of the supported C int type has to be configured with
    C_INT up to 64 bit. The implementation has to be realized
    highly efficient, because SDLNumber objects are the most often created
    temporary objects.
*/
class SDL_API SDLNumber : public SDLType
{
  protected:
    /** Hold the integer value. */
    C_INT _value;

  public:
    /* Call of generated macro for code shared by all declarations of SDL types
     */
    declareSDLType(SDLNumber,SDLType)

    /** Constructor for an invalid value */
    SDLNumber() : _value(0) {}

    /** Constructor for a given valid value */
    SDLNumber(C_INT i) : _value(i)
    { set_state(validValue); }

    /** Constructor for an omitted (invalid) value */
    SDLNumber(const SDLNull&) : _value(0) {}

    /** Copy constructor */
    SDLNumber(const SDLNumber& i) :
      SDLType(i),_value(i._value)
    {
#ifdef SITE_LOG
      if (SDLType::_type_debug & SITE_COPY_LOG)
        std::cerr << "(SDLRTE) int/enum copy of value "
             << i << std::endl;
#endif
    }

    /** Initialize all literals for running in a multi-thread environment.
        If the method is not called, any literal access is realized with
        on-the-fly literal initialization. The correctness in a multi-thread
        environment depends on the used compiler.
    */
    virtual void init_type();

    /** Valid check.
        @return true, if the data object is a valid one.
    */
    virtual bool valid()const;

    /** ASN1 PER encoding of a number.
        @param octBuf the buffer the encoding is written to
     */
    AsnLen pEnc(pAsnBuf& octBuf)const;

    /** ASN1 PER decoding of a number.
        @param octBuf the buffer the bytes are read from
     */
    void pDec(pAsnBuf& octBuf);

    /** ASN1 BER encoding of a number with tag and length */
    virtual AsnLen bEnc(BUF_TYPE b) const;

    /** Decoding of a number with tag and length */
    virtual void bDec(BUF_TYPE b, AsnLen& bytesDecoded);

    /** Encoding of a number without tag and length */
    virtual AsnLen bEncContent(BUF_TYPE) const;

    /** Decoding of a number without tag and length */
    virtual void bDecContent(BUF_TYPE,AsnTag,AsnLen,AsnLen&);

    /** Prints the number. */
    virtual void Print(std::ostream&)const;

    /** Returns a hash value. */
    virtual unsigned int hash(unsigned int max)const;

    /** Assignment operator for simple values.
        Has to be present as best match.
    */
    SDLNumber& operator=(C_INT l)
    {
#ifdef SITE_LOG
      if (SDLType::_type_debug & SITE_ASSIGNMENT_LOG)
        std::cerr << "(SDLRTE) primitive int/enum assignment of " << l <<
                " to variable with value " << *this << std::endl;
#endif
      _value=l; set_state(validValue); return *this;
    }

    /** Assignment operator.
        If not present, 'uninitialized access' errors for allignment space.
    */
    SDLNumber& operator=(const SDLNumber& i)
    {
#ifdef SITE_LOG
      if (SDLType::_type_debug & SITE_ASSIGNMENT_LOG)
        std::cerr << "(SDLRTE) int/enum assignment of " << i <<
                " to variable with value " << *this << std::endl;
#endif
      _value=i.val(); set_state(validValue); return *this;
    }

    /** Cast operator to C++ inline C_INT */
    operator C_INT() const
    { if (!state(validValue)) check_valid(); return _value; }

    /** Explicit value access. */
    C_INT val()const { return C_INT(*this); }

    /** SDL equality. */
    //@{
    const SDLBool& eq(C_INT l)const
    { return (val()==l)?SDLBool::SDLTrue():SDLBool::SDLFalse(); }

    const SDLBool& ne(C_INT l)const
    { return (val()!=l)?SDLBool::SDLTrue():SDLBool::SDLFalse(); }

    /** Compares integer objects.
        @param b an integer object
        The dynamic cast failure is not caught because the code is
        generated correctly.
    */
    bool equal(const SDLType& b) const;

    //@}

    /** SDL standard operations */
    //@{
    SDLNumber add(C_INT l)const;
    SDLNumber sub(C_INT l)const;
    SDLNumber mul(C_INT l)const;
    SDLNumber div(C_INT l)const;
    SDLNumber rem(C_INT l)const;
    SDLNumber mod(C_INT l)const;
    SDLNumber neg()const;

    void inc(C_INT l)
    { if (!state(validValue)) check_valid(); _value += l; }

    const SDLBool& lt(C_INT l)const
    { return (val()<l)?SDLBool::SDLTrue():SDLBool::SDLFalse(); }

    const SDLBool& gt(C_INT l)const
    { return (val()>l)?SDLBool::SDLTrue():SDLBool::SDLFalse(); }

    const SDLBool& le(C_INT l)const
    { return (val()<=l)?SDLBool::SDLTrue():SDLBool::SDLFalse(); }

    const SDLBool& ge(C_INT l)const
    { return (val()>=l)?SDLBool::SDLTrue():SDLBool::SDLFalse(); }


    /** generate a random value in the range */
    static SDLNumber Any(C_INT,C_INT);

    static SDLNumber Any();

    /** operator Float */
    SDLReal op_float()const;

    /** operator Chr of SDL Character */
    SDLChar chr()const;
    //@}

    /** Access to the kind of the object */
    virtual SDLTypeId sdl_type_id()const;

    /** Generic literal access.
        @param pos position of the literal, starts from 1.
        @param val the literal singleton.
        @param val the int value of the literal.
        @return true if there is a literal at the given position.
    */
    virtual bool get_literal(int pos,const SDLNumber** val,C_INT* i)const;

    /** Return the number of symbolic literals. */
    virtual int nr_literals()const;

    /** Gives access to named literals of derived (ASN.1) types.
	      This function could be used for simulation purposes.
        The actual access will be generated code in derived classes.
        @param index the index of the literal to access (starting at 1)
        @param lit_name the memory to hold the literal name
        @param literal the memory to hold a pointer to the literal
        @return true if there is a literal at the specified index
     */
    virtual bool datainfo(long index, SDLIA5String& lit_name,
	      const SDLType*& literal)const;

    /** Writes the represented value to the string stream. Does nothing if
	      invalid. */
    void to_string(std::stringstream& buf);
};
