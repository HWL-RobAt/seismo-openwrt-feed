/*******************************************************************************
*   vim:sw=2:ts=2:et
*
*   File    : SDLEnum.cxx
*   Author  : Ralf Schr�der
*             Humboldt University Berlin
*             Department of Computer Science / System Analysis
*   e-mail  : r.schroeder@informatik.hu-berlin.de
*   Project : @vantage platform
*   $Date: 2005-05-05 17:38:41 +0200 (Thu, 05 May 2005) $
*   $Revision: 1.4 $
*
*******************************************************************************/
#include "sdlconfig.h"

#ifdef SITE_RCS_IDENT
static const char* RCSID FRWUNUSED = "$Id: SDLEnum.cc 554 2005-05-05 15:38:41Z tneumann $";
#else
static const char* SCCSID FRWUNUSED = "@(#) ";
#endif

#include "SDLEnum.h"
#include "SDLInt.h"
#include "AsnTag.h"

#define C_INT long
#define SDLNumber SDLEnumBase
#define ID SDLEnumBase_ID
#define get_literal _get_literal
#include "SDLNumber.cc"
#undef get_literal
#undef ID
#undef C_INT
#undef SDLNumber

implementSDLType(SDLEnum,SDLEnumBase)


AsnLen
SDLEnum::pEnc(pAsnBuf& b) const {
  throw SDLCodingError("pEnc for SDLEnum not implemented");
  return 0;
}

void
SDLEnum::pDec(pAsnBuf& b){
  throw SDLCodingError("pDec for SDLEnum not implemented");
}




AsnLen
SDLEnum::bEnc(BUF_TYPE b) const
{
  AsnLen l = bEncContent(b);
  BEncDefLenTo127(b,l);
  l++;
  l += BEncTag1(b, UNIV, PRIM, ENUM_TAG_CODE);
  return l;
}

void
SDLEnum::bDec( BUF_TYPE b, AsnLen& bytesDecoded)
{
    AsnTag tagId = BDecTag1(b,bytesDecoded);
    AsnLen elmtLen;
    if (tagId != MAKE_TAG_ID(UNIV,PRIM,ENUM_TAG_CODE)) {
      TagError(MAKE_TAG_ID(UNIV,PRIM,ENUM_TAG_CODE),tagId); return;
    }
    elmtLen = BDecLen(b,bytesDecoded);
    AsnLen localBytesDecoded = 0;
    bDecContent(b,tagId,elmtLen,localBytesDecoded);
    bytesDecoded += localBytesDecoded;
}


const SDLEnum&
SDLEnum::pred()const{
  const SDLEnum *prev=0,*ptmp=0,*pmax=0;
  long pval=0,max=0;
  long tmp=0;
  long v=val();
  bool assigned=false;
  for(int i=1;get_literal(i,&ptmp,&tmp);i++){
    if(tmp<v && (!assigned || tmp>pval)){
       pval=tmp;
       prev=ptmp;
       assigned=true;
    }
    if(i==1 || (tmp>max)){
      max=tmp;
      pmax=ptmp;
    }
  }
  if(prev && pval<v)
     return *prev;
  assert(pmax);
  return *pmax;
}

// ASN.1 literals can be unordered
const SDLEnum&
SDLEnum::succ()const{
  const SDLEnum *next=0,*ptmp=0,*pmin=0;
  long nval=0,min=0;
  long tmp=0;
  long v=val();
  bool assigned=false;

  // iterate all literals
  for(int i=1;get_literal(i,&ptmp,&tmp);i++){
    if(v<tmp && (!assigned || tmp<nval)){
      nval=tmp;
      next=ptmp;
      assigned=true;
    }
    if(i==1 || (tmp<min)){
      min=tmp;
      pmin=ptmp;
    }
  }
  if(next && nval>v)
     return *next;
  assert(pmin);
  return *pmin;
}

const SDLEnum&
SDLEnum::first()const{
  const SDLEnum *pmin=0,*ptmp;
  long min=0,tmp=0;
  bool assigned=false;
  for(int i=1;get_literal(i,&ptmp,&tmp);i++)
    if(!assigned || tmp<min){
      min=tmp;
      pmin=ptmp;
      assigned=true;
    }
  //requiring support for get_literal
  assert(pmin);
  return *pmin;
}

const SDLEnum&
SDLEnum::last()const{
  const SDLEnum *pmax=0,*ptmp;
  long max=0,tmp=0;
  bool assigned=false;
  for(int i=1;get_literal(i,&ptmp,&tmp);i++)
    if(!assigned || tmp>max){
      max=tmp;
      pmax=ptmp;
      assigned=true;
    }
  //requiring support for get_literal
  assert(pmax);
  return *pmax;
}

SDLInt
SDLEnum::num()const { return val(); }


SDLTypeId
SDLEnum::sdl_type_id()const
{ return TypeId_SDLEnum; }

bool
SDLEnum::get_literal(int,const SDLEnum**,long*) const
{ return false; }
