/*******************************************************************************
*   vim:sw=2:ts=2:et
*
*   File    : SDLArrayTemplate.h
*   Author  : Ralf Schr�der
*             Humboldt University Berlin
*             Department of Computer Science / System Analysis
*   e-mail  : r.schroeder@informatik.hu-berlin.de
*   Project : @vantage platform
*   $Date: 2005-05-05 17:38:41 +0200 (Thu, 05 May 2005) $
*   $Revision: 1.2 $
*
*******************************************************************************/
#ifndef _SDLARRAYTEMPLATE_H
#define _SDLARRAYTEMPLATE_H

// in case the user did not use SDLArray.h
#include "SDLArray.h"

/** SITE template of SDL Array generator.
    The template provides the correct signatures.
    An extra file is used because Reliant CC includes
    an existing cxx file implicitly.
*/
template <typename KEY, typename VALUE>
class SDLArray : public SDLArrayBase
{
    /** A simple type name */
    typedef SDLArray<KEY,VALUE> self;

  protected:
    /** Create an elem object as SDLType*.
        This method has to be reimplemented for context parameter support.
    */
    virtual SDLType* create_elem() const { return new VALUE; }

    /** Create a key object as SDLType*.
        This method has to be reimplemented for context parameter support.
    */
    virtual SDLType* create_key() const { return new KEY; }

  public:
    /** Constructor for empty array without default value (non SDL) */
    SDLArray() {}

    /** Constructor for empty array with default value */
    SDLArray(const VALUE& val) : SDLArrayBase(val) {}

    /** Constructor for an omitted (invalid) value */
    SDLArray(const SDLNull&n) : SDLArrayBase(n) {}

    /** Copy constructor */
    SDLArray(const SDLArray<KEY,VALUE>&a) : SDLArrayBase(a) {}

    /** Assignment operator for arrays. */
    self& operator=(const SDLArray<KEY,VALUE>&a)
    { return SITE_STATIC_CAST(self&,SDLArrayBase::operator=(a)); }

    /** SDL operations */
    //@{
    /** operator Modify (SITE semantics)
        @exception SDLException for invalid values.
        The modify operation does not attend default value assignments.
        It is not possible to reduce the size of an SDL array by using
        such an assignment. This is not a contradiction to SDL but could
        be changed with a small price of efficiancy.
        Note, that this operator inserts a (default) value on
        the requested position implicitly.
    */
    VALUE& operator()(const KEY&k)
    { return SITE_STATIC_CAST(VALUE&,modify(k)); }

    /** operator Extract (SITE semantics)
        @exception SDLException for invalid values or, if no default value
                   is given, for access of unassigned fields.
    */
    const VALUE& operator[](const KEY&k)const
    { return SITE_STATIC_CAST(const VALUE&,extract(k)); }

    /** Deletes an array entry.
        It is a non SDL operation with side effects for the array argument.
        The generated code can be wrong, because in/out parameters for
        operators are not checked by the SITE design.
    */
    const SDLBool& del(const KEY&k)
    { return _del(k); }

    /** Resets the iterator state and returns the first key. */
    const KEY& firstkey() const
    { return SITE_STATIC_CAST(const KEY&,_firstkey()); }

    /** Returns the next key. If any operation except [] is used,
        then the result of nextkey() is undefined.
    */
    const KEY& nextkey() const
    { return SITE_STATIC_CAST(const KEY&,_nextkey()); }
    //@}
};

#endif
