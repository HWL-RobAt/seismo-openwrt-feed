/*******************************************************************************
*   vim:sw=2:ts=2:et
*
*   File    : predefined.h
*   Author  : Ralf Schr�der
*             Humboldt University Berlin
*             Department of Computer Science / System Analysis
*   e-mail  : r.schroeder@informatik.hu-berlin.de
*   Project : @vantage platform
*   $Date: 2005-05-05 18:46:43 +0200 (Thu, 05 May 2005) $
*   $Revision: 1.3 $
*
*******************************************************************************/
#ifndef _PREDEFINED_H
#define _PREDEFINED_H


#include "SDLBool.h"
#include "SDLBit.h"
#include "SDLInt.h"
#include "SDLChar.h"
#include "SDLCharstring.h"
#include "SDLEnum.h"
#include "SDLReal.h"
#include "SDLNullType.h"
#include "SDLBitString.h"
#include "SDLOctet.h"
#include "SDLOctetString.h"
#include "SDLSeqSet.h"
#include "SDLChoice.h"
#include "SDLArray.h"
#include "SDLAny.h"

#include "SDLString.h"
#include "SDLSetof.h"
#include "SDLArray.h"

#include "BasicEncoding.h"

#include "SDLPredefined.h"

static const char* PREDEFINED_RCSID FRWUNUSED = "$Id: predefined.h 558 2005-05-05 16:46:43Z tneumann $";

#endif

