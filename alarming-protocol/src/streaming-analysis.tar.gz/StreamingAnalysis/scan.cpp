#include "Butterworth.h"
#include "Kanamori.h"
#include "Detector.h"
#include "Energy.h"
#include "StationData.h"
#include "StationOutput.h"
#include "EventParams.h"

#include <iostream>
#include <fstream>
#include <string>
#include <sstream>
#include <utility>
#include <cmath>
#include <cstdlib>

#include <sys/stat.h>
#include <sys/types.h>

#ifdef _MSC_VER
#include <direct.h>
#endif

using namespace std;

std::string EventDate ("29.09.2004");
std::string DataDir ("rr_20040929_txt");


void  scan(StationData& s, StationOutput& o);

int main() {
#ifdef _MSC_VER
	std::string slash = "\\";
#else
	std::string slash = "/";
#endif
	std::string inDir = EventDate+slash+DataDir+slash;
	ifstream stationList ((inDir+"lista_oper_staz.txt").c_str());
	if (!stationList) {
		cerr<<"cannot open station list\n";
		return -1;
	}

	std::string file;
	std::string outRoot = "OUTPUT"+slash;
#ifdef _MSC_VER
	int ret = _mkdir(outRoot.c_str());
#else
	int ret = mkdir(outRoot.c_str(), S_IRUSR|S_IWUSR|S_IXUSR);
#endif
	if (ret) { std::perror("cannot make root dir"); std::exit(-1);}

	while (1) {
		stationList>>file;
		if (stationList.eof()) break;
		std::string inFile = inDir+file;
		// cout << "Scanning "<< inFile << endl;
		StationData station(inFile.c_str());
	
		file.assign(file.substr(0, file.find('.')));
		std::string outDir = outRoot+file;
#ifdef _MSC_VER
		int ret = _mkdir(outDir.c_str());
#else
		int ret = mkdir(outDir.c_str(), S_IRUSR|S_IWUSR|S_IXUSR);
#endif
		if (ret) { std::perror("cannot make dir"); std::exit(-1);}
		// cout << "Output directory: "<< outDir << endl;
		

		StationOutput output(outDir);
		scan(station, output);
	}
}
		
	
void  scan(StationData& s, StationOutput& o) {
	float t, e, n, z;
	BW4 E, N, Z;

        ofstream& aE = o.aE();
        ofstream& aN = o.aN();
        ofstream& aZ = o.aZ();
        ofstream& vE = o.vE();
        ofstream& vN = o.vN();
        ofstream& vZ = o.vZ();
        ofstream& dE = o.dE();
        ofstream& dN = o.dN();
        ofstream& dZ = o.dZ();
        ofstream& En  = o.En();
        ofstream& PSNR  = o.PSNR();
        ofstream& SSNR  = o.SSNR();

	const int sps = 200; // samples per second
	const int energyIntervall = sps; // 1 second
	int eN = 0;
	const float dt = 1./sps;

	float sWindow = 0.6; // seconds

	Energy energy(dt);
	float Pcutoff = 5.f;
	float Scutoff = 100.f;

    Detector dect(               
		sps,  // float sampleInterval        
		0.2, // float shortWindow
		50,  // int SLratio             
		1,   // float delay         
		6,   // int gamma
        sWindow  // sWindow
	);

	Pparams P;
	Sparams S;

	bool Pevent = false;
	float Ptime = 0.f;
	bool Sevent = false;
	float Stime = 0.f;

	while (!s.end()) {
		s.getData(t, e, n, z); // emulate data streaming: next sample from file
		e=E.filter(e*9.81);    // the test data are in g - units
		n=N.filter(n*9.81);    // IIR filtering the raw data 
		z=Z.filter(z*9.81);

        aE<<t<<'\t'<<e<<endl;  // log filtered accelerations
        aN<<t<<'\t'<<n<<endl;
        aZ<<t<<'\t'<<z<<endl;

        VD kE(dt), kN(dt), kZ(dt);  // Kanamori filter objects

        std::pair<float,float> vdE;
        std::pair<float,float> vdN;
        std::pair<float,float> vdZ;

        vdE = kE(e);
        vE<<t<<'\t'<<vdE.first<<endl;  // get v and d east/west
        dE<<t<<'\t'<<vdE.second<<endl; // and log them

        vdN = kN(n);
        vN<<t<<'\t'<<vdN.first<<endl;  // get v and d north/south
        dN<<t<<'\t'<<vdN.second<<endl; // and log them

        vdZ = kZ(z);
        vZ<<t<<'\t'<<vdZ.first<<endl;  // get v and d vertically
        dZ<<t<<'\t'<<vdZ.second<<endl; // and log them

		P.updateAVD(t, z, vdZ.first, vdZ.second);  // watch for vertical peaks
		// if (!Pevent) P.updateAVD(t, z, vdZ.first, vdZ.second);

	float SH2 = (e*e + n*n)/2; 
        float psig = dect.Psignal(z, std::sqrt(SH2));
        PSNR << psig << std::endl;
        if (psig > Pcutoff && !Pevent) { // trigger found
            Pevent = true;
            Ptime = t;
        }
	
	if (Pevent) {
        	float ssig = dect.Ssignal(std::sqrt(SH2));
                SSNR << ssig << std::endl;
                if (ssig > Scutoff && !Sevent) { // trigger found
                   Sevent = true;
                   Stime = t;
                }
 	}

	if (Pevent  && !Sevent) {
	    S.updateAVDeast    (t, e, vdE.first, vdE.second); // watch for S parameters
	    S.updateAVDnorth   (t, n, vdN.first, vdN.second);
	    S.updateAVDvertical(t, z, vdZ.first, vdZ.second);
	}

	// if (Sevent) {
		energy.sample(SH2);
		if (++eN > energyIntervall) { // cyclic reset at the callers site
		    eN=1;
	            En<<t<<'\t'<<energy.energy()<<endl;
		    energy.resetEnergy();
		}
	// }	
			
		// there should be similar cyclic reports on wave parameters at he callers site
	    // for now i have only a final report on them:
	}
	cout<<o.name()<<"\n==============================\n";
	if (Pevent) 
		cout<<"\t P event at"<<'\t'<<Ptime<<endl;
	else 
		cout<<"\t no P event detected !"<<endl;
	if (Sevent) 
		cout<<"\t S event at"<<'\t'<<Stime<<endl;
	else 
		cout<<"\t no S event detected !"<<endl;

    cout<<"\t Pam "<<P.Pam().second<<" at"<<'\t'<<P.Pam().first<<endl;
    cout<<"\t Pvm "<<P.Pvm().second<<" at"<<'\t'<<P.Pvm().first<<endl;
    cout<<"\t Pdm "<<P.Pdm().second<<" at"<<'\t'<<P.Pdm().first<<endl;

    cout<<"\t PGAm "<<S.PGAm().second<<" at"<<'\t'<<S.PGAm().first<<endl;
    cout<<"\t PGAn "<<S.PGAn().second<<" at"<<'\t'<<S.PGAn().first<<endl;
    cout<<"\t PGAe "<<S.PGAe().second<<" at"<<'\t'<<S.PGAe().first<<endl;
}
	
